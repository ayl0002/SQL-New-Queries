Set NoCount On
--Roll Ins--
select final.*, mca_percent + [projected accrual] as 'Next Month MCA', mca_percent + [projected accrual] + [projected accrual] + .01 as '2 Month MCA',
[Tag_2_Val], [Group], [Incurable Flag] into   #RollIn1
 from 
(select final.*, round([Accrual]/current_total_upb,3) as 'Projected Accrual' 
 from 
(select base.*, b.[mth_srvc_fee_amt], ROUND(CURRENT_TOTAL_UPB * CURRENT_INTEREST_RATE /12,2)+ROUND(CURRENT_TOTAL_UPB * MIP_RATE /12,2)+[MTH_SRVC_FEE_AMT]  as 'Accrual'

 from 
(select loan_nbr, loan_key, mca_percent, current_total_upb, current_interest_rate, mip_rate, status_code from Reverse_DW.[dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW]) base

  left join
   
(select loan_key, [MTH_SRVC_FEE_AMT] from Reverse_DW.[dbo].[RVRS_LOAN_BAL] where curr_ind = 'Y') b on base.loan_key=b.loan_key) final
where mca_percent > 0 and mip_rate > 0 and current_interest_rate > 0) final
left join
(select distinct [Loan Number] as loan_nbr,[HUD Assigned Loans Tag2] as [TAG_2_VAL]
                           ,[Group] 
                           ,[Incurable Flag] 
                     from RM_DMART01..dm_hud_dim(nolock) 
                     where curr_ind='y'
              ) hld on cast(final.loan_nbr as varchar)=hld.loan_nbr


--BASE--
SELECT D.Loan_Nbr,D.[MCA_PERCENT],D.Property_Type,[Next Month MCA],[2 Month MCA]
,CASE 
WHEN D.[MCA_PERCENT] >= 97.5 THEN CAST(GETDATE() AS DATE)
WHEN [Next Month MCA] >= 97.5 THEN CAST(DATEADD(MM,1,GETDATE()) AS DATE)
WHEN [2 Month MCA] >= 97.5 THEN CAST(DATEADD(MM,2,GETDATE()) AS DATE)
ELSE NULL
END AS 'Roll_In'

INTO #BASE
FROM Reverse_DW.[dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] D
LEFT JOIN (SELECT * FROM Reverse_DW.Dbo.HUD_ASGN_Loans WHERE Curr_IND IN ('Y')) A
ON CAST(A.[Loan_Nbr] AS VARCHAR) = CAST(D.LOAN_NBR AS VARCHAR)
LEFT JOIN (SELECT * FROM Reverse_DW.Dbo.HUD_ASGN_HUD_STS WHERE Curr_IND IN ('Y')) B
ON CAST(A.[Loan_Nbr] AS VARCHAR) = CAST(B.[Loan_Nbr] AS VARCHAR)
LEFT JOIN #RollIn1 E
ON CAST(A.[Loan_Nbr] AS VARCHAR) = CAST(E.[Loan_Nbr] AS VARCHAR)

WHERE (D.[MCA_PERCENT] >= 97.5 OR [Next Month MCA] >= 97.5 OR [2 Month MCA] >= 97.5) AND D.[LOAN_STATUS] IN ('Active') 
AND B.[HUD_STS_DESC] NOT IN ('Pkg Submitted to HUD','Resubmitted to HUD','Rebuttal to HUD','HUD Approved','HUD Approval')
AND A.[Tag_2_Val] IS NULL AND A.[INCRBL_FLG_DESC] IN ('0')
AND ISNULL(A.[GRP_DESC],'No Group') NOT IN ('Grp 5 BofA GNMAs')

/*
SELECT Loan_Nbr,MAX(BUS_PROC_DT) AS 'BUS_PROC_DT'
INTO #MAX
FROM [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_SWBC_INS_RET]
GROUP BY Loan_Nbr

--SWBC MAX--
SELECT CAST(A.Loan_NBR AS INT) AS 'Loan_Number',A.Loan_Nbr,A.[CVR_TYPE],A.PLCY_NBR,	A.PLCY_EFF_DT,	A.PLCY_EXPR_DT,	A.PLCY_TERM,	A.AGNT_CD,	A.AGNT_NM,	A.AGNT_ADDR1,	A.AGNT_ADDR2,	A.AGNT_CITY,	A.AGNT_ST,	A.AGNT_ZIP,	A.CMPNY_NM,A.BUS_PROC_DT
INTO #MAXSWBC
FROM [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_SWBC_INS_RET] A
LEFT JOIN #MAX B 
ON B.Loan_Nbr = A.Loan_Nbr
WHERE A.BUS_PROC_DT = B.Bus_Proc_DT --AND CVR_TYPE IN ('F','W','1','G') 
*/

--MAX SWBC--
SELECT CAST(A.Loan_NBR AS INT) AS 'Loan_Number',A.Loan_Nbr,A.[CVR_TYPE],A.PLCY_NBR,	A.PLCY_EFF_DT,	A.PLCY_EXPR_DT,	A.PLCY_TERM,	A.AGNT_CD,	A.AGNT_NM,	A.AGNT_ADDR1,	A.AGNT_ADDR2,	A.AGNT_CITY,	A.AGNT_ST,	A.AGNT_ZIP,	ISNULL(A.CMPNY_NM,'No_Cmpny_Name') AS 'CMPNY_NM',A.BUS_PROC_DT
INTO #MAXSWBC
FROM Reverse_DW.[dbo].[TP_SWBC_INS_RET] A
LEFT JOIN (SELECT Loan_Nbr AS 'Loan_NbrMax',MAX([Bus_Proc_DT]) AS 'Bus_Proc_DTMAX' FROM [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_SWBC_INS_RET] GROUP BY Loan_Nbr) B
ON B.Loan_NbrMAx = A.Loan_Nbr
WHERE A.BUS_PROC_DT = B.Bus_Proc_DTMAX --AND CVR_TYPE IN ('F','W','1','G') 



--MP Scrub--
SELECT [Loan_Nbr],'HOA_Flag' AS 'HOA_Flag'
INTO #MP
FROM Reverse_DW.Dbo.HUD_ASGN_EXCP_EDW
WHERE [Doc_Desc] IN ('HOA') AND ISNULL([Excp_STS_DESC],'NotStarted') NOT IN ('Not Valid','Incurable') AND Curr_IND IN ('Y')

--FPI Scrub--
SELECT Loan_Number,Loan_Nbr,'FPI' AS 'FPI'--,[CVR_TYPE] AS 'FPI_CVR_TYPE',
/*CASE
		WHEN [CVR_TYPE] = 'F' THEN 'FPI - Fire(Hazard)'
        WHEN [CVR_TYPE] = 'W' THEN 'FPI - Flood'
        WHEN [CVR_TYPE] = 'A' THEN 'FPI - Wind'
        WHEN [CVR_TYPE] = 'G' THEN 'FPI - Flood Gap'
        WHEN [CVR_TYPE] = 'L' THEN 'FPI - Liability'
        WHEN [CVR_TYPE] = 'E' THEN 'FPI - Equipment'
        WHEN [CVR_TYPE] = 'Q' THEN 'FPI - Quake'
        WHEN [CVR_TYPE] = '1' THEN 'FPI - Condo'
        WHEN [CVR_TYPE] = '3' THEN 'FPI - Condo Flood Gap'
        WHEN [CVR_TYPE] = '4' THEN 'FPI - Condo w/Wind Supp'
END AS 'FPI_Type'*/
INTO #FPI
FROM #MAXSWBC 
WHERE CMPNY_NM IN ('FP POL')

--Insurance Exception Scrub--
SELECT A.[Loan_Nbr],
CASE 
	WHEN FPI.[Doc_Desc] IS NULL THEN 'No FPI Excp'
	ELSE 'FPI - ' + FPI.[Doc_Desc] 
END AS 'FPI_Excp',
CASE 
	WHEN Haz.[Doc_Desc] IS NULL THEN 'No Haz Excp' 
	ELSE 'Open Excp - ' + Haz.[Doc_Desc] 
END AS 'Haz_Excp'
,CASE
	WHEN MP.[Doc_Desc] IS NULL THEN 'No MP Excp'
	ELSE 'Open Excp - ' + MP.[Doc_Desc] 
	END AS 'MP_Excp'
,CASE
	WHEN FLD.[Doc_Desc] IS NULL THEN 'No Flood Excp'
	ELSE 'Open Excp - ' + FLD.[Doc_Desc]
END AS 'Flood_Excp'
INTO #EXCP
FROM #BASE A
LEFT JOIN (SELECT Loan_Nbr,[Doc_Desc]FROM Reverse_DW.Dbo.HUD_ASGN_EXCP_EDW WHERE [ISSU_Desc] IN ('Forced Placed Insurance') AND [Excp_Sts_Desc] NOT IN ('Incurable','Not Valid','Resolved') AND CURR_IND IN ('Y')) FPI
ON CAST(A.Loan_Nbr AS VARCHAR) = CAST(FPI.Loan_NBR AS VARCHAR)
LEFT JOIN (SELECT Loan_Nbr,[Doc_Desc]FROM Reverse_DW.Dbo.HUD_ASGN_EXCP_EDW WHERE [DOC_DESC] IN ('Condo Insurance','Hazard Insurance') AND [ISSU_DESC] NOT IN ('Forced Placed Insurance') AND [Excp_Sts_Desc] NOT IN ('Incurable','Not Valid','Resolved') AND CURR_IND IN ('Y')) Haz
ON CAST(A.Loan_Nbr AS VARCHAR) = CAST(HAZ.Loan_NBR AS VARCHAR)
LEFT JOIN (SELECT Loan_Nbr,[Doc_Desc] FROM Reverse_DW.Dbo.HUD_ASGN_EXCP_EDW WHERE [DOC_DESC] IN ('Master Policy') AND [ISSU_DESC] NOT IN ('Forced Placed Insurance') AND [Excp_Sts_Desc] NOT IN ('Incurable','Not Valid','Resolved') AND CURR_IND IN ('Y')) MP
ON CAST(A.Loan_Nbr AS VARCHAR) = CAST(MP.Loan_NBR AS VARCHAR)
LEFT JOIN (SELECT Loan_Nbr,[Doc_Desc] FROM Reverse_DW.Dbo.HUD_ASGN_EXCP_EDW WHERE [DOC_DESC] IN ('Flood Insurance') AND [ISSU_DESC] NOT IN ('Forced Placed Insurance') AND [Excp_Sts_Desc] NOT IN ('Incurable','Not Valid','Resolved') AND CURR_IND IN ('Y')) FLD
ON CAST(A.Loan_Nbr AS VARCHAR) = CAST(FLD.Loan_NBR AS VARCHAR)

--Final--
SELECT DISTINCT A.Loan_Nbr,
GETDATE() AS 'Last Refreshed',B.CVR_TYPE,Property_Type
,CASE
		--WHEN D.FPI IS NOT NULL THEN 'FPI - ' + D.Policy_Type 

		WHEN B.CVR_TYPE IN ('F') AND HOA_Flag IS NOT NULL AND Property_Type IN ('Condo') AND CMPNY_NM NOT IN ('FP POL') THEN 'Master Policy'
		WHEN B.CVR_TYPE IN ('F') AND HOA_Flag IS NOT NULL AND CMPNY_NM NOT IN ('FP POL') THEN 'Possible Master Policy'
		WHEN B.[CVR_TYPE] = 'F' AND CMPNY_NM NOT IN ('FP POL') THEN 'Fire(Hazard)'
        WHEN B.[CVR_TYPE] = 'W' AND CMPNY_NM NOT IN ('FP POL') THEN 'Flood'
        WHEN B.[CVR_TYPE] = 'A' AND CMPNY_NM NOT IN ('FP POL') THEN 'Wind'
        WHEN B.[CVR_TYPE] = 'G' AND CMPNY_NM NOT IN ('FP POL') THEN 'Flood Gap'
        WHEN B.[CVR_TYPE] = 'L' AND CMPNY_NM NOT IN ('FP POL') THEN 'Liability'
        WHEN B.[CVR_TYPE] = 'E' AND CMPNY_NM NOT IN ('FP POL') THEN 'Equipment'
        WHEN B.[CVR_TYPE] = 'Q' AND CMPNY_NM NOT IN ('FP POL') THEN 'Quake'
        WHEN B.[CVR_TYPE] = '1' AND CMPNY_NM NOT IN ('FP POL') THEN 'Condo'
        WHEN B.[CVR_TYPE] = '3' AND CMPNY_NM NOT IN ('FP POL') THEN 'Condo Flood Gap'
        WHEN B.[CVR_TYPE] = '4' AND CMPNY_NM NOT IN ('FP POL') THEN 'Condo w/Wind Supp'
		WHEN B.CVR_TYPE IN ('F') AND HOA_Flag IS NOT NULL AND Property_Type IN ('Condo') AND CMPNY_NM IN ('FP POL') THEN 'FPI - Master Policy'
		WHEN B.CVR_TYPE IN ('F') AND HOA_Flag IS NOT NULL AND CMPNY_NM IN ('FP POL') THEN 'FPI - Possible Master Policy'
		WHEN [CVR_TYPE] = 'F' AND CMPNY_NM IN ('FP POL') THEN 'FPI - Fire(Hazard)'
        WHEN [CVR_TYPE] = 'W' AND CMPNY_NM IN ('FP POL') THEN 'FPI - Flood'
        WHEN [CVR_TYPE] = 'A' AND CMPNY_NM IN ('FP POL') THEN 'FPI - Wind'
        WHEN [CVR_TYPE] = 'G' AND CMPNY_NM IN ('FP POL') THEN 'FPI - Flood Gap'
        WHEN [CVR_TYPE] = 'L' AND CMPNY_NM IN ('FP POL') THEN 'FPI - Liability'
        WHEN [CVR_TYPE] = 'E' AND CMPNY_NM IN ('FP POL') THEN 'FPI - Equipment'
        WHEN [CVR_TYPE] = 'Q' AND CMPNY_NM IN ('FP POL') THEN 'FPI - Quake'
        WHEN [CVR_TYPE] = '1' AND CMPNY_NM IN ('FP POL') THEN 'FPI - Condo'
        WHEN [CVR_TYPE] = '3' AND CMPNY_NM IN ('FP POL') THEN 'FPI - Condo Flood Gap'
        WHEN [CVR_TYPE] = '4' AND CMPNY_NM IN ('FP POL') THEN 'FPI - Condo w/Wind Supp'
		WHEN B.CMPNY_NM IN ('FP POL') THEN 'FPI - ' + B.[CVR_TYPE]
		WHEN CMPNY_NM NOT IN ('FP POL') THEN 'NOT FP POL'	
ELSE 'Error'
END AS 'Policy Type'
,CASE	
		WHEN D.FPI IS NOT NULL THEN FPI_Excp
		WHEN B.CVR_TYPE IN ('F') AND HOA_Flag IS NOT NULL AND Property_Type IN ('Condo') THEN MP_Excp
		WHEN B.CVR_TYPE IN ('F') AND HOA_Flag IS NOT NULL THEN MP_Excp
		WHEN B.[CVR_TYPE] = 'F' THEN Haz_Excp
        WHEN B.[CVR_TYPE] = 'W' THEN Flood_Excp
        WHEN B.[CVR_TYPE] = '1' THEN Haz_Excp
		ELSE 'No Exception for Insurance Type'
END AS 'ExcpFlag'
,ISNULL(D.FPI,'No FPI') AS 'FPI Flag'
/*
,CASE
		WHEN [CVR_TYPE] = 'F' AND CMPNY_NM IN ('FP POL') THEN 'FPI - Fire(Hazard)'
        WHEN [CVR_TYPE] = 'W' AND CMPNY_NM IN ('FP POL') THEN 'FPI - Flood'
        WHEN [CVR_TYPE] = 'A' AND CMPNY_NM IN ('FP POL') THEN 'FPI - Wind'
        WHEN [CVR_TYPE] = 'G' AND CMPNY_NM IN ('FP POL') THEN 'FPI - Flood Gap'
        WHEN [CVR_TYPE] = 'L' AND CMPNY_NM IN ('FP POL') THEN 'FPI - Liability'
        WHEN [CVR_TYPE] = 'E' AND CMPNY_NM IN ('FP POL') THEN 'FPI - Equipment'
        WHEN [CVR_TYPE] = 'Q' AND CMPNY_NM IN ('FP POL') THEN 'FPI - Quake'
        WHEN [CVR_TYPE] = '1' AND CMPNY_NM IN ('FP POL') THEN 'FPI - Condo'
        WHEN [CVR_TYPE] = '3' AND CMPNY_NM IN ('FP POL') THEN 'FPI - Condo Flood Gap'
        WHEN [CVR_TYPE] = '4' AND CMPNY_NM IN ('FP POL') THEN 'FPI - Condo w/Wind Supp'
		WHEN CMPNY_NM NOT IN ('FP POL') THEN 'NOT FP POL'
END AS 'FPI_Type'
*/
,CAST(DATEPART(mm,Roll_In) AS VARCHAR) +'/'+ CAST(DATEPART(YYYY,Roll_In)AS VARCHAR) AS 'Roll-In Month'
,CAST([MCA_PERCENT] AS FLOAT(2)) AS 'Curr_MCA'--,
,CASE 
	WHEN [MCA_PERCENT] < 97.5 THEN '< 97.5'
	WHEN [MCA_PERCENT] >= 100 THEN '>= 100.00'
	WHEN [MCA_PERCENT] >= 97.5 THEN '>= 97.5'
END AS 'MC_Flag'
,CAST([Next Month MCA] AS FLOAT(2)) AS 'Next Month MCA',CAST([2 Month MCA] AS FLOAT(2)) AS '2 Month MCA'
,PLCY_NBR,	PLCY_EFF_DT,	PLCY_EXPR_DT
,CASE 
		--WHEN D.FPI IS NOT NULL THEN 'Forced Placed Insurance for ' + D.[Policy_Type]
		--WHEN CMPNY_NM IN ('FP POL') THEN 'Forced Placed Insurance'
		WHEN CAST(GETDATE() AS DATE) >= CAST(PLCY_EXPR_DT AS DATE) THEN 'Policy Expired'
		WHEN DATEPART(mm,PLCY_EXPR_DT) = DATEPART(mm,Roll_In) AND DATEPART(YYYY,PLCY_EXPR_DT) = DATEPART(YYYY,Roll_In) THEN 'Expires During Roll-In Month'
		WHEN DATEDIFF(DAY,CAST(GETDATE() AS DATE),CAST(PLCY_EXPR_DT AS DATE)) <= 15 THEN 'Policy Expires <= 15 Days'
		WHEN DATEDIFF(DAY,CAST(GETDATE() AS DATE),CAST(PLCY_EXPR_DT AS DATE)) <= 30 THEN 'Policy Expires <= 30 Days'
		WHEN DATEDIFF(DAY,CAST(GETDATE() AS DATE),CAST(PLCY_EXPR_DT AS DATE)) <= 45 THEN 'Policy Expires <= 45 Days'
		WHEN CAST(PLCY_EXPR_DT AS DATE) >= CAST(GETDATE() AS DATE) THEN 'Insured'
ELSE 'Error'
END AS 'Expire Flag'
,PLCY_TERM,	AGNT_CD,	AGNT_NM,	AGNT_ADDR1,	AGNT_ADDR2,	AGNT_CITY,	AGNT_ST,	AGNT_ZIP,	CMPNY_NM
FROM #BASE A
LEFT JOIN #MAXSWBC B
ON A.LOAN_NBR = B.Loan_Number
LEFT JOIN #MP C
ON A.LOAN_NBR = C.[Loan_Nbr]
LEFT JOIN #FPI D
ON A.LOAN_NBR = D.Loan_Number  
LEFT JOIN #EXCP E
ON CAST(A.Loan_Nbr AS VARCHAR) = CAST(E.Loan_Nbr AS VARCHAR)


ORDER BY A.Loan_Nbr,CVR_TYPE

DROP TABLE #FPI,#MAXSWBC,#BASE,#RollIn1,#MP,#EXCP
