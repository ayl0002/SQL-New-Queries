SELECT A.[Loan Number]
,CAST(A.[MCA %] AS FLOAT(2)) AS 'MCA %',
CASE
WHEN A.[MCA %] BETWEEN 90 AND 92.49 THEN '90 < 92.5'
WHEN A.[MCA %] BETWEEN 92.5 AND 94.99 THEN '92.5 < 95'
WHEN A.[MCA %] BETWEEN 95 AND 97.49 THEN '95 < 97.5'
WHEN A.[MCA %] BETWEEN 97.5 AND 99.99 THEN '97.5 < 100'
WHEN A.[MCA %] >= 100 THEN '>= 100'
ELSE '< 100'
END AS 'MCA Flag'
,A.[Loan Status],A.[Stage],A.[Tag 2]
,A.[Incurable Flag]
,CASE 
WHEN I.[OpenCurative] = 1 THEN CAST(CAST(I.[OpenCurative] AS INT) AS NVARCHAR(MAX)) + ' Curative Exception' 
ELSE CAST(CAST(I.[OpenCurative] AS INT) AS NVARCHAR(MAX)) + ' Curative Exceptions' 
END AS 'Open Curative'
,CAST(I.[OpenHACG] AS INT) AS 'Open HACG',CAST(I.[Open Exceptions] AS INT) AS 'Open Exceptions'
,[Initial Review Status],[Initial Review Start Date],A.[Initial Review End Date]
,[HUD Status Start Date],[Initial Review Collateral Start Date],[Initial Review Collateral End Date],[Initial Review Collateral Stage Update By]
,[Initial Review Compliance Start Date],[Initial Review Compliance End Date],[Initial Review Compliance Stage Update By]
,[Initial Review Servicing Start Date],[Initial Review Servicing End Date],[Initial Review Servicing Stage Update By]
FROM SharepointData.Dbo.HUDAssignLoans A
LEFT JOIN SharepointData.[dbo].[HUDAssignInitialReview] B	
ON A.[Loan Number] = B.[Loan Number]
LEFT JOIN SharepointData.Dbo.HUDAssignHUDStatus C
ON A.[Loan Number] = C.[Loan Number]
LEFT JOIN (SELECT LOAN_NBR,DT_SBMT_TO_HUD FROM [VRSQLRODS\RODS_PROD].Reverse_DW.Dbo.HUD_ASSGN_DT_SBMT_RESBMT WHERE CURR_IND IN ('Y')) D
On A.[Loan Number] = D.[Loan_Nbr]
LEFT JOIN SharepointData.[dbo].[HUDAssignInitialReviewServicing] E
ON A.[Loan Number] = E.[Loan Number]
LEFT JOIN SharepointData.[dbo].[HUDAssignInitialReviewCollateral] F
ON A.[Loan Number] = F.[Loan Number]
LEFT JOIN SharepointData.[dbo].[HUDAssignInitialReviewCompliance] G
ON A.[Loan Number] = g.[Loan Number]
LEFT JOIN SharepointData.Dbo.[HUDAssignDocPooling] H
ON A.[Loan Number] = H.[Loan Number]
Left JOIN SharepointData.Dbo.HUDAssignLoanExceptionTotals I
ON A.[Loan Number] = I.[Loan Number]
WHERE A.[MCA %] >= 90.0 AND A.[Loan Status] IN ('Active') AND A.[TAG 2] IS NULL AND A.[Incurable Flag] IN ('0') AND (A.[GROUP] NOT IN ('Grp 5 BofA GNMAs') OR A.[GROUP] IS NULL) AND ISNULL(A.[Stage],'No Stage') IN ('Initial Review','No Stage')
ORDER BY [MCA %] DESC
