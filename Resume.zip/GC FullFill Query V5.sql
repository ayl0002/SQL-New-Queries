SET NoCount ON
SET ANSI_WARNINGS OFF
SELECT B.*,A.[MCA %],A.[Loan Status]
INTO #BASE
FROM SharepointData.Dbo.HUDAssignLoans A
LEFT JOIN SharepointData.Dbo.HUDAssignExceptions B
ON A.[Loan Number] = B.[Loan Number]

WHERE A.[Loan Status] NOT IN ('Called Due: Death','Refer for FCL: Death') AND (( B.[Sent for Gift Card Processing] IS NULL) OR (B.[Document] IN ('HOA') AND B.[Sent for Gift Card Processing] IS NOT NULL AND [Ledger Sent for Gift Card Processing] IS NULL))
AND ([Gift Card Letter Sent] IS NOT NULL OR ([DOCUMENT] IN ('OCC','HOA') AND [Non GC Letter Sent 1] IS NOT NULL) OR ([DOCUMENT] IN ('HOA') AND [Ledger Letter Sent 1] IS NOT NULL)) 
AND [Document] IN ('Current Occ Cert','HOA','Death Cert HACG','Trust - HACG','Death Cert','Trust','Proof of Repair')
--Exception Scrub--
SELECT A.[Loan Number],A.[MCA %],A.[Loan Status],[Exception ID],[Document],[Issue],[Exception Status],[Exception Status Date]
,CASE
	WHEN [Document] IN ('Current OCC Cert') AND [Non GC Letter Sent 1] IS NOT NULL AND [Gift Card Letter Sent] IS NULL
	THEN (SELECT MAX(V) FROM (VALUES ([Non GC Letter Sent 1]),	([Non GC Letter Sent 2]),	([Non GC Letter Sent 3])) AS VALUE (V)) 
	WHEN [Document] IN ('HOA') AND [Non GC Letter Sent 1] IS NOT NULL AND [Gift Card Letter Sent] IS NULL AND [Ledger Letter Sent 1] IS NULL
	THEN (SELECT MAX(V) FROM (VALUES ([Non GC Letter Sent 1]),	([Non GC Letter Sent 2]),	([Non GC Letter Sent 3])) AS VALUE (V))
	END AS 'Max_NonGC'
,CASE 
	WHEN [Document] IN ('HOA')
	THEN (SELECT MAX(V) FROM (VALUES ([Gift Card Letter Sent]),([Gift Card Letter Sent 2]),	([Gift Card Letter Sent 3]),([Ledger Letter Sent 1]),	([Ledger Letter Sent 2]),	([Ledger Letter Sent 3])) AS VALUE (V)) 
	ELSE (SELECT MAX(V) FROM (VALUES ([Gift Card Letter Sent]),([Gift Card Letter Sent 2]),	([Gift Card Letter Sent 3])) AS VALUE (V)) 
END AS 'MAX_GC'
,CASE WHEN [Document] IN ('HOA') THEN (SELECT MAX(V) FROM (VALUES ([Sent for Gift Card Processing]),([Ledger Sent for Gift Card Processing])) AS VALUE (V)) 
ELSE [Sent for Gift Card Processing]
END AS 'Max_Fulfill'
,CAST([Gift Card Letter Sent] AS DATE) AS 'Gift Card Letter Sent',	CAST([Gift Card Letter Sent 2] AS DATE) AS 'Gift Card Letter Sent 2',	CAST([Gift Card Letter Sent 3] AS DATE) AS 'Gift Card Letter Sent 3',	CAST([Sent For Gift Card Processing] AS DATE) AS 'Sent For Gift Card Processing',	CAST([Document Returned] AS DATE) AS 'Document Returned',	CAST([Ledger Letter Document Returned] AS DATE) AS 'Ledger Letter Document Returned',	CAST([Ledger Letter Sent 1] AS DATE) AS 'Ledger Letter Sent 1',	CAST([Ledger Letter Sent 2] AS DATE) AS 'Ledger Letter Sent 2',	CAST([Ledger Letter Sent 3] AS DATE) AS 'Ledger Letter Sent 3',	CAST([Ledger Sent for Gift Card Processing] AS DATE) AS 'Ledger Sent for Gift Card Processing',	CAST([Non GC Letter Sent 1] AS DATE) AS 'Non GC Letter Sent 1',	CAST([Non GC Letter Sent 2] AS DATE) AS 'Non GC Letter Sent 2',	CAST([Non GC Letter Sent 3] AS DATE) AS 'Non GC Letter Sent 3',	CAST([Non GC Letter Document Returned] AS DATE) AS 'Non GC Letter Document Returned'
INTO #Exceptions
FROM #BASE A
WHERE ([Exception Status] IN ('Resolved','Resolved by ML') AND (CAST([Exception Status Date] AS DATE) >= CAST('12/1/2019' AS DATE))
OR ([Document] IN ('HOA') AND [ISSUE] NOT IN ('Authorization Received - Invalid','Missing','Missing Contact Info','Missing Contact Info','BCR- Authorization required')))
AND (CAST([Exception Status Date] AS DATE) >= CAST('12/1/2019' AS DATE))

--GC Scrub--
SELECT A.[Exception ID],A.[Loan Number],CAST(GETDATE() AS DATE) AS 'GC Order Date',[Document]
,CAST(Max_NonGC AS DATE) AS 'Max_NonGC'
,CAST(MAX_GC AS DATE) AS 'MAX_GC'
,CAST(Max_Fulfill AS DATE) AS 'Max_Fulfill'
--,CAST(B.MaxClose AS DATE) AS 'MaxClose'
,CAST([Non GC Letter Document Returned] AS DATE) AS 'Non GC Letter Returned'
,CASE
WHEN [Document] IN ('HOA') AND DATEDIFF(DAY,CAST(Max_Fulfill AS DATE),CAST(GETDATE() AS DATE)) <= 60 THEN 'DoNotSend'
WHEN [Document] IN ('OCC') AND MAX_GC IS NULL AND [Non GC Letter Document Returned] IS NULL THEN 'Non-GC'
WHEN [Document] IN ('HOA') AND MAX_GC IS NULL AND [Non GC Letter Document Returned] IS NULL THEN 'Non-GC'
WHEN [Document] IN ('OCC') AND MAX_GC IS NULL AND [Non GC Letter Document Returned] IS NOT NULL THEN 'DoNotSend'
WHEN [Document] IN ('HOA') AND MAX_GC IS NULL AND [Non GC Letter Document Returned] IS NOT NULL THEN 'DoNotSend'
WHEN [Non GC Letter Document Returned] IS NOT NULL AND [MAX_GC] IS NULL THEN 'DoNotSend'
WHEN CAST(ISNULL([MAX_GC],'1/1/1900') AS DATE) <= CAST(ISNULL(Max_Fulfill,'1/1/1900') AS DATE) THEN 'DoNotSend'
WHEN [Document] IN ('HOA') and [Sent for Gift Card Processing] IS NOT NULL AND [Ledger Letter Sent 1] IS NOT NULL AND [Exception Status] NOT IN ('Resolved','Resolved by ML')THEN 'DoNotSend'
WHEN [Document] IN ('HOA') and [Sent for Gift Card Processing] IS NULL THEN 'GC'
WHEN [Document] IN ('HOA') and [Sent for Gift Card Processing] IS NOT NULL AND [MAX_GC] IS NOT NULL AND CAST([MAX_GC] AS DATE) >= CAST(ISNULL(Max_Fulfill,'1/1/1900') AS DATE) AND [Exception Status] IN ('Resolved','Resolved by ML')  THEN 'Ledger'
--WHEN [Document] IN ('HOA') AND [MAX_GC] IS NOT NULL AND CAST([MAX_GC] AS DATE) >= CAST(ISNULL([Non GC Letter Document Returned],'1/1/1900') AS DATE) AND [Sent for Gift Card Processing] IS NULL THEN 'GC'
WHEN [Document] IN ('HOA') and [Sent for Gift Card Processing] IS NOT NULL AND [Ledger Letter Sent 1] IS NULL THEN 'DoNotSend'
WHEN [Document] NOT IN ('HOA') THEN 'GC'

ELSE 'Error'
END AS 'Send Flag' 
,[Sent For Gift Card Processing]
,[Ledger Sent for Gift Card Processing]
,DATEDIFF(Day,Cast([Exception Status Date] AS Date),CAST(GETDATE() AS DATE)) AS 'Exception Update Aging'
,[Exception Status Date],[Exception Status],[Issue]
,CAST([Gift Card Letter Sent] AS DATE) AS 'Gift Card Letter Sent',	CAST([Gift Card Letter Sent 2] AS DATE) AS 'Gift Card Letter Sent 2',	CAST([Gift Card Letter Sent 3] AS DATE) AS 'Gift Card Letter Sent 3',	CAST([Document Returned] AS DATE) AS 'Document Returned',	CAST([Ledger Letter Document Returned] AS DATE) AS 'Ledger Letter Document Returned',	CAST([Ledger Letter Sent 1] AS DATE) AS 'Ledger Letter Sent 1',	CAST([Ledger Letter Sent 2] AS DATE) AS 'Ledger Letter Sent 2',	CAST([Ledger Letter Sent 3] AS DATE) AS 'Ledger Letter Sent 3',	CAST([Non GC Letter Sent 1] AS DATE) AS 'Non GC Letter Sent 1',	CAST([Non GC Letter Sent 2] AS DATE) AS 'Non GC Letter Sent 2',	CAST([Non GC Letter Sent 3] AS DATE) AS 'Non GC Letter Sent 3',	CAST([Non GC Letter Document Returned] AS DATE) AS 'Non GC Letter Document Returned'
,GETDATE() AS 'Refreshed'
INTO #FINAL
FROM #Exceptions A
--LEFT JOIN (Select A.[Exception ID],MAX(A.[Exception Status Date]) AS 'MaxClose' FROM SharepointData.Dbo.HUDAssignExceptions A  WHERE A.[Exception Status] IN ('CLOSED','RESOLVED','NOT VALID','INCURABLE','CLOSED WITH VENDOR') GROUP BY A.[Exception ID]) B
--ON A.[Exception ID] = B.[Exception ID]
--
--SELECT * FROM #Final

--Manifest--
SELECT DISTINCT MAX_GC,Max_Fulfill,Max_NonGC,CMT.LOAN_NBR	
	,CASE WHEN [Send Flag] IN ('GC') THEN [Document]
			WHEN [Send Flag] IN ('Ledger') THEN [Document] + '-' + [Send Flag] 
			WHEN [Send Flag] IN ('Non-GC') THEN [Send Flag] + '-' + [Document]
			ELSE 'Error'
		END AS 'Voucher Type'			
	,'50' AS 'Amount'
	/*,CASE WHEN CAST(CMT.BORROWER_DATE_OF_DEATH AS VARCHAR) NOT IN ('NULL') 
		THEN 'Estate of ' + CMT.BORROWER_FIRST_NAME + ' ' + CMT.BORROWER_LAST_NAME
	ELSE CMT.BORROWER_FIRST_NAME + ' ' + CMT.BORROWER_LAST_NAME
	END AS "Borr1"
	,CASE WHEN CAST(CMT.COBORROWER_DATE_OF_DEATH as varchar) NOT IN ('NULL')
		THEN 'Estate of ' + CMT.COBORROWER_FIRST_NAME + ' ' + CMT.COBORROWER_LAST_NAME
	ELSE CMT.COBORROWER_FIRST_NAME + ' ' + CMT.COBORROWER_LAST_NAME
	END AS "Borr2"*/
	,CASE WHEN [Borrower Name] LIKE '%Estate of%'
		THEN [CoBorrower Name]
	ELSE [Borrower Name]	
	END AS 'Addressed to'

	,' ' AS 'Carrier Message'
	,' 'AS Company
	,CMT.BORROWER_MAIL_ADDRESS
	,' ' AS 'Address 2'
	,CMT.BORROWER_MAIL_CITY
	,CMT.BORROWER_MAIL_STATE
	,CASE WHEN LEN(CMT.BORROWER_MAIL_ZIP_CODE) > 5
		THEN SUBSTRING(BORROWER_MAIL_ZIP_CODE, 1,5)+'-'+SUBSTRING(borrower_mail_zip_code,6,4) 
	ELSE CAST(CMT.BORROWER_MAIL_ZIP_CODE AS NVARCHAR)
	END AS "BORROWER_MAIL_ZIP_CODE"
	,CAST(GETDATE() AS DATE) AS 'Order Date'
	,[Send Flag]
	,[Document] AS 'Document2'
	,[Exception ID]
	,GETDATE() AS 'Refreshed'
	
FROM TACT_REV.dbo.champbase CMT
LEFT JOIN #FINAL B
ON CMT.Loan_Nbr = B.[Loan Number]

WHERE [Send Flag] NOT IN ('DoNotSend')

ORDER BY [Send Flag],[Document2] 
DROP TABLE #BASE,#Exceptions,#Final