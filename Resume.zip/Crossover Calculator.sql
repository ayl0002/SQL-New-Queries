Select [Loan Number],Cast(UPB AS INT) AS 'UPB',Cast((Cast([Original Loan Amount] AS INT)/1.5) AS INT) AS 'MCA',[MCA %]
,Cast((Cast(UPB AS INT)-(Cast([Original Loan Amount] AS INT)/1.5)) AS INT) AS 'CrossOver Amount'
,Cast(((Cast(UPB AS INT)/(Cast([Original Loan Amount] AS INT)/1.5))*100) AS varchar) + '%' AS 'Calc MCA'
FROM SharepointData.DBO.HUDAssignLoans
WHERE [Loan Number] in ('2641394')