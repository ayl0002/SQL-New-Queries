SELECT
E.[Loan Number]
,A.[Loan Status]
,A.[Tag 2]
,A.[Incurable Flag]
,c.[HUD Status]
,a.[MCA %]
 ,case 
	when a.[MCA %] < '95' then '0 < 94.99'	
	when a.[MCA %] between '95' and '95.99' then '95.0 < 95.99'
	when a.[MCA %] between '96' and '97.49' then '96.0 < 97.49'
	when a.[MCA %] between '97.50' and '97.99' then '97.5 < 97.99'
	when a.[MCA %] between '98.00' and '99.99' then '98.00 < 99.99'
	when a.[MCA %] >= '100.00' then '> 100'
	else '97.49 >'
	end as 'MCA Bucket'
,e.[Exception ID]
,E.[Document]
,Case
	WHEN E.[Sent For Gift Card Processing] is not null then 'Voucher Sent'
	WHEN E.[Gift Card Letter Sent 3] is not null then 'GC 3 Sent'
	WHEN E.[Gift Card Letter Sent 2] is not null then 'GC 2 Sent'
	WHEN E.[Gift Card Letter Sent] is not null THEN 'GC 1 Sent'
	ELSE 'No GC Sent'
END AS 'GC Flag'
,CAST(E.[Exception Status Date] AS DATE) AS 'Exception Status Date'
,Cast (E.[Gift Card Letter Sent] AS Date) AS 'I-Assign Date 1'
,Cast (E.[Gift Card Letter Sent 2] AS Date) AS 'I-Assign Date 2'
,Cast (E.[Gift Card Letter Sent 3] AS Date) AS 'I-Assign Date 3'
,Cast(E.[Sent For Gift Card Processing] AS Date) AS 'I-Assign Sent for Processing'
,Cast([Ledger Letter Sent 1] AS DATE) AS 'Ledger 1'
,Cast([Ledger Letter Sent 2] AS DATE) AS 'Ledger 2'
,Cast([Ledger Letter Sent 3] AS DATE) AS 'Ledger 3'
,CAST(E.[Ledger Sent For Gift Card Processing] AS Date) AS 'Ledger Gift Card Processing'
,Cast(E.[Non GC Letter Sent 1] AS DATE) AS 'Non GC 1'
,Cast(E.[Non GC Letter Sent 2] AS DATE) AS 'Non GC 2'
,Cast(E.[Non GC Letter Sent 3] AS DATE) AS 'Non GC 3'
,E.[Issue]
,E.[Exception Status]
,CAST(E.[Exception Request Date] AS DATE) AS 'Exception Request Date'
,case
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) <= 0  then '0 to 15'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 0 and 15 then '0 to 15'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 16 and 30 then '16 to 30'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 31 and 60 then '31 to 60'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 61 and 90 then '61 to 90'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 91 and 120 then '91 to 120'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) >= 121 then '121+'
	end as 'Exception Request Aging'
--,CASE
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) <= 0  then '0 to 15'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 0 and 15 then '0 to 15'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 16 and 30 then '16 to 30'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 31 and 60 then '31 to 60'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 61 and 90 then '61 to 90'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 91 and 120 then '91 to 120'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) >= 121 then '121+'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) <= 0  then '0 to 15'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 0 and 15 then '0 to 15'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 16 and 30 then '16 to 30'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 31 and 60 then '31 to 60'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 61 and 90 then '61 to 90'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 91 and 120 then '91 to 120'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) >= 121 then '121+'
--	END AS 'Exception Status Aging'
,e.[Exception Assigned To]
,c.[hud assigned to]
,T.[Open Exceptions]
,T.OpenCurative
,T.OpenHACG
,e.[Delinquent Amount]
,e.[Installment Frequency]
,e.[Due Date]
,e.[Entity or County Name]
,e.[Contact Info]
,e.[Fee to Obtain Info]
,e.[Fee Amount]
,r.[MGR_NM]
,r.[ST_LOC]

FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignLoans A
ON E.[Loan Number]=A.[Loan Number]
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignFinalReview B
ON E.[Loan Number]=B.[Loan Number]
left join SharepointData.dbo.HUDAssignHUDStatus c
on a.[Loan Number]=c.[Loan Number]
LEFT JOIN SharepointData.DBO.HUDAssignLoanExceptionTotals T
ON A.[Loan Number]=T.[Loan Number]
left join [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_HUD_RSTR] r
on c.[hud assigned to]=r.[AGNT_NM]

WHERE E.[Exception ID] IN ('342849',
'512946',
'512852',
'512828',
'512878',
'450954',
'512863',
'512904',
'512952',
'512879',
'512898',
'511434',
'512050',
'512860',
'512934',
'512901',
'512905',
'512849',
'503826',
'512845',
'512971',
'512888',
'510377',
'512935',
'512998',
'512954',
'512906',
'513011',
'512936',
'512903',
'512972',
'512889',
'512986',
'512895',
'512927',
'512780',
'512861',
'514225',
'482477',
'508815',
'512867',
'512892',
'512865',
'512153',
'512843',
'512880',
'512809',
'512928',
'512999',
'512908',
'490093',
'512890',
'512967',
'512949',
'500377',
'319837',
'489850',
'454416',
'512792',
'512868',
'512988',
'512989',
'512869',
'513021',
'512942',
'512922',
'512912',
'512929',
'512974',
'512870',
'512915',
'512959',
'512975',
'512980',
'512968',
'511940',
'512712',
'512991',
'490316',
'512950',
'512894',
'512976',
'513309',
'512938',
'512992',
'512955',
'490074',
'514328',
'512003',
'514217',
'512969',
'512960',
'513002',
'513101',
'512784',
'512930',
'512943',
'513003',
'513004',
'512961',
'513005',
'512993',
'512917',
'512871',
'512956',
'512984',
'512920',
'512891',
'512882',
'512994',
'512883',
'512913',
'512897',
'481383',
'512875',
'512944',
'512977',
'511078',
'513007',
'512884',
'512995',
'512919',
'512940',
'512921',
'512978',
'511457',
'513008',
'506256',
'512806',
'512825',
'512945',
'511586',
'512911',
'512862',
'512885',
'512851',
'503816',
'512957',
'323154',
'495141',
'516028',
'461642',
'516450',
'438238',
'445605',
'516458',
'515387',
'515371',
'515376',
'485411',
'425904',
'515388',
'515380',
'480325',
'447080',
'515381',
'515382',
'515383',
'480314',
'466650',
'501145',
'516487',
'466561',
'402131',
'466436',
'516056',
'459390',
'515386',
'480244',
'466437',
'480236',
'480231',
'515351',
'480221',
'498018',
'459145',
'480157',
'480151',
'480145',
'511756',
'480139',
'480138',
'515353',
'466473',
'459218',
'480116',
'515358',
'480107',
'512262',
'480093',
'480090',
'473988',
'466383',
'483958',
'515870',
'498749',
'516208',
'514232',
'414275',
'485665',
'419470',
'479998',
'414545',
'479962',
'498242',
'479961',
'486040',
'479951',
'479950',
'466409',
'479940',
'515367',
'515327',
'512008',
'511079',
'459284',
'500908',
'495204',
'515928',
'492690',
'500457',
'494309',
'492505',
'439464',
'485740',
'509255',
'511825',
'504798',
'507381',
'466373',
'459428',
'492719',
'409196',
'466310',
'498120',
'466489',
'480336',
'466335',
'480331',
'432158',
'430885',
'436930',
'498035',
'466393',
'466412',
'459346',
'459420',
'466576',
'459375',
'459418',
'459419',
'466539',
'459429',
'466651',
'466572',
'457576',
'480224',
'466682',
'459293',
'466635',
'480191',
'466349',
'480186',
'411727',
'480181',
'459379',
'466556',
'459357',
'459248',
'466652',
'466467',
'416686',
'466302',
'466376',
'409165',
'451594',
'466431',
'412440',
'459185',
'491065',
'466542',
'466623',
'466558',
'466629',
'480082',
'459251',
'466511',
'459153',
'498779',
'459175',
'459372',
'497248',
'480030',
'459431',
'466670',
'466655',
'466642',
'458962',
'447392',
'484446',
'466399',
'479964',
'466565',
'466596',
'498019',
'457869',
'479946',
'466684',
'466360',
'491112',
'479935',
'466679',
'483890',
'479916',
'459271',
'416284',
'466312',
'466553',
'466665',
'498218',
'459306')
/*E.[DOCUMENT] IN ('Current OCC Cert') AND 
--[ISSUE] IN ('Forced Placed Insurance')AND
E.[EXCEPTION STATUS] NOT IN ('RESOLVED','CANCELLED','NOT VALID','CLOSED','INCURABLE','closed with vendor') AND
A.[Tag 2] IS NULL AND
--T.OpenCurative IN ('0')AND
A.[Incurable Flag] IN ('0')AND
A.[Loan Status] IN ('active')AND
--A.Stage IN ('FINAL REVIEW','HUD STATUS') AND 
--A.[MCA %] BETWEEN 96.0 and 96.49 
(a.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or a.[Group] is null)
ORDER BY E.[Document],[MCA %] DESC*/
