SELECT C.[Loan Number]
,A.[Work Group]
,A.[Document]
,A.[Issue]
,A.[Exception Status]
,A.[Exception Status Date]
,A.[Exception Assigned To]
,C.[Loan Status]
,C.[MCA %]
,C.[Stage],
CASE 
WHEN B.[FNMA Approval Indicator] is not null then ('Not FNMA Denied')
ELSE 'Not FNMA Denied'
END AS 'FNMA Approval Status',
CASE
WHEN C.[MCA %] between 0 and 97.5 then '0% to 97.5%'
WHEN C.[MCA %] between 97.5 and 100.00 then '97.5% to 99.9%'
WHEN C.[MCA %] > 100.00 then '100% or Over'
END AS 'Segment'
FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS A
Left Join Sharepointdata.dbo.HUDAssignHUDStatus B
ON A.[Loan Number] = B.[Loan Number]
Left Join Sharepointdata.dbo.HUDAssignLoans C
ON A.[Loan Number] = C.[Loan Number]
WHERE A.[Exception Status] in ('Incurable') AND A.[Work Group] in ('HACG') AND B.[FNMA Denied Date] is null AND C.[Loan Status] not in ('Inactive','Liquidated/3rd Party Sale','Liquidated/Assigned to HU','Liquidated/Held for Sale')
ORDER BY C.[Stage] ASC
