SELECT [Loan Number], [FHA Case Number], [Loan Status], [MCA %]
FROM [SharepointData].[dbo].[HUDAssignLoans]
WHERE [MCA %] >= 97.5 AND [Tag 2] is null AND [Incurable Flag] = ('0') AND [Loan Status] in ('Active') AND [FHA Case Number] in ('0')