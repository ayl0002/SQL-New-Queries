--Base--
SELECT A.[Loan Number],B.[MCA_Percent] AS 'MCA_%',
CASE
	WHEN B.[MCA_Percent] < 98 THEN 'f 97.5 - 97.99'
	WHEN B.[MCA_Percent] < 98.5 THEN 'e 98 - 98.49'	
	WHEN B.[MCA_Percent] < 99 THEN 'd 98.5 - 98.99'	
	WHEN B.[MCA_Percent] < 99.5 THEN 'c 99 - 99.49'	
	WHEN B.[MCA_Percent] < 100 THEN 'b 99.5 - 99.99'
	WHEN B.[MCA_Percent] >= 100 THEN 'a 100+'
END AS 'MCA_Flag'
,A.[Exception ID],A.[Document],A.[Issue],A.[Exception Status],A.[Exception Request Date],C.[Loan Status],D.[HUD Status]
,ROW_NUMBER () OVER (Partition By A.[Exception ID] ORDER BY A.[Loan Number]) AS 'HOA_Count',HACG_Count,ISNULL(Cura_Count,0) AS 'Cura_Count',G.Reopen_Date
,CASE
	WHEN G.Reopen_Date > [Exception Request Date] THEN G.Reopen_Date
	ELSE [Exception Request Date] 
	END AS 'True_Open'
,CASE
	WHEN G.Reopen_Date > [Exception Request Date] THEN ABS(DATEDIFF(DAY,GETDATE(),G.Reopen_Date))
	ELSE ABS(DATEDIFF(DAY,GETDATE(),[Exception Request Date]))
	END AS 'Exception_Aging'	
INTO #BASE

FROM SharepointData.Dbo.HUDAssignExceptions A
LEFT JOIN Tact_Rev.[dbo].[champbase] B
	ON A.[Loan Number] = B.[loan_nbr]
LEFT JOIN SharepointData.Dbo.HUDAssignLoans C
	ON A.[Loan Number] = C.[Loan Number]
LEFT JOIN SharepointData.Dbo.HUDAssignHUDStatus D
	ON A.[Loan Number] = D.[Loan Number]
LEFT JOIN (SELECT A.[Loan Number],MAX(Cura_Count) AS Cura_Count
			FROM SharepointData.Dbo.HUDAssignExceptions A
			RIGHT JOIN
			(SELECT [Loan Number], Row_Number () Over (Partition by [Loan Number] Order By [Document]) AS 'Cura_Count'  
				FROM SharepointData.Dbo.HUDAssignExceptions 
				WHERE ISNULL([Work Group],'None') IN ('LandTran','Curative') AND [EXCEPTION STATUS] NOT IN ('RESOLVED','CLOSED','NOT VALID','CLOSED WITH VENDOR','Incurable')) B
				ON A.[Loan Number] = B.[Loan Number]
				GROUP BY A.[Loan Number]
				) E
	ON A.[Loan Number] = E.[Loan Number]
LEFT JOIN (SELECT A.[Loan Number],MAX(HACG_Count) AS 'HACG_Count'
			FROM SharepointData.Dbo.HUDAssignExceptions A
			RIGHT JOIN
			(SELECT [Loan Number], Row_Number () Over (Partition by [Loan Number] Order By [Document]) AS 'HACG_Count'  
				FROM SharepointData.Dbo.HUDAssignExceptions 
				WHERE ISNULL([Work Group],'None') IN ('HACG') AND [EXCEPTION STATUS] NOT IN ('RESOLVED','CLOSED','NOT VALID','CLOSED WITH VENDOR','Incurable')) B
				ON A.[Loan Number] = B.[Loan Number]
				GROUP BY A.[Loan Number]
				) F
	ON A.[Loan Number] = F.[Loan Number]
LEFT JOIN (SELECT [Excp_ID],MAX([END_DTTM]) AS 'Reopen_Date' FROM [VRSQLRODS\RODS_PROD].Reverse_dw.[dbo].[HUD_ASGN_EXCP_EDW] WHERE [Doc_Desc] IN ('HOA') AND CURR_IND NOT IN ('Y') GROUP BY [Excp_ID])G
ON A.[Exception ID]  = G.[EXCP_ID]
WHERE A.[Document] IN ('HOA') AND A.[EXCEPTION STATUS] NOT IN ('RESOLVED','CLOSED','NOT VALID','CLOSED WITH VENDOR','Incurable')
AND B.[mca_percent] >= 97.5 AND B.[status_description] IN ('Active') AND C.[Tag 2] IS NULL AND C.[Incurable Flag] IN ('0')
AND (CAST(D.[HUD Preliminary Title Approval] AS DATE) IS NULL OR CAST(D.[HUD Preliminary Title Denial Date] AS DATE) >= CAST(D.[HUD Preliminary Title Approval] AS DATE))
AND ISNULL(C.[Group],'No Group') NOT IN ('Grp 5 BofA GNMAs')
AND [HUD Status] NOT IN ('Pkg Submitted to HUD','HUD Approved','HUD Approval','Resubmitted to HUD','Rebuttal to HUD')


--OutFlow Scrub--
SELECT A.CaseNumber,B.[Loan Number],B.[Exception ID] 
INTO #OUTFLOW
FROM Tact_Rev.[dbo].[PrecedentReport] A
	LEFT JOIN #BASE B
ON A.[CaseNumber] = B.[Loan Number]


--Inflow Scrub--
SELECT A.*
,CASE 
	WHEN B.[CaseNumber] IS NULL THEN 'Inflow'
	ELSE 'Static'
	END AS 'Inflow',B.*,C.Outflow
FROM #BASE A  
LEFT JOIN Tact_Rev.[dbo].[PrecedentReport] B 
ON A.[Loan Number] = B.[CaseNumber]
LEFT JOIN (SELECT CAST('HOA' AS NVARCHAR) AS 'Document',COUNT(CaseNumber) AS 'Outflow' FROM #OUTFLOW WHERE [Exception ID] IS NULL) C
ON A.[Document] = C.Document


DROP TABLE #BASE,#OUTFLOW


--Tact_REv.[dbo].[PrecedentReport]