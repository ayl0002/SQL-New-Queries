--Base Population--
SELECT A.[Loan Number],A.[Loan Status],A.[TAG 2],A.[Incurable Flag],CAST(D.[MCA_PERCENT] AS Float(2)) AS 'MCA %'
,CASE
WHEN D.[MCA_PERCENT] < 95 THEN '<95'
WHEN D.[MCA_PERCENT] BETWEEN 95 AND 96.49 THEN '95 < 96.5'
WHEN D.[MCA_PERCENT] BETWEEN 96.5 AND 97.49 THEN '96.5 < 97.5'
WHEN D.[MCA_PERCENT] BETWEEN 97.5 AND 99.99 THEN '97.5 < 100'
WHEN D.[MCA_PERCENT] >= 100 THEN '>= 100'
ELSE 'Error'
END AS 'MCA Flag'
,B.[HUD Status],C.[Final Review Status],B.[HUD Assigned To],C.[Final Review Assigned To],A.[Group]
INTO #LoanStatus
FROM SharepointData.Dbo.HUDAssignLoans A
LEFT JOIN SharepointData.Dbo.HUDAssignHUDStatus B
ON A.[Loan Number] = B.[Loan Number]
LEFT JOIN SharepointData.Dbo.HUDAssignFinalReview C
ON A.[Loan Number] = C.[Loan Number]
LEFT JOIN [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] D
ON A.[Loan Number] = D.Loan_Nbr
WHERE A.[Loan Status] IN ('Active') AND  A.[TAG 2] IS NULL AND A.[Incurable Flag] IN ('0')
AND (A.[GROUP] IN ('Grp 1 NSM Balance Sheet',	'Grp 3 GNMA excl BofA',	'Grp 2 FNMA',	'Grp 4 Trust / Private exlc BofA') OR A.[GROUP] IS NULL)
AND B.[HUD Status] IN ('Not Started','HUD Denied')

--Curative Scrub--
SELECT [Loan Number],'Open_Cura' AS 'Cura_Flag'
INTO #Cura_Flag
FROM SharepointData.Dbo.HUDAssignExceptions A
WHERE A.[Work Group] IN ('CURATIVE','LANDTRAN') AND A.[EXCEPTION STATUS] NOT IN ('CLOSED','RESOLVED','NOT VALID','INCURABLE','CLOSED WITH VENDOR') 
		AND A.[DOCUMENT] NOT IN ('TITLE POLICY','Assignments','Assignments-3rd Party','Assignments-POA','DEATH CERT','TRUST','orig appraisal')

--Exception Scrub Scrub--
SELECT A.*,B.Cura_Flag
INTO #Exceptions
FROM SharepointData.Dbo.HUDAssignExceptions A
LEFT JOIN #Cura_Flag B
ON A.[Loan Number] = B.[Loan Number]
WHERE (Document IN ('Death Cert HACG','Trust - HACG') AND [EXCEPTION STATUS] NOT IN ('CLOSED','RESOLVED','NOT VALID','INCURABLE','CLOSED WITH VENDOR'))
OR (ISNULL(A.[Proof of Repairs Status],'No Status') NOT IN ('Report/Inspection complete repairs are not complete') AND Document IN ('Proof of Repair') AND [EXCEPTION STATUS] NOT IN ('CLOSED','RESOLVED','NOT VALID','INCURABLE','CLOSED WITH VENDOR'))

--SELECT * FROM #Exceptions
--Max Letter Date--
SELECT #Exceptions.[Exception ID],(SELECT MAX(V) FROM (VALUES ([Gift Card Letter Sent]),([Gift Card Letter Sent 2]),	([Gift Card Letter Sent 3]),([Ledger Letter Sent 1]),	([Ledger Letter Sent 2]),	([Ledger Letter Sent 3]),	([Non GC Letter Sent 1]),	([Non GC Letter Sent 2]),	([Non GC Letter Sent 3])) AS VALUE (V)) AS 'Max Date'
	,(SELECT COUNT(V) FROM (VALUES ([Gift Card Letter Sent]),([Gift Card Letter Sent 2]),	([Gift Card Letter Sent 3]),([Ledger Letter Sent 1]),	([Ledger Letter Sent 2]),	([Ledger Letter Sent 3]),	([Non GC Letter Sent 1]),	([Non GC Letter Sent 2]),	([Non GC Letter Sent 3])) AS VALUE (V)) AS 'LTR Count'
INTO #MAXDATE
FROM #Exceptions


/*
INSERT INTO #MAXDATE
SELECT #Exceptions.*,(SELECT MAX(V) FROM (VALUES ([Gift Card Letter Sent]),([Gift Card Letter Sent 2]),([Gift Card Letter Sent 3]),([Non GC Letter Sent 1]),([Non GC Letter Sent 2]),([Non GC Letter Sent 3])) AS VALUE (V)) AS 'Max Date'
	,(SELECT COUNT(V) FROM (VALUES ([Gift Card Letter Sent]),([Gift Card Letter Sent 2]),([Gift Card Letter Sent 3]),([Non GC Letter Sent 1]),([Non GC Letter Sent 2]),([Non GC Letter Sent 3])) AS VALUE (V)) AS 'LTR Count'
FROM #Exceptions
WHERE [Document] IN ('CURRENT OCC CERT')*/


--GC Drop--
SELECT A.[Loan Number] ,CAST(GETDATE() AS DATE) AS 'TODAY',A.[Loan Status],A.[TAG 2],A.[Incurable Flag],CAST(A.[MCA %] AS Float(2)) AS 'MCA %'
,CASE 
/*
WHEN A.[MCA %] >= 97 AND B.[Ledger Sent for Gift Card Processing] IS NOT NULL THEN 'DO NOT SEND - Ledger Fulfilled'
WHEN [Sent For Gift Card Processing] IS NOT NULL AND [ISSUE] NOT IN ('Missing Contact Info','Missing') THEN 'DO NOT SEND - GC Sent'
WHEN [Non GC Letter Document Returned] IS NOT NULL AND [ISSUE] NOT IN ('Missing Contact Info','Missing') THEN 'DO NOT SEND - NON GC RECEIVED'
WHEN [Sent For Gift Card Processing] IS NOT NULL AND [ISSUE] IN ('Missing Contact Info','Missing') THEN 'Review Issue - Doc Received'
WHEN [Non GC Letter Document Returned] IS NOT NULL AND [ISSUE] IN ('Missing Contact Info','Missing') THEN 'Review Issue - Doc Received'
WHEN A.[MCA %] >= 97 AND B.[Ledger Letter Sent 1] IS NULL THEN 'Send Ledger 1'
WHEN A.[MCA %] >= 97.5 AND B.[Ledger Letter Sent 2] IS NULL THEN 'Send Ledger 2'
WHEN A.[MCA %] >= 98 AND B.[Ledger Letter Sent 3] IS NULL THEN 'Send Ledger 3'
WHEN A.[MCA %] >= 98 AND B.[Ledger Letter Sent 3] IS NOT NULL THEN 'Incurable Review'*/
--WHEN [Non GC Letter Document Returned] IS NOT NULL AND [ISSUE] NOT IN ('Missing Contact Info','Missing') THEN 'DO NOT SEND - NON GC REVEIVED'
WHEN C.[Sent For Gift Card Processing] IS NOT NULL THEN 'DO_NOT_SEND'
WHEN DATEDIFF(Day,CAST([Max Date] AS DATE),CAST(GETDATE() AS DATE)) <= 15 THEN  'DO_NOT_SEND'
WHEN C.[Gift Card Letter Sent] IS NULL THEN 'Send GC 1'
WHEN C.[Gift Card Letter Sent 2] IS NULL AND (A.[MCA %] >= 90 OR DATEDIFF(Day,CAST([Max Date] AS DATE),CAST(GETDATE() AS DATE)) >= 65) THEN 'Send GC 2'
WHEN C.[Gift Card Letter Sent 3] IS NULL AND (A.[MCA %] >= 91 OR DATEDIFF(Day,CAST([Max Date] AS DATE),CAST(GETDATE() AS DATE)) >= 65) THEN 'Send GC 3'
WHEN C.[Gift Card Letter Sent 3] IS NOT NULL AND [Sent to Inspection Vendor] IS NOT NULL AND [Document] IN ('Proof of Repair') THEN 'DO_NOT_SEND'
WHEN C.[Gift Card Letter Sent 3] IS NOT NULL AND DATEDIFF(Day,CAST([Max Date] AS DATE),CAST(GETDATE() AS DATE)) >= 65 THEN 'Send GC 3 - Incurable Review'
/*
WHEN A.[MCA %] < 96.5 AND [Non GC Letter Sent 1] IS NULL THEN 'Send Non GC 1'
WHEN (A.[MCA %] < 96.5 AND A.[MCA %] >=95.5) AND [Non GC Letter Sent 2] IS NULL THEN 'Send Non GC 2'
WHEN (A.[MCA %] < 96.5 AND A.[MCA %] >=96) AND [Non GC Letter Sent 3] IS NULL THEN 'Send Non GC 3'*/
ELSE 'DO_NOT_SEND'
END AS 'Send Flag'
,C.[Exception ID],--[Proof of Repairs Status],[Sent to Inspection Vendor],
C.[Document],C.[Exception Status],C.[Issue],CAST(C.[Gift Card Letter Sent] AS DATE) AS 'Gift Card Letter Sent',	CAST(C.[Gift Card Letter Sent 2] AS DATE) AS 'Gift Card Letter Sent 2',	CAST(C.[Gift Card Letter Sent 3] AS DATE) AS 'Gift Card Letter Sent 3',	CAST(C.[Sent For Gift Card Processing] AS DATE) AS 'Sent For Gift Card Processing',	CAST(C.[Document Returned] AS DATE) AS 'Document Returned',	CAST(C.[Ledger Letter Document Returned] AS DATE) AS 'Ledger Letter Document Returned',	CAST(C.[Ledger Letter Sent 1] AS DATE) AS 'Ledger Letter Sent 1',	CAST(C.[Ledger Letter Sent 2] AS DATE) AS 'Ledger Letter Sent 2',	CAST([Ledger Letter Sent 3] AS DATE) AS 'Ledger Letter Sent 3',	CAST([Ledger Sent for Gift Card Processing] AS DATE) AS 'Ledger Sent for Gift Card Processing',	CAST([Non GC Letter Sent 1] AS DATE) AS 'Non GC Letter Sent 1',	CAST([Non GC Letter Sent 2] AS DATE) AS 'Non GC Letter Sent 2',	CAST([Non GC Letter Sent 3] AS DATE) AS 'Non GC Letter Sent 3',	CAST([Non GC Letter Document Returned] AS DATE) AS 'Non GC Letter Document Returned',CAST([Max Date] AS DATE) AS 'Max Date',
[LTR Count]
INTO #FINAL
FROM #LoanStatus A
LEFT JOIN #Exceptions C
ON A.[Loan Number] = C.[Loan Number]
LEFT JOIN #MAXDATE B
ON B.[Exception ID] = C.[Exception ID]
WHERE A.[MCA %] >= 89 AND C.[Document] IN ('Death Cert HACG','Trust - HACG','Proof of Repair')

/*
--OCC--
INSERT INTO #FINAL
SELECT A.[Loan Number],CAST(GETDATE() AS DATE) AS 'TODAY',A.[Loan Status],A.[TAG 2],A.[Incurable Flag],CAST(A.[MCA %] AS Float(2)) AS 'MCA %'
,CASE 
WHEN DATEDIFF(Day,CAST([Max Date] AS DATE),CAST(GETDATE() AS DATE)) <= 20 THEN  'DO NOT SEND - 20 Day Rule'
WHEN A.[MCA %] >= 96.5 AND [Sent For Gift Card Processing] IS NOT NULL THEN 'DO NOT SEND - GC Fulfilled'
WHEN A.[MCA %] >= 96.5 AND [Gift Card Letter Sent] IS NULL THEN 'Send GC 1'
WHEN A.[MCA %] >= 97 AND [Gift Card Letter Sent 2] IS NULL THEN 'Send GC 2'
WHEN A.[MCA %] >= 97.5 AND [Gift Card Letter Sent 3] IS NULL THEN 'Send GC 3'
WHEN A.[MCA %] >= 97.5 AND [Gift Card Letter Sent 3] IS NOT NULL AND ([Sent to Inspection Vendor] IS NOT NULL OR [Ledger Letter Sent 1] IS NOT NULL) THEN 'Pending NCCI'
WHEN A.[MCA %] >= 97.5 AND [Gift Card Letter Sent 3] IS NOT NULL AND [Sent to Inspection Vendor] IS NOT NULL AND [Ledger Letter Document Returned] IS NOT NULL THEN 'Incurable Review'
WHEN A.[MCA %] < 96.5 AND [Non GC Letter Sent 1] IS NULL THEN 'Send Non GC 1'
WHEN (A.[MCA %] < 96.5 AND A.[MCA %] >=95.5) AND [Non GC Letter Sent 2] IS NULL THEN 'Send Non GC 2'
WHEN (A.[MCA %] < 96.5 AND A.[MCA %] >=96) AND [Non GC Letter Sent 3] IS NULL THEN 'Send Non GC 3'
WHEN A.[MCA %] < 96.5 AND [Non GC Letter Sent 3] IS NOT NULL THEN 'DO NOT SEND - Under 96.5'
ELSE 'DO NOT SEND'
END AS 'Send Flag'
,[Exception ID],[Document],[Exception Status],[Issue],CAST([Gift Card Letter Sent] AS DATE) AS 'Gift Card Letter Sent',	CAST([Gift Card Letter Sent 2] AS DATE) AS 'Gift Card Letter Sent 2',	CAST([Gift Card Letter Sent 3] AS DATE) AS 'Gift Card Letter Sent 3',	CAST([Sent For Gift Card Processing] AS DATE) AS 'Sent For Gift Card Processing',	CAST([Document Returned] AS DATE) AS 'Document Returned',	CAST([Ledger Letter Document Returned] AS DATE) AS 'Ledger Letter Document Returned',	CAST([Ledger Letter Sent 1] AS DATE) AS 'Ledger Letter Sent 1',	CAST([Ledger Letter Sent 2] AS DATE) AS 'Ledger Letter Sent 2',	CAST([Ledger Letter Sent 3] AS DATE) AS 'Ledger Letter Sent 3',	CAST([Ledger Sent for Gift Card Processing] AS DATE) AS 'Ledger Sent for Gift Card Processing',	CAST([Non GC Letter Sent 1] AS DATE) AS 'Non GC Letter Sent 1',	CAST([Non GC Letter Sent 2] AS DATE) AS 'Non GC Letter Sent 2',	CAST([Non GC Letter Sent 3] AS DATE) AS 'Non GC Letter Sent 3',	CAST([Non GC Letter Document Returned] AS DATE) AS 'Non GC Letter Document Returned',CAST([Max Date] AS DATE) AS 'Max Date',
[LTR Count]
FROM #LoanStatus A
LEFT JOIN #MAXDATE B
ON A.[Loan Number] = B.[Loan Number]
WHERE B.[Document] IN ('Current OCC Cert') AND A.[MCA %] >= 95
*/

--GC Report--
SELECT *
FROM #Final
ORDER BY [Document],[Send Flag]

--Manifest--
/*
DECLARE @RD DATE = (SELECT ServicingPreviousDay FROM [REVERSE_DW].[dbo].[RM_CALENDAR_BUSINESS_DAYS_TBL] WHERE [DATE] = CAST(GETDATE() AS DATE))
DECLARE @RDINT INT = CAST(CONVERT(VARCHAR(8),DATEADD(D,0,DATEADD(M,0,@RD)), 112) AS INT)
*/
--SELECT @RD RD, @RDINT RDINT

SELECT DISTINCT A.[Send Flag],'50' AS 'Amount',A.[Exception ID],CAST(GETDATE() AS DATE) AS 'Letter_Date', CMT.LOAN_NBR
	,CASE WHEN CAST(CMT.BORROWER_DATE_OF_DEATH AS VARCHAR) NOT IN ('NULL') 
		THEN 'Estate of ' + CMT.BORROWER_FIRST_NAME + ' ' + CMT.BORROWER_LAST_NAME
	ELSE CMT.BORROWER_FIRST_NAME + ' ' + CMT.BORROWER_LAST_NAME
	END AS "Borr1"
	,CASE WHEN CAST(CMT.COBORROWER_DATE_OF_DEATH as varchar) NOT IN ('NULL')
		THEN 'Estate of ' + CMT.COBORROWER_FIRST_NAME + ' ' + CMT.COBORROWER_LAST_NAME
	ELSE ISNULL(CMT.COBORROWER_FIRST_NAME,' ') + ' ' + ISNULL(CMT.COBORROWER_LAST_NAME,' ')
	END AS "Borr2"
,CMT.Status_DESCRIPTION
,CMT.BORROWER_MAIL_ADDRESS
,CMT.BORROWER_MAIL_CITY
,CMT.BORROWER_MAIL_STATE
,CASE WHEN LEN(CMT.borrower_mail_zip_code) > 5
	THEN SUBSTRING(BORROWER_MAIL_ZIP_CODE, 1,5)+'-'+SUBSTRING(borrower_mail_zip_code,6,4) 
	WHEN LEN(CMT.borrower_mail_zip_code) <= 5
	THEN CMT.BORROWER_MAIL_ZIP_CODE
	ELSE 'Error'
	END AS "BORROWER_MAIL_ZIP_CODE"
	,CMT.PROP_ADDRESS
	,CMT.PROP_CITY
	,CMT.PROP_STATE
	,CASE WHEN LEN(CMT.PROP_ZIP_CODE) > 5
		THEN SUBSTRING(CMT.PROP_ZIP_CODE, 1,5)+'-'+SUBSTRING(CMT.PROP_ZIP_CODE,6,4) 
	ELSE CMT.PROP_ZIP_CODE
	END AS "PROP_ZIP_CODE"
,Case
	--WHEN CMT.BORROWER_MAIL_STATE LIKE ('%HI%') AND (CMT.BORROWER_MAIL_ADDRESS LIKE ('PO Box%') or CMT.BORROWER_MAIL_ADDRESS LIKE ('P.O. Box%') or CMT.BORROWER_MAIL_ADDRESS LIKE ('P O Box%') or CMT.BORROWER_MAIL_ADDRESS LIKE ('P. O. BOX%')) THEN 'HI - PO BOX'
	WHEN CMT.BORROWER_MAIL_STATE LIKE ('%PR%') THEN 'PR Address' 
	WHEN CMT.BORROWER_MAIL_ADDRESS LIKE ('PO Box%') or CMT.BORROWER_MAIL_ADDRESS LIKE ('P.O. Box%') or CMT.BORROWER_MAIL_ADDRESS LIKE ('P O Box%') or CMT.BORROWER_MAIL_ADDRESS LIKE ('P. O. BOX%') THEN 'PO BOX'
	ELSE 'Standard Address'
	END AS 'PO Box Flag'	
	,CMT.MCA_PERCENT
,A.Document
FROM #Final A
LEFT JOIN [VRSQLRODS\RODS_PROD].Reverse_DW.dbo.[RM_CHAMPION_MASTER_TBL_CURR_VW]CMT
ON A.[Loan Number] = CMT.Loan_Nbr
WHERE A.[Send Flag] IN ('Send GC 1',
'Send GC 2',
'Send GC 3')  --CMT.BORROWER_MAIL_ADDRESS LIKE ('PO Box%') or CMT.BORROWER_MAIL_ADDRESS LIKE ('P.O. Box%') or CMT.BORROWER_MAIL_ADDRESS LIKE ('P O Box%')

ORDER BY A.Document,('PO Box Flag')

DROP TABLE #LoanStatus,#Exceptions,#MaxDate,#FINAL,#Cura_Flag

