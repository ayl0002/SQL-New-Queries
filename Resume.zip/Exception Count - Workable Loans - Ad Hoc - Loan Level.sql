SET NOCOUNT ON
--Active Scrub--	
SELECT CAST(A.LOAN_NBR AS NVARCHAR) AS 'Loan_Nbr',CAST(A.[MCA_PERCENT] AS FLOAT(2)) AS 'MCA%',
CASE
	WHEN A.[MCA_PERCENT] >= 105 THEN '105+'	
	WHEN A.[MCA_PERCENT] BETWEEN 100 AND 104.99 THEN '100 to 104.99'	
	WHEN A.[MCA_PERCENT] BETWEEN 98 AND 99.99 THEN '98 to 99.99'
	WHEN A.[MCA_PERCENT] BETWEEN 97.5 AND 97.99 THEN '97.5 to 97.99'
ELSE '< 97.5'
END AS 'MCA Flag'
,A.[LOAN_STATUS],B.[Group],A.[POOL_NAME],B.[Tag 2],B.[Incurable Flag],C.[HUD Status],D.[Final Review Status]

--CASE STATEMENT TO SORT OUT PHANTOM LOANS NOT IN I-ASSIGN--
,CASE
	WHEN C.[HUD Assigned To] IS NULL AND C.[HUD Status] IN ('New File','Not Started') AND D.[Final Review Assigned To] IN ('Robert Gough') THEN D.[Final Review Assigned To]
	ELSE C.[HUD Assigned To]
END AS 'HUD Assigned To'
--CASE STATEMENT TO SORT OUT PHANTOM LOANS NOT IN I-ASSIGN--

,D.[Final Review Assigned To]
,CASE
	WHEN C.[HUD Status] IN ('New File','Not Started') THEN D.[Final Review Assigned To]
	ELSE C.[HUD Assigned To]
	END AS 'Agent'
INTO #Active
FROM SharepointData.Dbo.HUDAssignLoans B
LEFT JOIN [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] A
	ON Cast(A.Loan_Nbr AS NVARCHAR) = B.[Loan Number]
LEFT JOIN SharepointData.Dbo.HUDAssignHUDStatus C
	ON Cast(A.Loan_Nbr AS NVARCHAR) = C.[Loan Number]
Left JOIN SharepointData.[dbo].[HUDAssignFinalReview] D
	ON Cast(A.Loan_Nbr AS NVARCHAR) = D.[Loan Number]
WHERE A.[MCA_PERCENT] >=97.5 AND A.[LOAN_STATUS] IN ('Active') AND B.[Incurable Flag] IN ('0') AND B.[Tag 2] IS NULL AND ISNULL(B.[Group],'NoGroup') NOT IN ('Grp 5 BofA GNMAs') AND C.[HUD Status] IN ('HUD Denied','New File','Not Started')

--Agent Scrub--
SELECT A.*,	MGR_NM,	ST_LOC,	GRP_NM
,CASE 
	WHEN A.Agent IN ('Shasta Patton') THEN 'Assignable-ARM Loan'
	WHEN A.Agent IN ('Robert Gough') THEN 'Assignable-FPI'
	WHEN A.Agent IN ('Chelsea Daniel') THEN 'Assignable-Loss Draft'
	WHEN A.Agent IN ('Shelby Dominguez') THEN 'Assignable-Repays'
	WHEN A.Agent IN ('Norse Lockhart') THEN 'Assignable-Active Lit'
	ELSE NULL
END AS 'ASGN_Pipeline'
INTO #AGENT
FROM #Active A 
LEFT JOIN [VRSQLRODS\RODS_PROD].reverse_dw.dbo.TP_HUD_RSTR B
ON A.Agent = B.[AGNT_NM]

--Curative Scrub--
SELECT [Loan Number],[Exception ID],Row_Number () OVER (Partition By [Loan Number] ORDER BY [Exception ID]) AS 'Cura_Count','Open Curative' AS 'Cura_Flag'
INTO #Cura_Count
FROM SharepointData.Dbo.HUDAssignExceptions
WHERE [Work Group] IN ('Curative','LandTran') AND [Exception Status] NOT IN ('INCURABLE','CLOSED','RESOLVED','NOT VALID','CLOSED WITH VENDOR')

--HACG Scrub--
SELECT [Loan Number],[Exception ID],Row_Number () OVER (Partition By [Loan Number] ORDER BY [Exception ID]) AS 'HACG_Count'
INTO #HACG_Count
FROM SharepointData.Dbo.HUDAssignExceptions
WHERE [Work Group] IN ('HACG') AND [Exception Status] NOT IN ('INCURABLE','CLOSED','RESOLVED','NOT VALID','CLOSED WITH VENDOR')

--Exception Count--
SELECT [Loan Number],[Exception ID],Row_Number () OVER (Partition By [Loan Number] ORDER BY [Exception ID]) AS 'Excp_Count'
,CASE
	WHEN [Document] IN ('Tax Bill','HOA') AND [Issue] IN ('Delinquent') THEN 'Assignable-Delinquent'
ELSE NULL
END AS 'Excp_Asgn_Flag'
INTO #Excp_Count
FROM SharepointData.Dbo.HUDAssignExceptions
WHERE [Exception Status] NOT IN ('INCURABLE','CLOSED','RESOLVED','NOT VALID','CLOSED WITH VENDOR')

--Exception Level--
SELECT DISTINCT A.[Loan_Nbr],GETDATE() AS 'Refreshed',A.[MCA%],	A.[MCA Flag],	A.[LOAN_STATUS],	A.[Group],	A.[POOL_NAME],	A.[Tag 2],	A.[Incurable Flag],	A.[HUD Status],A.[Final Review Status],A.[HUD Assigned To],	A.[Final Review Assigned To],	A.[Agent],	A.[MGR_NM],	A.[ST_LOC],	A.[GRP_NM],B.[Exception ID],B.[Document],B.[Exception Status],B.[Issue],B.[Exception Description],B.[Work Group],CAST(B.[Exception Request Date] AS DATE) AS 'Excp_Request_Dt',B.[Exception Assigned To]
,Cast(B.[Exception Status Date] AS Date) AS 'Excp_Sts_Dt',Cura_Flag,ASGN_Pipeline,Excp_Asgn_Flag
,ISNULL(C.Cura_Count,0) AS 'Cura_Count',ISNULL(D.HACG_Count,0) AS 'HACG_Count',ISNULL(F.Excp_Count,0) AS 'Excp_Count'
,CASE
	WHEN Cura_Flag IS NOT NULL THEN Cura_Flag
	WHEN ASGN_Pipeline IS NOT NULL THEN ASGN_Pipeline
	WHEN Excp_Asgn_Flag IS NOT NULL THEN Excp_Asgn_Flag
	WHEN (ASGN_Pipeline  IS NULL AND Excp_Asgn_Flag IS NULL) AND A.Agent IS NULL THEN 'New File'
ELSE 'Assignable'
END AS'Asgn_Flag'
INTO #Exceptions
FROM #AGENT A 
LEFT JOIN --SharepointData.Dbo.HUDAssignExceptions B
(SELECT * FROM SharepointData.Dbo.HudAssignExceptions WHERE [Exception Status] NOT IN ('INCURABLE','CLOSED','RESOLVED','NOT VALID','CLOSED WITH VENDOR'))B
	ON A.Loan_Nbr = CAST(B.[Loan Number] AS NVARCHAR)
LEFT JOIN (SELECT [Loan Number],MAX(Cura_Count) AS 'Cura_Count' FROM #Cura_Count GROUP BY [Loan Number]) C
	ON A.Loan_Nbr = C.[Loan Number]
LEFT JOIN (SELECT [Loan Number],MAX(HACG_Count) AS 'HACG_Count' FROM #HACG_Count GROUP BY [Loan Number]) D
	ON A.Loan_Nbr = D.[Loan Number]
LEFT JOIN (SELECT [Loan Number],MAX(Excp_Count) AS 'Excp_Count' FROM #Excp_Count GROUP BY [Loan Number]) F
	ON A.Loan_Nbr =F.[Loan Number]
LEFT JOIN (SELECT [Loan Number],Excp_Asgn_Flag FROM #Excp_Count WHERE Excp_Asgn_Flag IS NOT NULL) E
	ON A.Loan_Nbr = E.[Loan Number]
LEFT JOIN (SELECT [Loan Number],Cura_Flag FROM #Cura_Count WHERE Cura_Flag IS NOT NULL) G
	ON A.Loan_Nbr = G.[Loan Number]
--WHERE  OR (B.[Exception ID] IS NULL) -- F.Excp_Count in ('0') AND )
	
--Loan Level--

SELECT DISTINCT A.[Loan_Nbr],	A.[Refreshed],	A.[MCA%],	A.[MCA Flag],	A.[LOAN_STATUS],	A.[Group],	A.[POOL_NAME],	A.[Tag 2],	A.[Incurable Flag],	A.[HUD Status],A.[Final Review Status],A.[HUD Assigned To],	A.[Final Review Assigned To],	A.[Agent],	A.[MGR_NM],	A.[ST_LOC],	A.[GRP_NM],	A.[Cura_Flag],	A.[ASGN_Pipeline],	A.[Excp_Asgn_Flag],	A.[Cura_Count],	A.[HACG_Count],	A.[Excp_Count],	A.[Asgn_Flag]

FROM #Exceptions A

ORDER BY A.[Asgn_Flag],Excp_Count ASC,[MCA%] DESC
DROP TABLE  #ACTIVE,#AGENT,#HACG_Count,#Cura_Count,#Excp_Count,#Exceptions--,#BASE