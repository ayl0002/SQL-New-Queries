DECLARE @Vendor VARCHAR(50) = 'Title365',
		@RequestDate DATE = DATEADD(MONTH, DATEDIFF(MONTH, -1, GETDATE())-1, -1),
		@iAssignVendor VARCHAR(50)



SELECT @IAssignVendor = CASE @Vendor WHEN 'Title365' THEN 'SolutionStar' ELSE @Vendor END


--SELECT @Vendor,
--		@RequestDate,
--		@iAssignVendor

Select 

	--'1. Title365 01.2019' 'Research Pop',
	'1. '+@Vendor+ ' '+ CONVERT(VARCHAR(2), MONTH(@RequestDate))+ '.'+ CONVERT(VARCHAR(4), YEAR(@RequestDate)) 'Research Pop'
	,cotm.LOAN_NBR
	,ex.[Exception ID]
	, ex.[Work Group]
	,ex.[Exception Request Group], ex.[Exception Requestor], ex.[Exception Assigned To]
	,ex.Document, ex.Issue
	,case when AcqName like ('BOA%') then 'Y' else 'N' end as 'BOA Acq?'
	,AcqName
	,case when POOL_NAME like ('%BOA%') then 'Y' else 'N' end as 'BOA Pool?'
	,POOL_NAME
	,INVESTOR
	,case when AcqName like ('BOA%') OR POOL_NAME like ('%BOA%') then 'Y' else 'N' end as 'BANA Flag?'
	,INVESTOR_LOAN_NBR
	,CLIENT_LOAN_NBR
	
FROM [TACT_REV].docs.tbl_ChainOfTitle_Master cotm
	left join [SharepointData].[dbo].HUDAssignExceptions ex on cast(cotm.loan_nbr as nvarchar(18)) = ex.[Loan Number]


where 1=1
and CONVERT(DATE,ex.[Exception Request Date]) <= @RequestDate
--and isnull(vendor,'') in ('Solutionstar','')
and vendor = @iAssignVendor
and cotm.LOAN_NBR in ('1149597',
'1154020',
'2398388',
'1075574',
'1054909',
'890058',
'1049155',
'1068004',
'2846346',
'1107399',
'751315',
'1039336'
)




order by [Research Pop], cotm.LOAN_NBR, ex.[Exception ID]