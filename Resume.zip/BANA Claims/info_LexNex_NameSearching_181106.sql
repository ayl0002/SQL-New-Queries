/*
declare @srcName as varchar(15) = '%sloan%';

select
	lns.[Loan Number], lns.Borrower1, lns.Borrower2, ex.Document, ex.Issue
	
	FROM SharepointData.dbo.HUDAssignExceptions ex
		left join SharepointData.dbo.HUDAssignLoans lns on ex.[Loan Number] = lns.[Loan Number]
		left join TACT_REV.docs.tbl_ChainOfTitle_Master cotm on lns.[Loan Number] = cotm.LOAN_NBR
		
		where ex.Document like ('Death Cert%')
			and (cotm.BORROWER_LAST_NAME like (@srcName)
			or cotm.COBORROWER_LAST_NAME like (@srcName))
		
declare @Lname as varchar(15) = '%abernathy%',@Fname as varchar(15) = '%roland%'

select
	lns.[Loan Number], lns.Borrower1, lns.Borrower2--, ex.Document, ex.Issue
	
	FROM 
	--SharepointData.dbo.HUDAssignExceptions ex
		--left join 
		SharepointData.dbo.HUDAssignLoans lns --on ex.[Loan Number] = lns.[Loan Number]
		left join TACT_REV.docs.tbl_ChainOfTitle_Master cotm on lns.[Loan Number] = cotm.LOAN_NBR
		
		where 1=1--ex.Document like ('Death Cert%')
			and ((cotm.BORROWER_LAST_NAME like @Lname and cotm.BORROWER_FIRST_NAME like @Fname
			)
			or (cotm.COBORROWER_LAST_NAME like @Lname and cotm.COBORROWER_FIRST_NAME like @Fname
			)
			)


select b.LOAN_NBR,a.frst_nm,a.last_nm,a.full_nm
from reverse_dw..borr a
join reverse_dw.[dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] b
on a.loan_key = b.LOAN_KEY
where frst_nm like '%sharon%' and last_nm like '%abernathy%'
and curr_ind = 'y'




*/
	
select distinct
	lns.[Loan Number], lns.Borrower1, lns.Borrower2, ex.Document, ex.Issue,cotm.BORROWER_LAST_NAME,cotm.BORROWER_FIRST_NAME,cotm.COBORROWER_LAST_NAME,cotm.COBORROWER_FIRST_NAME,cotm.BORROWER_LAST_NAME+','+cotm.BORROWER_FIRST_NAME AS 'Borrower Concat',cotm.COBORROWER_LAST_NAME+','+cotm.COBORROWER_FIRST_NAME AS 'Co-Borrower Concat'
	
	FROM SharepointData.dbo.HUDAssignExceptions ex
		left join SharepointData.dbo.HUDAssignLoans lns on ex.[Loan Number] = lns.[Loan Number]
		left join TACT_REV.docs.tbl_ChainOfTitle_Master cotm on lns.[Loan Number] = cotm.LOAN_NBR
		
		where ex.Document like ('Death Cert%') and
		(cotm.BORROWER_LAST_NAME IN ('WARREN',
'PETTY',
'SALE',
'PRINCE',
'BURKE',
'BOYER',
'PATTERSON',
'DICKERSON',
'THOMPSON',
'SALINAS',
'CLARK',
'AREFORD',
'BROWN',
'SMITH',
'MARK',
'WOLD',
'HALLETT',
'ESTRADA',
'CONDEZ',
'SELLMAN',
'HERNANDEZ',
'TOPP',
'COOK',
'COULTER',
'TINGLING',
'VISCUSI',
'JONES',
'BALOLONG',
'DONATHAN',
'LEEGER',
'CZULEWICZ',
'LEWIS',
'FARRELL',
'WATKINS')
					or cotm.COBORROWER_LAST_NAME IN ('WARREN',
'PETTY',
'SALE',
'PRINCE',
'BURKE',
'BOYER',
'PATTERSON',
'DICKERSON',
'THOMPSON',
'SALINAS',
'CLARK',
'AREFORD',
'BROWN',
'SMITH',
'MARK',
'WOLD',
'HALLETT',
'ESTRADA',
'CONDEZ',
'SELLMAN',
'HERNANDEZ',
'TOPP',
'COOK',
'COULTER',
'TINGLING',
'VISCUSI',
'JONES',
'BALOLONG',
'DONATHAN',
'LEEGER',
'CZULEWICZ',
'LEWIS',
'FARRELL',
'WATKINS')

)


--Order by cotm.BORROWER_LAST_NAME

