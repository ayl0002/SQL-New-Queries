Select 

	cotm.LOAN_NBR as 'Champion Loan #'
	,case when AcqName like ('BOA%') OR POOL_NAME like ('%BOA%') then 'Y' else 'N' end as 'BANA Flag?'
	,case when AcqName like ('BOA%') OR POOL_NAME like ('%BOA%') then CLIENT_LOAN_NBR else null end 'BANA Loan#'
	,POOL_NAME
		--,case when AcqName like ('BOA%') then 'Y' else 'N' end as 'BOA Acq?'
	,AcqName
	,CONVERT(DATE,AcqDate) AcqDate
	,case when POOL_NAME like ('%BOA%') then 'Y' else 'N' end as 'BOA Pool?'
	,INVESTOR
	
FROM [TACT_REV].docs.tbl_ChainOfTitle_Master cotm


where 1=1
and cotm.LOAN_NBR in ('761722',
'1089057',
'2589447',
'2784887',
'755196',
'1154907',
'837251')order by convert(int,LOAN_NBR)

--select loan_nbr,prop_address,PROP_CITY,prop_state
--from [TACT_REV].docs.tbl_ChainOfTitle_Master
--where loan_nbr in ('1013038'
--,'892063'
--,'748526')