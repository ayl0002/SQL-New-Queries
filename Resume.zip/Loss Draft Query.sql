SELECT [Loan Number],[Exception ID],[Document]
,[Issue],[Exception Status],[Exception Status Date]
INTO #Exceptions
FROM SharepointData.dbo.HUDAssignExceptions 
WHERE [Document] in ('Loss Draft') AND [Exception Status] not in ('Resolved','Closed','Not Valid')

SELECT DISTINCT SWBC.LoanNumber
,ActiveILD.ILD_ID AS 'Active ILD',
ActiveILD.ILDStatus AS 'Active Status',
ActiveILD.[Create Date] AS 'Active Create Date',
ActiveILD.LastInspectionResults AS 'Active Results',
InspComplete.ILD_ID AS 'Complete ILD',
InspComplete.ILDStatus AS 'Complete Status',
InspComplete.[Create Date] AS 'Complete Create Date',
InspComplete.LastInspectionResults AS 'Complete Results',
Incur.ILD_ID AS 'Incurable ILD',
Incur.ILDStatus AS 'Incurable Status',
Incur.[Create Date] AS 'Incurable Create Date',
Incur.LastInspectionResults AS 'Incurable Results'
,CASE 
WHEN ActiveILD.ILD_ID IS NOT NULL THEN 'Active ILD'
WHEN ActiveILD.ILD_ID IS NULL AND InspComplete.ILD_ID IS NOT NULL THEN 'Inspection Complete'
WHEN ActiveILD.ILD_ID IS NULL AND InspComplete.ILD_ID IS NULL AND Incur.ILD_ID IS NOT NULL THEN 'Incurable Review'
ELSE 'Error'
END AS 'ILD_Flag'
INTO #ILDS
FROM TACT_REV.[dbo].[HACGLossDraft] SWBC
LEFT JOIN (SELECT * FROM (SELECT LoanNumber,ILD_ID,ILDStatus,CAST(CreatedDate AS Date) AS 'Create Date',LastInspectionResults,Row_Number() Over (Partition BY LoanNumber ORDER BY [CreatedDate] DESC) RN FROM TACT_REV.[dbo].[HACGLossDraft] WHERE ILDStatus in ('Active') AND LastInspectionResults < 1.0) A WHERE A.RN = 1) ActiveILD
ON SWBC.LoanNumber = ActiveILD.LoanNumber
LEFT JOIN (SELECT * FROM (SELECT LoanNumber,ILD_ID,ILDStatus,CAST(CreatedDate AS Date) AS 'Create Date',LastInspectionResults,Row_Number() Over (Partition BY LoanNumber ORDER BY [CreatedDate] DESC) RN FROM TACT_REV.[dbo].[HACGLossDraft] WHERE ILDStatus in ('Active','Closed') AND LastInspectionResults >= 1.0) A WHERE A.RN = 1) InspComplete
ON SWBC.LoanNumber = InspComplete.LoanNumber
LEFT JOIN (SELECT * FROM (SELECT LoanNumber,ILD_ID,ILDStatus,CAST(CreatedDate AS Date) AS 'Create Date',LastInspectionResults,Row_Number() Over (Partition BY LoanNumber ORDER BY [CreatedDate] DESC) RN FROM TACT_REV.[dbo].[HACGLossDraft] WHERE ILDStatus in ('Closed') AND LastInspectionResults < 1.0) A WHERE A.RN = 1) Incur
ON SWBC.LoanNumber = Incur.LoanNumber
ORDER BY ActiveILD.ILDStatus DESC ,InspComplete.ILDStatus DESC ,Incur.ILDStatus DESC

SELECT 
A.[LoanNumber],C.[Loan Status],CAST(C.[MCA %] AS FLOAT(2)) AS 'MCA %'
,C.[Tag 2]
,C.[Incurable Flag]
,CASE
WHEN C.[MCA %] >= 100 THEN '>=100'
WHEN C.[MCA %] >= 97.5 AND C.[MCA %] < 100.00 THEN ' <= 97.5 < 100'
WHEN C.[MCA %] < 97.5 THEN '< 97.5'
WHEN C.[MCA %] is NULL THEN 'NULL'
ELSE 'Error'
END AS 'MCA Flag'
,E.[Final Review Status],	D.[HUD Status],	E.[Final Review Assigned To],	D.[HUD Assigned To],	B.[Exception ID],	B.[Document],	B.[Issue],	B.[Exception Status],	B.[Exception Status Date],	A.[Active ILD],	A.[Active Status],	A.[Active Create Date],	A.[Active Results],	A.[Complete ILD],	A.[Complete Status],	A.[Complete Create Date],	A.[Complete Results],	A.[Incurable ILD],	A.[Incurable Status],	A.[Incurable Create Date],	A.[Incurable Results],	A.[ILD_Flag]
,CASE 
WHEN A.[ILD_Flag] IN ('Active ILD') AND D.[HUD Status] IN ('HUD Approved','HUD Approval','Pkg Submitted to HUD','Resubmitted to HUD') THEN 'Submitted to HUD - Active ILD'
WHEN A.[ILD_Flag] in ('Active ILD') AND (D.[HUD Assigned To] NOT IN ('Chelsea Daniel') OR D.[HUD Assigned To] IS NULL) AND B.[Document] IS NULL THEN 'Open Exception - Move to Chelsea'
WHEN A.[ILD_Flag] in ('Active ILD') AND D.[HUD Assigned To] IN ('Chelsea Daniel') AND B.[Document] IS NULL THEN 'Open Exception - Already with Chelsea'
WHEN A.[ILD_Flag] in ('Active ILD') AND (D.[HUD Assigned To] NOT IN ('Chelsea Daniel') OR D.[HUD Assigned To] IS NULL)  AND B.[Document] IS NOT NULL THEN 'Exception Already Opened - Move to Chelsea'
WHEN A.[ILD_Flag] in ('Active ILD') AND D.[HUD Assigned To] IN ('Chelsea Daniel') AND B.[Document] IS NOT NULL THEN 'No Action Required - Active ILD - Exception Opened'
WHEN A.[ILD_Flag] in ('Inspection Complete') AND C.[TAG 2] is not null AND B.[Document] IS NOT NULL THEN 'Send to RG - Move to Blank'
WHEN A.[ILD_Flag] in ('Inspection Complete') AND D.[HUD Assigned To] IN ('Chelsea Daniel') AND B.[Document] IS NOT NULL AND C.[MCA %] >= 95 AND C.[Loan Status] in ('Active') AND C.[Tag 2] is null THEN 'Close Exception - Send to Floor'
WHEN A.[ILD_Flag] in ('Inspection Complete') AND (D.[HUD Assigned To] NOT IN ('Chelsea Daniel') OR D.[HUD Assigned To] IS NULL)  AND B.[Document] IS NOT NULL AND C.[MCA %] >= 97.5 AND C.[Loan Status] in('Active') AND C.[Tag 2] is Null THEN 'Close Exception - Notify Floor'
WHEN A.[ILD_Flag] in ('Inspection Complete') AND D.[HUD Assigned To] IN ('Chelsea Daniel') AND B.[Document] IS NOT NULL AND (C.[MCA %] < 95 or C.[Loan Status] NOT IN ('Active')) THEN 'Send to RG - Move to Blank'
WHEN A.[ILD_Flag] in ('Inspection Complete') AND(D.[HUD Assigned To] NOT IN ('Chelsea Daniel') OR D.[HUD Assigned To] IS NULL)  AND B.[Document] IS NOT NULL AND (C.[MCA %] < 97.5 or C.[Loan Status] NOT IN ('Active')) THEN 'Send to RG - No Reassign Needed'
WHEN A.[ILD_Flag] in ('Inspection Complete') AND D.[HUD Assigned To] IN ('Chelsea Daniel') AND B.[Document] IS NULL AND C.[MCA %] >= 97.5 AND C.[Loan Status] in ('Active') AND C.[Tag 2] is null THEN 'Exception Already Closed - Send to Floor'
WHEN A.[ILD_Flag] in ('Inspection Complete') AND (D.[HUD Assigned To] NOT IN ('Chelsea Daniel') OR D.[HUD Assigned To] IS NULL)  AND B.[Document] IS NULL THEN 'No Action Required - ILD Closed - Exception Closed'
WHEN A.[ILD_Flag] in ('Incurable Review') AND (C.[Loan Status] NOT IN ('Active') or C.[Tag 2] IS NOT NULL) THEN 'No Action Required - Non-Workable'
WHEN A.[ILD_Flag] IN ('Incurable Review') AND A.[Incurable Results] >= .95 AND D.[HUD Status] IN ('HUD Approved','HUD Approval','Pkg Submitted to HUD','Resubmitted to HUD') THEN 'Submitted to HUD - Incurable ILD'
WHEN A.[ILD_Flag] in ('Incurable Review') AND B.[Document] IS NOT NULL AND A.[Incurable Results] >= .95 THEN ('Request New Inspection')
WHEN A.[ILD_Flag] in ('Incurable Review') AND B.[Document] IS NULL AND A.[Incurable Results] >= .95 THEN ('Request New Inspection - Reopen Exception')
WHEN A.[ILD_Flag] in ('Incurable Review') AND B.[Document] IS NOT NULL AND B.[Exception Status] NOT IN ('Incurable') THEN ('Incurable Review')
WHEN A.[ILD_Flag] in ('Incurable Review') AND B.[Document] IS NOT NULL AND B.[Exception Status] IN ('Incurable') THEN ('Incurable Review')
WHEN A.[ILD_Flag] in ('Incurable Review') AND B.[Document] IS NULL THEN 'No Action Required - No Exception Opened - Incurable'
WHEN A.[ILD_Flag] NOT IN ('Active ILD') AND D.[HUD Assigned To] IN ('Chelsea Daniel') AND (C.[MCA %] < 97.5 OR C.[Loan Status] NOT IN ('Active') OR C.[TAG 2] is not null) THEN 'Move from Chelsea to Blank'
WHEN A.[ILD_Flag] NOT IN ('Active ILD') AND D.[HUD Assigned To] IN ('Chelsea Daniel') THEN 'Move from Chelsea'
WHEN A.[ILD_FLAG] IN ('Active ILD') AND (D.[HUD Assigned To] NOT IN ('Chelsea Daniel') OR D.[HUD Assigned To] IS NULL)  THEN 'Move to Chelsea'
ELSE 'Error'
END AS 'Action Flag'
FROM #ILDS A
LEFT JOIN #Exceptions B
ON A.[LoanNumber] = B.[Loan Number]
LEFT JOIN SharepointData.Dbo.HUDAssignLoans C
ON A.[LoanNumber] = C.[Loan Number]
LEFT JOIN SharepointData.Dbo.HUDAssignHUDStatus D
ON A.[LoanNumber] = D.[Loan Number]
LEFT JOIN SharepointData.Dbo.HUDAssignFinalReview E
ON A.[LoanNumber] = E.[Loan Number]
WHERE C.[Loan Number] NOT in ('755630.') AND (C.[TAG 2] NOT IN ('Servicer Cure') OR C.[TAG 2] IS NULL) AND C.[Loan Status] not in ('Liquidated/Held for Sale','Paid Off','Liquidated/Assigned to HU','Liquidated/3rd Party Sale','Called Due: Death','Inactive','Refer for FCL: Death') 
AND (C.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
C.[Group] is null)
ORDER BY A.ILD_Flag,A.[Complete Results],[HUD Assigned To],B.[Document]

DROP TABLE #Exceptions,#ILDS