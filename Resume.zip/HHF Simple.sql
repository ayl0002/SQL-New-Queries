SELECT Loan_Nbr,cast(TXN_PST_DT as date) 'Post Date',cast(TXN_EFF_DT as date) 'Effective Date',CELINK_TXN_CD
FROM [Reverse_DW].[dbo].[RM_MASTER_TXN_VW]

WHERE CELINK_TXN_CD in ('105G') AND Loan_Nbr In ('748084',
'845957',
'873453') 