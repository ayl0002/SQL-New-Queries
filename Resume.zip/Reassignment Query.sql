select 
LOAN_NBR
,FNL_RVW_ASGN_TO_NM
,ISNULL(AGNT_NM,'Not Active Producer') AS ACTIVE_PRODUCER
,MGR_NM
,EFF_DTTM
,FNL_RVW_STS_DESC

from reverse_dw.dbo.HUD_ASGN_FNL_RVW

LEFT JOIN (Select * from reverse_dw.dbo.TP_HUD_RSTR Where GRP_NM in ('Producer')) R ON R.AGNT_NM = FNL_RVW_ASGN_TO_NM


where  LOAN_NBR in ('1086705')
