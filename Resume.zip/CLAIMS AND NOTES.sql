/****** Script for SelectTopNRows command from SSMS  ******/


select base.*, case

when [HUD Preliminary Title Approval] is not null and [Original Note Sent to HUD] is null then 'N' 
else 'Y' end as 'Note Sent Status', case when [Original Note Sent to HUD] is null then datediff(day,[HUD Preliminary Title Approval],getdate())
when [Original Note Sent to HUD] is not null then datediff(day,[HUD Preliminary Title Approval],[Original Note Sent to HUD]) end as 'Title to Note Aging'
from
(SELECT 
  
 a.[Loan Number]
,a.Investor
,a.[Pool Name]
,a.[FHA Case Number]
,a.[Loan Status]
,B.[HUD Status]
,b.[HUD Status Date]
,B.[HUD Assigned To]
,b.[HUD Status Updated By]
,A.[MCA %]
,A.MCARange
,A.UPB
,b.[HUD Preliminary Title Approval]
,b.[Original Note Received by HUD]
,b.[Original Note Sent to HUD]
,b.[Initial Claim Filed]
,b.[FNMA Approval Required]
,b.[FNMA Approved Date]
,b.[FNMA Denied Date]

FROM 
  
[SharepointData].[dbo].[HUDAssignLoans]a
  
join [SharepointData].[dbo].[HUDAssignHUDStatus] b
on a.[Loan Number]= b.[Loan Number]

join [SharepointData].[dbo].[HUDAssignFinalReview] c
on a.[Loan Number]= c.[Loan Number]
  
where 

CAST (b.[HUD Preliminary Title Approval] as date) >= '2020-02-01'
or CAST (b.[Original Note Sent to HUD] as date) >= '2020-02-01') base
where [HUD Preliminary Title Approval] is not null

