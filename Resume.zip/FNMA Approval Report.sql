SELECT 
A.[Loan Number]
	,CASE
	WHEN L.[pool name] IN ('WELLSFARG') THEN 'WELLSFARGO'
	ELSE 'EBOUTIQUE'
	END AS 'POOL NAME'

,CONVERT(NVARCHAR(10),A.[FNMA Approval Requested Date],101) as 'FNMA Request Date'

	,CASE
	WHEN A.[FNMA Denied Date] IS NOT NULL THEN 'DENIED'
	WHEN A.[FNMA Approval Requested Date] IS NOT NULL AND A.[FNMA Denied Date] IS NULL AND A.[FNMA Approved Date] IS NULL THEN 'PENDING'
	WHEN A.[FNMA Approved Date] IS NOT NULL THEN 'APPROVED'
	END AS 'FNMA DECISION'
	
	,CASE
	WHEN A.[FNMA Denied Date] IS NOT NULL THEN CONVERT(NVARCHAR(10),A.[FNMA Denied Date],101)
	ELSE  CONVERT(NVARCHAR(10),A.[FNMA Approved Date],101)
	END AS 'DECISION DATE'
	
,A.[FNMA Owned Loss]
,A.[MRC Owned Loss]
,case
	when a.[HUD Status] IN ('Pkg Submitted to HUD','Not Started') then B.[Final Review Status]
	else a.[HUD Status]
	end as 'Status'

FROM SharepointData.dbo.HUDAssignHUDStatus A
LEFT JOIN SharepointData.dbo.HUDAssignFinalReview B
ON B.[Loan Number]= A.[Loan Number]
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNLOANS L
ON L.[LOAN NUMBER]=A.[LOAN NUMBER]

where a.[FNMA Approval Requested Date] is NOT NULL  
Order by A.[FNMA Approval Requested Date] desc