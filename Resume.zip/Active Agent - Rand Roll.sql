Select B.*
from --SharepointData.DBO.HUDAssignHUDStatus A 
--LEFT JOIN 
[VRSQLRODS\RODS_PROD].reverse_dw.dbo.TP_HUD_RSTR B
--ON A.[HUD Assigned To] = B.[Agnt_NM]
Where GRP_NM in ('Producer')