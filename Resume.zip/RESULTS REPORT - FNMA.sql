SELECT distinct
base.[LOAN_nbr]
,a.[tag 2]
,a.[incurable flag]
,base.[status_description]
,CASE WHEN status_description = 'Active' THEN 'Active'
WHEN status_description = 'Liquidated/Assigned to HU' THEN 'Liquidated/Assigned to HUD'
ELSE 'Default / Not Active'
END AS 'Active / Not Active'
,a.Stage
,[mca_percent]
,a.[group]
,a.[pool name]
,A.UPB
,CASE
	WHEN [mca_percent] < 97.5 THEN '< 97.5'
	WHEN [mca_percent] < 98 THEN '97.5 - 97.99'
	WHEN [mca_percent] < 100 THEN '98.00 - 99.99'
	WHEN [mca_percent] < 105 THEN '99.99 - 104.99'
	ELSE '>= 105'
	END AS 'MCA Flag'
,b.[final review assigned to]
,c.[hud assigned to]
,r.mgr_nm
,r.st_loc
,t.[Open Exceptions]
,T.OpenCurative
,T.OpenHACG
,case
	when C.[HUD Status] IN ('Pkg Submitted to HUD','resubmitted to hud','rebuttal to hud') then 'Submitted'
	when c.[hud status] in ('hud approved') then 'HUD Approved'
	WHEN [HUD Preliminary Title Approval] IS NOT NULL AND [HUD Preliminary Title Denial Date] IS NULL THEN 'PTA Granted'
	WHEN c.[hud status] in ('HUD Denied') then 'HUD Denied'
	else 'Not Submitted'
	end as 'Status'
,[HUD Preliminary Title Approval],[HUD Preliminary Title Denial Date]
,C.[HUD Status]
,B.[Final Review Status]
--,CASE
	--WHEN b.[Final Review Status Date] > C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),b.[Final Review Status Date],101)
	--WHEN b.[Final Review Status Date] < C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),C.[HUD Status Date],101)
	--ELSE CONVERT(NVARCHAR(10),b.[Final Review Status Date],101) END AS 'Last Updated'

--,CASE
	--WHEN B.[Final Review Comment] > C.[HUD Status Comment] THEN B.[Final Review Comment]
	--WHEN B.[Final Review Comment] < C.[HUD Status Comment] THEN C.[HUD Status Comment]
	--ELSE B.[Final Review Comment]  END AS 'Last Comment'
,[FNMA Approval Requested Date]
,[FNMA Approved Date]
,CASE WHEN [FNMA Approved Date] IS NOT NULL AND [FNMA Approved Date] >  ISNULL([FNMA Denied Date],'1/1/1900') THEN 'Y' ELSE 'N' END AS 'FNMA Approved'
,[FNMA Denied Date]
,isnull(EXCP_COUNT,0) AS 'EXCP_COUNT'
FROM SHAREPOINTDATA.dbo.HUDAssignLoans A
LEFT JOIN SHAREPOINTDATA.dbo.HUDAssignFinalReview B
ON a.[LOAN NUMBER]=b.[LOAN NUMBER] 
LEFT JOIN (SELECT [LOAN NUMBER],[EXCEPTION ID],[DOCUMENT],[ISSUE], [EXCEPTION ASSIGNED TO],[EXCEPTION REQUEST DATE],[EXCEPTION STATUS],[EXCEPTION STATUS DATE],[Exception Status Updated By],[Work Group],[Gift Card Letter Sent],[Sent For Gift Card Processing],[Ledger Sent for Gift Card Processing],[Non GC Letter Document Returned],[Sent to Inspection Vendor],[Ledger Letter Sent 1],[Ledger Letter Sent 2] FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS WHERE ([DOCUMENT] = 'Loss Draft' OR [ISSUE] = 'Forced placed Insurance' OR isnull([Work Group],'No Group') IN ('Curative','LandTran')) AND [EXCEPTION STATUS] NOT IN ('RESOLVED','Resolved by ML','CLOSED','NOT VALID','CLOSED WITH VENDOR'))E--WHERE [EXCEPTION STATUS] NOT IN ('RESOLVED','CLOSED','NOT VALID','CLOSED WITH VENDOR')) E --[Document] in ('Current OCC Cert')) E-- AND [EXCEPTION STATUS] NOT IN ('RESOLVED','CLOSED','NOT VALID','CLOSED WITH VENDOR')) E
ON A.[LOAN NUMBER]=E.[Loan Number]
LEFT JOIN 
(SELECT EXCP1.[Loan Number],MAX(EXCP_COUNT) AS 'EXCP_COUNT' FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS EXCP1 LEFT JOIN 
	(SELECT [LOAN NUMBER],[EXCEPTION ID],[DOCUMENT],[ISSUE], [EXCEPTION ASSIGNED TO],[EXCEPTION REQUEST DATE],[EXCEPTION STATUS],[EXCEPTION STATUS DATE],[Exception Status Updated By],[Work Group],[Gift Card Letter Sent],[Sent For Gift Card Processing],[Ledger Sent for Gift Card Processing],[Non GC Letter Document Returned],[Sent to Inspection Vendor],[Ledger Letter Sent 1],[Ledger Letter Sent 2],ROW_NUMBER () OVER (Partition By [Loan Number] Order By [Document]) AS 'EXCP_COUNT' FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS WHERE [EXCEPTION STATUS] NOT IN ('RESOLVED','CLOSED','NOT VALID','CLOSED WITH VENDOR','Resolved by ML'))EXCP2--WHERE [EXCEPTION STATUS] NOT IN ('RESOLVED','CLOSED','NOT VALID','CLOSED WITH VENDOR')) E --[Document] in ('Current OCC Cert')) E-- AND [EXCEPTION STATUS] NOT IN ('RESOLVED','CLOSED','NOT VALID','CLOSED WITH VENDOR')) E
	ON EXCP1.[Loan Number] = EXCP2.[Loan Number] GROUP BY EXCP1.[Loan Number]) F
ON A.[LOAN NUMBER]=F.[Loan Number]
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNHUDSTATUS C
ON a.[LOAN NUMBER]=c.[LOAN NUMBER]
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignLoanExceptionTotals T
on a.[Loan Number]=T.[Loan Number]
LEFT JOIN (SELECT [Loan Number],[Exception ID],[Gift Card Letter Sent],[Gift Card Letter Sent 2],[Gift Card Letter Sent 3] FROM SharepointData.Dbo.HUDAssignExceptions) EXCP
ON E.[Exception ID] = EXCP.[Exception ID]
left join [VRSQLRODS\RODS_PROD].reverse_dw.[dbo].[TP_HUD_RSTR] r
on CAST(c.[HUD Assigned To] AS NVarchar) =CAST(r.agnt_nm AS NVARCHAR)
RIGHT JOIN Tact_REv.Dbo.champbase base
ON CAST(a.[Loan Number] AS NVARCHAR) = CAST(base.[Loan_Nbr] AS NVARCHAR)


WHERE 1=1 -- AND C.[HUD Status] NOT IN ('Pkg Submitted to HUD','resubmitted to hud','rebuttal to hud') AND [MCA %] <96.5 AND A.[Loan Status] IN ('Active') AND A.[Tag 2] IS NULL AND A.[Incurable Flag] IN ('0')--E.[Exception ID] IN ()--A.[MCA %] BETWEEN 97.5 AND 98 --
--AND E.[Document] = 'Current OCC Cert'
AND base.[Loan_Nbr] IN ('2428669',
'2729925',
'2783853',
'1010320',
'1012640',
'1017043',
'2316904',
'2689723',
'2693035',
'2698520',
'2708418',
'2718580',
'2729709',
'2731736',
'2732635',
'2742067',
'2752106',
'2752413',
'2805508',
'2736504',
'2689949',
'2749428',
'2312409',
'1024984',
'2693193',
'2700034',
'2715996',
'2720049',
'2726261',
'2731246',
'1011730',
'1154756',
'2676933',
'2692170',
'2707177',
'2730336',
'2762530',
'2759136',
'2777899')



--[Exception Status] IN ('Resolved') AND [Sent For Gift Card Processing] IS NULL AND
--E.[Exception ID] IN ()



