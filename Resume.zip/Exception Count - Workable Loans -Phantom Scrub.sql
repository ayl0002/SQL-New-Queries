CREATE TABLE ##excp_match
(excp_id INT,Document NVARCHAR(MAX))

INSERT INTO ##excp_match
VALUES
('299676','Flood Insurance'),
('299678','Note-First'),
('299733','Flood Insurance'),
('299735','Note-First'),
('299795','Flood Insurance'),
('299797','Note-First'),
('299864','Flood Insurance'),
('299867','Note-First'),
('299907','Flood Insurance'),
('299909','Note-First'),
('299962','Flood Insurance'),
('478302','Title Policy'),
('483251','Title Policy'),
('484909','HUD1'),
('484915','Note-First'),
('484918','Note-Second'),
('490866','Mortgage-Second'),
('301223','Title Policy'),
('301261','Title Policy'),
('301277','Title Policy'),
('301293','Title Policy'),
('301309','Title Policy'),
('297752','Loan Agreement'),
('297756','Loan Agreement'),
('297760','Loan Agreement'),
('297764','Loan Agreement'),
('297768','Loan Agreement'),
('302651','Note-First'),
('302655','Orig Loan App'),
('302657','Orig Appraisal'),
('278968','Assignments'),
('490474','HOLD')

