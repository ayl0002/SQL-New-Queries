--DEFUNCT: Need to Calculate 97.0 + crossover date to make query work--

--Default Scrub--
SELECT Loan_Nbr,ISNULL([LOAN_STS_DESC],'No Default') AS 'LOAN_STS_DESC',ISNULL([EFF_DTTM],'No Default') AS 'EFF_DTTM'
INTO #Default
FROM Reverse_DW.DBO.HUD_ASGN_LOANS 
WHERE [LOAN_STS_DESC] NOT IN('Active',	'Inactive',	'Liquidated/3rd Party Sale',	'Liquidated/Assigned to HU',	'Liquidated/Assigned to HUD',	'Liquidated/Held for Sale',	'Liquidated/Pre-Foreclosure Short Sale',	'Loan Paid in Full',	'Paid Off',	'Refer for FCL: Death')

AND Loan_Nbr IN ('1151893',
'2780510',
'2784854',
'2786457',
'2788277',
'2500383',
'2773009',
'2779287',
'2780166',
'2780348',
'2780827',
'2780985',
'2781748',
'2791409',
'2794765',
'2798747',
'2799793',
'2806417',
'2811824',
'2816705',
'2842115',
'2862110',
'2743832',
'2758453')



--Exception Scrub--
SELECT A.Loan_Nbr,ROW_NUMBER() OVER (Partition BY A.Loan_Nbr ORDER BY A.Loan_Nbr) AS 'ExcpCount'
INTO #Excp
FROM Reverse_DW.[dbo].[HUD_ASGN_EXCP_EDW] A
RIGHT JOIN #Default B
ON A.Loan_Nbr = B.LOAN_NBR
WHERE Curr_Ind IN ('Y') AND A.Loan_Nbr IS NOT NULL
ORDER BY Loan_Nbr,EXCPCOUNT DESC

--FINAL--
SELECT A.LOAN_NBR,CAST(a.MCA_CROSSOVER_DT AS DATE)
,CASE 
	WHEN CAST(a.MCA_CROSSOVER_DT AS DATE) >= CAST(C.EFF_DTTM AS DATE) AND A.[LOAN_STS_DESC] NOT IN ('No Default') THEN 'Loan In Default 
	ELSE 'No Default'
END AS 'Default Flag'



,B.ExcpCount
FROM  reverse_dw.[dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] A
LEFT JOIN #Default C
	ON CAST(A.Loan_Nbr AS VARCHAR) = CAST(C.Loan_Nbr AS VARCHAR)
LEFT JOIN (SELECT Loan_Nbr,MAX(ExcpCount) AS 'ExcpCount' FROM #Excp) B
	ON CAST(A.Loan_Nbr AS VARCHAR) = CAST(B.Loan_Nbr AS VARCHAR)

WHERE C.[LOAN_STS_DESC] IS NOT NULL

DROP TABLE #Default,#EXCP