SET NOCOUNT ON

SELECT [Loan Number],[Document],Row_Number() OVER (Partition By [Loan Number] ORDER BY [Document]) AS 'RN'
INTO #Exceptions
FROM SharepointData.DBO.HUDAssignExceptions
WHERE [Exception Status] NOT IN ('RESOLVED','CLOSED','NOT VALID','CLOSED WITH VENDOR')

SELECT
A.[LOAN NUMBER]
,case
	when B.[Final Review Status] IN ('Pending QC') THEN B.[Final Review Status]
	--WHEN C.[HUD Status] IN ('Pkg Submitted to HUD','Not Started') then B.[Final Review Status]
	else C.[HUD Status]
end as 'Status'	
,B.[Final Review Status]
INTO #STATUS
FROM SHAREPOINTDATA.DBO.HUDASSIGNFINALREVIEW B
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNLOANS A
ON A.[LOAN NUMBER]=B.[LOAN NUMBER]
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNHUDSTATUS C
ON A.[LOAN NUMBER]=C.[LOAN NUMBER]

SELECT
[LoanNumber]
,MAX([DateSubmittedToHUD]) as 'Max Submission Date'
INTO #SUB
FROM SHAREPOINTDATA.dbo.HUDAssignDateSubmittedResubmittedtoHUD
GROUP BY [LoanNumber]

SELECT
A.[LOAN NUMBER],GETDATE() AS 'Refreshed'
,RN1.Document AS 'Exception 1'
,RN2.Document AS 'Exception 2'
,RN3.Document AS 'Exception 3'
,a.[Loan Status]
,a.[MCA %]
,CASE 
WHEN a.[MCA %] >= 100 THEN '>=100'
WHEN a.[MCA %] >= 99 THEN '>=99.0'
WHEN a.[MCA %] >= 98.0 THEN '>=98.0'
WHEN a.[MCA %] >= 97.5 THEN '>=97.5'

END AS 'MCA Flag'
,S.STATUS AS 'HUD Status'
,B.[Final Review Status]
,CONVERT(NVARCHAR(10),C.[HUD Preliminary Title Denial Date],101) AS 'DENIAL DATE'
,CAST(C.[HUD Preliminary Title Approval] AS DATE) AS 'PTA Date'
,CASE
	when datediff(day,cast(C.[HUD Preliminary Title Denial Date] as date),getdate()) <= 0  then '0 to 15'
	when datediff(day,cast(C.[HUD Preliminary Title Denial Date] as date),getdate()) between 0 and 15 then '0 to 15'
	when datediff(day,cast(C.[HUD Preliminary Title Denial Date] as date),getdate()) between 16 and 30 then '16 to 30'
	when datediff(day,cast(C.[HUD Preliminary Title Denial Date] as date),getdate()) between 31 and 60 then '31 to 60'
	when datediff(day,cast(C.[HUD Preliminary Title Denial Date] as date),getdate()) between 61 and 90 then '61 to 90'
	when datediff(day,cast(C.[HUD Preliminary Title Denial Date] as date),getdate()) between 91 and 120 then '91 to 120'
	when datediff(day,cast(C.[HUD Preliminary Title Denial Date] as date),getdate()) >= 121 then '121+'
	END AS 'DENIAL AGING'
,C.[RESUBMIT TO HUD COUNT]
,case
	when convert(nvarchar(10),sub.[Max Submission Date],101)>= cast(C.[HUD Preliminary Title Denial Date] as date) then convert(nvarchar(10),sub.[Max Submission Date],101)
	else 'NULL'
	end as 'Resubmit Date'
,case

	when DATEDIFF(day,cast(C.[HUD Preliminary Title Denial Date] as date),convert(nvarchar(10),sub.[Max Submission Date],101)) between 0 and 3 then '0 to 3'
	when DATEDIFF(day,cast(C.[HUD Preliminary Title Denial Date] as date),convert(nvarchar(10),sub.[Max Submission Date],101)) between 4 and 15 then '4 to 15'
	when DATEDIFF(day,cast(C.[HUD Preliminary Title Denial Date] as date),convert(nvarchar(10),sub.[Max Submission Date],101)) between 16 and 30 then '16 to 30'
	when DATEDIFF(day,cast(C.[HUD Preliminary Title Denial Date] as date),convert(nvarchar(10),sub.[Max Submission Date],101)) between 31 and 60 then '31 to 60'
	when DATEDIFF(day,cast(C.[HUD Preliminary Title Denial Date] as date),convert(nvarchar(10),sub.[Max Submission Date],101)) between 61 and 90 then '61 to 90'
	when DATEDIFF(day,cast(C.[HUD Preliminary Title Denial Date] as date),convert(nvarchar(10),sub.[Max Submission Date],101)) between 91 and 120 then '91 to 120'
	when DATEDIFF(day,cast(C.[HUD Preliminary Title Denial Date] as date),convert(nvarchar(10),sub.[Max Submission Date],101)) >=121 then '121+'
	else 'NULL'
	end as 'Days to Conversion'
,B.[FINAL REVIEW ASSIGNED TO]
,C.[HUD Assigned To]
,T.[OPENCURATIVE]
,T.[OpenHACG]
,case
	when T.[OPENCURATIVE] + T.[OpenHACG] = 0 then '0'
	when T.[OPENCURATIVE] + T.[OpenHACG] = 1 then '1'
	when T.[OPENCURATIVE] + T.[OpenHACG] = 2 then '2'
	when T.[OPENCURATIVE] + T.[OpenHACG] >=3 then '3+'
	end as 'Open Exceptions'
	
,CASE
	WHEN b.[Final Review Status Date] > C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),b.[Final Review Status Date],101)
	WHEN b.[Final Review Status Date] < C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),C.[HUD Status Date],101)
	ELSE CONVERT(NVARCHAR(10),b.[Final Review Status Date],101) END AS 'Last Updated'
,CASE
	WHEN S.[Status] IN ('HUD APPROVED','HUD APPROVAL') THEN 'HUD Approved'
	WHEN S.[Status] IN ('RESUBMITTED TO HUD','REBUTTAL TO HUD','PKG SUBMITTED TO HUD') THEN 'Pending @ HUD'
	WHEN S.[Status] IN ('HUD DENIED') THEN 'Pipeline'
	ELSE 'NULL'
	END AS 'RESUBMIT STATUS'
,CASE
	WHEN A.[Incurable Flag] NOT IN('0') OR A.[TAG 2] IS NOT NULL THEN 'INCURABLE/TAG2'
	WHEN A.[MCA %] < '97.5' THEN 'NOT MCA ELIGIBLE'
	WHEN A.[Loan Status] NOT IN ('ACTIVE') THEN 'INELIGIBLE LOAN STATUS'
	WHEN c.[HUD Assigned To] IN ('JAMES WARREN') THEN 'HUD LOC ADVANCE'
	WHEN c.[HUD Assigned To] IN ('CHELSEA DANIEL') THEN 'ACTIVE LOSS DRAFT'
	WHEN c.[HUD Assigned To] IN ('SHASTA PATTON') THEN 'ARM INTEREST'
	WHEN c.[HUD Assigned To] IN ('ROBERT GOUGH') THEN 'FPI'
	WHEN t.[OpenCurative] NOT IN ('0') THEN 'WORKABLE-CURATIVE'
	ELSE 'WORKABLE'
	END AS 'PIPELINE STATUS'
,r.[MGR_NM]
,r.[ST_LOC]


FROM SHAREPOINTDATA.DBO.HUDASSIGNLOANS A
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNFINALREVIEW B
ON A.[LOAN NUMBER]=B.[LOAN NUMBER]
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNHUDSTATUS C
ON A.[LOAN NUMBER]=C.[LOAN NUMBER]

LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNLOANEXCEPTIONTOTALS T
ON A.[LOAN NUMBER]=T.[LOAN NUMBER]
LEFT JOIN #STATUS S
ON A.[LOAN NUMBER]=S.[LOAN NUMBER]
left join [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_HUD_RSTR] R
ON c.[hud assigned to]=R.[AGNT_NM]
left join #SUB sub
on a.[Loan Number]=sub.LoanNumber
LEFT JOIN (SELECT * FROM #Exceptions WHERE RN IN ('1')) RN1
ON A.[Loan Number] = RN1.[Loan Number]
LEFT JOIN (SELECT * FROM #Exceptions WHERE RN IN ('2')) RN2
ON A.[Loan Number] = RN2.[Loan Number]
LEFT JOIN (SELECT * FROM #Exceptions WHERE RN IN ('3')) RN3
ON A.[Loan Number] = RN3.[Loan Number]

WHERE C.[HUD Preliminary Title Denial Date] IS NOT NULL AND B.[Loan Status] IN ('Active') AND [MCA %] >= 97.5
AND CAST(ISNULL(C.[HUD Preliminary Title Approval],CAST('1/1/1900' AS DATE)) AS DATE) <= CAST(C.[HUD Preliminary Title Denial Date] AS DATE)
AND S.[Status] NOT IN ('Rebuttal to HUD','Resubmitted to HUD') AND B.[Tag 2] IS NULL AND [Incurable Flag] IN ('0')

ORDER BY C.[HUD Preliminary Title Denial Date] ASC

DROP TABLE #STATUS, #SUB, #Exceptions