select
a.[loan number]
,a.[loan status]
,e.[exception id]
,e.[Exception Status]
,case
	when [exception status] in ('closed','resolved','not valid','incurable') then 'Dont Send'
	when a.[loan status] not in ('active') then 'Send'
	else 'open'
	end as 'open/close'

from sharepointdata.dbo.hudassignexceptions e
left join sharepointdata.dbo.hudassignloans a
on e.[loan number]=a.[loan number]

where [exception id] in ('258492',
'433098',
'428894',
'427425',
'327281',
'437734',
'332953',
'426364',
'425612',
'428018',
'291679',
'342098',
'428886',
'338786',
'433910',
'355334',
'287432',
'433555',
'336402',
'257744',
'435675',
'435627',
'435365',
'434643',
'435614',
'434318',
'427826')