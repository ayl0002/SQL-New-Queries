SELECT distinct
A.[LOAN NUMBER]
,a.[tag 2]
,a.[incurable flag]
,a.[loan status]
,a.Stage
,a.[mca %]
,e.[Exception ID]
,case
	when c.[hud status] in ('not started') then b.[final review assigned to]
	else c.[hud assigned to]
	end as 'Agent'
,r.mgr_nm
,r.st_loc
,t.[Open Exceptions]
,T.OpenCurative
,T.OpenHACG
,case
	when C.[HUD Status] IN ('Pkg Submitted to HUD','Not Started') then B.[Final Review Status]
	else C.[HUD Status]
	end as 'Status'

,CASE
	WHEN b.[Final Review Status Date] > C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),b.[Final Review Status Date],101)
	WHEN b.[Final Review Status Date] < C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),C.[HUD Status Date],101)
	ELSE CONVERT(NVARCHAR(10),b.[Final Review Status Date],101) END AS 'Last Updated'

,CASE
	WHEN B.[Final Review Comment] > C.[HUD Status Comment] THEN B.[Final Review Comment]
	WHEN B.[Final Review Comment] < C.[HUD Status Comment] THEN C.[HUD Status Comment]
	ELSE B.[Final Review Comment]  END AS 'Last Comment'
,E.Document as 'excp1'
,E.Issue as 'issue1'
,E.[Exception Status] as 'status1'
,e2.Document as 'excp2'
,e2.[Issue] as 'issue2'
,e2.[Exception Status] as 'status2'

FROM SHAREPOINTDATA.dbo.HUDAssignLoans A
LEFT JOIN SHAREPOINTDATA.dbo.HUDAssignFinalReview B
ON a.[LOAN NUMBER]=b.[LOAN NUMBER]
LEFT JOIN (SELECT [LOAN NUMBER],[EXCEPTION ID],[DOCUMENT],[ISSUE], [EXCEPTION ASSIGNED TO],[EXCEPTION REQUEST DATE],[EXCEPTION STATUS],[EXCEPTION STATUS DATE], ROW_NUMBER () OVER (PARTITION BY [LOAN NUMBER] ORDER BY [Exception ID] asc)RN
FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS 
WHERE [EXCEPTION STATUS] NOT IN ('RESOLVED','CLOSED','NOT VALID','CLOSED WITH VENDOR')) E
ON A.[LOAN NUMBER]=E.[Loan Number] and e.RN=1
LEFT JOIN (SELECT [LOAN NUMBER],[EXCEPTION ID],[DOCUMENT],[ISSUE], [EXCEPTION ASSIGNED TO],[EXCEPTION REQUEST DATE],[EXCEPTION STATUS],[EXCEPTION STATUS DATE], ROW_NUMBER () OVER (PARTITION BY [LOAN NUMBER] ORDER BY [Exception ID] asc)RN
FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS 
WHERE [EXCEPTION STATUS] NOT IN ('RESOLVED','CLOSED','NOT VALID','CLOSED WITH VENDOR')) E2
ON e.[LOAN NUMBER]=E2.[Loan Number] and E2.RN=2
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNHUDSTATUS C
ON a.[LOAN NUMBER]=c.[LOAN NUMBER]
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignLoanExceptionTotals T
on a.[Loan Number]=T.[Loan Number]
left join [VRSQLRODS\RODS_PROD].reverse_dw.[dbo].[TP_HUD_RSTR] r
on c.[HUD Assigned To]=r.agnt_nm

WHERE A.[Loan Number] IN ('2695300',
'848887',
'2682225',
'2786059',
'759220',
'867642',
'1020457',
'2446319',
'2482699',
'2599085',
'2616974',
'741861',
'890082')