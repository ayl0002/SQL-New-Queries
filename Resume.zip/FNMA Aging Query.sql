SET NOCOUNT ON 
SELECT A.[Loan Number]
,GETDATE() AS 'Last Refreshed'
,A.[Loan Status],B.[HUD Status],CAST(A.[MCA %] AS FLOAT(2)) AS 'MCA %',C.[DT_SBMT_TO_HUD]
,CAST(DATEDIFF(DAY,CAST(C.[DT_SBMT_TO_HUD] AS DATE),CAST(GETDATE() AS DATE)) AS NVarchar(Max)) + ' Days' AS 'Aging to HUD'
,CAST(DATEDIFF(DAY,CAST(B.[FNMA Approval Requested Date] AS DATE),CAST(GETDATE() AS DATE)) AS NVarchar(Max)) + ' Days' AS 'Aging to FNMA'
,CASE
WHEN (B.[FNMA Approval Required] IN ('Yes') AND B.[FNMA Approved Date] IS NULL AND A.[Loan Status] IN ('Liquidated/Assigned to HU')) THEN 'ASSIGNED NO FNMA APPROVAL'
ELSE B.[FNMA Approval Indicator]
END AS 'FNMA Approval Indicator'
,B.[FNMA Approval Requested Date]
FROM SharepointData.Dbo.HUDAssignLoans A
LEFT JOIN SharepointData.Dbo.HUDAssignHUDStatus B
ON A.[Loan Number] = B.[Loan Number]
LEFT JOIN (SELECT Loan_Nbr,MAX([DT_SBMT_TO_HUD]) AS 'DT_SBMT_TO_HUD' FROM [VRSQLRODS\RODS_PROD].Reverse_DW.DBO.HUD_ASSGN_DT_SBMT_RESBMT GROUP BY Loan_NBR) C
ON A.[Loan Number] = C.[Loan_Nbr]
WHERE (B.[FNMA Approval Requested Date] IS NOT NULL AND A.[Loan Status] IN ('Active') AND A.[Tag 2] is null AND A.[Incurable Flag] IN ('0') AND B.[HUD Status] IN ('Pkg Submitted to HUD','Resubmitted to HUD','Rebuttal to HUD','HUD Approved','HUD Approval') AND [FNMA Approval Indicator] IN ('FNMA Approval Requested')) 

ORDER BY ('FNMA Approval Indicator') ASC

