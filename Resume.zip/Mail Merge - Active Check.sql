SELECT distinct
A.[LOAN NUMBER]
,a.[tag 2]
,a.[incurable flag]
,a.[loan status]
,a.Stage
,a.[mca %]
,e.[Exception ID]
,case
	when c.[hud status] in ('not started') then b.[final review assigned to]
	else c.[hud assigned to]
	end as 'Agent'
,r.mgr_nm
,r.st_loc
,t.[Open Exceptions]
,T.OpenCurative
,T.OpenHACG
,case
	when C.[HUD Status] IN ('Pkg Submitted to HUD','resubmitted to hud','rebuttal to hud') then 'Submitted'
	when c.[hud status] in ('hud approved') then 'HUD Approved'
	else 'Not Submitted'
	end as 'Status'

,CASE
	WHEN b.[Final Review Status Date] > C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),b.[Final Review Status Date],101)
	WHEN b.[Final Review Status Date] < C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),C.[HUD Status Date],101)
	ELSE CONVERT(NVARCHAR(10),b.[Final Review Status Date],101) END AS 'Last Updated'

,CASE
	WHEN B.[Final Review Comment] > C.[HUD Status Comment] THEN B.[Final Review Comment]
	WHEN B.[Final Review Comment] < C.[HUD Status Comment] THEN C.[HUD Status Comment]
	ELSE B.[Final Review Comment]  END AS 'Last Comment'
,case
	when E.Document is null then 'No Issue'
	when e.[Document] is not null then e.[Document]
	end as 'Document'
,E.Issue
,E.[Exception Status]

FROM SHAREPOINTDATA.dbo.HUDAssignLoans A
LEFT JOIN SHAREPOINTDATA.dbo.HUDAssignFinalReview B
ON a.[LOAN NUMBER]=b.[LOAN NUMBER]
LEFT JOIN (SELECT [LOAN NUMBER],[EXCEPTION ID],[DOCUMENT],[ISSUE], [EXCEPTION ASSIGNED TO],[EXCEPTION REQUEST DATE],[EXCEPTION STATUS],[EXCEPTION STATUS DATE] FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS WHERE [DOCUMENT] IN ('Death Cert HACG','HOA','Trust - HACG','Proof of Repair','Current Occ Cert','Tax Bill') AND [EXCEPTION STATUS] NOT IN ('RESOLVED','CLOSED','NOT VALID','CLOSED WITH VENDOR')) E
ON A.[LOAN NUMBER]=E.[Loan Number]
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNHUDSTATUS C
ON a.[LOAN NUMBER]=c.[LOAN NUMBER]
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignLoanExceptionTotals T
on a.[Loan Number]=T.[Loan Number]
left join [VRSQLRODS\RODS_PROD].reverse_dw.[dbo].[TP_HUD_RSTR] r
on c.[HUD Assigned To]=r.agnt_nm

WHERE A.[Loan Number] IN ()