select
a.loan_nbr
,a.status_description
,a.pool_name
,l.[GRP_DESC]
,a.[MCA_PERCENT]
   ,case 
	when a.[MCA_PERCENT] between '97.50' and '99.99' then '97.5-99.99'
	when a.[MCA_PERCENT]>= '100.00' then '100+'
	else '<97.49'
	end as 'MCA Bucket'
,c.[HUD_ASGN_TO_NM]
,r.[MGR_NM]
,r.[ST_LOC]
,cast(c.[HUD_PRELIM_TTL_APRVL_DT]as date) as 'HUD_PRELIM_TTL_APRVL_DT'
,e.[EXCP_ID]
,cast(e.[EXCP_RQST_DTTM] as date) as 'Exception Request Date'
,case
	when datediff(day,cast(e.[EXCP_RQST_DTTM] as date),getdate()) <= 30 then '<= 30'
	when datediff(day,cast(e.[EXCP_RQST_DTTM] as date),getdate()) between 31 and 60 then '31 to 60'
	when datediff(day,cast(e.[EXCP_RQST_DTTM] as date),getdate()) >=61 then '61+'
	end as 'Exception Aging'
,e.[EXCP_STS_DESC]
,case
	when flag.[hhf flag] is not null then 'Yes'
	else 'No'
	end as 'Hardest Hit Funds Flag'
,case
	when e.[EXCP_ID] Is null and flag.[HHF Flag] is not null then 'Review for New Inflow'
	when e.[EXCP_ID] is null and flag.[HHF Flag] is null then 'Potential New Inflow - LEGACY'
	ELSE ' '
	end as 'New Inflow'

,case
	when c.[HUD_PRELIM_TTL_APRVL_DT] is not null and c.[HUD_STS_DESC] in ('hud approved','hud approval') and a.status_description in ('active','Liquidated/Assigned to HU')
	then 'Review for Sending Check/Tran 43A'
	ELSE ' '
	end as 'Sending Check'
,ti.TAX_AND_INS_SET_ASIDE_AMT

from (select l.* from [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[HUD_ASGN_LOANS] l where l.[LOAN_STS_DESC] not in ('paid off','inactive')and l.tag_2_val is null and l.[INCRBL_FLG_DESC] in ('0') and (l.[GRP_DESC] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
l.[GRP_DESC] is null)and l.curr_ind in ('y')) l
left join (select * from [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] a where a.[status_description] not in ('paid off','inactive'))a
 on l.loan_nbr=a.loan_nbr
left join (select c.* from reverse_dw.[dbo].[HUD_ASGN_HUD_STS] c where c.curr_ind in ('y'))c
on c.loan_nbr=a.loan_nbr
left join [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_HUD_RSTR] r
on c.[HUD_ASGN_TO_NM]=r.[AGNT_NM]
left join ( select x.[MOD_LOAN_NBR], sum(a.[PREPYMT_AMT]) as 'HHF Flag' 
	from [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[RVRS_LOAN_PPD] a
	left join [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[LOAN_NBR_CROSS_REF] x
	on a.loan_key=x.loan_key
	where a.curr_ind = 'Y' and a.[SRC_OF_FND] = '3' and a.prepay_type_cd = '83' 
	group by x.[MOD_LOAN_NBR])flag
on a.loan_nbr=flag.mod_loan_nbr
left join (select B.MOD_LOAN_NBR ,a.TAX_AND_INS_SET_ASIDE_AMT 
	from [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[RVRS_LOAN_BAL] A
	LEFT JOIN [VRSQLRODS\RODS_PROD].reverse_dw.[dbo].[LOAN_NBR_CROSS_REF] B
	on a.loan_key=b.loan_key
	where a.TAX_AND_INS_SET_ASIDE_AMT is not null and a.curr_ind in ('y')) TI
on a.Loan_nbr=TI.mod_loan_nbr
left join (SELECT
	[LOAN_NBR]
	,[EXCP_ID]
	,[DOC_DESC]
	,[ISSU_CD]
	,[EXCP_RQST_DTTM]
	,[EXCP_STS_DESC]
	FROM reverse_dw.[dbo].[HUD_ASGN_EXCP_EDW]
	WHERE [DOC_DESC] IN ('HARDEST HIT FUNDS') and curr_ind in ('y'))e
on a.[LOAN_NBR]=e.[LOAN_NBR]

where
--(a.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
--a.[Group] is null)--and
--c.[HUD Status] not in ('HUD Approved','Pkg Submitted to HUD','Resubmitted to HUD','Rebuttal to HUD') --
--and e.[Exception ID] is null 
--and flag.[HHF Flag] is not null 
TI.TAX_AND_INS_SET_ASIDE_AMT >= 1
ORDER BY ('New Inflow') DESC
