--Base Population--
SELECT A.[Loan Number],[Document],[Exception ID]
,CAST(D.[MCA_PERCENT] AS Float(2)) AS 'MCA %'
,CASE
WHEN D.[MCA_PERCENT] < 95 THEN '< 95'
WHEN D.[MCA_PERCENT] BETWEEN 95 AND 96.49 THEN '95 < 96.5'
WHEN D.[MCA_PERCENT] BETWEEN 96.5 AND 97.49 THEN '96.5 < 97.5'
WHEN D.[MCA_PERCENT] BETWEEN 97.5 AND 99.99 THEN '97.5 < 100'
WHEN D.[MCA_PERCENT] >= 100 THEN '>= 100'
ELSE 'Error'
END AS 'MCA Flag'
,B.[HUD Status],C.[Final Review Status],B.[HUD Assigned To],C.[Final Review Assigned To],CAST(CAST(A.[Incurable Flag] AS Float) AS INT) AS 'Incurable Flag'--,A.[Group]

FROM SharepointData.Dbo.HUDAssignLoans A
LEFT JOIN SharepointData.Dbo.HUDAssignHUDStatus B
ON A.[Loan Number] = B.[Loan Number]
LEFT JOIN SharepointData.Dbo.HUDAssignFinalReview C
ON A.[Loan Number] = C.[Loan Number]
LEFT JOIN Tact_Rev.[dbo].[champbase] D
ON A.[Loan Number] = D.Loan_Nbr
LEFT JOIN SharepointData.Dbo.HUDAssignExceptions E
ON A.[Loan Number] = E.[Loan Number]
WHERE A.[Loan Status] IN ('Active') AND  A.[TAG 2] IS NULL
AND (A.[GROUP] IN ('Grp 1 NSM Balance Sheet',	'Grp 3 GNMA excl BofA',	'Grp 2 FNMA',	'Grp 4 Trust / Private exlc BofA') OR A.[GROUP] IS NULL)
AND B.[HUD Status] IN ('Not Started','HUD Denied')
AND D.[MCA_PERCENT] >= 89

AND E.[Document] IN ('HUD1') AND [Exception Status] IN ('Incurable')

ORDER BY [MCA %] Desc




