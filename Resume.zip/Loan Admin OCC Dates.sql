
/*--Max Sent Date--
SELECT A.[Loan_Key] FROM [Reverse_DW].[dbo].[OCCUP_CERT] A
LEFT JOIN (SELECT Loan_Key,MAX(EFF_DTTM) AS 'EFF_DTTM' FROM [Reverse_DW].[dbo].[OCCUP_CERT] GROUP BY Loan_Key) B
ON	A.Loan_Key = B.Loan_Key AND CAST(A.EFF_DTTM AS DATE) = CAST(B.EFF_DTTM AS DATE)*/


--Results--
SELECT CAST(C.[Loan_Nbr] AS NVARCHAR) AS 'Loan_Nbr',C.[Current Year Anniversary of Loan Closing Date],C.[Prior Year Anniversary of Loan Closing Date],C.[Next Year Anniversary of Loan Closing Date],A.[EFF_DTTM],	A.[OCCUP_REC_DT],	A.[OCCUP_CERT_SENT_BEFORE_DUE_DT],	A.[OCCUP_CERT_SENT_ON_DUE_DT],	A.[OCCUP_CERT_SENT_AFTER_DUE_DT],	A.[OCCUP_CERT_RCVD_DT],	A.[BORR_OCCUP_STS_CD],	A.[COBORR_OCCUP_STS_CD],	A.[NOTE_TXT],	A.[CURR_IND],	A.[BUS_PROC_DT]
FROM [Reverse_DW].[dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] C
LEFT JOIN (SELECT * FROM Reverse_DW.DBO.HUD_ASGN_LOANS WHERE CURR_IND IN ('Y')) B
ON CAST(B.Loan_Nbr AS NVARCHAR) = CAST(C.Loan_Nbr AS NVARCHAR)
LEFT JOIN (SELECT A.* FROM [Reverse_DW].[dbo].[OCCUP_CERT] A
LEFT JOIN (SELECT Loan_Key,MAX(EFF_DTTM) AS 'EFF_DTTM' FROM [Reverse_DW].[dbo].[OCCUP_CERT] GROUP BY Loan_Key) B
ON	A.Loan_Key = B.Loan_Key WHERE A.Loan_Key = B.Loan_Key AND CAST(A.EFF_DTTM AS DATE) = CAST(B.EFF_DTTM AS DATE)) A
ON A.Loan_Key = B.Loan_Key

WHERE DATEPART(YYYY,A.EFF_DTTM) IN ('2019','2018') AND C.[Loan_Nbr] IN 
('848918')