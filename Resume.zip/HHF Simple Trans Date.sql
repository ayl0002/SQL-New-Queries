SELECT Loan_Nbr,cast(TXN_PST_DT as date) 'Post Date',cast(TXN_EFF_DT as date) 'Effective Date',ORGNL_TXN_DESC,CELINK_TXN_CD
FROM [Reverse_DW].[dbo].[RM_MASTER_TXN_VW]

WHERE ORGNL_TXN_DESC Like ('%Servicer%') AND Loan_Nbr In ('748084',
'845957',
'873453') 