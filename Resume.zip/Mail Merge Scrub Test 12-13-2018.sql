SELECT A.[Loan Number]

,Case 
WHEN E.[Exception Status] not in ('Not Valid','Incurable','Cancelled','Resolved') and A.[Loan Status] in ('Active') THEN ('Send Letter')
ELSE ('DO NOT SEND LETTER')
END AS 'Letter Flag'

,A.[Loan Status],
CASE
WHEN A.[Loan Status] not in ('Active') then 'Not Active'
ELSE 'Active'
END AS 'Active Status', 
E.[Exception ID], E.[Document], E.[Issue],E.[Exception Status]

,CASE 
WHEN C.[HUD Status] in ('Not Started') then B.[Final Review Status]
ELSE C.[HUD Status]
END as 'Status'
,B.[Final Review Status Date],B.[Final Review Assigned To],E.[Exception Status]

,CASE
WHEN E.[Exception Status] in ('Not Valid','Incurable','Cancelled','Resolved') then 'Exception Closed'
ELSE 'Exception Open'
End as 'Exception Status'

FROM sharepointdata.dbo.HUDAssignExceptions E
LEFT JOIN sharepointdata.dbo.hudassignloans A
ON A.[Loan Number] = E.[Loan Number]
LEFT JOIN sharepointdata.dbo.HudAssignFinalReview B
ON E.[Loan Number] = B.[Loan Number]
LEFT JOIN sharepointdata.dbo.HudAssignHUDStatus C
ON E.[Loan Number] = C.[Loan Number]

where E.[exception ID] in ('338933',
'267691',
'279947',
'355360',
'348227',
'298754',
'350055',
'343465',
'315559',
'342549',
'316083',
'296083',
'350244',
'349362',
'296632',
'315859',
'304291',
'296753',
'320505',
'336334',
'324698',
'349021',
'325311',
'326410',
'347945',
'328783',
'311048',
'330591',
'315533',
'315225',
'342109',
'328178',
'342053',
'341970',
'343351',
'339393',
'356442',
'196966',
'320173',
'357432',
'324646',
'347739',
'358096',
'358552',
'358743',
'358750',
'358317',
'361265',
'360081',
'363822',
'363437',
'364105',
'367657',
'372080',
'366426',
'293497',
'372247',
'373646',
'373818',
'374449',
'378288',
'375031',
'377224',
'377553',
'308912',
'359582',
'368572',
'379755',
'364677',
'377606',
'364954',
'379349',
'288000',
'373109',
'367090',
'370545',
'363311',
'377189',
'286639',
'365333',
'377271',
'376130',
'313262',
'381642',
'380226',
'382004',
'381302',
'383721',
'383536',
'382293',
'384019',
'383044',
'383449',
'384127',
'310005')
