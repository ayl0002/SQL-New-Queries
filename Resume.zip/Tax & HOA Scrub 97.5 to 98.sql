SET NoCount ON
SELECT A.[Loan Number],GETDATE() AS 'Last Refreshed',CAST(A.[MCA %] AS Float(2)) AS 'MCA %',B.[Document],B.[Exception ID],B.[Exception Status],C.[HUD Status],t.[Open Exceptions]
,T.OpenCurative
,T.OpenHACG
,CASE
WHEN C.[HUD Status] IN ('Not Started') THEN ISNULL(D.[Final Review Assigned To],'Unassigned')
WHEN C.[HUD Status] NOT IN ('Not Started') THEN ISNULL(C.[HUD Assigned To],'Unassigned')
ELSE 'Error'
END AS 'Agent'
,CASE
WHEN C.[HUD Status] IN ('Not Started') THEN ISNULL(F.[MGR_NM],'Unassigned')
WHEN C.[HUD Status] NOT IN ('Not Started') THEN ISNULL(E.[MGR_NM],'Unassigned')
END AS 'Manager'
,CASE
WHEN C.[HUD Status] IN ('Not Started') THEN ISNULL(F.ST_LOC,'Unassigned')
WHEN C.[HUD Status] NOT IN ('Not Started') THEN ISNULL(E.ST_LOC,'Unassigned')
ELSE 'Error'
END AS 'Site'
FROM SharepointData.Dbo.HUDAssignLoans A
LEFT JOIN SharepointData.Dbo.HUDAssignExceptions B
ON A.[Loan Number] = B.[Loan Number]
LEFT JOIN SharepointData.Dbo.HUDAssignHUDStatus C
ON A.[Loan Number] = C.[Loan Number]
LEFT JOIN SharepointData.Dbo.HUDAssignFinalReview D
ON A.[Loan Number] = D.[Loan Number]
LEFT JOIN [VRSQLRODS\RODS_Prod].reverse_dw.dbo.TP_HUD_RSTR E
ON C.[HUD Assigned To] = E.AGNT_NM
LEFT JOIN [VRSQLRODS\RODS_Prod].reverse_dw.dbo.TP_HUD_RSTR F
ON D.[Final Review Assigned To] = F.AGNT_NM
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignLoanExceptionTotals T
ON T.[Loan Number] = A.[Loan Number]
WHERE A.[Loan Status] IN ('Active') AND B.[Document] IN ('HOA','Tax Bill') AND B.[Exception Status] IN ('RESOLVED','CLOSED','NOT VALID','CLOSED WITH VENDOR') 
AND A.[MCA %] BETWEEN 97.5 AND 98 AND C.[HUD Status] IN ('Not Started','HUD Denied') AND A.[Tag 2] IS NULL AND A.[Incurable Flag] IN ('0')
AND (A.[Group] IS NULL OR (A.[GROUP] IN ('Grp 1 NSM Balance Sheet','Grp 3 GNMA excl BofA','Grp 2 FNMA','Grp 4 Trust / Private exlc BofA')))
ORDER BY B.[Document],B.[Exception Status]



