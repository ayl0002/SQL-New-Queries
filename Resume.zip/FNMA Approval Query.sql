SELECT A.[Loan Number],A.[Loan Status],B.[Tag 2],B.[Incurable Flag],B.[MCA %],B.[Group],[HUD Status],[HUD Status Date],[HUD Status Updated By],[HUD Assigned To],[HUD Status Comment],CAST([HUD Preliminary Title Approval] AS DATE) AS 'PTA Date',CAST([HUD Preliminary Title Denial Date] AS DATE) AS 'PTA Denied',[MCA],CAST([FNMA Approved Date] AS DATE) AS 'FNMA Approved Date',CAST([FNMA Denied Date] AS DATE) AS 'FNMA Denied Date',DATEDIFF(DAY,CAST([HUD Preliminary Title Approval] AS DATE),CAST(GETDATE() AS DATE)) AS 'PTA Diff',[MRC Owned Loss],[FNMA Owned Loss],CAST(B.[Original Loan Amount]/1.5 AS Float(2)) AS'MCA Amount',CAST(B.UPB-(B.[Original Loan Amount]/1.5) AS Float(2)) AS 'Current CrossOver'
,CASE
WHEN [MRC Owned Loss] IS NOT NULL THEN CAST(B.UPB-(B.[Original Loan Amount]/1.5) AS Float(2)) - [MRC Owned Loss]
WHEN [FNMA Owned Loss] IS NOT NULL THEN CAST(B.UPB-(B.[Original Loan Amount]/1.5) AS Float(2)) - [FNMA Owned Loss]
ELSE 'Error'
END AS 'CrossOver Diff'
,CASE
WHEN CAST(B.UPB-(B.[Original Loan Amount]/1.5) AS Float(2)) > [MRC Owned Loss] THEN 'Flag 1'
WHEN CAST(B.UPB-(B.[Original Loan Amount]/1.5) AS Float(2)) > [FNMA Owned Loss] THEN 'Flag 2'
WHEN [MRC Owned Loss] IS NOT NULL AND [FNMA Owned Loss] IS NOT NULL AND (CAST(B.UPB-(B.[Original Loan Amount]/1.5) AS Float(2)) > ([MRC Owned Loss] + [FNMA Owned Loss])) THEN 'Flag 3'
WHEN [MRC Owned Loss] IS NULL AND [FNMA Owned Loss] IS NULL THEN 'No Loss Entered'
ELSE 'Error'
END AS 'Review Flag'
FROM SharepointData.Dbo.HUDAssignHUDStatus A
LEFT JOIN SharepointData.Dbo.HUDAssignLoans B
ON A.[Loan Number] = B.[Loan Number]
WHERE A.[Loan Status] IN ('Active') AND ((CAST([FNMA Approved Date] AS DATE) <= CAST([HUD Preliminary Title Approval] AS DATE)) OR  ([FNMA Approved Date] IS NOT NULL AND [HUD Preliminary Title Approval] IS NULL))
ORDER BY ('Review Flag')