SELECT Loan_Nbr,[MCA_Crossover_DT],[MAX_CLAIM_AMOUNT] ,A.[CURRENT_TOTAL_UPB]
,CASE WHEN CAST([MCA_Crossover_DT] AS DATE) <= CAST('6/24/2019' AS DATE) THEN 'Eligible'
ELSE 'Not Eligible'
END AS 'CrossOverFlag'
INTO #BASE
FROM Reverse_DW.[dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] A
WHERE A.Loan_Nbr IN ('2723827',
'2147738',
'2780781',
'2788346',
'2139818',
'2170088',
'2734693',
'2777775',
'2820552',
'2861062',
'2170102',
'2743364',
'2798907',
'2685444',
'2755256',
'2755768',
'2763314',
'2808841',
'2851162',
'2111587',
'2116161',
'2681064',
'2732862',
'2744731',
'2757975',
'2766475',
'2780612',
'2789791',
'2814360',
'2677796',
'2715246',
'2742900',
'2775067',
'2799964',
'2804949',
'2835376',
'2768592',
'2788950',
'2811312',
'2867386',
'2769150',
'2823884',
'2796222',
'2713541',
'2763096',
'2768912',
'2770972',
'2787686',
'2795185',
'2810140',
'2856167',
'2698074',
'2754448',
'2757225',
'2793560',
'2753130',
'2770119',
'2800091',
'2104646',
'2776397',
'2778663',
'1009961',
'2157800',
'2755187',
'2755405',
'2770379',
'2770687',
'2780337',
'2802823',
'2767227',
'2104555',
'2715166',
'2792785',
'2813677',
'2846790',
'2758475',
'2782670',
'2150632',
'2435511',
'2743080',
'2787766',
'2807931',
'2157230',
'2236428',
'2679173',
'2714757',
'2721266',
'2775078',
'2779880',
'2785606',
'2787038',
'2830348',
'1154409',
'2127927',
'2129667',
'2169223',
'2236929',
'2684740',
'2711947',
'2764872',
'2767933',
'2772849',
'2788803',
'2840987',
'2858352',
'2444408',
'2762200',
'2769138',
'2788222',
'2836059',
'2860700',
'1153352',
'2176197',
'2179305',
'2243655',
'2693239',
'2780075',
'2787824',
'2148977',
'2195167',
'2689153',
'2704835',
'2776148',
'1012646',
'1012962',
'2770391',
'2779528',
'2781236',
'2806473',
'2118675',
'2765599',
'2786823',
'2791181',
'2795458',
'1004731',
'2158093',
'2752947',
'2764587',
'2777241',
'2777478',
'2690851',
'2812723',
'2860835',
'2123091',
'2167345',
'2132274',
'2720802',
'2771995',
'1154542',
'2756543',
'2768239')


--Incurable Scrub--
SELECT 
A.*,B.Excp_ID,B.[DOC_DESC],B.EXCP_STS_DESC,B.EFF_DTTM,B.Row_Nbr
INTO #Incur_Scrub
FROM #BASE A
LEFT JOIN (SELECT Loan_Nbr,Excp_ID,[DOC_DESC],EXCP_STS_DESC,EFF_DTTM,ROW_NUMBER() OVER (Partition by Excp_ID ORDER BY EFF_DTTM ASC) AS 'Row_Nbr'  FROM Reverse_Dw.[dbo].[HUD_ASGN_EXCP_EDW] WHERE EXCP_STS_DESC IN ('INCURABLE')) B 
On A.Loan_Nbr = B.Loan_Nbr

--UPB Scrub--
SELECT A.Loan_Nbr,TXN_EFF_DT,UPB_AMT AS 'June_UPB',ROW_NUMBER() OVER (Partition BY A.Loan_Nbr ORDER BY TXN_EFF_DT) AS 'MaxDate'
INTO #UPB 
FROM #Incur_Scrub A
LEFT JOIN [Reverse_DW].[dbo].[RM_MASTER_TXN_VW] B
ON A.Loan_Nbr = B.Loan_Nbr
WHERE CAST(TXN_EFF_DT AS DATE) <= CAST('6/24/2019' AS DATE) AND CAST(TXN_EFF_DT AS DATE) >= CAST('5/31/2019' AS DATE)

------

SELECT DISTINCT A.Loan_Nbr,CAST([MCA_Crossover_DT] AS DATE) AS 'Crossover_Date',[MAX_CLAIM_AMOUNT] AS 'MCA',CAST(A.[CURRENT_TOTAL_UPB] AS FLOAT(2)) AS 'Current_UPB',([CURRENT_TOTAL_UPB] - [MAX_CLAIM_AMOUNT])  AS 'TOTAL_CROSSOVER'
,TXN_EFF_DT,JUNE_UPB,(JUNE_UPB - [MAX_CLAIM_AMOUNT]) AS 'June_CrossOver'
,C.EXCP_ID,C.[DOC_DESC],C.Min_Excp_Dt,D.Max_Excp_Dt,A.CrossOverFlag,[MAX_CLAIM_AMOUNT] ,A.[CURRENT_TOTAL_UPB]
INTO #BASE2
FROM #Incur_Scrub A
LEFT JOIN (SELECT UPB.* FROM #UPB UPB
	LEFT JOIN (SELECT Loan_Nbr,MAX(MaxDate) AS 'MaxDate' FROM #UPB GROUP BY Loan_Nbr) MaxUpb ON  UPB.Loan_NBR = MaxUpb.Loan_Nbr WHERE UPB.MaxDate =  MaxUpb.MaxDate) B
ON A.Loan_Nbr = B.LOAN_NBR
LEFT JOIN (SELECT A.Loan_Nbr,A.Excp_ID,A.[DOC_DESC],A.EXCP_STS_DESC,A.EFF_DTTM AS 'Min_Excp_Dt' FROM #Incur_Scrub A LEFT JOIN
			(SELECT Excp_ID AS 'Min_Excp_ID',MIN(Row_Nbr) AS 'Min_Row' FROM #Incur_Scrub GROUP BY Excp_ID ) B ON A.EXCP_ID = B.Min_Excp_ID WHERE Row_Nbr = Min_Row AND Min_Excp_ID = A.Excp_ID)
 C
ON A.Excp_ID = C.Excp_ID
LEFT JOIN (SELECT A.Loan_Nbr,A.Excp_ID,A.[DOC_DESC],A.EXCP_STS_DESC,A.EFF_DTTM AS 'Max_Excp_Dt' FROM #Incur_Scrub A LEFT JOIN
			(SELECT Excp_ID AS 'Max_Excp_ID',Max(Row_Nbr) AS 'Max_Row' FROM #Incur_Scrub GROUP BY Excp_ID ) B ON A.EXCP_ID = B.Max_Excp_ID WHERE Row_Nbr = Max_Row AND Max_Excp_ID = A.Excp_ID) 
 D
ON A.Excp_ID = D.Excp_ID

--Final1--
SELECT Loan_Nbr,Excp_ID,Loan_Nbr+Excp_ID AS 'Excp_Key'
,CASE 
WHEN DOC_DESC IS NULL THEN 'Not Eligible'
WHEN CrossOverFlag IN ('Eligible')  AND CAST('6/24/2019' AS DATE) BETWEEN CAST(Min_Excp_Dt AS DATE) AND CAST(Max_Excp_Dt AS DATE) THEN 'Eligible'
ELSE 'Not Eligible'
END AS 'Flag'
,ISNULL(DOC_DESC,'No Incurable') AS 'Exception_Type',
CAST((TOTAL_CROSSOVER - June_CrossOver) AS FLOAT(2)) AS 'Recommended Servicer Loss Amount',
CAST('6/24/2019' AS DATE) AS 'Recommended Servicer Loss Period Start Date',
CAST(GETDATE() AS DATE) AS 'Recommended Servicer Loss Period End Date',
CAST(June_CrossOver AS FLOAT(2)) AS 'Recommended Fannie Mae Loss Amount',
CAST([Crossover_Date] AS DATE) AS 'Recommended Fannie Mae Loss Period Start Date',
CAST('6/24/2019' AS DATE) AS 'Recommended Fannie Mae Loss Period End Date'

,TOTAL_CROSSOVER,[MAX_CLAIM_AMOUNT] ,[CURRENT_TOTAL_UPB],Crossover_Date
,CAST(Min_Excp_Dt AS DATE) AS 'Min_Incur_Date',CAST(Max_Excp_Dt AS DATE) AS 'Max_Incur_Date'
INTO #Final1
FROM #BASE2
ORDER BY 'Flag'

--Final2--
SELECT A.*,ROW_NUMBER () Over (Partition By Loan_Nbr Order By A.Flag) AS 'RowFlag'
INTO #Final2 
FROM #Final1 A
	LEFT JOIN (SELECT Excp_Key FROM #Final1 WHERE Flag IN ('Eligible')) B
	ON A.Excp_Key = B.Excp_Key
	LEFT JOIN (SELECT Excp_Key FROM #Final1 WHERE Flag IN ('Not Eligible')) C
	ON A.Excp_Key = C.Excp_Key

--Final 3--
SELECT A.[Loan_Nbr],A.[Excp_ID],A.[Flag],A.[Exception_Type],A.[Recommended Servicer Loss Amount],A.[Recommended Servicer Loss Period Start Date],A.[Recommended Servicer Loss Period End Date],A.[Recommended Fannie Mae Loss Amount],A.[Recommended Fannie Mae Loss Period Start Date],A.[Recommended Fannie Mae Loss Period End Date],A.[TOTAL_CROSSOVER],A.[MAX_CLAIM_AMOUNT],A.[CURRENT_TOTAL_UPB],A.[Crossover_Date],A.[Min_Incur_Date],A.[Max_Incur_Date]

FROM #Final2 A
WHERE RowFlag = 1

ORDER BY A.[Flag]




DROP TABLE #Incur_Scrub,#BASE,#UPB,#BASE2,#Final1,#Final2