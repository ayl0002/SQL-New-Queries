SET NOCOUNT ON
SELECT A.[Loan Number],D.[Exception ID]
--,CASE
	--WHEN A.[MCA %] > 100 AND A.[Open Exceptions] <= 1 THEN 'Priority 1'
	--WHEN A.[MCA %] > 100 AND A.[Open Exceptions] = 2 THEN 'Priority 2'
	--WHEN A.[MCA %] > 100 AND A.[Open Exceptions] = 3 THEN 'Priority 3'	
	--WHEN A.[MCA %] > 100 AND A.[Open Exceptions] > 3 THEN 'Priority 4'
	--WHEN A.[MCA %] Between 97.5 AND 100 AND A.[Open Exceptions] <= 1 THEN 'Priority 5'
	--WHEN A.[MCA %] Between 97.5 AND 100 AND A.[Open Exceptions] = 2 THEN 'Priority 6'
	--WHEN A.[MCA %] Between 97.5 AND 100 AND A.[Open Exceptions] = 3 THEN 'Priority 7'
	--WHEN A.[MCA %] Between 97.5 AND 100 AND A.[Open Exceptions] > 3 THEN 'Priority 8'
	--WHEN A.[MCA %] < 97.5 THEN 'Priority 9 - Below 97.5'
	--ELSE 'Error'
	--END AS 'Loan Priority'
,Case
	WHEN D.[Document] in ('Tax Bill','Current OCC Cert','Hazard Insurance','Master Policy','HOA') THEN 'Time Sensitive'
	WHEN D.[Document] in ('Not Doc Issue') THEN 'Not Doc'
	ELSE 'Other'
	END AS 'Exception Type'
,Case
	WHEN D.[Exception Assigned To] is null THEN 'Exception Unassigned'
	WHEN D.[Exception Assigned To] in ('Georgia Rowe') THEN 'Georgia Rowe'
	WHEN D.[Exception Assigned To] in ('Tiffani Levi') THEN 'Tiffani Levi'
	ELSE 'Exception Unassigned'
	END AS 'Team Ed'
,D.[Exception Assigned To]
--,Case WHEN D.[Exception Assigned To] is null THEN 'Exception Unassigned'
	--  WHEN D.[Exception Assigned To] in ('Georgia Rowe','Tiffani Levi') THEN ('Call Team')
	  --WHEN D.[Document] in ('Not Doc Issue') THEN 'Not Doc Team'
	  --ELSE 'Exception Unassigned to Call Team'
	  --END AS 'Team'
,D.[Document],D.[Issue]
,CASE
	WHEN D.[Document] in ('Assignments',	'Assignments-3rd Party',	'Assignments-POA',	'Death Cert',	'Flood Cert',	'HUD1',	'Lien Release',	'Loan Agreement',	'Manufactured Home',	'Mortgage-First',	'Mortgage-Second',	'Note-First',	'Note-Second',	'Orig Appraisal',	'Orig Loan App',	'PoA',	'Title Policy',	'Trust',	'Verif of Mobile Home') THEN 'Curative'
	WHEN D.[Document] in ('Not Doc Issue') THEN 'Not Doc'
	WHEN D.[Document] is Null THEN 'Null'
	WHEN D.[Document] in ('Current Occ Cert',	'Death Cert HACG',	'HOA',	'PoA',	'Master Policy',	'Trust',	'Trust - HACG',	'Hazard Insurance',	'Flood Insurance',	'Walls In Policy',	'Update Time Sensitive Documents',	'Tax Bill') THEN 'Priority 1'
	WHEN D.[Document] in ('Signed Pay Plan',	'Proof of Repair',	'Flood Cert') THEN 'Priority 2'
	WHEN D.[Document] in ('Loss Draft',	'Hardest Hit Funds') THEN 'Priority 3'
	WHEN D.[Document] in ('HOLD',	'HUD LOC Advance') THEN 'Priority 4'
	WHEN D.[Document] in ('MIC',	'FNMA Denied',	'NSB Denied',	'Title Grade Report',	'Certification',	'Lien Release',	'Pay History',	'Notice to Borrower',	'Breach Letter',	'HEC Agreement') THEN 'Unknown'
	ELSE 'Unknown'
	END AS 'Priority'
,D.[Exception Status],CAST(CAST(A.[MCA %] AS Decimal(5,2)) AS NvarChar(6)) + '%' AS 'MCA'
,CASE
	WHEN A.[MCA %] < 97.5 THEN '< 97.5'
	WHEN A.[MCA %] BETWEEN 97.5 AND 100 THEN '97.5 < 100'
	WHEN A.[MCA %] > '100' THEN '> 100'
	ELSE 'Error'
	END AS 'MCA Bucket'
,D.[Exception Memo] AS'Exception Comment'
,Cast(Cast(A.[Open Exceptions] AS INT) AS nvarchar(1)) + ' - Open Exceptions' AS 'Open Exceptions'
,Cast(D.[Exception Status Date] AS DATE) AS 'Exception Last Updated'
,Case
WHEN D.[Exception Status Date] is null AND DateDiff(day,CAST(D.[Exception Request Date] AS DATE),Cast(GetDate() AS DATE)) not in ('0') THEN 'Exception Never Updated'
WHEN CAST(D.[Exception Request Date] AS DATE) = Cast(GetDate() AS DATE) THEN 'Exception Opened Today'
WHEN DateDiff(day,CAST(D.[Exception Status Date] AS DATE),Cast(GetDate() AS DATE)) >= 14 THEN 'Over 2 Weeks'
WHEN DateDiff(day,CAST(D.[Exception Status Date] AS DATE),Cast(GetDate() AS DATE)) >= 7 THEN 'Over 1 Week'
WHEN DateDiff(day,CAST(D.[Exception Status Date] AS DATE),Cast(GetDate() AS DATE)) Between 3 AND 7 THEN 'Under 1 Week'
WHEN DateDiff(day,CAST(D.[Exception Status Date] AS DATE),Cast(GetDate() AS DATE)) <= 3 THEN 'Under 3 Days'
ELSE 'Reviewed Today'
END AS 'Exception Last Reviewed'
,A.[Loan Status]
,B.[HUD Assigned to]
,E.[MGR_NM]
,E.[ST_LOC]
FROM SharepointData.Dbo.HUDAssignLoans A
LEFT JOIN SharepointData.DBO.HUDAssignHUDStatus B
ON A.[Loan Number] = B.[Loan Number]
LEFT JOIN SharepointData.dbo.HUDAssignFinalReview C
ON A.[Loan Number] = C.[Loan Number]
LEFT JOIN  (SELECT *
FROM SharepointData.Dbo.HUDAssignExceptions A
LEFT JOIN (SELECT [Exception ID] AS 'Excp_ID',[Exception Memo]
FROM SharepointData.dbo.HUDAssignExceptionActions A
LEFT JOIN (SELECT [Exception ID] AS 'Excp_ID',MAX([Exception Status Date]) AS 'Excp Status Date' FROM SharePointData.[dbo].[HUDAssignExceptionActions] GROUP BY [Exception ID]) B
ON B.[Excp_ID] = A.[Exception ID]
WHERE A.[Exception Status Date] = B.[Excp Status Date] and B.[Excp_ID] is not null) B
ON A.[Exception ID] = B.[Excp_ID]) D
ON D.[Loan Number] = A.[Loan Number]
LEFT JOIN [VRSQLRODS\RODS_PROD].reverse_dw.[dbo].[TP_HUD_RSTR] E
ON E.AGNT_NM = B.[HUD Assigned To]
--LEFT JOIN (SELECT * FROM SharePointData.[dbo].[HUDAssignExceptionActions] A LEFT JOIN (SELECT MAX([Exception Status Date]) FROM SharePointData.[dbo].[HUDAssignExceptionActions]) B ON A.[Exception Status Date] = B.[Exception Status Date]) F
--ON F.[Exception ID] = D.[Exception ID]
WHERE E.[ST_LOC] in ('Offshore') AND A.[TAG 2] is NULL AND A.[Incurable Flag] in ('0') AND A.[Loan Status] in ('Active') AND A.[MCA %] > 97.5 AND D.[Exception Status] not in ('Closed','Not Valid','Resolved','Closed with Vendor') AND D.[Exception ID] is not null
AND D.[Work Group] in ('HACG')
--AND D.[Exception Assigned To] in ('Tiffani Levi')
--AND E.[GRP_NM] in ('OS Submitter','OS Phone')
ORDER BY --'Loan Priority',
'Team Ed','Exception Type',CAST(D.[Exception Status Date] AS DATE),'Exception Last Reviewed' DESC,A.[Loan Number]