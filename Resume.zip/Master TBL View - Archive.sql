SELECT A.Loan_Nbr,[FHA_CASE_NBR],[STATUS_DESCRIPTION],MCA_Percent AS '3/1/2020 MCA',[Liquidated Date]
FROM reverse_dw.[dbo].[RM_CHAMPION_MASTER_TBL_VW] ('2020-03-01',20200301) A
LEFT JOIN (SELECT Loan_Nbr,Min(EFF_DTTM) AS 'Liquidated Date' FROM Reverse_DW.DBO.HUD_ASGN_Loans WHERE Loan_STS_DESC ='Liquidated/Assigned to HU' GROUP BY Loan_Nbr) B
ON A.Loan_Nbr = B.Loan_Nbr
WHERE A.Loan_Nbr IN ('843287',
'845165',
'840975',
'849351',
'845059',
'838582',
'888029',
'843021',
'885883',
'841596',
'841934',
'845367')