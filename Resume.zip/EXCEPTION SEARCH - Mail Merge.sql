SELECT
E.[Loan Number]
,CAST(GETDATE() AS Date) AS 'Todays Date'
,A.[Loan Status]
,A.[Tag 2]
,A.[Incurable Flag]
,c.[HUD Status]
,a.[MCA %]
 ,case 
	when a.[MCA %] < '95' then '0 < 94.99'	
	when a.[MCA %] between '95' and '95.99' then '95.0 < 95.99'
	when a.[MCA %] between '96' and '96.49' then '96.0 < 96.49'
	when a.[MCA %] between '96.50' and '97.49' then '96.5 < 97.49'
	when a.[MCA %] between '97.50' and '99.99' then '97.50 < 99.99'
	when a.[MCA %] >= '100.00' then '> 100'
	else '97.49 >'
	end as 'MCA Bucket'
,e.[Exception ID]
,E.[Document]
,Case
	WHEN E.[Sent For Gift Card Processing] is not null or E.[Ledger Sent for Gift Card Processing] is not null then 'Voucher Sent'
	WHEN E.[Non GC Letter Document Returned] is not null THEN 'DO NOT SEND - NON GC DOC RETURNED'
	WHEN E.[Document] IN ('HOA') AND E.[Ledger Letter Sent 3] is not null AND a.[MCA %] >= 97 THEN 'Ledger 3 Sent'	
	WHEN E.[Document] IN ('HOA') AND E.[Ledger Letter Sent 2] is not null AND a.[MCA %] >= 97 THEN 'Ledger 2 Sent'	
	WHEN E.[Document] IN ('HOA') AND E.[Ledger Letter Sent 1] is not null AND a.[MCA %] >= 97 THEN 'Ledger 1 Sent'
	WHEN E.[Gift Card Letter Sent 3] is not null then 'GC 3 Sent'
	WHEN E.[Gift Card Letter Sent 2] is not null then 'GC 2 Sent'
	WHEN E.[Gift Card Letter Sent] is not null then 'GC 1 Sent'
	WHEN E.[Non GC Letter Sent 3] is not null then 'Non GC 3 Sent'
	WHEN E.[Non GC Letter Sent 2] is not null then 'Non GC 2 Sent'
	WHEN E.[Non GC Letter Sent 1] is not null then 'Non GC 1 Sent'
	ELSE 'No Letter Sent'
END AS 'GC Flag'
,CAST(E.[Exception Status Date] AS DATE) AS 'Exception Status Date'
,CASE
WHEN E.[Gift Card Letter Sent] is NULL AND E.[Ledger Letter Sent 3] is not null then ('Ledger 3 Sent - No GC 1')
WHEN E.[Gift Card Letter Sent] is NULL AND E.[Ledger Letter Sent 2] is not null then ('Ledger 2 Sent - No GC 1')
WHEN E.[Gift Card Letter Sent] is NULL AND E.[Ledger Letter Sent 1] is not null then ('Ledger 1 Sent - No GC 1')
Else ('No Error')
END AS 'Ledger Check'
,Cast (E.[Gift Card Letter Sent] AS Date) AS 'I-Assign Date 1'
,Cast (E.[Gift Card Letter Sent 2] AS Date) AS 'I-Assign Date 2'
,Cast (E.[Gift Card Letter Sent 3] AS Date) AS 'I-Assign Date 3'
,Cast(E.[Sent For Gift Card Processing] AS Date) AS 'I-Assign Sent for Processing'
,Cast(E.[Ledger Sent for Gift Card Processing] AS Date) AS 'Ledger Sent for Gift Card Processing'
,E.[Issue]
,E.[Exception Status]
,CAST(E.[Ledger Letter Sent 1] AS DATE) AS 'Ledger Letter 1'
,CAST(E.[Ledger Letter Sent 2] AS DATE) AS 'Ledger Letter 2'
,CAST(E.[Ledger Letter Sent 3] AS DATE) AS 'Ledger Letter 3'
,CAST(E.[Non GC Letter Sent 1] AS DATE) AS 'Non GC 1'
,CAST(E.[Non GC Letter Sent 2] AS DATE) AS 'Non GC 2'
,CAST(E.[Non GC Letter Sent 3] AS DATE) AS 'Non GC 3'
,case
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) <= 0  then '0 to 15'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 0 and 15 then '0 to 15'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 16 and 30 then '16 to 30'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 31 and 60 then '31 to 60'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 61 and 90 then '61 to 90'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 91 and 120 then '91 to 120'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) >= 121 then '121+'
	end as 'Exception Request Aging'
--,CASE
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) <= 0  then '0 to 15'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 0 and 15 then '0 to 15'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 16 and 30 then '16 to 30'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 31 and 60 then '31 to 60'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 61 and 90 then '61 to 90'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 91 and 120 then '91 to 120'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) >= 121 then '121+'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) <= 0  then '0 to 15'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 0 and 15 then '0 to 15'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 16 and 30 then '16 to 30'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 31 and 60 then '31 to 60'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 61 and 90 then '61 to 90'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 91 and 120 then '91 to 120'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) >= 121 then '121+'
--	END AS 'Exception Status Aging'
,e.[Exception Assigned To]
,c.[hud assigned to]
,T.[Open Exceptions]
,T.OpenCurative
,T.OpenHACG
,e.[Delinquent Amount]
,e.[Installment Frequency]
,e.[Due Date]
,e.[Entity or County Name]
,e.[Contact Info]
,e.[Fee to Obtain Info]
,e.[Fee Amount]
,r.[MGR_NM]
,r.[ST_LOC]

FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignLoans A
ON E.[Loan Number]=A.[Loan Number]
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignFinalReview B
ON E.[Loan Number]=B.[Loan Number]
left join SharepointData.dbo.HUDAssignHUDStatus c
on a.[Loan Number]=c.[Loan Number]
LEFT JOIN SharepointData.DBO.HUDAssignLoanExceptionTotals T
ON A.[Loan Number]=T.[Loan Number]
left join [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_HUD_RSTR] r
on c.[hud assigned to]=r.[AGNT_NM]

WHERE E.[DOCUMENT] IN ('HOA','CURRENT OCC CERT','Proof of Repair') AND
--[ISSUE] IN ('Forced Placed Insurance')AND
E.[EXCEPTION STATUS] NOT IN ('RESOLVED','CANCELLED','NOT VALID','CLOSED','INCURABLE','closed with vendor') AND
A.[Tag 2] IS NULL AND
--T.OpenCurative IN ('0')AND
A.[Incurable Flag] IN ('0')AND
A.[Loan Status] IN ('active')AND
--A.Stage IN ('FINAL REVIEW','HUD STATUS') AND 
A.[MCA %] >= 95
AND (a.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or a.[Group] is null)
ORDER BY E.[Document],[MCA %] DESC
