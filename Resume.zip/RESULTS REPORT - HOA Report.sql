SELECT distinct
base.[LOAN_nbr]
,Cast(E.[Exception Request Date] AS Date) AS 'Exception Request Date'
,DATEDIFF(day,E.[Exception Request Date],Getdate()) AS 'Aged'
,a.[tag 2]
,a.[incurable flag]
,base.[status_description]
,a.Stage
,[mca_percent]
,a.[group]
,a.[pool name]
,A.UPB
,CASE
	WHEN [mca_percent] < 97.5 THEN '< 97.5'
	WHEN [mca_percent] < 98 THEN '97.5 - 97.99'
	WHEN [mca_percent] < 100 THEN '98.00 - 99.99'
	WHEN [mca_percent] < 105 THEN '99.99 - 104.99'
	ELSE '>= 105'
	END AS 'MCA Flag'
,e.[Exception ID]
,e.[Work Group]
,b.[final review assigned to]
,c.[hud assigned to]
,r.mgr_nm
,r.st_loc
,t.[Open Exceptions]
,T.OpenCurative
,T.OpenHACG
,case
	when C.[HUD Status] IN ('Pkg Submitted to HUD','resubmitted to hud','rebuttal to hud') then 'Submitted'
	when c.[hud status] in ('hud approved') then 'HUD Approved'
	WHEN [HUD Preliminary Title Approval] IS NOT NULL AND [HUD Preliminary Title Denial Date] IS NULL THEN 'PTA Granted'
	WHEN c.[hud status] in ('HUD Denied') then 'HUD Denied'
	else 'Not Submitted'
	end as 'Status'
,[HUD Preliminary Title Approval],[HUD Preliminary Title Denial Date]
,C.[HUD Status]
,B.[Final Review Status]
--,CASE
	--WHEN b.[Final Review Status Date] > C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),b.[Final Review Status Date],101)
	--WHEN b.[Final Review Status Date] < C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),C.[HUD Status Date],101)
	--ELSE CONVERT(NVARCHAR(10),b.[Final Review Status Date],101) END AS 'Last Updated'

--,CASE
	--WHEN B.[Final Review Comment] > C.[HUD Status Comment] THEN B.[Final Review Comment]
	--WHEN B.[Final Review Comment] < C.[HUD Status Comment] THEN C.[HUD Status Comment]
	--ELSE B.[Final Review Comment]  END AS 'Last Comment'
,case
	when E.Document is null then 'No Issue'
	when e.[Document] is not null then e.[Document]
	end as 'Document'
,E.Issue
,E.[Exception Status]
,E.[Exception Status Updated By]
,Cast(E.[Exception Status Date] AS Date) AS 'Exception Status Date'

,[Sent For Gift Card Processing],[Ledger Sent for Gift Card Processing],[Non GC Letter Document Returned],E.[Sent To Inspection Vendor],EXCP.[Gift Card Letter Sent],[Ledger Letter Sent 1],[Ledger Letter Sent 2]
,(SELECT MAX(V) FROM (VALUES (EXCP.[Gift Card Letter Sent]),(EXCP.[Gift Card Letter Sent 2]),(EXCP.[Gift Card Letter Sent 3])) AS VALUE(V)) AS [MAX GC]
,(SELECT MAX(V) FROM (VALUES ([Sent To Inspection Vendor]),([Ledger Letter Sent 1]),([Ledger Letter Sent 2])) AS VALUE(V)) AS [MAX DK]
FROM SHAREPOINTDATA.dbo.HUDAssignLoans A
LEFT JOIN SHAREPOINTDATA.dbo.HUDAssignFinalReview B
ON a.[LOAN NUMBER]=b.[LOAN NUMBER] 
LEFT JOIN (SELECT [LOAN NUMBER],[EXCEPTION ID],[DOCUMENT],[ISSUE], [EXCEPTION ASSIGNED TO],[EXCEPTION REQUEST DATE],[EXCEPTION STATUS],[EXCEPTION STATUS DATE],[Exception Status Updated By],[Work Group],[Gift Card Letter Sent],[Sent For Gift Card Processing],[Ledger Sent for Gift Card Processing],[Non GC Letter Document Returned],[Sent to Inspection Vendor],[Ledger Letter Sent 1],[Ledger Letter Sent 2] FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS WHERE ([DOCUMENT] = 'Loss Draft' OR [ISSUE] = 'Forced placed Insurance' OR isnull([Work Group],'No Group') IN ('Curative','LandTran')) AND [EXCEPTION STATUS] NOT IN ('RESOLVED','CLOSED','NOT VALID','CLOSED WITH VENDOR'))E--WHERE [EXCEPTION STATUS] NOT IN ('RESOLVED','CLOSED','NOT VALID','CLOSED WITH VENDOR')) E --[Document] in ('Current OCC Cert')) E-- AND [EXCEPTION STATUS] NOT IN ('RESOLVED','CLOSED','NOT VALID','CLOSED WITH VENDOR')) E
ON A.[LOAN NUMBER]=E.[Loan Number]
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNHUDSTATUS C
ON a.[LOAN NUMBER]=c.[LOAN NUMBER]
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignLoanExceptionTotals T
on a.[Loan Number]=T.[Loan Number]
LEFT JOIN (SELECT [Loan Number],[Gift Card Letter Sent],[Gift Card Letter Sent 2],[Gift Card Letter Sent 3] FROM SharepointData.Dbo.HUDAssignExceptions) EXCP
ON A.[Loan Number] = EXCP.[Loan Number]
left join [VRSQLRODS\RODS_PROD].reverse_dw.[dbo].[TP_HUD_RSTR] r
on CAST(c.[HUD Assigned To] AS NVarchar) =CAST(r.agnt_nm AS NVARCHAR)
RIGHT JOIN Tact_REv.Dbo.champbase base
ON CAST(a.[Loan Number] AS NVARCHAR) = CAST(base.[Loan_Nbr] AS NVARCHAR)


WHERE E.document is not null and
/*--C.[HUD Status] NOT IN ('Pkg Submitted to HUD','resubmitted to hud','rebuttal to hud') AND [MCA %] >= 100 AND A.[Loan Status] IN ('Active') AND A.[Tag 2] IS NULL AND A.[Incurable Flag] IN ('0')--E.[Exception ID] IN ()--A.[MCA %] BETWEEN 97.5 AND 98 --
*/
base.[Loan_Nbr] IN ('1047200',
'1010390',
'1072396',
'1081754',
'2217469',
'2497572',
'2573655',
'2281195',
'742512',
'2730644',
'2766501',
'746909',
'890660',
'2782863',
'853276',
'869156',
'894676',
'1087231',
'2283186',
'2148114',
'2816011',
'860892',
'2476679',
'2163728',
'2810480',
'1043548',
'2104839',
'2257457',
'2472766',
'2593648',
'2652684',
'868807',
'2666588',
'2798805',
'2855850',
'758781',
'849544',
'870291',
'2401087',
'2415584',
'874621',
'889438',
'2832976',
'2860960',
'1087344',
'2413321',
'892125',
'741878',
'749389',
'1042203',
'1076650',
'1088328',
'1150420',
'1008995',
'2238282',
'2568896',
'2650216',
'2803573',
'2842558',
'869335',
'845821',
'1052550',
'1150578',
'755712',
'2531596',
'2550215',
'2413310',
'847433',
'888407',
'1053806',
'2581779',
'2469453')



--[Exception Status] IN ('Resolved') AND [Sent For Gift Card Processing] IS NULL AND
--E.[Exception ID] IN ()



