SET NoCount ON
--Max Order--
SELECT B.Loan_Nbr + CAST(B.ORDR_DT AS NVARCHAR) AS 'Order_Key',B.*
INTO #MAXORDER
FROM (SELECT Loan_Nbr,MAX(ORDR_DT) AS 'ORDR_DT' FROM Reverse_DW.Dbo.NCCI_INBND_LM WHERE CMPGN_NM_DESC in ('LM0381') GROUP BY Loan_Nbr) A
	LEFT JOIN Reverse_DW.Dbo.NCCI_INBND_LM B
	ON (A.Loan_Nbr + CAST(A.ORDR_DT AS NVARCHAR)) = (B.Loan_Nbr + CAST(B.ORDR_DT AS NVARCHAR))
WHERE CMPGN_NM_DESC in ('LM0381')

--MAX BUS PROC--
SELECT A.*
INTO #MAXBUS
From #MAXORDER A
LEFT JOIN (SELECT Order_Key,MAX(BUS_PROC_DT) AS 'BUS_PROC_DT' FROM #MAXORDER GROUP BY Order_Key) B
ON A.Order_Key = B.Order_Key
WHERE A.BUS_PROC_DT = B.BUS_PROC_DT

--MAX NCCI--
SELECT Replace(Ltrim(Replace(A.LOAN_NBR,0,' ')),' ',0) AS 'Loan_Nbr',	A.ORDR_DT,	A.CMPGN_NM_DESC,	A.INSP_RSLT_DESC_1,	A.INSP_DT_2,	A.INSP_RSLT_DESC_2,	A.INSP_DT_3,	A.INSP_RSLT_DESC_3
,CASE
WHEN (CLSD_CD IN ('BCU-Borrower Contacted & Unable to Obtain Signed Occupancy Cert') AND A.NT_SGN IS NOT NULL) THEN 'BCU ' + A.NT_SGN
ELSE CLSD_CD
END AS 'Closed Status'
,A.CLSD_CD
,A.CLSD_DT
,A.NT_SGN
INTO #MAXNCCI
From #MAXBUS A

--Loan Status--
SELECT A.Loan_Nbr,[LOAN_STATUS],C.TAG_2_VAL,C.INCRBL_FLG_DESC,C.GRP_DESC,CAST(A.MCA_Percent AS Float(2)) AS 'MCA %',B.HUD_STS_DESC
INTO #LoanStatus
FROM reverse_DW.[dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] A
LEFT JOIN 
(SELECT * FROM reverse_DW.Dbo.HUD_ASGN_HUD_STS B WHERE CURR_IND IN ('Y')) B
ON A.[Loan_Nbr] = B.[Loan_Nbr]
LEFT JOIN 
(SELECT * FROM reverse_DW.[dbo].[HUD_ASGN_Loans] WHERE CURR_IND IN ('Y')) C
ON Cast(A.[Loan_Nbr] AS NVarChar) = CAST(C.[Loan_Nbr] AS NVarChar)

--OCC--
SELECT A.*,EXCP_ID,DOC_DESC,EXCP_STS_DESC,ISSU_DESC,EXCP_RQST_DTTM
,CASE
WHEN DOC_DESC IS NULL AND CLSD_CD IS NULL THEN 'Close Referral'
ELSE 'NA'
END AS 'Exception Close'
INTO #NCCIFinal
FROM #MAXNCCI A
LEFT JOIN (SELECT EXCP_ID,LOAN_NBR,DOC_DESC,EXCP_STS_DESC,ISSU_DESC,EXCP_RQST_DTTM FROM Reverse_DW.[dbo].[HUD_ASGN_EXCP_EDW] WHERE DOC_DESC in ('Current OCC Cert') AND EXCP_STS_DESC NOT IN ('Cancelled','Closed','Closed with Vendor','Cured','Incurable','Resolved','Resolved-Pending Original','Not Valid') AND CURR_IND IN ('Y')) B
ON B.[Loan_Nbr] = A.[Loan_Nbr]
WHERE A.CMPGN_NM_DESC IN ('LM0381')

/*
--HOA--
INSERT INTO #NCCIFinal
SELECT A.*,EXCP_ID,DOC_DESC,EXCP_STS_DESC,ISSU_DESC,EXCP_RQST_DTTM
,CASE
WHEN DOC_DESC IS NULL AND CLSD_CD IS NULL THEN 'Close Referral'
ELSE 'NA'
END AS 'Exception Close'
FROM #MAXNCCI A
LEFT JOIN (SELECT EXCP_ID,LOAN_NBR,DOC_DESC,EXCP_STS_DESC,ISSU_DESC,EXCP_RQST_DTTM FROM Reverse_DW.[dbo].[HUD_ASGN_EXCP_EDW] WHERE DOC_DESC in ('HOA') AND EXCP_STS_DESC NOT IN ('Cancelled','Closed','Closed with Vendor','Cured','Incurable','Resolved','Resolved-Pending Original','Not Valid') AND CURR_IND IN ('Y')) B
ON B.[Loan_Nbr] = A.[Loan_Nbr]
WHERE A.CMPGN_NM_DESC IN ('LM0387','LM0389')

--POR--
INSERT INTO #NCCIFinal
SELECT A.*,EXCP_ID,DOC_DESC,EXCP_STS_DESC,ISSU_DESC,EXCP_RQST_DTTM
,CASE
WHEN DOC_DESC IS NULL AND CLSD_CD IS NULL THEN 'Close Referral'
ELSE 'NA'
END AS 'Exception Close'
FROM #MAXNCCI A
LEFT JOIN (SELECT EXCP_ID,LOAN_NBR,DOC_DESC,EXCP_STS_DESC,ISSU_DESC,EXCP_RQST_DTTM FROM Reverse_DW.[dbo].[HUD_ASGN_EXCP_EDW] WHERE DOC_DESC in ('Proof of Repair') AND EXCP_STS_DESC NOT IN ('Cancelled','Closed','Closed with Vendor','Cured','Incurable','Resolved','Resolved-Pending Original','Not Valid') AND CURR_IND IN ('Y')) B
ON B.[Loan_Nbr] = A.[Loan_Nbr]
WHERE A.CMPGN_NM_DESC IN ('LM0388','LM0389')
*/

--Results Query--
SELECT A.*,LOAN_STATUS,[MCA %],
CASE
	WHEN [MCA %] < 97.5 THEN '< 97.5'
	ELSE '>= 97.5'
	END AS 'MCA Flag'
,HUD_STS_DESC,TAG_2_VAL,INCRBL_FLG_DESC,GRP_DESC
,CASE
WHEN A.[Exception Close] NOT IN ('NA') AND CLSD_CD IS NULL THEN A.[Exception Close]
WHEN B.Loan_Status NOT IN ('Active') AND CLSD_CD IS NULL THEN 'Close Referral'
WHEN B.[HUD_STS_DESC] IN ('Pkg Submitted to HUD','HUD Approved','HUD Approval','Resubmitted to HUD') AND CLSD_CD IS NULL THEN 'Close Referral'
WHEN A.[Exception Close] IN ('NA') THEN 'NA'
WHEN B.Loan_Status NOT IN ('Active') AND CLSD_CD IS NOT NULL THEN 'NA'
WHEN B.[HUD_STS_DESC] IN ('Pkg Submitted to HUD','HUD Approved','HUD Approval','Resubmitted to HUD') AND CLSD_CD IS NOT NULL THEN 'NA'
ELSE 'Error'
END AS 'Close Flag'
,CASE
WHEN A.CLSD_CD in ('VAC-Vacant Property') AND [LOAN_STATUS] in ('Active') THEN 'Vacancy Review'
WHEN A.CLSD_CD in ('ORU-Occupant Renting Property - Unconfirmed') AND [LOAN_STATUS] in ('Active') THEN 'Renting Review'
ELSE 'NA'
END AS 'Vacancy Flag'
,CASE
WHEN [CLSD_CD] IN ('SGN-Borrower contact and signed agreement') AND [EXCP_STS_DESC] IS NOT NULL THEN 'Review Exception'
WHEN [EXCP_STS_DESC] IS NULL AND A.[CLSD_CD] IS NULL THEN 'Close NCCI Referral'
WHEN [EXCP_STS_DESC] IS NULL AND A.[CLSD_CD] IS NOT NULL THEN 'N/A - Exception Already Closed'
WHEN [CLSD_CD] NOT IN ('SGN-Borrower contact and signed agreement') AND [CLSD_CD] IS NOT NULL THEN 'NCCI Not Obtained'
WHEN [EXCP_STS_DESC] IS NOT NULL AND [CLSD_CD] IS NULL THEN 'Open Referral'
ELSE 'Error'
END AS 'Exception Flag'
,CASE 
WHEN A.CLSD_CD IN ('BCU-Borrower Contacted & Unable to Obtain Signed Occupancy Cert','CNA-Client Not Available.','GTE-Gated Community No Access to Property','NDC-No Direct Contact/Verification',
'OSA-Out of Current Service Area, Closed by NCCI','OTV-3rd Party: Verification Only','POU-Property Occupied-Unable to Verify Occupant','SKK-Skipped/No Forwarding Info','AGR-Agreed to Contact You','BAD-Bad or Incomplete Address','CON-Debtor Put in Contact with Lender','NBR-Debtor Residency Verified by Neighbor','OTN-3rd Party: Verify & New Info') THEN 'NCCI Unable to Obtain'
WHEN A.CLSD_CD IN ('BKK-Filed Bankruptcy') THEN 'Borrower in BK'
WHEN A.CLSD_CD IN ('SGN-Borrower contact and signed agreement') THEN 'NCCI Obtained'
WHEN A.CLSD_CD IN ('CAN-NCCI Services Cancelled','CLR-Cancelled Lender Request') THEN 'Referral Closed by Champion'
WHEN A.CLSD_CD IN ('VAC-Vacant Property','ORU-Occupant Renting Property - Unconfirmed','RNT-Occupant Renting Property') THEN 'NCCI Reports Vacant'
WHEN A.CLSD_CD is NULL THEN 'Open Referral'
ELSE 'Error'
END AS 'Success Flag' 
FROM #NCCIFinal A
LEFT JOIN #LoanStatus B
ON CAST(A.Loan_Nbr AS nvarchar) = CAST(B.Loan_Nbr AS NVarchar)
WHERE (B.[TAG_2_VAL] NOT IN ('Servicer Cure') OR B.[TAG_2_VAL] IS NULL)
AND CMPGN_NM_DESC IN ('LM0381')

ORDER BY [MCA Flag],CMPGN_NM_DESC,ORDR_DT DESC

DROP TABLE #MAXNCCI,#LoanStatus,#NCCIFinal,#MaxBus,#MAXORDER