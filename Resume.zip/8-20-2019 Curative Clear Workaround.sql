CREATE TABLE #RosterTemp (AGNT_NM NVARCHAR(MAX), MGR_NM NVARCHAR(MAX),ST_LOC NVARCHAR(MAX), GRP_NM NVARCHAR(MAX))

INSERT INTO #RosterTemp
VALUES 
('Aida Trainer','Thomas Ruelas','Texas','Validators'),
('Aishwarya T','Rupalita Sarangi','Offshore','Producer'),
('Akhash S','Rupalita Sarangi','Offshore','Producer'),
('Akshay P','Rupalita Sarangi','Offshore','Resubmission'),
('Alexander Ledger','Pipeline Management','Pipeline Management','Non Producer'),
('Amber Ledesma','Chelsea Daniel','Arizona','QC Team'),
('Anand Srinivasan','Offshore - Manager','Offshore','Manager'),
('Andrika Lasker','Robert Gough','Arizona','Non Time Sensitive'),
('Anita Shepherd','Chelsea Daniel','Arizona','QC Team'),
('Antoinette Barnes','Edward Martin','Texas','OS Submitter'),
('Ashwin Kumar S','Rupalita Sarangi','Offshore','Producer'),
('Avinash K','Rupalita Sarangi','Offshore','Producer'),
('Bianca Stimson','Jason Adams','Arizona','Producer'),
('Billy Moore','Pipeline Management','Pipeline Management','Manager'),
('Blaine Finto','Norse Lockhart','Texas','Producer'),
('Braniqua Castleberry','Thomas Ruelas','Texas','Validators'),
('Brian Hahn','Jason Adams','Arizona','Producer'),
('Brianne Hamilton','Chelsea Daniel','Texas','QC Team'),
('Bryan Petty','Jason Adams','Arizona','Producer'),
('Catrina Wofford','Edward Martin','Texas','Producer'),
('Charlonda Howard','Thomas Ruelas','Texas','Validators'),
('Chaunie Horton','Jason Adams','Arizona','LOA'),
('Chelsea Daniel','Pipeline Management','Pipeline Management','Manager'),
('Chingmak Lachumong Chang','Rupalita Sarangi','Offshore','Producer'),
('Chris Wandel','Pipeline Management','Pipeline Management','Non Producer'),
('Christopher Arredondo','Jason Adams','Arizona','Producer'),
('Crystal Gray','Norse Lockhart','Texas','Producer'),
('Deepak N','Rupalita Sarangi','Offshore','Producer'),
('Devona Price','Thomas Ruelas','Texas','Validators'),
('Dhinesh Kumar K','Rupalita Sarangi','Offshore','Producer'),
('Dinah Segaye','Jordan Frost','Texas','Claims'),
('Ebony Williams','Edward Martin','Texas','OS Submitter'),
('Edward Martin','Pipeline Management','Pipeline Management','Manager'),
('Emiliya Ivanova','Edward Martin','Texas','Producer'),
('Emmanuel Vongor','Thomas Ruelas','Texas','Validators'),
('Eric Wallace','Edward Martin','Texas','Producer'),
('Georgia Rowe','Edward Martin','Texas','OS Phone'),
('Heidi Molina','Thomas Ruelas','Texas','Validators'),
('Issac Browne','Thomas Ruelas','Texas','Validators'),
('James Patrone','Jason Adams','Arizona','Producer'),
('James Warren','Pipeline Management','Pipeline Management','Manager'),
('Jason Adams','Pipeline Management','Pipeline Management','Manager'),
('Jatori Moore','Thomas Ruelas','Texas','Validators'),
('Jeff Joyner','Thomas Ruelas','Texas','Validators'),
('Jeff Morelan','Jordan Frost','Texas','Claims'),
('Jesse Eyman','Jason Adams','Arizona','Producer'),
('Jonelle Christmas','Thomas Ruelas','Texas','Validators'),
('Jordan Frost','James Warren','Texas','Claims'),
('Jyothi K','Rupalita Sarangi','Offshore','Producer'),
('Kalaivani K','Rupalita Sarangi','Offshore','Producer'),
('Kari Pester','Pipeline Management','Pipeline Management','Non Producer'),
('Karrington Henson','Billy Moore','Texas','Time Sensitive'),
('Kayla Dupre','Thomas Ruelas','Texas','Validators'),
('Kiersten Davis','Chelsea Daniel','Texas','QC Team'),
('Krystal Wallace','Norse Lockhart','Texas','Producer'),
('Ladarius Bryant','Edward Martin','Texas','Producer'),
('LaMarcus Jackson','Billy Moore','Texas','Time Sensitive'),
('Lance Lyons','Norse Lockhart','Texas','Producer'),
('LaQuitha Johnson','Jordan Frost','Texas','Claims'),
('LaTonia Marshall','Thomas Ruelas','Texas','Validators'),
('Lokesh Kumar S','Rupalita Sarangi','Offshore','Producer'),
('Lori Wendt','Jason Adams','Arizona','LOA'),
('Madeline Caldwell','Pipeline Management','Pipeline Management','Manager'),
('Madona Jhansi Rani N','Rupalita Sarangi','Offshore','Producer'),
('Margaret Cantu','Norse Lockhart','Texas','Producer'),
('Marisela Martinez','Billy Moore','Texas','Time Sensitive'),
('Marisol Trejo','Chelsea Daniel','Texas','QC Team'),
('Michelle McRae','Jason Adams','Arizona','Producer'),
('Monica Zhang','Billy Moore','Texas','Time Sensitive'),
('Nacie Williams','Robert Gough','Arizona','Non Time Sensitive'),
('Niha Jaffarin H','Rupalita Sarangi','Offshore','Producer'),
('Nikita Hilson','Chelsea Daniel','Texas','QC Team'),
('Norse Lockhart','Pipeline Management','Pipeline Management','Manager'),
('Prem Harish C','Rupalita Sarangi','Offshore','Producer'),
('Priyanka E','Rupalita Sarangi','Offshore','Producer'),
('Renee Williams','Chelsea Daniel','Texas','QC Team'),
('Robert Gough','Pipeline Management','Pipeline Management','Manager'),
('Rupalita Sarangi','Rupalita Sarangi','Offshore','Manager'),
('Sai Pujitha J','Rupalita Sarangi','Offshore','Resubmission'),
('Sai Vignesh Premsai','Rupalita Sarangi','Offshore','Resubmission'),
('Sathish Kumar P','Rupalita Sarangi','Offshore','Producer'),
('Senthil Kumaran D','Rupalita Sarangi','Offshore','Producer'),
('Shalonda Rodgers','Norse Lockhart','Texas','Producer'),
('Shameka Easterling','Norse Lockhart','Texas','Producer'),
('Shanika Stanley','Chelsea Daniel','Arizona','QC Team'),
('Shannon Harris-Mcbrayer','Pipeline Management','Pipeline Management','Manager'),
('Sharon Berry','Thomas Ruelas','Texas','Validators'),
('Shasta Patton','Pipeline Management','Pipeline Management','Manager'),
('Shawn Clayborne-Greer','Norse Lockhart','Texas','Producer'),
('Shawneequa Mitchell','Edward Martin','Texas','Producer'),
('Shelby Dominguez','Pipeline Management','Pipeline Management','Manager'),
('Shelia White','Thomas Ruelas','Texas','Validators'),
('Sherry Alquino','Robert Gough','Arizona','Non Time Sensitive'),
('Suresh Adhikesavan','Rupalita Sarangi','Offshore','Producer'),
('Tabitha Howard','Chelsea Daniel','Arizona','Non Producer'),
('Tiffani Levi','Billy Moore','Texas','OS Phone'),
('Tina Bryson-Langley','Robert Gough','Arizona','Non Time Sensitive'),
('Velma Alvarado','Thomas Ruelas','Texas','Validators'),
('Veronica Garcia','Thomas Ruelas','Texas','Validators'),
('Vijay Sankaralingam','AVP - Offshore','Offshore','Manager')


SET NOCOUNT ON 
select
a.[Loan Number]
,A.Stage
,a.[MCA %]
,case
	when a.[Stage] IN ('Final Review') then b.[Final Review Status]
	else c.[HUD status]
	end as 'Status'
,b.[final review assigned to]
,c.[HUD Assigned To]
,ISNULL(c.[HUD Assigned To], b.[final review assigned to]) AS 'AGENT'
,case
	when t.[Open Exceptions] = 0 then '0 Exceptions'
	When t.[Open Exceptions] = 1 then '1 Exception'
	when t.[open exceptions] = 2 then '2 Exceptions'
	when t.[open exceptions] >=3 then '3+ Exceptions'
	end as 'Open Exceptions'
,cast(cer.[Certification Date]as date) as 'Certification Date'
,cer.[Certification Status]
,CAST(CER.[Reviewed Date] AS DATE) AS 'Reviewed Date'
,case
	when cer.[certification date] is null then 'Validation Request'
	else 'Curative Cleared'
	end as 'Pipeline Flag'
,r.grp_nm

from SharepointData.dbo.HUDAssignLoans a
left join SharepointData.dbo.HUDAssignFinalReview b
on b.[Loan Number]=a.[Loan Number]
left join SharepointData.dbo.HUDAssignHUDStatus c
on c.[Loan Number]=a.[Loan Number]
left join sharepointdata.dbo.HUDAssignLoanExceptionTotals t
on a.[Loan Number]=t.[Loan Number]
left join sharepointdata.dbo.HUDAssignCertificationReview cer
on a.[Loan Number]=cer.[Loan Number]
left join #RosterTemp r
on c.[HUD Assigned To]=r.[AGNT_NM]

where a.[Tag 2] is null and
a.[Loan Status] in ('active') and
a.[MCA %] >= 97.5 and
(c.[HUD Assigned To] is null or r.grp_nm is null) and
--a.[stage] not in ('doc pooling') and
t.opencurative = 0 and
a.[Incurable Flag] in ('0') and
(a.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
a.[Group] is null)and
c.[HUD Status] not in ('HUD Approved','Pkg Submitted to HUD','Resubmitted to HUD','Rebuttal to HUD')
--AND A.[Loan Number] IN ('874649')

order by [Pipeline Flag] desc

DROP TABLE #RosterTemp


--version2 6.27.2019: removed 'stage' restriction from where statement "--a.[stage] not in ('doc pooling') and"