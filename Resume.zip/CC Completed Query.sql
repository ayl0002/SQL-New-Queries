select base.*, [Call Date/Time], [HOAA/CHOA Description] as 'Call Result' from 
(select [loan number],[document],issue, [exception id], cast([exception status date] as date) as 'Closed Date', [exception status]
from sharepointdata.dbo.HUDAssignBackupExceptions
where ([document] like 'Not Eno%' or [issue] like 'Not En%' or [issue] like 'Force%' or [document] = 'Loss Draft' or [document] = 'Current OCC Cert' or [document] = 'Tax Bill' or [document] = 'Death Cert HACG' or [document] = 'HOA' or [document] = 'Trust - HACG') 
and [exception status] in ('Resolved', 'Closed with Vendor', 'Canceled', 'Not Valid', 'Incurable','Resolved by ML')
and datediff(day,[exception status date],getdate()) < 61) base
left join


(select * from tact_rev.dbo.billcalldata
where /*xrank = 1 and*/ [Call Type] is not null
 /*and [Call Type] = 'NER'
and [HOAA/CHOA] in ('ANER', 'PNER')*/) cd on base.[loan number]=cd.[Loan Number] 
