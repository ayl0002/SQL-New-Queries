with Submissions as (
select
p.LoanNumber
,max(p.DateSubmittedToHUD) 'Submission Date'

from [SharepointData].[dbo].[HUDAssignDateSubmittedResubmittedtoHUD] P
group by p.LoanNumber)


SELECT distinct
    
      l.[Loan Number]
	  ,datediff(day,cast(p.[Submit Date] as date),getdate()) as 'Days Submitted'
	        ,case 
 when datediff(day,cast(p.[Submit Date] AS DATE),getdate()) < 0 and s.[HUD Status] in ('Pkg Submitted to HUD','Resubmitted to HUD') then '0-2'
 when datediff(day,cast(p.[Submit Date] AS DATE),getdate()) between 0 and 2 and s.[HUD Status] in ('Pkg Submitted to HUD','Resubmitted to HUD') then '0-2'
  when datediff(day,cast(p.[Submit Date] AS DATE),getdate()) between 3 and 14 and s.[HUD Status] in ('Pkg Submitted to HUD','Resubmitted to HUD') then '3-5'
 when datediff(day,cast(p.[Submit Date] AS DATE),getdate()) between 6 and 10 and s.[HUD Status] in ('Pkg Submitted to HUD','Resubmitted to HUD') then '6-10'
 when datediff(day,cast(p.[Submit Date] AS DATE),getdate()) between 11 and 15 and s.[HUD Status] in ('Pkg Submitted to HUD','Resubmitted to HUD') then '11-15'
 when datediff(day,cast(p.[Submit Date] AS DATE),getdate()) between 16 and 20 and s.[HUD Status] in ('Pkg Submitted to HUD','Resubmitted to HUD') then '16-20'
 when datediff (day,cast(p.[Submit Date] AS DATE),getdate())  >= 21 and s.[HUD Status] in ('Pkg Submitted to HUD','Resubmitted to HUD') then '21+'
        else 'Not Submitted'
         end as 'Submitted to HUD Aging'
	 ,convert(nvarchar(10),p.[Submit Date],101)as'Submit Date'
	 ,convert(nvarchar(10),a.MCA_CROSSOVER_DT,101)as '100% Date'
      ,l.[Loan Status]
      ,i.[FHA Case Number]
      ,I.Investor
      ,I.[Pool Name]
      ,I.Portfolio
      ,s.[FNMA Approval Indicator]
      ,s.[FNMA Approval Requested Date]
      ,s.[FNMA Approval Required]
      ,s.[FNMA Approved Date]
      ,s.[FNMA Denied Date]
      ,s.[FNMA Owned Loss]
      ,case
      when I.Portfolio = 'BOA' and I.Investor = 'GNMA' then 'BOA Buyout'
      when i.Portfolio = 'RMS' and i.Investor = 'GNMA' then 'BOA Buyout'
      when i.Investor = 'NSM' then 'NSM'
     when i.[Pool Name] = 'EBOUTIQUE-FNMA-CHAMPION' and i.Investor = 'FNMA' then 'eBoutique'
     when i.Portfolio = 'WF' then 'Wells Fargo'
     when i.[Pool Name] = 'MECA-2011' and i.Investor = 'FNMA' then 'MECA'
      
      else 'Private'
      
      end as 'Pipeline'
,f.[Final Review Status]
,s.[HUD Status]
,cast(f.[Date Submitted to HUD] as date) 'FR Submitted to HUD'
	,cast(s.[HUD Preliminary Title Denial Date]as date) 'Denial Date'
	  ,l.[Loan Status]
      ,m.CASE_STATUS
      ,m.CASE_SUB_STATUS
      ,m.SERVICING_STATUS
      ,m.SERVICING_TYPE
 
      
      ,cast(m.HERMIT_CREATED_DATE as date) 'HERMIT Date'
          ,case 
      when datediff(day,cast(m.HERMIT_CREATED_DATE as date),getdate()) < 0  then '0-15'
      when datediff(day,cast(m.HERMIT_CREATED_DATE as date),getdate()) between 0 and 15 then '0-15'
      when datediff(day,cast(m.HERMIT_CREATED_DATE as date),getdate()) between 15 and 30 then '15-30'
      when datediff(day,cast(m.HERMIT_CREATED_DATE as date),getdate()) between 30 and 45 then '30-45'
       when datediff(day,cast(m.HERMIT_CREATED_DATE as date),getdate()) between 45 and 60 then '45-60'
       when datediff(day,cast(m.HERMIT_CREATED_DATE as date),getdate()) between 60 and 90 then '60-90'
       when datediff(day,cast(m.HERMIT_CREATED_DATE as date),getdate()) > 90 then '90+'
         end as 'HERMIT Submission Aging'
         
        ,s.[HUD Status] 'iAssign Submission Status'
 
      ,CASE
      when s.[HUD Status] = 'Pkg Submitted to HUD' and cast(m.HERMIT_CREATED_DATE as date) is NULL then 'Check HERMIT Timeline'
      when s.[HUD Status] = 'Pkg Submitted to HUD' and cast(m.HERMIT_CREATED_DATE as date) is not NULL then 'Timeline Open'
      when s.[HUD Status] = 'Resubmitted to HUD' and cast(m.HERMIT_CREATED_DATE as date) is NULL then 'Check HERMIT Timeline'
      when s.[HUD Status] = 'Resubmitted to HUD' and cast(m.HERMIT_CREATED_DATE as date) is not NULL then 'Timeline Open'
      when s.[HUD Status] = 'HUD Denied' and cast(m.HERMIT_CREATED_DATE as date) is NULL then 'HUD Denied'
      when s.[HUD Status] = 'HUD Denied' and cast(m.HERMIT_CREATED_DATE as date) is not NULL then 'Timeline Open'
      when s.[HUD Status] = 'HUD Approval'and cast(m.HERMIT_CREATED_DATE as date) is NULL then 'Check HERMIT Timeline'
      when s.[HUD Status] = 'HUD Approval'and cast(m.HERMIT_CREATED_DATE as date) is not NULL then 'HUD Approved'
      
      else 'Not Submitted in iAssign'
      end as 'HERMIT Timeline Status'
      
   ,l.Stage
   
,f.[Final Review Assigned To]
,f.[Final Review Status Updated By]
,f.[Final Review Status]
,s.[HUD Assigned To]
,cast(f.[Final Review Status Date] as date) 'Final Review Status Date'
    ,datediff(day,cast(f.[Final Review Status Date] as date),getdate()) 'Final Review Aging'
      ,case 
      when datediff(day,cast(f.[Final Review Status Date] as date),getdate()) < 0  then '0-15'
      when datediff(day,cast(f.[Final Review Status Date] as date),getdate()) between 0 and 15 then '0-15'
      when datediff(day,cast(f.[Final Review Status Date] as date),getdate()) between 15 and 30 then '15-30'
      when datediff(day,cast(f.[Final Review Status Date] as date),getdate()) between 30 and 45 then '30-45'
       when datediff(day,cast(f.[Final Review Status Date] as date),getdate()) between 45 and 60 then '45-60'
       when datediff(day,cast(f.[Final Review Status Date] as date),getdate()) between 60 and 90 then '60-90'
       when datediff(day,cast(f.[Final Review Status Date] as date),getdate()) > 90 then '90+'
         end as 'Final Review Aging'
         

,cast(s.[HUD Status Date] as date) 'HUD Status Date'
,s.[HUD Status]
      ,case 
      when datediff(day,cast(s.[HUD Status Date] as date),getdate()) < 0  then '0-15'
      when datediff(day,cast(s.[HUD Status Date] as date),getdate()) between 0 and 2 then '0-2'
	  when datediff(day,cast(s.[HUD Status Date] as date),getdate()) between 3 and 14 then '3-14'
      when datediff(day,cast(s.[HUD Status Date] as date),getdate()) between 15 and 30 then '15-30'
      when datediff(day,cast(s.[HUD Status Date] as date),getdate()) between 30 and 45 then '30-45'
       when datediff(day,cast(s.[HUD Status Date] as date),getdate()) between 45 and 60 then '45-60'
       when datediff(day,cast(s.[HUD Status Date] as date),getdate()) between 60 and 90 then '60-90'
       when datediff(day,cast(s.[HUD Status Date] as date),getdate()) > 90 then '90+'
         end as 'HUD Status Aging'

,cast(s.[HUD Preliminary Title Approval]as date) 'Approval Date'
,datediff(day,cast(s.[HUD Preliminary Title Approval]as date),getdate()) 'PTA Aging'

,datediff(day,cast(s.[HUD Preliminary Title Denial Date]as date),getdate()) 'Denial Aging'

,CASE
when datediff(day,cast(s.[HUD Preliminary Title Denial Date]as date),getdate()) = '1' then '1 Day'
when datediff(day,cast(s.[HUD Preliminary Title Denial Date]as date),getdate()) = '2' then '2 Days'
when datediff(day,cast(s.[HUD Preliminary Title Denial Date]as date),getdate()) = '3' then '3 Days'
when datediff(day,cast(s.[HUD Preliminary Title Denial Date]as date),getdate()) = '4' then '4 Days'
when datediff(day,cast(s.[HUD Preliminary Title Denial Date]as date),getdate()) > '4' then '4+ Days'
end as 'Denial Day(s) Aging'

,cast(s.[Original Note Sent to HUD] as date) 'Original Note Sent to HUD'
,cast(s.[Original Note Received by HUD] as date) 'Original Note Received by HUD'
,cast(s.[Initial Claim Filed] as date) 'Initial Claim'

      ,f.MCA
           
          
    ,case 
    
	when f.MCA between '92.00' and '95.00' then '92-95'
    when f.MCA between '95.00' and '97.49' then '95-97.5'
      when f.MCA between '97.49' and '98.00' then '97.5-98.00'
      when f.MCA between '98.00' and '98.50' then '98-98.5'
      when f.MCA between '98.50' and '99.00' then '98.5-99'
       when f.MCA between '99.00' and '99.50' then '99-99.5'
      when f.MCA between '99.50' and '100.00' then '99.5-100'
      when f.MCA > '100.00' then '>100'
      else '<92'
      end as 'MCA Bucket'
      
      ,l.UPB
            ,case when l.UPB > 600000 then '$600,000+'
when l.UPB between 550000 and 600000 then '$550-600k'
when l.UPB between 500000 and 550000 then '$500-550k'
when l.UPB between 450000 and 500000 then '$450-500k'
when l.UPB between 400000 and 450000 then '$400-450k'
when l.UPB between 350000 and 400000 then '$350-400k'
when l.UPB between 300000 and 350000 then '$300-350k'
when l.UPB between 250000 and 300000 then '$250-300k'
when l.UPB between 200000 and 250000 then '$200-250k'
when l.UPB between 100000 and 200000 then '$100-200k'
when l.UPB < 100000 then '<$100k'
end as 'UPB Bucket'
      ,l.[Open Exceptions]
      ,l.[Pool Name]
      ,l.Portfolio
      ,l.[Tag 1]
      ,l.[Tag 2]
      ,l.[Tag 3]


  FROM 

 [SharepointData].[dbo].[HUDAssignLoans] L (nolock)
join [SharepointData].[dbo].[HUDAssignLoanExceptionTotals] E 
  on e.[Loan Number] = l.[Loan Number]
join [SharepointData].[dbo].[HUDAssignFinalReview] F (nolock)
on f.[Loan Number] = e.[Loan Number]
join [SharepointData].[dbo].[HUDAssignHUDStatus] S (nolock)
on s.[Loan Number] = f.[Loan Number]
 join [TACT_REV].[docs].[tbl_ChainOfTitle_Master] M (Nolock)
 on m.LOAN_NBR = s.[Loan Number]
left join (select p.LoanNumber, max(p.DateSubmittedToHUD) as 'Submit Date' from [SharepointData].[dbo].[HUDAssignDateSubmittedResubmittedtoHUD] P group by p.[LoanNumber]) p
on p.LoanNumber = s.[Loan Number]
join Submissions X on x.LoanNumber = p.LoanNumber and cast(p.[Submit Date] as date) = cast(x.[Submission Date] as date)
 join [SharepointData].[dbo].[HUDAssignLoanPopulationIndex] I (nolock)
 on I.[Loan Number] = s.[Loan Number]
 left join [VRSQLRODS\RODS_PROD].reverse_dw.[dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] a
 on l.[Loan Number]=a.loan_nbr

 where
 
  
s.[HUD Status] in ('Pkg Submitted to HUD','HUD Approval','Resubmitted to HUD','AOM Sent to HUD','HUD Approved')

and a.MCA_CROSSOVER_DT < p.[Submit Date]

and i.[Pool Name] in('EBOUTIQUE-FNMA-CHAMPION','WellsFarg')

and l.[MCA %] >= '100.00'

and l.[Loan Status] = 'Active'

and (s.[FNMA Approval Requested Date] IS NULL OR (s.[FNMA Approval Requested Date] IS NOT NULL AND [FNMA Approved Date] IS NULL AND [FNMA Denied Date] IS NULL))

order by 'Days Submitted' desc