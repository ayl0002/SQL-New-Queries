SELECT
A.[LOAN NUMBER]
,M.[Pool_Name]
,M.[MCA_PERCENT]
,S.[Submit Date]


FROM SHAREPOINTDATA.DBO.HUDASSIGNLOANS A
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNHUDSTATUS C
ON A.[LOAN NUMBER]=C.[LOAN NUMBER]
LEFT JOIN (SELECT [LoanNumber], max([DateSubmittedToHUD])as 'Submit Date' FROM SHAREPOINTDATA.[dbo].[HUDAssignDateSubmittedResubmittedtoHUD] group by [LoanNumber])S
ON A.[Loan Number]=S.LOANNUMBER
LEFT JOIN [VRSQLRODS\RODS_PROD].REVERSE_DW.[dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] M
ON A.[LOAN NUMBER]=M.LOAN_NBR
WHERE
M.[Pool_Name] IN ('EBOUTIQUE-FNMA-CHAMPION','WellsFarg') AND
M.[MCA_PERCENT] >= ('100') AND
C.[HUD Status] IN ('Pkg Submitted to HUD','HUD Approval','Resubmitted to HUD','AOM Sent to HUD','HUD Approved') AND
C.[FNMA Approval Required] IN ('YES') AND
C.[FNMA Approval Requested Date] IS NULL AND
A.[Loan Status] IN ('ACTIVE')

ORDER BY S.[Submit Date] ASC