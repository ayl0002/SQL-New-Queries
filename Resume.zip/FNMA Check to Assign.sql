select *  from 
(select loan_nbr, mca_percent, current_total_upb - max_claim_amount as 'Cross Over Exposure' from [dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] where status_code = 0 and pool_name like '%eboutique%'
and mca_percent >= 100) base
left join
(select loan_nbr, max([DT_SBMT_TO_HUD]) as 'Last Submission' from [dbo].[HUD_ASSGN_DT_SBMT_RESBMT]
group by loan_nbr) sbm on cast(base.loan_nbr as varchar)=sbm.loan_nbr
left join
(select [loan number],[HUD Assigned Loans Tag1], [HUD Assigned Loans Tag2] as 'Tag_2_Val' , [Incurable Flag],[HUD Denied Date]  from
rm_dmart01.[dbo].[DM_HUD_DIM] where curr_ind = 'Y') dmrt on cast(base.loan_nbr as varchar)=dmrt.[loan number]
left join
(select [loan_nbr], [FNM_APRV_RQST_DTTM] from [dbo].[HUD_ASGN_HUD_STS] where curr_ind = 'Y') hsts on cast(base.loan_nbr as varchar)=hsts.[loan_nbr]
left join
(select lndr_loan_nbr, max(dny_dt) as 'Last Denial' from [dbo].[TP_HRMT_PRELIM_TTL_DNY]
group by lndr_loan_nbr) dny on cast(base.loan_nbr as varchar)=dny.lndr_loan_nbr
left join
(select lndr_loan_nbr, max(hud_aprv_dt) as 'Approval' from [dbo].[TP_HRMT_PRELIM_TTL_aprv]
group by lndr_loan_nbr) apr on cast(base.loan_nbr as varchar)=apr.lndr_loan_nbr
left join
(select loan_nbr, count(distinct excp_id) as 'Inc Count' from [dbo].[HUD_ASGN_EXCP_EDW] where excp_sts_desc = 'Incurable' and
doc_desc in ('Orig Loan App', 'Orig Appraisal', 'Loan Agreement', 'Signed Pay Plan')
and eff_dttm < '2019-08-01' group by loan_nbr) inc on cast(base.loan_nbr as varchar)=inc.loan_nbr
left join
(select loan_nbr, max(end_dttm) as 'Cure Date' from [dbo].[HUD_ASGN_EXCP_EDW] where 
excp_sts_desc = 'Incurable' group by loan_nbr) cur on cast(base.loan_nbr as varchar)=cur.loan_nbr
left join
(select * from ##augmca) aug on base.loan_nbr=aug.loan_nbr
left join
(select * from ##maymca) jun on base.loan_nbr=jun.loan_nbr

where [Last Submission] is not null and [incurable flag] = '0' and [tag_2_val] is null and [FNM_APRV_RQST_DTTM] is null 
and ([last denial] is null or [last Submission] > [last denial])
and ([hud denied date] is null or [last Submission] > [hud denied date]) and [inc count] is not null

order by [cure date]



select loan_nbr, current_total_upb 'August UPB', max_claim_amount, case when mca_percent >= 100 then  current_total_upb - max_claim_amount end as 'Cross Over as of August 1' into ##augmca
from [dbo].[RM_CHAMPION_MASTER_TBL_VW]('2019-07-31',20190731)


select loan_nbr, current_total_upb as 'June UPB', case when mca_percent >= 100 then  current_total_upb - max_claim_amount end as 'Cross Over as of May 1' into ##maymca
from [dbo].[RM_CHAMPION_MASTER_TBL_VW]('2019-05-31',20190531)