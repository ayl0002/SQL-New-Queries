SELECT Distinct A.Loan_Nbr,
A.CLIENT_LOAN_NBR
,A.Pool_Name
,A.Investor
--,D.FNL_RVW_ASGN_TO_NM
--,C.HUD_ASGN_TO_NM
,B.BORR_NM
,A.Borrower_Last_Name
,B.LOAN_STS_DESC
,B.STG_VAL
,B.HUD_STS_DESC
,CASE
WHEN B.ALL_EXCP_CNT > 0 THEN (CAST(B.ALL_EXCP_CNT - B.ALL_CLOSD_EXCP_CNT AS INT)) 
ELSE B.ALL_EXCP_CNT
END AS 'Open Exceptions'
,CAST(B.ALL_EXCP_CNT AS INT)AS 'Total Exceptions'
,CAST(B.ALL_CLOSD_EXCP_CNT AS INT)AS 'Closed Exceptions'
,B.MCA_PCT,(SELECT MAX (BUS_PROC_DT) FROM [Reverse_DW].[dbo].[HUD_ASGN_LOANS]) AS 'Last Updated Date'
,CASE
WHEN B.LOAN_STS_DESC in ('Liquidated/Assigned to HU') AND B.HUD_STS_DESC in ('HUD Approved') THEN 'Claim Paid'
When B.HUD_STS_DESC in ('HUD Denied') and B.LOAN_STS_DESC in ('Active') THEN 'HUD Denied'
When B.LOAN_STS_DESC not in ('Active') THEN B.LOAN_STS_DESC
WHEN B.HUD_STS_DESC in ('Pkg Submitted to HUD') and B.LOAN_STS_DESC in ('Active') or B.HUD_STS_DESC in ('Resubmitted to HUD') AND B.LOAN_STS_DESC in ('Active') THEN 'Submitted to HUD'
WHEN B.MCA_PCT > '97.5' AND B.LOAN_STS_DESC in ('Active') AND B.HUD_STS_DESC in ('Not Started') THEN 'Currently Under Review for Assignment'
ELSE 'Under 97.5'
END AS 'Claim Status'
,Case
WHEN B.MCA_PCT < '97.5' then 'Less Than 97.5'
WHEN B.MCA_PCT BETWEEN '97.5' and '100' THEN 'Between 97.5 and 100'
ELSE 'Above 100'
END AS 'MCA Bucket'
FROM [Reverse_DW].[dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] A
LEFT JOIN [Reverse_DW].[dbo].[HUD_ASGN_LOANS] B
ON B.Loan_Nbr = A.Loan_Nbr
--LEFT JOIN [Reverse_DW].[dbo].[HUD_ASGN_HUD_STS] C
--ON C.Loan_Nbr = A.Loan_Nbr AND C.CURR_IND = C.CURR_IND
--LEFT JOIN [Reverse_DW].[dbo].[HUD_ASGN_FNL_RVW] D
--ON D.Loan_Nbr = A.Loan_Nbr
WHERE A.Investor in ('GNMA')  
ORDER BY ('Claim Status'),('MCA Bucket')
