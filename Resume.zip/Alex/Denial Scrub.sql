--REASSIGN TO MARISELA OR TO HACG FLOOR--
SELECT
A.*

,D.[Final Review Assigned To]
,C.[HUD Assigned To]
,T.OpenCurative
,t.OpenHACG
,C.[HUD Status]
,Cast([HUD Status Date] AS Date) AS 'HUD Last Updated'
,[HUD Status Updated By]
,[HUD Status Comment]
,DATEDIFF(Day,cast(c.[HUD Preliminary Title Denial Date]as DATE),Cast(GetDate() AS Date)) AS 'Denied Aging'
,cast(c.[HUD Preliminary Title Denial Date]as DATE) as 'Denial Date'

FROM (SELECT [Loan NUMBER],[MCA %],[Loan STATUS],[TAG 2],[INCURABLE FLAG],[Group] FROM SHAREPOINTDATA.DBO.HUDAssignLoans WHERE [Loan Status] IN ('ACTIVE') AND [Incurable Flag] IN ('0') AND [Tag 2] IS NULL)A
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignLoanExceptionTotals T
ON A.[Loan Number]=T.[Loan Number]
LEFT JOIN SharepointData.DBO.HUDAssignHUDStatus C
ON A.[Loan Number]=C.[Loan Number]
LEFT Join SharepointData.Dbo.HUDAssignFinalReview D
ON A.[Loan Number] = D.[Loan Number]

WHERE C.[HUD Status] NOT IN ('RESUBMITTED TO HUD','REBUTTAL TO HUD','HUD Approved') AND DATEDIFF(Day,cast(c.[HUD Preliminary Title Denial Date]as DATE),Cast(GetDate() AS Date)) >= 10 AND [HUD Assigned To] IN ('Akshay P','Sai Pujitha J','Sai Vignesh Premsai') AND [MCA %] >= 98

order by [Denial Date] desc