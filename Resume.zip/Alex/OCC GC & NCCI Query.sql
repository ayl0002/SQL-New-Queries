SET NOCOUNT ON
SELECT A.[Loan Number],A.[Stage],B.[Exception ID],B.[Document],B.[Issue],B.[Exception Status],A.[Loan Status],CAST(CAST(A.[MCA %] AS Decimal (10,2)) AS VarChar) + ' %' AS 'MCA %'
,CAST(B.[Exception Request Date] AS Date) 'Exception Opened'
,CASE
	WHEN DATEDIFF (Days,(B.[Exception Request Date] AS Date),GetDate()) =< 1 THEN 'New Exception'
	WHEN DATEDIFF (Days,(B.[Exception Request Date] AS Date),GetDate()) BETWEEN 1 AND 7 THEN 'Between 1 and 7 Days'
	WHEN DATEDIFF (Days,(B.[Exception Request Date] AS Date),GetDate()) BETWEEN 8 AND 15 THEN 'Between 8 and 15 Days'
	WHEN DATEDIFF (Days,(B.[Exception Request Date] AS Date),GetDate()) BETWEEN 16 AND 30 THEN 'Between 16 and 30 Days'
	WHEN DATEDIFF (Days,(B.[Exception Request Date] AS Date),GetDate()) BETWEEN 31 AND 60 THEN 'Between 31 and 60 Days'
,CASE
	WHEN A.[MCA %] >'100' THEN 'Over 100 MCA'
	WHEN A.[MCA %] BETWEEN 97.5 AND 100  THEN '97.5 < 100'
	WHEN A.[MCA %] BETWEEN 96.5 AND 97.5 THEN '96.5 AND 97.5'
	WHEN A.[MCA %] < 96.5 THEN 'Below 96.5'
ELSE 'Error'
END AS 'MCA Bucket'
,CASE
	WHEN B.[Sent for Gift Card Processing] is not null AND B.[Sent to Inspection Vendor] is null THEN 'No NCCI / GC Voucher Sent'
	WHEN B.[Sent for Gift Card Processing] is not null AND B.[Sent to Inspection Vendor] is not null THEN 'Referred to NCCI / GC Voucher Sent'
	WHEN B.[Gift Card Letter Sent] is null AND B.[Gift Card Letter Sent 2] is null AND B.[Gift Card Letter Sent 3] is null AND B.[Sent for Gift Card Processing] is null AND B.[Sent to Inspection Vendor] is null THEN 'No NCCI / No GC'
	WHEN B.[Gift Card Letter Sent] is null AND B.[Gift Card Letter Sent 2] is null AND B.[Gift Card Letter Sent 3] is null AND B.[Sent for Gift Card Processing] is null AND B.[Sent to Inspection Vendor] is not null THEN 'Referred to NCCI / No GC'
	WHEN B.[Gift Card Letter Sent] is not null AND B.[Gift Card Letter Sent 2] is null AND B.[Gift Card Letter Sent 3] is null AND B.[Sent for Gift Card Processing] is null AND B.[Sent to Inspection Vendor] is null THEN 'No NCCI / GC 1' 
	WHEN B.[Gift Card Letter Sent] is not null AND B.[Gift Card Letter Sent 2] is null AND B.[Gift Card Letter Sent 3] is null AND B.[Sent for Gift Card Processing] is null AND B.[Sent to Inspection Vendor] is not null THEN 'Referred to NCCI / GC 1'
	WHEN B.[Gift Card Letter Sent] is not null AND B.[Gift Card Letter Sent 2] is not null AND B.[Gift Card Letter Sent 3] is null AND B.[Sent for Gift Card Processing] is null AND B.[Sent to Inspection Vendor] is null THEN 'No NCCI / GC 2'
	WHEN B.[Gift Card Letter Sent] is not null AND B.[Gift Card Letter Sent 2] is not null AND B.[Gift Card Letter Sent 3] is null AND B.[Sent for Gift Card Processing] is null AND B.[Sent to Inspection Vendor] is not null THEN 'Referred to NCCI / GC 2'
	WHEN B.[Gift Card Letter Sent] is not null AND B.[Gift Card Letter Sent 2] is not null AND B.[Gift Card Letter Sent 3] is not null AND B.[Sent for Gift Card Processing] is null AND B.[Sent to Inspection Vendor] is null THEN 'No NCCI / GC 3'
	WHEN B.[Gift Card Letter Sent] is not null AND B.[Gift Card Letter Sent 2] is not null AND B.[Gift Card Letter Sent 3] is not null AND B.[Sent for Gift Card Processing] is null AND B.[Sent to Inspection Vendor] is not null THEN 'Referred to NCCI / GC 3'
ELSE 'Error'
END AS 'Campaign Status'
,CAST(B.[Gift Card Letter Sent] AS Date) 'Gift Card Letter Sent',Cast(B.[Gift Card Letter Sent 2] AS Date)'Gift Card Letter Sent 2',Cast(B.[Gift Card Letter Sent 3] AS Date)'Gift Card Letter Sent 3',CAST(B.[Sent for Gift Card Processing] AS Date)'Sent for Gift Card Processing',CAST(B.[Sent to Inspection Vendor] AS Date)'Sent to NCCI',B.[Sent to Inspection Vendor]
,CASE
WHEN C.[HUD Status] not in ('Not Started') THEN C.[HUD Status]
ELSE D.[Final Review Status]
END AS 'Status'
FROM SharepointData.Dbo.HUDAssignExceptions B
LEFT JOIN SharepointData.Dbo.HUDAssignLoans A
ON A.[Loan Number] = B.[Loan Number]
LEFT JOIN SharepointData.Dbo.HUDAssignHUDStatus C
ON A.[Loan Number] = C.[Loan Number]
LEFT JOIN SharepointData.Dbo.HUDAssignFinalReview D
ON D.[Loan Number] = A. [Loan Number]
WHERE B.[Document] in ('Current OCC Cert') AND B.[Exception Status] not in ('Resolved','Not Valid','Closed') AND A.[MCA %] >= '92' AND A.[Incurable Flag] in ('0') AND A.[Tag 2] is null AND A.[Loan Status] in ('Active') --AND C.[HUD Status] not in ('Submitted to HUD','Resubmitted to HUD','HUD Approved','HUD Approval')
AND (a.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or a.[Group] is null)
ORDER BY 'MCA Bucket' DESC,'Campaign Status'