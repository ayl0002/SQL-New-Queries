SELECT A.[Loan Number],B.[Exception ID],A.[Loan Status],a.[tag 2],a.[incurable flag],a.[loan status],B.[Document],B.[Exception Status],B.[Gift Card Letter Sent],B.[Gift Card Letter Sent 2],B.[Gift Card Letter Sent 3],B.[Sent for Gift Card Processing]
,case
	when C.[HUD Status] IN ('Pkg Submitted to HUD','resubmitted to hud','rebuttal to hud') then 'Submitted'
	when c.[hud status] in ('hud approved') then 'HUD Approved'
	else 'Not Submitted'
	end as 'Status'
FROM SharepointData.Dbo.HUDAssignLoans A
LEFT JOIN SharepointData.Dbo.HUDAssignExceptions B
ON A.[Loan Number] = B.[Loan Number]
LEFT JOIN SharepointData.Dbo.HUDAssignHUDStatus C
ON A.[Loan Number] = C.[Loan Number]
WHERE B.[Document] in ('HOA') AND B.[Sent for Gift Card Processing] is not null
ORDER BY 'Status' DESC,B.[Exception Status]