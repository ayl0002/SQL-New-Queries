SELECT Distinct
A.loan_nbr
--,B.Loan_Key
--,C.Loan_Key
--,B.[BUS_PROC_DT]
--,C.[BUS_PROC_DT]
,case
	when B.Curr_Ind in ('Y') then 'IAssign Pipe'
	when B.loan_nbr is not null then 'IAssign Pipe'
	else 'Not in IAssign'
	end as 'IAssign flag'
,A.CLIENT_LOAN_NBR AS 'Client Loan Number'
,A.Pool_Name AS 'Pool Name'
,A.Investor
--,D.FNL_RVW_ASGN_TO_NM
 ,C.HUD_ASGN_TO_NM
--,B.BORR_NM
,A.Borrower_Last_Name AS 'Borrower Last Name'
,A.BORROWER_FIRST_NAME AS 'Borrower First Name'
,A.STATUS_DESCRIPTION
--,B.LOAN_STS_DESC
,B.STG_VAL
,B.HUD_STS_DESC
--,CAST(b.[BUS_PROC_DT]AS DATE) AS 'BUS_PROC_DT'
--,c.[BUS_PROC_DT]
--,d.[BUS_PROC_DT]
,CASE
	WHEN B.ALL_EXCP_CNT > 0 THEN (CAST(B.ALL_EXCP_CNT - B.ALL_CLOSD_EXCP_CNT AS INT)) 
	WHEN B.ALL_EXCP_CNT = 0 THEN CAST(B.ALL_EXCP_CNT AS INT)
	ELSE '0'
	END AS 'Open Exceptions'
,CASE
	WHEN B.ALL_EXCP_CNT is not null then CAST(B.ALL_EXCP_CNT AS INT)
	ELSE '0'
	END AS 'Total Exceptions'
,CASE
	WHEN B.ALL_CLOSD_EXCP_CNT is not null then CAST(B.ALL_CLOSD_EXCP_CNT AS INT)
	ELSE '0'
	END AS 'Closed Exceptions'
,A.MCA_PERCENT
--,(SELECT MAX (BUS_PROC_DT) FROM [Reverse_DW].[dbo].[HUD_ASGN_LOANS]) AS 'Last Updated Date'
,CASE
	WHEN A.STATUS_DESCRIPTION in ('Liquidated/Assigned to HU') THEN 'Claim Paid'
	When B.HUD_STS_DESC in ('HUD Denied') and B.LOAN_STS_DESC in ('Active') THEN 'HUD Denied'
	WHEN B.HUD_STS_DESC in ('HUD Approved') and A.STATUS_DESCRIPTION in ('Active') THEN 'Claim Pending'
	When A.STATUS_DESCRIPTION not in ('Active') THEN ('Not Assignable')
	WHEN B.HUD_STS_DESC in ('Pkg Submitted to HUD') and B.LOAN_STS_DESC in ('Active') or B.HUD_STS_DESC in ('Resubmitted to HUD') AND B.LOAN_STS_DESC in ('Active') THEN 'Submitted to HUD - Pending HUD Review'
	WHEN A.MCA_PERCENT >= '97.5' AND A.STATUS_DESCRIPTION in ('Active') AND B.HUD_STS_DESC in ('Not Started') THEN 'Currently Under Review for Assignment'
	ELSE 'Not Assignable'
	END AS 'Claim Status'
,Case
	WHEN A.MCA_PERCENT < '97.5' then 'Less Than 97.5'
	WHEN A.MCA_PERCENT BETWEEN '97.5' and '100' THEN 'Between 97.5 and 100'
	ELSE 'Above 100'
	END AS 'MCA Bucket'
FROM [Reverse_DW].[dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] A
--(SELECT A.* FROM [Reverse_DW].[dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] A WHERE A.Investor in ('GNMA'))A
--LEFT JOIN (select A.*
	--	from
		--(select max([BUS_PROC_DT]) as 'BUS_PROC_DT' from  [Reverse_DW].[dbo].[HUD_ASGN_LOANS])B
		--LEFT JOIN (SELECT * FROM [Reverse_DW].[dbo].[HUD_ASGN_LOANS])A
		--ON B.[BUS_PROC_DT]=A.[BUS_PROC_DT]
		--) B
 LEFT JOIN [Reverse_DW].[dbo].[HUD_ASGN_LOANS] B
ON B.Loan_Key = A.Loan_Key AND B.CURR_IND = ('Y')
LEFT JOIN [Reverse_DW].[dbo].[HUD_ASGN_HUD_STS] C
ON C.Loan_Key = B.Loan_Key and B.[CURR_IND] = ('Y') AND C.[CURR_IND] = ('Y')
LEFT JOIN [Reverse_DW].[dbo].[HUD_ASGN_FNL_RVW] D
ON D.Loan_Key = b.Loan_Key and d.[BUS_PROC_DT] = b.[BUS_PROC_DT]

WHERE --B.INVSTR_DESC in ('GNMA') AND 
A.Investor in ('GNMA')-- and 
--B.STG_VAL not in ('Non HAC')
--and B.Curr_Ind in ('Y') and c.CURR_IND in ('y') and c.CURR_IND in ('y')
--B.LOAN_NBR IS NOT NULL
ORDER BY ('Claim Status'),('MCA Bucket')
