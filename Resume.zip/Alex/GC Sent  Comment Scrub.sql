SELECT A.[Loan Number]
,CASE
WHEN LEN(A.[Loan Number]) < 6 THEN 'Error'
WHEN LEN(A.[Loan Number]) = 6 THEN '0000' + CAST(A.[Loan Number] AS varchar)
WHEN LEN(A.[Loan Number]) = 7 THEN '000' + CAST(A.[Loan Number] AS varchar)
ELSE 'Error'
END AS 'Concat Loan Number'
,A.[Exception ID],B.[Exception Memo],Cast(A.[Gift Card Letter Sent] AS Date) AS 'GC Letter Date # 1',Cast(A.[Gift Card Letter Sent 2] AS Date) AS 'GC Letter Date # 2',Cast(A.[Gift Card Letter Sent 3] AS Date) AS 'GC Letter Date # 3',Cast(A.[Exception Status Date] AS Date) AS 'Exception Last Updated'
FROM SharepointData.dbo.HUDAssignExceptionActions B
LEFT JOIN SharepointData.Dbo.HUDAssignExceptions A
ON A.[Exception ID] = B.[Exception ID]
WHERE B.[Exception Memo] LIKE ('%Tracking%') AND A.[Gift Card Letter Sent] is not null AND A.[Document] in ('CURRENT OCC CERT',	'DEATH CERT HACG',	'TRUST - HACG',	'Proof of Repair',	'HOA')