SELECT C.LOAN_NBR,E.HUD_STS_DESC,C.EXCP_ID,C.DOC_DESC
,CASE 
WHEN C.DOC_DESC in ('Current Occ Cert') THEN 'LM0381'
WHEN C.DOC_DESC in ('HOA') THEN 'LM0387'
WHEN C.DOC_DESC in ('Proof of Repair') THEN 'LM0388'
ELSE 'Error'
END AS 'Excp_Cmpgn'
,C.EXCP_STS_DESC
,C.ISSU_DESC
INTO #Exception
FROM (SELECT EXCP_ID,LOAN_NBR,DOC_DESC,EXCP_STS_DESC,ISSU_DESC,excp_rqst_dttm FROM reverse_DW.[dbo].[HUD_ASGN_EXCP_EDW] WHERE Doc_Desc in ('HOA','Current OCC Cert','Proof of Repair') AND EXCP_STS_DESC NOT IN ('Resolved','Not Valid','Closed with Vendor')) C
LEFT JOIN (SELECT * FROM Reverse_DW.[dbo].[HUD_ASGN_HUD_STS] WHERE CURR_IND = ('Y'))  E
FROM 
ON E.Loan_Nbr = C.LOAN_NBR 

DROP TABLE #Exception