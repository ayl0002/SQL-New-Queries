SELECT A.[Loan Number],D.[Exception ID]
,CASE
	WHEN A.[MCA %] > 100 AND A.[Open Exceptions] <= 1 THEN 'Priority 1'
	WHEN A.[MCA %] > 100 AND A.[Open Exceptions] = 2 THEN 'Priority 2'
	WHEN A.[MCA %] > 100 AND A.[Open Exceptions] = 3 THEN 'Priority 3'	
	WHEN A.[MCA %] > 100 AND A.[Open Exceptions] > 3 THEN 'Priority 4'
	WHEN A.[MCA %] Between 97.5 AND 100 AND A.[Open Exceptions] <= 1 THEN 'Priority 5'
	WHEN A.[MCA %] Between 97.5 AND 100 AND A.[Open Exceptions] = 2 THEN 'Priority 6'
	WHEN A.[MCA %] Between 97.5 AND 100 AND A.[Open Exceptions] = 3 THEN 'Priority 7'
	WHEN A.[MCA %] Between 97.5 AND 100 AND A.[Open Exceptions] > 3 THEN 'Priority 8'
	WHEN A.[MCA %] < 97.5 THEN 'Priority 9 - Below 97.5'
	ELSE 'Error'
	END AS 'Loan Priority'
,D.[Exception Assigned To],D.[Document],D.[Exception Status],CAST(CAST(A.[MCA %] AS Decimal(5,2)) AS NvarChar(6)) + '%' AS 'MCA'
,CASE
	WHEN A.[MCA %] < 97.5 THEN '< 97.5'
	WHEN A.[MCA %] BETWEEN 97.5 AND 100 THEN '97.5 < 100'
	WHEN A.[MCA %] > '100' THEN '> 100'
	ELSE 'Error'
	END AS 'MCA Bucket'
,Cast(A.[Open Exceptions] AS INT) AS 'Open Exceptions'
,Cast(D.[Exception Status Date] AS DATE) AS 'Exception Last Updated'
,Case
WHEN D.[Exception Status Date] is null THEN '0'
ELSE DateDiff(day,CAST(D.[Exception Status Date] AS DATE),Cast(GetDate() AS DATE))
END AS 'Days Since Last Update'
,A.[Loan Status]
,B.[HUD Assigned to]
,E.[MGR_NM]
,E.[ST_LOC]
FROM SharepointData.Dbo.HUDAssignLoans A
LEFT JOIN SharepointData.DBO.HUDAssignHUDStatus B
ON A.[Loan Number] = B.[Loan Number]
LEFT JOIN SharepointData.dbo.HUDAssignFinalReview C
ON A.[Loan Number] = C.[Loan Number]
LEFT JOIN SharepointData.dbo.HUDAssignExceptions D
ON A.[Loan Number] = D.[Loan Number]
LEFT JOIN (SELECT * FROM [VRSQLRODS\RODS_PROD].reverse_dw.[dbo].[TP_HUD_RSTR] WHERE [ST_LOC] IN ('Offshore'))  E
ON E.AGNT_NM = B.[HUD Assigned to]
WHERE E.[ST_LOC] in ('Offshore') AND A.[TAG 2] is NULL AND A.[Incurable Flag] in ('0') AND A.[Loan Status] in ('Active') AND A.[MCA %] > 97.5 AND D.[Exception Status] not in ('Closed','Not Valid','Resolved','Closed with Vendor') AND D.[Exception ID] is not null
--AND D.[Exception Assigned To] in ('Georgia Rowe','Tiffani Levi')
ORDER BY 'Loan Priority','Days Since Last Update' DESC,D.[Exception Assigned to],A.[Loan Number]