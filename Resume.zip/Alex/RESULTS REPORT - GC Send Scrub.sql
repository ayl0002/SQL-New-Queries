SELECT distinct
A.[LOAN NUMBER]
,Cast(E.[Exception Request Date] AS Date) AS 'Exception Request Date'
,DATEDIFF(day,E.[Exception Request Date],Getdate()) AS 'Aged'
,a.[tag 2]
,a.[incurable flag]
,a.[loan status]
,a.Stage
,a.[mca %]
,LIT.ACTV_LITG_IND
,E.[Sent to Inspection Vendor]
,CASE
WHEN LIT.ACTV_LITG_IND IN ('Y') THEN ('Do Not Send - Active Lit')
WHEN A.[Tag 2] is Not Null THEN 'Do Not Send - Tag 2'
WHEN (A.[loan status] not in ('active') or A.[Loan Status] is Null) THEN 'Do Not Send - Non-Active Loan'
WHEN E.[Document] IN ('Proof of Repair') AND E.[Exception Status] IN ('Incurable') AND Cast(A.[Incurable Flag] AS nvarchar(1)) in ('1') AND E.[Sent to Inspection Vendor] is not NULL THEN ('Incurable POR') 
WHEN (E.[Exception Status] in ('closed','resolved','not valid','incurable') or E.[Exception Status] is Null) THEN ('Do Not Send - Exception Closed')
WHEN A.[Incurable Flag] not in ('0') THEN 'Do Not Send - Incurable Flag - Check POR'
WHEN C.[HUD Status] IN ('Pkg Submitted to HUD','Resubmitted to Hud','Rebuttal to Hud') then 'Do Not Send - Submitted'
WHEN C.[HUD Status] in ('HUD Approved') THEN 'Do Not Send - HUD Approved'
WHEN A.[Loan Status] in ('Active') AND E.[Exception Status] not in ('closed','resolved','not valid','incurable') THEN ('Send')
ELSE 'Error'
END AS 'Send Flag' 

,CASE
	WHEN a.[MCA %] < 97.5 THEN '< 97.0'
	WHEN a.[MCA %] >= 97.5 THEN '>= 97.0'
	WHEN A.[MCA %] is null THEN 'NULL'
	ELSE 'Error'
	END AS 'MCA Flag'
,e.[Exception ID]
,case
	when c.[hud status] in ('not started') then b.[final review assigned to]
	else c.[hud assigned to]
	end as 'Agent'
,r.mgr_nm
,r.st_loc
,t.[Open Exceptions]
,T.OpenCurative
,T.OpenHACG
,case
	when C.[HUD Status] IN ('Pkg Submitted to HUD','resubmitted to hud','rebuttal to hud') then 'Submitted'
	when c.[hud status] in ('hud approved') then 'HUD Approved'
	else 'Not Submitted'
	end as 'Status'

--,CASE
	--WHEN b.[Final Review Status Date] > C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),b.[Final Review Status Date],101)
	--WHEN b.[Final Review Status Date] < C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),C.[HUD Status Date],101)
	--ELSE CONVERT(NVARCHAR(10),b.[Final Review Status Date],101) END AS 'Last Updated'

--,CASE
	--WHEN B.[Final Review Comment] > C.[HUD Status Comment] THEN B.[Final Review Comment]
	--WHEN B.[Final Review Comment] < C.[HUD Status Comment] THEN C.[HUD Status Comment]
	--ELSE B.[Final Review Comment]  END AS 'Last Comment'
,case
	when E.Document is null then 'No Issue'
	when e.[Document] is not null then e.[Document]
	end as 'Document'
,E.Issue
,E.[Exception Status]
,E.[Exception Status Updated By]
,Cast(E.[Exception Status Date] AS Date) AS 'Exception Status Date'

FROM SHAREPOINTDATA.dbo.HUDAssignLoans A
LEFT JOIN SHAREPOINTDATA.dbo.HUDAssignFinalReview B
ON a.[LOAN NUMBER]=b.[LOAN NUMBER]
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
ON A.[LOAN NUMBER]=E.[Loan Number]
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNHUDSTATUS C
ON a.[LOAN NUMBER]=c.[LOAN NUMBER]
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignLoanExceptionTotals T
on a.[Loan Number]=T.[Loan Number]
Left Join [VRSQLRODS\RODS_PROD].reverse_dw.[dbo].[TP_HUD_RSTR] R
on C.[HUD Assigned To]=R.agnt_nm
left join (SELECT R.Mod_Loan_Nbr,L.ACTV_LITG_IND FROM  [VRSQLRODS\RODS_PROD].REVERSE_DW.DBO.BORR_ADDL_DTL L LEFT JOIN [VRSQLRODS\RODS_PROD].REVERSE_DW.dbo.LOAN_NBR_CROSS_REF R ON L.LOAN_KEY=R.LOAN_KEY WHERE L.CURR_IND='Y') LIT
ON LIT.[Mod_Loan_Nbr]=A.[Loan Number]


WHERE E.[Exception ID] IN () 
ORDER BY 'MCA Flag' DESC,'Document','Open Exceptions'