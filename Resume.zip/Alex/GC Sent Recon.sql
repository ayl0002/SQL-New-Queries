SELECT A.[Loan Number],B.[Exception ID],C.[HUD Status],A.[Loan Status],B.[Document],B.[Issue],B.[Exception Status]
,Cast (B.[Gift Card Letter Sent] AS Date) AS 'I-Assign Date 1'
,Cast (B.[Gift Card Letter Sent 2] AS Date) AS 'I-Assign Date 2'
,Cast (B.[Gift Card Letter Sent 3] AS Date) AS 'I-Assign Date 3'
,Cast(B.[Sent For Gift Card Processing] AS Date) AS 'I-Assign Sent for Processing'
,Cast (B.[Non GC Letter Sent 1] AS Date) AS 'Non GC Sent 1'
,Cast (B.[Non GC Letter Sent 2] AS Date) AS 'Non GC Sent 2'
,Cast (B.[Non GC Letter Sent 3] AS Date) AS 'Non GC Sent 3'
,Cast(B.[Non GC Letter Document Returned] AS Date) AS 'Non GC Document Returned'
,Cast (B.[Ledger Letter Sent 1] AS Date) AS 'Ledger Letter Sent 1'
,Cast (B.[Ledger Letter Sent 2] AS Date) AS 'Ledger Letter Sent 2'
,Cast (B.[Ledger Letter Sent 3] AS Date) AS 'Ledger Letter Sent 3'
,Cast(B.[Ledger Sent for Gift Card Processing] AS Date) AS 'Ledger Sent for Gift Card Processing'
,Case
WHEN B.[Gift Card Letter Sent] is not null and B.[Gift Card Letter Sent 2] is not null and B.[Gift Card Letter Sent 3] is not null THEN '3'
WHEN B.[Gift Card Letter Sent] is not null and B.[Gift Card Letter Sent 2] is not null and B.[Gift Card Letter Sent 3] is null THEN '2'
WHEN B.[Gift Card Letter Sent] is not null and B.[Gift Card Letter Sent 2] is null and B.[Gift Card Letter Sent 3] is null THEN '1'
WHEN B.[Gift Card Letter Sent] is null and B.[Gift Card Letter Sent 2] is null and B.[Gift Card Letter Sent 3] is null THEN '0'
ELSE 'Error'
END AS 'Gift Card Count'
,Case
WHEN B.[Non GC Letter Sent 1] is not null and B.[Non GC Letter Sent 2] is not null and B.[Non GC Letter Sent 3] is not null THEN '3'
WHEN B.[Non GC Letter Sent 1] is not null and B.[Non GC Letter Sent 2] is not null and B.[Non GC Letter Sent 3] is null THEN '2'
WHEN B.[Non GC Letter Sent 1] is not null and B.[Non GC Letter Sent 2] is null and B.[Non GC Letter Sent 3] is null THEN '1'
WHEN B.[Non GC Letter Sent 1] is null and B.[Non GC Letter Sent 2] is null and B.[Non GC Letter Sent 3] is null THEN '0'
ELSE 'Error'
END AS 'Non-Gift Card Count'
,Case
WHEN B.[Ledger Letter Sent 1] is not null and B.[Ledger Letter Sent 2] is not null and B.[Ledger Letter Sent 3] is not null THEN '3'
WHEN B.[Ledger Letter Sent 1] is not null and B.[Ledger Letter Sent 2] is not null and B.[Ledger Letter Sent 3] is null THEN '2'
WHEN B.[Ledger Letter Sent 1] is not null and B.[Ledger Letter Sent 2] is null and B.[Ledger Letter Sent 3] is null THEN '1'
WHEN B.[Ledger Letter Sent 1] is null and B.[Ledger Letter Sent 2] is null and B.[Ledger Letter Sent 3] is null THEN '0'
ELSE 'Error'
END AS 'Ledger Letter Count'
,Case
WHEN B.[Sent For Gift Card Processing] is NULL THEN 'No'
WHEN B.[Sent For Gift Card Processing] is not NULL THEN 'Yes'
ELSE 'Error'
END AS 'GC Ordered'
,Case
WHEN B.[Ledger Sent for Gift Card Processing] is NULL THEN 'No'
WHEN B.[Ledger Sent for Gift Card Processing] is not NULL THEN 'Yes'
ELSE 'Error'
END AS 'Ledger GC Ordered'
,Case
WHEN B.[Sent For Gift Card Processing] is not null then 'Sent for GC Processing'
WHEN DateDiff(day,Cast(B.[Gift Card Letter Sent 2] AS Date),GetDate()) > 15 and B.[Gift Card Letter Sent] is not null and B.[Gift Card Letter Sent 2] is not null AND B.[Gift Card Letter Sent 3] is not null THEN 'GC 3 Sent'
WHEN DateDiff(day,Cast(B.[Gift Card Letter Sent 2] AS Date),GetDate()) > 15 and B.[Gift Card Letter Sent] is not null and B.[Gift Card Letter Sent 2] is not null  AND B.[Gift Card Letter Sent 3] is null then 'GC 2 Sent - Send GC 3'
WHEN DateDiff(day,Cast(B.[Gift Card Letter Sent 2] AS Date),GetDate()) <= 15 and B.[Gift Card Letter Sent] is not null and B.[Gift Card Letter Sent 2] is not null  AND B.[Gift Card Letter Sent 3] is null then 'GC 2 Sent - Hold GC 3'
WHEN DateDiff(day,Cast(B.[Gift Card Letter Sent] AS Date),GetDate()) > 15 and B.[Gift Card Letter Sent] is not null AND B.[Gift Card Letter Sent 2]is null THEN 'GC 1 Sent - Send GC 2' 
WHEN  DateDiff(day,Cast(B.[Gift Card Letter Sent] AS Date),GetDate()) <= 15 and B.[Gift Card Letter Sent] is not null AND B.[Gift Card Letter Sent 2]is null THEN 'GC 1 Sent - Hold GC 2'
WHEN B.[Gift Card Letter Sent] is null and B.[Sent For Gift Card Processing] is null THEN 'No GC Sent'
ELSE 'Error'
END AS 'GC Date Scrub'
,Case
WHEN B.[Sent For Gift Card Processing] is not null then Cast(B.[Sent For Gift Card Processing] AS Date)
WHEN B.[Gift Card Letter Sent] is not null and B.[Gift Card Letter Sent 2] is not null AND B.[Gift Card Letter Sent 3] is not null then Cast(B.[Gift Card Letter Sent 3] AS Date)
WHEN B.[Gift Card Letter Sent] is not null and B.[Gift Card Letter Sent 2] is not null AND B.[Gift Card Letter Sent 3] is null then Cast(B.[Gift Card Letter Sent 2] AS Date)
WHEN B.[Gift Card Letter Sent] is not null then Cast(B.[Gift Card Letter Sent] AS Date)
WHEN B.[Gift Card Letter Sent] is null and B.[Sent For Gift Card Processing] is null THEN null
ELSE Cast('1/1/1900' AS Date)
END AS 'Last GC Date'
FROM SharepointData.dbo.HUDAssignExceptions B
LEFT JOIN SharepointData.dbo.HUDAssignLoans A
ON A.[Loan Number] = B.[Loan Number]
LEFT JOIN SharepointData.dbo.HUDAssignHUDStatus C
ON A.[Loan Number] = C.[Loan Number]
WHERE --A.[Tag 2] is null and A.[Incurable Flag] in ('0') AND 
B.[Exception ID] in ('368403',
'401476',
'379054',
'372634',
'365726',
'375700',
'383360',
'380290',
'370993',
'369497',
'416593',
'381117',
'369165',
'364857',
'368636',
'362250',
'383419',
'378058',
'375325',
'383351',
'362377',
'371412',
'368376',
'367351',
'447244',
'374623',
'396620',
'365013',
'385455',
'375911',
'374850',
'349950',
'387637',
'375431',
'372729',
'372775',
'379300',
'380430',
'367453',
'452575',
'452560',
'452607',
'452608',
'452613',
'452637',
'455590',
'453346',
'452579',
'409138',
'452584',
'452491',
'452616',
'452319',
'409799',
'452572',
'448928',
'452424',
'452561',
'452564',
'452595',
'452612',
'452614',
'452624',
'409785',
'456072',
'455604',
'452618',
'405942',
'414878',
'456179',
'428685',
'404163',
'409678',
'452585',
'452850',
'452606',
'426059',
'426115',
'429758',
'426020',
'407037',
'426067',
'409649',
'366165',
'389800',
'384594',
'399508',
'449343',
'456084',
'363133',
'456083',
'380971',
'448687',
'399235',
'445823',
'454011',
'426866',
'455085',
'425820',
'456298',
'431444',
'431271',
'455101',
'456106',
'443984',
'444122',
'443969',
'455117',
'455121',
'455122',
'455124',
'449955',
'455125',
'413753',
'444243',
'453381',
'455144',
'455149',
'454307',
'454311',
'451236',
'455073',
'446996',
'444126',
'452898',
'456865',
'455080',
'426585',
'413989',
'431125',
'426663',
'456155',
'431268',
'426728',
'431631',
'425688',
'431610',
'431624',
'456813',
'455134',
'453220',
'456596',
'431088',
'310599',
'431532',
'456347',
'455074',
'455082',
'455083',
'431626',
'431095',
'431287',
'454165',
'455107',
'456108',
'456149',
'319241',
'455115',
'454649',
'411094',
'431461',
'427420',
'452050',
'454317',
'431597',
'455137',
'412904',
'431132',
'455146',
'431083',
'455160',
'455162')
--B.[Document] in ('Current OCC Cert','Proof of Repair','HOA','Trust') --AND A.[MCA %] >= '97.5'--AND B.[Exception Status] NOT IN ('Closed','Not Valid','Resolved','Incurable') AND A.[Loan Status] in ('Active') AND C.[HUD Status] not in ('Resubmitted to HUD','Pkg Submitted to HUD','HUD Approved') 
ORDER BY B.[Document],'GC Date Scrub' DESC