SELECT A.[Loan_Nbr],C.[TAG_2_VAL],C.[INCRBL_FLG_DESC]
,CASE
	WHEN A.[Status_Description] in ('Liquidated/Assigned to HU') AND B.HUD_PRELIM_TTL_APRVL_DT is null THEN 'PTA Missing - Liquidated / Assigned to HUD'
	WHEN A.[Status_Description] in ('Liquidated/Assigned to HU') AND B.HUD_PRELIM_TTL_APRVL_DT is not null THEN 'PTA Granted - Liquidated / Assigned to HUD'
	ELSE 'Error'
	END AS 'PTA Status'
,A.[STATUS_DESCRIPTION]
,Convert(varchar,B.HUD_PRELIM_TTL_APRVL_DT,100) AS 'PTA Granted'
,CONCAT(CAST((A.[MCA_PERCENT]*100) AS INT),'%') AS 'MCA %'
,A.[MCA_PERCENT]
,Cast(A.CURRENT_PRINCIPAL_BALANCE AS Decimal(18,2)) AS 'UPB'
,Cast(A.ORIGINAL_PRINCIPAL_BALANCE AS Decimal(18,2)) AS 'OPB'
,B.HUD_STS_DESC
,Convert(varchar,B.HUD_STS_DT,100) AS 'HUD Status Updated'
,CASE
	WHEN A.[MCA_PERCENT] < ('.95') THEN '<95% MCA'
	WHEN A.[MCA_PERCENT] BETWEEN ('.95') AND ('1.00') THEN '95% < 100% MCA'
	ELSE 'MCA > 100%'
	END AS 'MCA Bucket'
FROM [Reverse_DW].[dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] A
	LEFT JOIN (SELECT * FROM [Reverse_DW].[dbo].[HUD_ASGN_HUD_STS] WHERE Curr_Ind in ('Y')) B
	ON A.[Loan_Key] = B.[Loan_Key]
	LEFT JOIN (SELECT * FROM [Reverse_DW].[dbo].[HUD_ASGN_LOANS] WHERE Curr_Ind in ('Y')) C
	ON C.[Loan_Key] = B.[Loan_Key]
WHERE A.[STATUS_DESCRIPTION] in ('Liquidated/Assigned to HU')
ORDER BY ('PTA Granted') ASC