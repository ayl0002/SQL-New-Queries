SELECT Distinct REPLACE(LTRIM(REPLACE(A.LOAN_NBR, '0', ' ')), ' ', '0') AS 'Loan Number',D.LOAN_STATUS,Cast(CAST(D.MCA_Percent AS Float) AS NVARCHAR(6))+'%' AS 'MCA %'
,B.ORDR_DT
,A.CMPGN_NM_DESC
,A.CLSD_CD,CLSD_DT
,INSP_DT_1,INSP_RSLT_DESC_1,INSP_DT_2,INSP_RSLT_DESC_2,INSP_DT_3,INSP_RSLT_DESC_3,NT_SGN,OCCUP_TYPE,A.BUS_PROC_DT,D.PROP_ADDRESS+' '+D.PROP_CITY+', '+D.PROP_STATE+' '+D.PROP_ZIP_CODE AS 'Prop Address'
INTO #NCCI
FROM Reverse_DW.Dbo.NCCI_INBND_LM A
LEFT JOIN
(SELECT LOAN_NBR,REPLACE(LTRIM(REPLACE(LOAN_NBR, '0', ' ')), ' ', '0') AS 'Loan_Number',CMPGN_NM_DESC,ORDR_DT,MAX(BUS_PROC_DT)AS'BUS_PROC_DT' FROM Reverse_DW.Dbo.NCCI_INBND_LM GROUP BY ORDR_DT,LOAN_NBR,CMPGN_NM_DESC) B
ON A.LOAN_NBR = B.LOAN_NBR AND B.[ORDR_DT] = A.[ORDR_DT]
LEFT JOIN Reverse_DW.[dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] D
ON B.LOAN_Number = D.[Loan_Nbr] 
WHERE A.[LOAN_NBR] = B.LOAN_NBR AND A.[BUS_PROC_DT] = B.[BUS_PROC_DT] AND A.CMPGN_NM_DESC = B.CMPGN_NM_DESC AND A.CMPGN_NM_DESC NOT IN ('MC0283','MC0281')

SELECT C.LOAN_NBR,E.HUD_STS_DESC,C.EXCP_ID,C.DOC_DESC
,CASE 
WHEN C.DOC_DESC in ('Current Occ Cert') THEN 'LM0381'
WHEN C.DOC_DESC in ('HOA') THEN 'LM0387'
WHEN C.DOC_DESC in ('Proof of Repair') THEN 'LM0388'
ELSE 'Error'
END AS 'Excp_Cmpgn'
,C.EXCP_STS_DESC
,C.ISSU_DESC
INTO #Exception
FROM (SELECT EXCP_ID,LOAN_NBR,DOC_DESC,EXCP_STS_DESC,ISSU_DESC FROM reverse_DW.[dbo].[HUD_ASGN_EXCP_EDW] WHERE Doc_Desc in ('HOA','Current OCC Cert','Proof of Repair') AND CURR_IND in ('Y') AND Loan_Nbr not in ('customerservice@evergreen-lm.com')) C
LEFT JOIN (SELECT * FROM Reverse_DW.[dbo].[HUD_ASGN_HUD_STS] WHERE CURR_IND = ('Y'))  E
ON E.Loan_Nbr = C.LOAN_NBR 

SELECT REPLACE(LTRIM(REPLACE(LOAN_NBR, '0', ' ')), ' ', '0') AS 'Loan Number',CLSD_CD,MAX(ORDR_DT) AS 'ORDR_DT'
INTO #NULL
FROM Reverse_DW.Dbo.NCCI_INBND_LM 
GROUP BY LOAN_NBR,CLSD_CD

SELECT A.[Loan Number],A.[LOAN_STATUS],B.[HUD_STS_DESC]
,A.[MCA %],A.[ORDR_DT],A.[CMPGN_NM_DESC]
,CASE WHEN A.CLSD_CD IN ('SGN-Borrower contact and signed agreement') AND B.[EXCP_STS_DESC] NOT IN ('RESOLVED','CLOSED','NOT VALID','CLOSED WITH VENDOR') THEN 'NCCI Received'
ELSE 'NA'
END AS 'Doc Received'
,B.[EXCP_ID],B.[DOC_DESC],B.[EXCP_STS_DESC],B.[ISSU_DESC]
,CASE WHEN A.CLSD_CD is NULL THEN 'Open Referral'
WHEN A.CLSD_CD in ('BCU-Borrower Contacted & Unable to Obtain Signed Occupancy Cert') THEN 'BCU - ' + A.NT_SGN
WHEN A.CLSD_CD IS NULL THEN (SELECT CLSD_CD FROM Reverse_DW.Dbo.NCCI_INBND_LM WHERE 
ELSE A.CLSD_CD
END AS 'NCCI Status'
,CASE 
WHEN A.CLSD_CD IS NOT NULL AND B.[EXCP_STS_DESC] NOT IN ('RESOLVED','CLOSED','NOT VALID','CLOSED WITH VENDOR') THEN 'Close Referral'
ELSE 'NA'
END AS 'Close Flag'
,A.CLSD_DT,
A.INSP_DT_1,
A.INSP_RSLT_DESC_1,
A.INSP_DT_2,
A.INSP_RSLT_DESC_2,
A.INSP_DT_3,
A.INSP_RSLT_DESC_3,
A.NT_SGN,
A.OCCUP_TYPE
,CASE
WHEN A.CLSD_CD in ('VAC-Vacant Property') AND A.[LOAN_STATUS] in ('Active') THEN 'Vacancy Review'
WHEN A.CLSD_CD in ('ORU-Occupant Renting Property - Unconfirmed') AND A.[LOAN_STATUS] in ('Active') THEN 'Renting Review'
ELSE 'NA'
END AS 'Vacancy Flag'
,CASE 
WHEN A.CLSD_CD IN ('BCU-Borrower Contacted & Unable to Obtain Signed Occupancy Cert','CNA-Client Not Available.','GTE-Gated Community No Access to Property','NDC-No Direct Contact/Verification',
'OSA-Out of Current Service Area, Closed by NCCI','OTV-3rd Party: Verification Only','POU-Property Occupied-Unable to Verify Occupant','SKK-Skipped/No Forwarding Info','AGR-Agreed to Contact You','BAD-Bad or Incomplete Address','CON-Debtor Put in Contact with Lender','NBR-Debtor Residency Verified by Neighbor','OTN-3rd Party: Verify & New Info') THEN 'NCCI Unable to Obtain'
WHEN A.CLSD_CD IN ('BKK-Filed Bankruptcy') THEN 'Borrower in BK'
WHEN A.CLSD_CD IN ('SGN-Borrower contact and signed agreement') THEN 'NCCI Obtained'
WHEN A.CLSD_CD IN ('CAN-NCCI Services Cancelled','CLR-Cancelled Lender Request') THEN 'Referral Closed by Champion'
WHEN A.CLSD_CD IN ('VAC-Vacant Property','ORU-Occupant Renting Property - Unconfirmed','RNT-Occupant Renting Property') THEN 'NCCI Reports Vacant'
WHEN A.CLSD_CD is NULL THEN 'Open Referral'
ELSE 'Error'
END AS 'Success Flag'
,A.BUS_PROC_DT
FROM #NCCI A
LEFT JOIN #Exception B
ON A.[Loan Number] = B.LOAN_NBR AND B.Excp_Cmpgn = A.CMPGN_NM_DESC
ORDER BY A.CMPGN_NM_DESC,A.CLSD_CD


DROP TABLE #NCCI,#Exception,#NULL


