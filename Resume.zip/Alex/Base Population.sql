SELECT A.[Loan Number],A.[Loan Status],B.[HUD Status],C.[Final Review Status]
,CASE
	WHEN B.[HUD Status] in ('Not Started','HUD Denied') 
	AND  C.[Final Review Status] not in ('Pkg Submitted to HUD','Pending QC')
	AND D.[Open Exceptions] < 1
	OR (B.[HUD Status] in ('Not Started') AND C.[Final Review Status] in ('Incurable',	'Issue Pending',	'Hold Curative',	'Time Sensitive Item',	'New File',	'HOLD-NPL/UPB',	'In Progress',	'Not Started',	'In Process'))
	THEN '0 Exceptions'
	WHEN D.[Open Exceptions] > 0 AND [HUD Status] in ('Not Started','HUD Denied') THEN 'Open Exceptions'
	WHEN C.[Final Review Status] in ('Pending QC') AND B.[HUD Status] in ('Not Started') THEN 'Pending QC'
	ELSE 'Submitted to HUD'
	END AS 'Exception Flag'
--,CASE
	--WHEN C.[Final Review Status] in ('Pending QC','Pkg Submitted to HUD') AND B.[HUD Status] in ('Not Started') THEN CAST(CAST(C.[Final Review Status Date] AS DATE) AS Varchar) + ' Pending QC'
	--WHEN C.[Final Review Status] not in ('Pending QC','Pkg Submitted to HUD') and B.[HUD Status] in ('Not Started') THEN 'Pending Production'
	--WHEN B.[HUD Status] in ('HUD Denied') THEN 'HUD Denied'
	--ELSE 'Error'
	--END AS 'Production Flag'
,CASE
	WHEN C.[Final Review Status] in ('Pending QC','Pkg Submitted to HUD') AND B.[HUD Status] in ('Not Started') THEN CAST(CAST(C.[Final Review Status Date] AS DATE) AS Varchar) + ' Pending QC'
	WHEN B.[HUD Status] in ('Not Started') THEN C.[Final Review Status]
	ELSE B.[HUD Status]
	END AS 'Status'
,A.[Stage],A.[Group],A.[Tag 2],A.[MCA %]
   ,CASE 
	WHEN a.[MCA %] between '97.50' and '99.00' then '97.5 < 99'
	WHEN a.[MCA %] >='99' and a.[MCA %] < '100.00' then '99 < 100'
	WHEN a.[MCA %] >= '100.00' then '100+'
	END as 'MCA Bucket'
,C.[Final Review Assigned To]
,B.[HUD Assigned To]
,E.[MGR_NM] AS 'Manager'
,E.[ST_LOC] AS 'Site'
,D.OpenCurative AS 'Open Curative'
,D.OpenHACG AS 'OPEN HACG'
,D.[Open Exceptions]
,C.[Final Review Comment]
FROM SharepointData.Dbo.HUDAssignLoans A
LEFT JOIN SharepointData.Dbo.HUDAssignHUDStatus B
ON A.[Loan Number] = B.[Loan Number]
LEFT JOIN SharepointData.Dbo.HUDAssignFinalReview C
ON A.[Loan Number] = C.[Loan Number]
LEFT JOIN SharepointData.Dbo.HUDAssignLoanExceptionTotals D
ON A.[Loan Number] = D.[Loan Number]
left join [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_HUD_RSTR] E
ON B.[HUD Assigned To] = E.[AGNT_NM]
WHERE (a.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA') or a.[Group] is Null)
--AND (B.[HUD Assigned To] not in ('Shasta Patton') or B.[HUD Assigned To] is null)
AND A.[MCA %] >= '97.5'
AND A.[Loan Status] in ('Active') --AND (C.[Final Review Status] not in ('Pkg Submitted to HUD') and B.[HUD Status] in ('Not Started'))
AND B.[HUD Status] not in ('Pkg Submitted to HUD','Rebuttal to HUD','HUD Approved','HUD Approval','Resubmitted to HUD')
AND A.[Tag 2] is null
AND A.[Incurable Flag] in ('0')