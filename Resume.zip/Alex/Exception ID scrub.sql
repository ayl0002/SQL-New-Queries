SELECT B.[Loan Number],B.[Document],B.[Exception ID],B.[Issue],B.[Exception Status],A.[Loan Status]
,CASE
WHEN B.[Exception Status] in ('Resolved','Not Valid','Cancelled')
Then 'Exception Closed'
When B.[Exception Status] in ('Incurable')
Then 'Exception Incurable'
Else 'Exception Open'
End as 'Status'.
FROM SharepointData.dbo.HUDAssignExceptions B
Left Join SharepointData.dbo.HudAssignHudStatus A
On B.[Loan Number] = A.[Loan Number]
WHERE [Document] in ('Death Cert HACG')