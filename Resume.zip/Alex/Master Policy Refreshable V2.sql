Set NoCount ON
SELECT Convert(INT,Loan_Nbr) AS 'Loan_Nbr',CVR_TYPE,Cast(PLCY_NBR AS NVarChar(Max)) AS 'Policy Number',PLCY_EFF_DT,PLCY_EXPR_DT,PLCY_TERM,AGNT_NM,CMPNY_NM,BUS_PROC_DT
INTO #SWBC
FROM Reverse_DW.[dbo].[TP_SWBC_INS_RET] A
WHERE BUS_PROC_DT=(SELECT MAX(BUS_PROC_DT) FROM Reverse_DW.[dbo].[TP_SWBC_INS_RET]) AND CVR_TYPE in ('1','F')
ORDER BY CVR_TYPE

SELECT Distinct A.Loan_Nbr
,B.[LOAN_STATUS]
,C.HUD_STS_DESC
,B.[Property_Type]
,STR(B.MCA_Percent,6,2) + '%' AS 'MCA %'
,CASE WHEN Pol1.CMPNY_NM in ('FP POL')  THEN 'FPI - Policy 1'
	WHEN Pol2.CMPNY_NM in ('FP POL') THEN 'FPI - Policy 2'
	ELSE 'No FPI'
	END AS 'FPI Flag'
,CASE WHEN Pol1.PLCY_EXPR_DT <= GetDate() THEN 'Expired'
	  WHEN Pol1.PLCY_EXPR_DT > GetDate() THEN 'Current'
	  WHEN Pol1.PLCY_EXPR_DT is NULL THEN 'NULL'
	  ELSE 'Error'
	  END AS 'Expired Flag'
,Pol1.[Policy Number]
,CASE WHEN Pol1.Cvr_Type = 'F' THEN 'Master Policy'
         WHEN Pol1.Cvr_Type = '1' THEN 'HO6'
		 WHEN Pol1.Cvr_Type IS NULL THEN 'No Insurance'
         ELSE 'UNKNOWN'
		END AS 'Policy Type 1'
,Pol1.CMPNY_NM AS 'Policy 1 Company'
,Pol1.PLCY_EFF_DT AS 'Policy 1 Eff Date'
,Pol1.PLCY_EXPR_DT AS 'Policy 1 Exp Date'
,Pol1.PLCY_TERM AS 'Policy 1 Term'
,Pol1.AGNT_NM AS 'Policy 1 Agent'
,CASE WHEN Pol1.CMPNY_NM in ('FP POL')  THEN 'FPI - Policy 1'
	WHEN Pol2.CMPNY_NM in ('FP POL') THEN 'FPI - Policy 2'
	ELSE 'No FPI'
	END AS 'FPI Flag'
,CASE WHEN Pol2.PLCY_EXPR_DT <= GetDate() THEN 'Expired'
    WHEN Pol2.PLCY_EXPR_DT > GetDate() THEN 'Current'
	WHEN Pol2.PLCY_EXPR_DT is NULL THEN 'NULL'
    ELSE 'Error'
    END AS 'Expired Flag'
,Pol2.[Policy Number]
,CASE WHEN Pol2.Cvr_Type = 'F' THEN 'Master Policy'
         WHEN Pol2.Cvr_Type = '1' THEN 'HO6'
         WHEN Pol2.Cvr_Type IS NULL THEN 'No Insurance'
         ELSE 'UNKNOWN'
		END AS 'Policy Type 2'
,Pol2.CMPNY_NM AS 'Policy 2 Company'
,Pol2.PLCY_EFF_DT AS 'Policy 2 Eff Date'
,Pol2.PLCY_EXPR_DT AS 'Policy 2 Exp Date'
,Pol2.PLCY_TERM AS 'Policy 2 Term'
,Pol2.AGNT_NM AS 'Policy 2 Agent'
,B.BORROWER_FIRST_NAME +' '+B.BORROWER_LAST_NAME AS 'Borrower',B.COBORROWER_FIRST_NAME +' '+B.COBORROWER_LAST_NAME AS 'Co-Borrower',PROP_ADDRESS+' '+PROP_CITY+' '+PROP_STATE+' '+PROP_ZIP_CODE AS' Prop Address'
FROM #SWBC A
LEFT JOIN Reverse_DW.[dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] B
ON A.Loan_Nbr = B.Loan_Nbr
LEFT JOIN 
(SELECT Convert(INT,Loan_Nbr) AS 'Loan_Nbr',CVR_TYPE,Cast([Policy Number] AS NVarChar(Max)) AS 'Policy Number'
,PLCY_EFF_DT,PLCY_EXPR_DT,PLCY_TERM,AGNT_NM,CMPNY_NM,BUS_PROC_DT,Row_Number() Over (Partition BY Loan_Nbr ORDER BY [CVR_TYPE] DESC) RN
FROM #SWBC) Pol1
ON Convert(INT,A.Loan_Nbr) = Pol1.Loan_Nbr AND Pol1.RN = 1
LEFT JOIN 
(SELECT Convert(INT,Loan_Nbr) AS 'Loan_Nbr',CVR_TYPE,Cast([Policy Number] AS NVarChar(Max)) AS 'Policy Number'
,PLCY_EFF_DT,PLCY_EXPR_DT,PLCY_TERM,AGNT_NM,CMPNY_NM,BUS_PROC_DT,Row_Number() Over (Partition BY Loan_Nbr ORDER BY [CVR_TYPE] DESC) RN
FROM #SWBC) Pol2
ON Convert(INT,A.Loan_Nbr) = Pol2.Loan_Nbr AND Pol2.RN = 2
LEFT JOIN (SELECT * FROM Reverse_DW.[dbo].[HUD_ASGN_HUD_STS] WHERE CURR_IND in ('Y')) C
ON A.Loan_Nbr = C.Loan_Nbr
WHERE B.Property_Type in ('CONDO') AND B.[LOAN_STATUS] in ('Active') AND C.HUD_STS_DESC IN ('HUD Denied','New File','Not Started') AND B.MCA_Percent >= 95
ORDER BY B.Loan_Status,[MCA %] DESC

DROP TABLE #SWBC