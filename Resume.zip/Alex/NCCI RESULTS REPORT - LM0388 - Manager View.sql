SET NOCOUNT ON
SELECT Distinct
Cast(A.[LOAN NUMBER] as INT) AS 'Loan Number'
,Convert(varchar(20), getdate(), 0)  as 'Last Refreshed'
--A.[Loan Number]
,a.[tag 2]
,Round(a.[incurable flag],2) AS 'Incurable Flag'
,a.[loan status]
,a.Stage
,a.[mca %]
,CASE
	WHEN a.[MCA %] < 97.5 THEN '< 97.5'
	WHEN a.[MCA %] >= 97.5 THEN '>= 97.5'
	ELSE 'Error'
	END AS 'MCA Flag'
,e.[Exception ID]
,case
	when c.[hud status] in ('not started') then b.[final review assigned to]
	else c.[hud assigned to]
	end as 'Agent'
,r.mgr_nm
,t.[Open Exceptions]
,case
	when C.[HUD Status] IN ('Pkg Submitted to HUD','resubmitted to hud','rebuttal to hud') then 'Submitted'
	when c.[hud status] in ('hud approved') then 'HUD Approved'
	else 'Not Submitted'
	end as 'Status'

--,CASE
	--WHEN b.[Final Review Status Date] > C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),b.[Final Review Status Date],101)
	--WHEN b.[Final Review Status Date] < C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),C.[HUD Status Date],101)
	--ELSE CONVERT(NVARCHAR(10),b.[Final Review Status Date],101) END AS 'Last Updated'

--,CASE
	--WHEN B.[Final Review Comment] > C.[HUD Status Comment] THEN B.[Final Review Comment]
	--WHEN B.[Final Review Comment] < C.[HUD Status Comment] THEN C.[HUD Status Comment]
	--ELSE B.[Final Review Comment]  END AS 'Last Comment'
,E.[Proof of Repairs Status]
,case
	when E.[DOCUMENT] is NULL then 'POR Exception Closed'
	ELSE e.[Document]
	end as 'Document'
,E.Issue
,E.[Exception Status]
,E.[Sent to Inspection Vendor]	
,Case
WHEN A.[Tag 2] is null and A.[Incurable Flag] in ('0') then 'No Incurable / Tag 2'
WHEN A.[Tag 2] is null and A.[Incurable Flag] not in ('0') THEN 'Incurable Flag'
WHEN A.[Tag 2] is not null and A.[Incurable Flag] in ('0') THEN 'Tag 2'
ELSE 'Tag 2 / Incurable'
END AS 'HOLD Check'
,DateDiff(Day,Cast(E.[Exception Status Date] AS Date),Cast(GetDate() AS Date)) AS 'Last Updated'
,Case 
	WHEN DateDiff(Day,Cast(E.[Exception Status Date] AS Date),Cast(GetDate() AS Date)) > 3 THEN '>3'
	WHEN DateDiff(Day,Cast(E.[Exception Status Date] AS Date),Cast(GetDate() AS Date)) <= 3 THEN '<=3'
	WHEN E.[Exception Status Date] is null then '0'
	ELSE 'Error'
	END AS 'Last Updated Check'
,Cast(E.[Exception Status Date] AS Date) as 'Exception Last Updated'
FROM SHAREPOINTDATA.dbo.HUDAssignLoans A
LEFT JOIN SHAREPOINTDATA.dbo.HUDAssignFinalReview B
ON a.[LOAN NUMBER]=b.[LOAN NUMBER]
LEFT JOIN (SELECT [LOAN NUMBER],[EXCEPTION ID],[DOCUMENT],[ISSUE], [EXCEPTION ASSIGNED TO],[EXCEPTION REQUEST DATE],[EXCEPTION STATUS],[EXCEPTION STATUS DATE],[Sent to Inspection Vendor],[Proof of Repairs Status] FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS WHERE [DOCUMENT] IN ('Proof of Repair') AND [EXCEPTION STATUS] NOT IN ('RESOLVED','CLOSED','NOT VALID','CLOSED WITH VENDOR')) E
ON A.[LOAN NUMBER]=E.[Loan Number]
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNHUDSTATUS C
ON a.[LOAN NUMBER]=c.[LOAN NUMBER]
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignLoanExceptionTotals T
on a.[Loan Number]=T.[Loan Number]
left join [VRSQLRODS\RODS_PROD].reverse_dw.[dbo].[TP_HUD_RSTR] r
on c.[HUD Assigned To]=r.agnt_nm

WHERE 
--a.[Loan Status] not in ('Liquidated/Held for Sale','Paid Off','Liquidated/Assigned to HU','Liquidated/3rd Party Sale','Called Due: Death','Inactive','Refer for FCL: Death') and 
(A.[Tag 2] not in ('SERVICER CURE') or A.[TAG 2] is NULL) AND A.[LOAN NUMBER] NOT IN ('755630.')--AND E.[Sent to Inspection Vendor] is not null
ORDER BY 'MCA Flag' DESC,'Document' DESC,'Open Exceptions'