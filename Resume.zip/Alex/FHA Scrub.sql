SELECT [Loan Number],[FHA Case Number],
CASE
WHEN [FHA Case Number] is null THEN ('No FHA Case Number')
ELSE 'FHA Case Number Present'
END AS 'FHA Bucket'
,*
FROM SharepointData.Dbo.HUDAssignLoans
ORDER BY 'FHA Bucket' DESC