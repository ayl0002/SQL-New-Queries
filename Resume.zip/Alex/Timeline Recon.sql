SELECT A.[Loan Number],A.[FHA Case Number],A.[Loan Status],Cast(A.[MCA %] AS Decimal(18,2)) AS 'MCA'
,CASE
	WHEN B.[HUD Status] in ('Not Started') THEN C.[Final Review Status]
	ELSE B.[HUD Status]
	END AS 'Status'
,CASE	
	WHEN B.[HUD Status] in ('HUD Approved','HUD Approval') THEN 'HUD Approved'
	WHEN B.[HUD Status] in ('Not Started','New File') THEN 'Not Submitted'
	WHEN B.[HUD Status] in ('HUD Denied') THEN 'HUD Denied'
	WHEN B.[HUD Status] in ('Rebuttal to HUD') THEN 'Denial Rebutted'
	WHEN B.[HUD Status] in ('Pkg Submitted to HUD','Resubmitted to HUD') or C.[Final Review Status] in ('Pkg Submitted to HUD','Resubmitted to HUD') THEN 'Submitted'
	ELSE 'ERROR'
	END AS 'Submit Status'	
,CAST(B.[HUD Status Date] AS Date) AS 'HUD Status Date'
,CAST(D.[Date Submitted To HUD] AS DATE) AS'Date Submitted to HUD'
,B.[HUD Assigned To]
,C.[Final Review Assigned To]
,B.[HUD Preliminary Title Approval]
,CASE
	WHEN B.[Latest Comment] is null THEN C.[Final Review Comment]
	ELSE B.[Latest Comment]
	END AS 'Comment'
FROM SharepointData.Dbo.HUDAssignHUDStatus	B
LEFT JOIN SharepointData.Dbo.HUDAssignLoans A
ON A.[Loan Number] = B.[Loan Number]
LEFT JOIN SharepointData.DBO.HUDAssignFinalReview C
ON A.[Loan Number] = C.[Loan Number]
LEFT JOIN (SELECT [LoanNumber],MAX(DateSubmittedToHUD) AS 'Date Submitted to HUD' FROM SHAREPOINTDATA.dbo.HUDAssignDateSubmittedResubmittedtoHUD GROUP BY [LoanNumber]) D
ON A.[Loan Number] = D.[LoanNumber]
WHERE A.[MCA %] >= '97.5' AND B.[Loan Status] in ('Active') and A.[Tag 2] is null and A.[Incurable Flag] in ('0')
ORDER BY 'Submit Status'