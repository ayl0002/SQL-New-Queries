SELECT Distinct A.[Loan Number],A.[Loan Status],E.[Document],E.[Issue],E.[Exception Status],D.[HUD Status]
,CASE 
WHEN D.[HUD Status] in ('Not Started') THEN C.[Final Review Status]
ELSE D.[HUD Status]
END AS 'Assignment Status'
,CASE 
WHEN D.[HUD Status] in ('Not Started') and C.[Final Review Assigned to] in ('Robert Gough') AND E.[Document] in ('Master Policy', 'Hazard Insurance','Flood Insurance') AND E.[Issue] in ('Forced Placed Insurance') AND E.[Exception Status] not in ('Resolved','Not Valid','Canceled')
THEN 'Leave with Robert'
WHEN D.[HUD Status] not in ('Not Started') AND D.[HUD Assigned To] in ('Robert Gough') AND E.[Document] in ('Master Policy', 'Hazard Insurance','Flood Insurance') AND E.[Issue] in ('Forced Placed Insurance') AND E.[Exception Status] not in ('Resolved','Not Valid','Canceled')
THEN 'Leave with Robert'
WHEN D.[HUD Status] in ('Not Started') and C.[Final Review Assigned to] in ('Robert Gough')  AND E.[Document] in ('Master Policy', 'Hazard Insurance','Flood Insurance') AND E.[Issue] not in ('Forced Placed Insurance') THEN 'Move From Robert'
WHEN D.[HUD Status] not in ('Not Started') and D.[HUD Assigned To] in ('Robert Gough')  AND E.[Document] in ('Master Policy', 'Hazard Insurance','Flood Insurance') AND E.[Issue] not in ('Forced Placed Insurance') THEN 'Move From Robert'
WHEN D.[HUD Status] not in ('Not Started') AND D.[HUD Assigned To] in ('Robert Gough') AND E.[Issue] in ('Forced Placed Insurance') AND E.[Document] in ('Master Policy', 'Hazard Insurance','Flood Insurance') AND E.[Exception Status] in ('Resolved','Not Valid','Canceled') THEN 'Move From Robert'
WHEN D.[HUD Status] in ('Not Started') and C.[Final Review Assigned to] in ('Chelsea Daniel') AND E.[Document] in ('Loss Draft') AND E.[Exception Status] not in ('Resolved','Not Valid','Canceled') THEN 'Leave with Chelsea'
WHEN D.[HUD Status] not in ('Not Started') AND D.[HUD Assigned To] in ('Chelsea Daniel')AND E.[Document] in ('Loss Draft') AND E.[Exception Status] not in ('Resolved','Not Valid','Canceled') THEN 'Leave with Chelsea'
WHEN D.[HUD Status] in ('Not Started') and C.[Final Review Assigned to] in ('Chelsea Daniel') AND E.[Document] in ('Loss Draft') AND E.[Exception Status] in ('Resolved','Not Valid','Canceled') THEN 'Move From Chelsea'
WHEN D.[HUD Status] not in ('Not Started') AND D.[HUD Assigned To] in ('Chelsea Daniel') AND E.[Document] in ('Loss Draft') AND E.[Exception Status] in ('Resolved','Not Valid','Canceled') THEN 'Move From Chelsea'
WHEN C.[Final Review Assigned To] is Null and D.[HUD Assigned To] in ('Robert Gough') AND E.[Document] in ('Master Policy', 'Hazard Insurance','Flood Insurance') AND E.[Issue] in ('Forced Placed Insurance') AND E.[Exception Status] not in ('Resolved','Not Valid','Canceled')
THEN 'Leave with Robert'
WHEN C.[Final Review Assigned To] is Null and D.[HUD Assigned To] in ('Robert Gough') AND E.[Document] in ('Master Policy', 'Hazard Insurance','Flood Insurance') AND E.[Issue] not in ('Forced Placed Insurance') THEN 'Move From Robert' 
WHEN C.[Final Review Assigned To] is Null and D.[HUD Assigned To] in ('Chelsea Daniel') AND E.[Document] in ('Loss Draft') AND E.[Exception Status] not in ('Resolved','Not Valid','Canceled') THEN 'Leave with Chelsea'
WHEN C.[Final Review Assigned To] is Null and D.[HUD Assigned To] in ('Chelsea Daniel') AND E.[Document] in ('Loss Draft') AND E.[Exception Status] in ('Resolved','Not Valid','Canceled') THEN 'Move From Chelsea'
ELSE 'Both FPI and Loss Draft'
END AS 'Pipeline Management'
,A.[Tag 2],A.[Incurable Flag],C.[Final Review Assigned To],D.[HUD Assigned To] 
FROM SharepointData.dbo.HudAssignLoans A
LEFT JOIN SharepointData.dbo.HudAssignExceptions E
ON A.[Loan Number] = E.[Loan Number]
LEFT JOIN SharepointData.dbo.HUDAssignFinalReview C
ON C.[Loan Number] = A.[Loan Number]
LEFT JOIN SharepointData.Dbo.HUDAssignHUDStatus D
ON D.[Loan Number] = A.[Loan Number]
WHERE C.[Final Review Assigned To] in ('Robert Gough','Chelsea Daniel')	AND E.Document in ('Loss Draft','Master Policy','Hazard Insurance','Flood Insurance') or D.[HUD Assigned To] in ('Robert Gough','Chelsea Daniel') AND E.Document in ('Loss Draft','Master Policy','Hazard Insurance','Flood Insurance') 