SELECT A.[Loan Number],B.[Exception ID],Cast(B.[Sent For Gift Card Processing] AS Date) AS 'I-Assign Sent for Processing',C.[HUD Status],A.[Loan Status],B.[Document],B.[Issue],B.[Exception Status]
,Cast (B.[Gift Card Letter Sent] AS Date) AS 'I-Assign Date 1'
,Cast (B.[Gift Card Letter Sent 2] AS Date) AS 'I-Assign Date 2'
,Cast (B.[Gift Card Letter Sent 3] AS Date) AS 'I-Assign Date 3'
,Cast (B.[Sent For Gift Card Processing] AS Date) AS 'Sent for GC'
,Case
WHEN B.[Sent For Gift Card Processing] is not null then 'GC Processing Sent'
WHEN B.[Gift Card Letter Sent] is not null and B.[Gift Card Letter Sent 2] is not null AND B.[Gift Card Letter Sent 3] is not null THEN 'GC 3 Sent'
WHEN DateDiff(day,Cast(B.[Gift Card Letter Sent 2] AS Date),GetDate()) > 15 and B.[Gift Card Letter Sent] is not null and B.[Gift Card Letter Sent 2] is not null  AND B.[Gift Card Letter Sent 3] is null then 'GC 2 Sent - Send GC 3'
WHEN DateDiff(day,Cast(B.[Gift Card Letter Sent 2] AS Date),GetDate()) <= 15 and B.[Gift Card Letter Sent] is not null and B.[Gift Card Letter Sent 2] is not null  AND B.[Gift Card Letter Sent 3] is null then 'GC 2 Sent - Hold GC 3'
WHEN DateDiff(day,Cast(B.[Gift Card Letter Sent] AS Date),GetDate()) > 15 and B.[Gift Card Letter Sent] is not null AND B.[Gift Card Letter Sent 2]is null THEN 'GC 1 Sent - Send GC 2' 
WHEN  DateDiff(day,Cast(B.[Gift Card Letter Sent] AS Date),GetDate()) <= 15 and B.[Gift Card Letter Sent] is not null AND B.[Gift Card Letter Sent 2]is null THEN 'GC 1 Sent - Hold GC 2'
WHEN B.[Gift Card Letter Sent] is null and B.[Sent For Gift Card Processing] is null THEN 'No GC Sent'
ELSE 'Error'
END AS 'GC Date Scrub'
,Case
WHEN B.[Sent For Gift Card Processing] is not null then Cast(B.[Sent For Gift Card Processing] AS Date)
WHEN B.[Gift Card Letter Sent] is not null and B.[Gift Card Letter Sent 2] is not null AND B.[Gift Card Letter Sent 3] is not null then Cast(B.[Gift Card Letter Sent 3] AS Date)
WHEN B.[Gift Card Letter Sent] is not null and B.[Gift Card Letter Sent 2] is not null AND B.[Gift Card Letter Sent 3] is null then Cast(B.[Gift Card Letter Sent 2] AS Date)
WHEN B.[Gift Card Letter Sent] is not null then Cast(B.[Gift Card Letter Sent] AS Date)
WHEN B.[Gift Card Letter Sent] is null and B.[Sent For Gift Card Processing] is null THEN null
ELSE Cast('1/1/1900' AS Date)
END AS 'Last GC Date'
,CASE
	WHEN B.[Exception Status] in ('New Referral','Clarity Required','New Exception','FIOA Request','Fee Approved','Pending Counterparty Request','In Process','Cured in Error','Returned back to Vendor - Completion Error','Clarity Provided','Executed Document Returned','Referred','Issue Pending','Resolved-Pending Original') THEN 'Active Exception'
	WHEN B.[Exception Status] in ('Resolved','Not Valid','Incurable','Cancelled','Closed with Vendor') THEN 'Inactive Exception'
	WHEN B.[Exception Status] is null THEN 'No Exception'
	END AS 'Active Status'
,B.[Exception Status]
FROM SharepointData.dbo.HUDAssignExceptions B
LEFT JOIN SharepointData.dbo.HUDAssignLoans A
ON A.[Loan Number] = B.[Loan Number]
LEFT JOIN SharepointData.dbo.HUDAssignHUDStatus C
ON A.[Loan Number] = C.[Loan Number]
WHERE B.[Exception ID] in ('303459',
'381715',
'377670',
'384558',
'346056',
'302701',
'354684',
'353172',
'432328',
'424706',
'387669',
'388430',
'392612',
'432443',
'395644',
'412244',
'439031',
'419233',
'417588',
'411164',
'391059',
'371315',
'394343',
'411446',
'405184',
'368119',
'388149',
'430950',
'397703',
'430422',
'362764',
'405619',
'366939',
'400999',
'428288',
'376949',
'409153',
'313668',
'409161',
'404186',
'406924',
'406836',
'409154',
'372719',
'448290',
'404185',
'393688',
'406955',
'426023',
'404277',
'426078',
'425957',
'416122',
'425987',
'425997',
'426137',
'426119',
'426006',
'426087',
'426016',
'426141',
'439160',
'426047',
'425962',
'425970',
'426090',
'426104',
'426011',
'426113',
'419500',
'199206',
'426143',
'426032',
'425911',
'425912',
'425916',
'426081',
'443496',
'425936',
'436255',
'425948',
'409535',
'425951',
'425952',
'425992',
'426073',
'426145',
'409587',
'426005',
'439154',
'440975',
'426017',
'383050',
'426100',
'426033',
'426095',
'426064',
'425937',
'439591',
'431613',
'413918',
'431511',
'432096',
'359012',
'431590',
'414051',
'431465',
'443084',
'413828',
'431299',
'413926',
'431488',
'413633',
'405255',
'431589',
'431428',
'442955',
'431214',
'413942',
'395603',
'434989',
'438909',
'440437',
'431519',
'431339',
'427023')--A.[Tag 2] is null and A.[Incurable Flag] in ('0') AND B.[Document] in ('Current OCC Cert','Tax Bill','Proof of Repair','Trust - HACG','Death Cert HACG') --AND B.[Exception Status] NOT IN ('Closed','Not Valid','Resolved','Incurable') AND A.[Loan Status] in ('Active') AND C.[HUD Status] not in ('Resubmitted to HUD','Pkg Submitted to HUD','HUD Approved') AND A.[MCA %] >= '97.5'
ORDER BY B.[Document],A.[Loan Number],('Active Status'),B.[Exception ID] Desc