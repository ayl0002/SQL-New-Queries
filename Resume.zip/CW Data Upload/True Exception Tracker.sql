use reverse_dw
select final3.*, concat(datepart(mm,[True Open Date]), '-', datepart(yyyy,[True Open Date])) as [Open MY] into ##taxtreatment from 
(select final2.*,  row_number() over (partition by loan_nbr order by  [True Open Date] asc) as XRank from
(select final.*, case when [Last Resolved Date] > [Excp_rqst_dttm] then cast([last resolved date] as date) else cast(excp_rqst_dttm as date) end as 'True Open Date',
case when [Last Resolved Date] is not null then 'Y' else 'N' end as 'Previous Close'
 -- into -- ##delinquentbase
 from

(select base.*, [Last Resolved Date] from
(select loan_nbr, excp_id, [EXCP_RQST_DTTM], [DOC_DESC],[ISSU_DESC] , vndr_desc, [EXCP_ASGN_TO_DESC], excp_sts_dttm 
from
(select loan_nbr, excp_id, [EXCP_RQST_DTTM],[DOC_DESC], issu_desc, vndr_desc, [EXCP_ASGN_TO_DESC], excp_sts_dttm from [dbo].[HUD_ASGN_EXCP_EDW] where curr_ind = 'Y' and [WRK_GRP_DESC] in ('HACG')
and doc_desc = 'Tax Bill'  and [EXCP_STS_DESC] not in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable') ) a) base
left join
(select excp_id, max(end_dttm) as 'Last Resolved Date' from [dbo].[HUD_ASGN_EXCP_EDW] where doc_desc = 'Tax Bill' and 
[EXCP_STS_DESC] in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable') group by excp_id) prv on base.excp_id=prv.excp_id
) final
left join
(select [Loan Number], [Exception ID] from [Reverse_SPSTG].[dbo].[HUDAssignExceptionsEDW]) mtc on final.excp_id=mtc.[exception id]
where mtc.[Exception ID] is not null) final2) final3
where xrank = 1


select final3.*, concat(datepart(mm,[True Open Date]), '-', datepart(yyyy,[True Open Date])) as [Open MY] into ##hoatreatment from 
(select final2.*,  row_number() over (partition by loan_nbr order by  [True Open Date] asc) as XRank from
(select final.*, case when [Last Resolved Date] > [Excp_rqst_dttm] then cast([last resolved date] as date) else cast(excp_rqst_dttm as date) end as 'True Open Date',
case when [Last Resolved Date] is not null then 'Y' else 'N' end as 'Previous Close'
 -- into -- ##delinquentbase
 from

(select base.*, [Last Resolved Date] from
(select loan_nbr, excp_id, [EXCP_RQST_DTTM], [DOC_DESC],[ISSU_DESC] , vndr_desc, [EXCP_ASGN_TO_DESC], excp_sts_dttm 
from
(select loan_nbr, excp_id, [EXCP_RQST_DTTM],[DOC_DESC], issu_desc, vndr_desc, [EXCP_ASGN_TO_DESC], excp_sts_dttm from [dbo].[HUD_ASGN_EXCP_EDW] where curr_ind = 'Y' and [WRK_GRP_DESC] in ('HACG')
and doc_desc = 'HOA'  and [EXCP_STS_DESC] not in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable') ) a) base
left join
(select excp_id, max(end_dttm) as 'Last Resolved Date' from [dbo].[HUD_ASGN_EXCP_EDW] where doc_desc = 'HOA' and 
[EXCP_STS_DESC] in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable') group by excp_id) prv on base.excp_id=prv.excp_id
) final
left join
(select [Loan Number], [Exception ID] from [Reverse_SPSTG].[dbo].[HUDAssignExceptionsEDW]) mtc on final.excp_id=mtc.[exception id]
where mtc.[Exception ID] is not null) final2) final3
where xrank = 1



select final3.*, concat(datepart(mm,[True Open Date]), '-', datepart(yyyy,[True Open Date])) as [Open MY] into ##occtreatment from 
(select final2.*,  row_number() over (partition by loan_nbr order by  [True Open Date] asc) as XRank from
(select final.*, case when [Last Resolved Date] > [Excp_rqst_dttm] then cast([last resolved date] as date) else cast(excp_rqst_dttm as date) end as 'True Open Date',
case when [Last Resolved Date] is not null then 'Y' else 'N' end as 'Previous Close'
 -- into -- ##delinquentbase
 from

(select base.*, [Last Resolved Date] from
(select loan_nbr, excp_id, [EXCP_RQST_DTTM], [DOC_DESC],[ISSU_DESC] , vndr_desc, [EXCP_ASGN_TO_DESC], excp_sts_dttm 
from
(select loan_nbr, excp_id, [EXCP_RQST_DTTM],[DOC_DESC], issu_desc, vndr_desc, [EXCP_ASGN_TO_DESC], excp_sts_dttm from [dbo].[HUD_ASGN_EXCP_EDW] where curr_ind = 'Y' and [WRK_GRP_DESC] in ('HACG')
and doc_desc = 'Current OCC Cert'  and [EXCP_STS_DESC] not in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable') ) a) base
left join
(select excp_id, max(end_dttm) as 'Last Resolved Date' from [dbo].[HUD_ASGN_EXCP_EDW] where doc_desc = 'Current OCC Cert' and 
[EXCP_STS_DESC] in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable') group by excp_id) prv on base.excp_id=prv.excp_id
) final
left join
(select [Loan Number], [Exception ID] from [Reverse_SPSTG].[dbo].[HUDAssignExceptionsEDW]) mtc on final.excp_id=mtc.[exception id]
where mtc.[Exception ID] is not null) final2) final3
where xrank = 1




select final3.*, concat(datepart(mm,[True Open Date]), '-', datepart(yyyy,[True Open Date])) as [Open MY] into ##portreatment from 
(select final2.*,  row_number() over (partition by loan_nbr order by  [True Open Date] asc) as XRank from
(select final.*, case when [Last Resolved Date] > [Excp_rqst_dttm] then cast([last resolved date] as date) else cast(excp_rqst_dttm as date) end as 'True Open Date',
case when [Last Resolved Date] is not null then 'Y' else 'N' end as 'Previous Close'
 -- into -- ##delinquentbase
 from

(select base.*, [Last Resolved Date] from
(select loan_nbr, excp_id, [EXCP_RQST_DTTM], [DOC_DESC],[ISSU_DESC] , vndr_desc, [EXCP_ASGN_TO_DESC], excp_sts_dttm 
from
(select loan_nbr, excp_id, [EXCP_RQST_DTTM],[DOC_DESC], issu_desc, vndr_desc, [EXCP_ASGN_TO_DESC], excp_sts_dttm from [dbo].[HUD_ASGN_EXCP_EDW] where curr_ind = 'Y' and [WRK_GRP_DESC] in ('HACG')
and doc_desc = 'Proof of Repair'  and [EXCP_STS_DESC] not in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable') ) a) base
left join
(select excp_id, max(end_dttm) as 'Last Resolved Date' from [dbo].[HUD_ASGN_EXCP_EDW] where doc_desc = 'Proof of Repair' and 
[EXCP_STS_DESC] in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable') group by excp_id) prv on base.excp_id=prv.excp_id
) final
left join
(select [Loan Number], [Exception ID] from [Reverse_SPSTG].[dbo].[HUDAssignExceptionsEDW]) mtc on final.excp_id=mtc.[exception id]
where mtc.[Exception ID] is not null) final2) final3
where xrank = 1


select final3.*, concat(datepart(mm,[True Open Date]), '-', datepart(yyyy,[True Open Date])) as [Open MY] into ##spptreatment from 
(select final2.*,  row_number() over (partition by loan_nbr order by  [True Open Date] asc) as XRank from
(select final.*, case when [Last Resolved Date] > [Excp_rqst_dttm] then cast([last resolved date] as date) else cast(excp_rqst_dttm as date) end as 'True Open Date',
case when [Last Resolved Date] is not null then 'Y' else 'N' end as 'Previous Close'
 -- into -- ##delinquentbase
 from

(select base.*, [Last Resolved Date] from
(select loan_nbr, excp_id, [EXCP_RQST_DTTM], [DOC_DESC],[ISSU_DESC] , vndr_desc, [EXCP_ASGN_TO_DESC], excp_sts_dttm 
from
(select loan_nbr, excp_id, [EXCP_RQST_DTTM],[DOC_DESC], issu_desc, vndr_desc, [EXCP_ASGN_TO_DESC], excp_sts_dttm from [dbo].[HUD_ASGN_EXCP_EDW] where curr_ind = 'Y' and [WRK_GRP_DESC] in ('HACG')
and doc_desc = 'Signed Pay Plan'  and [EXCP_STS_DESC] not in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable') ) a) base
left join
(select excp_id, max(end_dttm) as 'Last Resolved Date' from [dbo].[HUD_ASGN_EXCP_EDW] where doc_desc = 'Signed Pay Plan' and 
[EXCP_STS_DESC] in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable') group by excp_id) prv on base.excp_id=prv.excp_id
) final
left join
(select [Loan Number], [Exception ID] from [Reverse_SPSTG].[dbo].[HUDAssignExceptionsEDW]) mtc on final.excp_id=mtc.[exception id]
where mtc.[Exception ID] is not null) final2) final3
where xrank = 1



select final3.*, concat(datepart(mm,[True Open Date]), '-', datepart(yyyy,[True Open Date])) as [Open MY] into ##trttreatment from 
(select final2.*,  row_number() over (partition by loan_nbr order by  [True Open Date] asc) as XRank from
(select final.*, case when [Last Resolved Date] > [Excp_rqst_dttm] then cast([last resolved date] as date) else cast(excp_rqst_dttm as date) end as 'True Open Date',
case when [Last Resolved Date] is not null then 'Y' else 'N' end as 'Previous Close'
 -- into -- ##delinquentbase
 from

(select base.*, [Last Resolved Date] from
(select loan_nbr, excp_id, [EXCP_RQST_DTTM], [DOC_DESC],[ISSU_DESC] , vndr_desc, [EXCP_ASGN_TO_DESC], excp_sts_dttm 
from
(select loan_nbr, excp_id, [EXCP_RQST_DTTM],[DOC_DESC], issu_desc, vndr_desc, [EXCP_ASGN_TO_DESC], excp_sts_dttm from [dbo].[HUD_ASGN_EXCP_EDW] where curr_ind = 'Y' and [WRK_GRP_DESC] in ('HACG')
and doc_desc = 'Trust - HACG'  and [EXCP_STS_DESC] not in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable') ) a) base
left join
(select excp_id, max(end_dttm) as 'Last Resolved Date' from [dbo].[HUD_ASGN_EXCP_EDW] where doc_desc = 'Trust - HACG' and 
[EXCP_STS_DESC] in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable') group by excp_id) prv on base.excp_id=prv.excp_id
) final
left join
(select [Loan Number], [Exception ID] from [Reverse_SPSTG].[dbo].[HUDAssignExceptionsEDW]) mtc on final.excp_id=mtc.[exception id]
where mtc.[Exception ID] is not null) final2) final3
where xrank = 1





select final3.*, concat(datepart(mm,[True Open Date]), '-', datepart(yyyy,[True Open Date])) as [Open MY] into ##dthtreatment from 
(select final2.*,  row_number() over (partition by loan_nbr order by  [True Open Date] asc) as XRank from
(select final.*, case when [Last Resolved Date] > [Excp_rqst_dttm] then cast([last resolved date] as date) else cast(excp_rqst_dttm as date) end as 'True Open Date',
case when [Last Resolved Date] is not null then 'Y' else 'N' end as 'Previous Close'
 -- into -- ##delinquentbase
 from

(select base.*, [Last Resolved Date] from
(select loan_nbr, excp_id, [EXCP_RQST_DTTM], [DOC_DESC],[ISSU_DESC] , vndr_desc, [EXCP_ASGN_TO_DESC], excp_sts_dttm 
from
(select loan_nbr, excp_id, [EXCP_RQST_DTTM],[DOC_DESC], issu_desc, vndr_desc, [EXCP_ASGN_TO_DESC], excp_sts_dttm from [dbo].[HUD_ASGN_EXCP_EDW] where curr_ind = 'Y' and [WRK_GRP_DESC] in ('HACG')
and doc_desc = 'Death Cert HACG'  and [EXCP_STS_DESC] not in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable') ) a) base
left join
(select excp_id, max(end_dttm) as 'Last Resolved Date' from [dbo].[HUD_ASGN_EXCP_EDW] where doc_desc = 'Death Cert HACG' and 
[EXCP_STS_DESC] in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable') group by excp_id) prv on base.excp_id=prv.excp_id
) final
left join
(select [Loan Number], [Exception ID] from [Reverse_SPSTG].[dbo].[HUDAssignExceptionsEDW]) mtc on final.excp_id=mtc.[exception id]
where mtc.[Exception ID] is not null) final2) final3
where xrank = 1

select distinct doc_desc from [dbo].[HUD_ASGN_EXCP_EDW]






select final.*, case when [Tax Open MY] is not null then 'Y' else 'N' end as 'Has Tax Exception', 
case when [OCC Open MY] is not null then 'Y' else 'N' end as 'Has OCC Exception', 
case when [HOA Open MY] is not null then 'Y' else 'N' end as 'Has HOA Exception' from 

(select base.*, prmca.[Previous Month MCA], tax.excp_id as 'Tax Exception', tax.[issu_desc] as 'Tax Issue', tax.[Open MY] as 'Tax Open MY', tax.[Previous Close] as 'Previous Tax Close',
-- tax.excp_asgn_to_desc as 'Tax Assigned To', tax.vndr_desc as 'Tax Vendor',
 occ.excp_id as 'OCC Exception', occ.[issu_desc] as 'OCC Issue', occ.[Open MY] as 'OCC Open MY', OCC.[Previous Close] as 'Previous OCC Close',
-- occ.excp_asgn_to_desc as 'OCC Assigned To', occ.vndr_desc as 'OCC Vendor'
  HOA.excp_id as 'HOA Exception', HOA.[issu_desc] as 'HOA Issue', HOA.[Open MY] as 'HOA Open MY', HOA.[Previous Close] as 'Previous HOA Close'
  --hoa.excp_asgn_to_desc as 'HOA Assigned To', hoa.vndr_desc as 'HOA Vendor' 
  ,case when [Curative Count] is null then 'N' else 'Y' end as 'In Curative', [FR Agent]
 from
(select loan_nbr, mca_percent, mca_bucket from ##curativeanalysis where mca_percent >= 95) base
left join
(select loan_nbr, case when [mca_percent] < 95 then 'Segment 1'
when mca_percent < 97 then 'Segment 2'
when mca_percent < 97.5 then 'Segment 2B'
when mca_percent < 100 then 'Segment 3A' else 'Segment 3B' end as 'Previous Month MCA' from ##prev) prmca on base.loan_nbr=prmca.loan_nbr

left join
(select loan_nbr, excp_id, [issu_desc], [true open date], [Open MY], [Previous Close], vndr_desc, excp_asgn_to_desc from ##taxtreatment) tax on cast(base.loan_nbr as varchar)=tax.loan_nbr
left join
(select loan_nbr, excp_id, [issu_desc], [true open date], [Open MY], [Previous Close], vndr_desc, excp_asgn_to_desc from ##occtreatment) occ on cast(base.loan_nbr as varchar)=occ.loan_nbr
left join
(select loan_nbr, excp_id, [issu_desc], [true open date], [Open MY], [Previous Close], vndr_desc, excp_asgn_to_desc from ##hoatreatment) hoa on cast(base.loan_nbr as varchar)=hoa.loan_nbr
left join
(select loan_nbr, count(*) as 'Curative Count' from ##curativebase group by loan_nbr) ccur on cast(base.loan_nbr as varchar)=ccur.loan_nbr
left join
(select loan_nbr, fnl_rvw_asgn_to_nm as 'FR Agent' from [dbo].[HUD_ASGN_FNL_RVW] where curr_ind = 'Y') agt on cast(base.loan_nbr as varchar)=agt.loan_nbr) final