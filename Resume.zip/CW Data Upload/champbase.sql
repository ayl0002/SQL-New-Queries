use reverse_dw 
select final.*, [PLCY_EFF_DT],[PLCY_EXPR_DT], PREM_AMT, [Policy_Type]   into ##champbase from 
(select loan_nbr, loan_key, max_claim_amount,[LITITGATION_STATUS], mca_percent, left(FHA_CaSe_NBR,10) as 'FHA Number', status_code, status_description, 

 case when [BORROWER_DATE_OF_DEATH] is not null then 'Estate of' + ' ' + [BORROWER_FIRST_NAME] + ' ' + [BORROWER_LAST_NAME] else
    [BORROWER_FIRST_NAME] + ' ' + [BORROWER_LAST_NAME] end as 'Borrower Name',
[CLOSING_DATE]

, [PROP_ADDRESS], [PROP_CITY], [PROP_STATE], [PROP_ZIP_CODE], 
[BORROWER_MAIL_ADDRESS],[BORROWER_MAIL_CITY] , [BORROWER_MAIL_STATE],[BORROWER_MAIL_ZIP_CODE] ,
case when [COBORROWER_DATE_OF_DEATH] is not null then 'Estate of' + ' ' + [COBORROWER_FIRST_NAME] + ' ' + [COBORROWER_LAST_NAME]
else [COBORROWER_FIRST_NAME] + ' ' + [COBORROWER_LAST_NAME] end as 'CoBorrower Name',

 case when investor = 'FNMA' then 'FNMA' else 'Non-FNMA' end as 'Investor'
,case when mca_percent >= 100 then current_total_upb - max_claim_amount end as 'Cross Over Loss',
[Current Year Anniversary of Loan Closing Date],[Next Year Anniversary of Loan Closing Date]
,ABS(DATEDIFF(Month,GETDATE(),[Current Year Anniversary of Loan Closing Date])) AS 'Curr_Anni'
,ABS(DATEDIFF(Month,[Next Year Anniversary of Loan Closing Date],GETDATE())) AS 'Next_Anni',
[BORROWER_FIRST_NAME], [BORROWER_LAST_NAME], [COBORROWER_FIRST_NAME], [COBORROWER_LAST_NAME], net_line_of_credit

  from [dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW]) final
  left join
  (select base3.* from 
(select base2.*, [PLCY_EFF_DT],[PLCY_EXPR_DT], PREM_AMT, [Policy_Type], row_number() over (partition by base2.loan_nbr order by  [plcy_expr_dt] desc) as XRank from 
(SELECT cast(loan_nbr as bigint) as 'Loan_NBR', max(bus_proc_dt) as 'Last Update' 
 FROM reverse_dw.[dbo].[TP_SWBC_INS_RET] WHERE PLCY_EXPR_DT IS NOT NULL and [CMPNY_NM] = 'FP POL'
 group by loan_nbr) base2
 left join
 (select cast(loan_nbr as bigint) as 'Loan_NBR', bus_proc_dt, [PLCY_EFF_DT],[PLCY_EXPR_DT], PREM_AMT, CASE WHEN [CVR_TYPE] = 'F' THEN 'Fire(Hazard)'
         WHEN [CVR_TYPE] = 'W' THEN 'Flood'
         WHEN [CVR_TYPE] = 'A' THEN 'Wind'
         WHEN [CVR_TYPE] = 'G' THEN 'Flood Gap'
         WHEN [CVR_TYPE] = 'L' THEN 'Liability'
         WHEN [CVR_TYPE] = 'E' THEN 'Equipment'
         WHEN [CVR_TYPE] = 'Q' THEN 'Quake'
         WHEN [CVR_TYPE] = '1' THEN 'Condo'
         WHEN [CVR_TYPE] = '3' THEN 'Condo Flood Gap'
         WHEN [CVR_TYPE] = '4' THEN 'Condo w/Wind Supp'
         WHEN [CVR_TYPE] IS NULL THEN 'No Insurance'
         ELSE 'UNKNOWN'
       END AS 'Policy_Type' FROM reverse_dw.[dbo].[TP_SWBC_INS_RET]  ) pld on base2.loan_nbr=pld.loan_nbr and base2.[Last Update]=pld.bus_proc_dt
	   where plcy_expr_dt > '2020-01-01' ) base3
	   where xrank = 1) base4 on final.loan_nbr=base4.loan_nbr



 

 










