use reverse_dw
/*select base.*, mca.[submission mca], case when [submission mca] = '97.5-97.99' then 'LT 98' else 'SLA Applies' end as 'Submission Group' from
(select * from ##pending) base
left join
(select loan_nbr, [submission mca] from ##mcarank where xrank=1 ) mca on base.loan_nbr=mca.loan_nbr
select * from ##mcarank*/  
----------------------------------------------------------------------

select distinct loan_nbr, [date submitted], [Aging], status_code,  [mca bucket], investor, pool_name
 into   ##pending 
 from
(select base4.*, hdn.dny_dt, case when pmca.loan_nbr is not null then 'Y' else 'N' end as 'Roll-In',
  mca.status_code , mca.[MCA Bucket], mca.investor, mca.pool_name from
(select base3.* from
(select base2.*, datediff(day,base2.[date submitted],getdate()) as 'Aging' from
(select base.*, dny.[Denial Date], apr.[Approval Date], case 
when dny.[Denial Date] is null then 0
when dny.[Denial Date] < base.[date submitted] then 0 else 1 end as 'True Denial'
,case
when apr.[Approval Date] is null then 0
when apr.[Approval Date] < base.[date submitted] then 0 else 1 end as 'True Approval'
from
(select loan_nbr, max([DT_SBMT_TO_HUD]) as 'Date Submitted'
from  
[dbo].[HUD_ASSGN_DT_SBMT_RESBMT]
where datediff(day,[DT_SBMT_TO_HUD],getdate()) < 90
group by loan_nbr) base

left join
(select distinct lndr_loan_nbr, max([DNY_DT]) as 'Denial Date'
from [dbo].[TP_HRMT_PRELIM_TTL_DNY]
 where [DNY_DT] < getdate()
 group by lndr_loan_nbr) dny on base.loan_nbr=dny.lndr_loan_nbr

 left join
(select distinct lndr_loan_nbr, max([HUD_APRV_DT]) as 'Approval Date'
from [dbo].[TP_HRMT_PRELIM_TTL_APRV]
 where [HUD_APRV_DT] < getdate()
 group by lndr_loan_nbr) APR on base.loan_nbr=apr.lndr_loan_nbr) base2
 where base2.[True Denial] = 0 and base2.[True Approval] = 0) base3


) base4
left join
(Select loan_nbr, status_code, investor, pool_name,  case when MCA_Percent < 98 then '97.5-97.99' when MCA_Percent < 100 then '98-99.99'
when MCA_Percent < 105 then '100-104.99' else '105+' end as 'MCA Bucket'
from [dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] ) mca on base4.loan_nbr=cast(mca.loan_nbr as varchar) 
left join
(select loan_nbr from [dbo].[RM_CHAMPION_MASTER_TBL_VW]('2019-09-30',20181230) where mca_percent < 97.5 ) pmca on base4.loan_nbr=cast(pmca.loan_nbr as varchar)


left join
(select [LNDR_LOAN_NBR], [HUD_APRV_DT] from [dbo].[TP_HRMT_PRELIM_TTL_APRV]) hap on base4.loan_nbr=hap.[LNDR_LOAN_NBR]
left join
(select [LNDR_LOAN_NBR], [DNY_DT] from [dbo].[TP_HRMT_PRELIM_TTL_DNY]) hdn on base4.loan_nbr=hdn.[LNDR_LOAN_NBR]
left join
(select loan_nbr, max([HUD_PRELIM_TTL_DNY_DT]) as 'Hud Denied Date' from [dbo].[HUD_ASGN_HUD_STS]
group by loan_nbr) hdsts on base4.loan_nbr=hdsts.loan_nbr
left join
(select loan_nbr, [TAG_2_VAL] from [dbo].[HUD_ASGN_LOANS] where end_dttm = '9999-12-31') hal on base4.loan_nbr=hal.loan_nbr
where mca.status_code = 0 and 
(hap.[HUD_APRV_DT] is null or hap.[HUD_APRV_DT] < [Date Submitted]) and (hdn.[dny_dt] is null or hdn.[dny_dt] <= [date submitted])
and(hdsts.[hud denied date] is null or hdsts.[Hud Denied Date] <= [Date Submitted])
and hal.[TAG_2_VAL] is null) finito
where status_code = 0





---------------------------------------------------------------------------------------------




-----------------------------------------------------------------
	select loan_nbr, excp_id,  [EXCP_RQST_DTTM],  [DOC_DESC],[ISSU_DESC] ,  [EXCP_STS_UPDT_BY_DESC] as 'Updated By' , row_number() over (partition by loan_nbr order by excp_rqst_dttm ) as XRank into  ##inclookup
	from
	(select loan_nbr, excp_id,   [EXCP_RQST_DTTM],[DOC_DESC], issu_desc, [EXCP_STS_UPDT_BY_DESC] from [dbo].[HUD_ASGN_EXCP_EDW] where curr_ind = 'Y'  
	 and [EXCP_STS_DESC] = 'Incurable' ) a
	











--select * from  ##febco order by [group]	






