use reverse_dw
select final.*, mca_percent + [projected accrual] as 'Next Month MCA', mca_percent + [projected accrual] + [projected accrual] + .01 as '2 Month MCA'
, mca_percent + [projected accrual] + [projected accrual] + [projected accrual] + .02 as '3 Month MCA'
, mca_percent + [projected accrual] + [projected accrual] + [projected accrual] + [projected accrual] + .03 as '4 Month MCA'
, mca_percent + [projected accrual] + [projected accrual] + [projected accrual] + [projected accrual] + [projected accrual] + .04 as '5 Month MCA',

[Tag_2_Val], [Group], [Incurable Flag] into  ##billdashaccrual
 from 
(select final.*, round([Accrual]/current_total_upb,3) as 'Projected Accrual' 
 from 
(select base.*, b.[mth_srvc_fee_amt], ROUND(CURRENT_TOTAL_UPB * CURRENT_INTEREST_RATE /12,2)+ROUND(CURRENT_TOTAL_UPB * MIP_RATE /12,2)+[MTH_SRVC_FEE_AMT]  as 'Accrual'

 from 
(select loan_nbr, loan_key, mca_percent, current_total_upb, current_interest_rate, mip_rate, status_code from [dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW]) base

  left join
   
(select loan_key, [MTH_SRVC_FEE_AMT] from [dbo].[RVRS_LOAN_BAL] where curr_ind = 'Y') b on base.loan_key=b.loan_key) final
where mca_percent > 0 and mip_rate > 0 and current_interest_rate > 0) final
left join
(select distinct [Loan Number] as loan_nbr,[HUD Assigned Loans Tag2] as [TAG_2_VAL]
                           ,[Group] 
                           ,[Incurable Flag] 
                     from RM_DMART01..dm_hud_dim(nolock) 
                     where curr_ind='y'
              ) hld on cast(final.loan_nbr as varchar)=hld.loan_nbr
	

