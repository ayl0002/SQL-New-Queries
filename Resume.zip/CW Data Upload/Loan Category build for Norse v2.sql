use reverse_dw
select loan_key, cast(max(txn_dt) as date) as 'Active Date' into ##activedt from [dbo].[LOAN_STS_EVT_TXN] where  [OLD_LOAN_STS_CD] <> '0' and [NEW_LOAN_STS_CD] = '0'
group by loan_key

select [loan number], cast(max(end_dttm) as date) as 'Incurable Cleared Date' into ##Incurabledt from rm_dmart01.dbo.dm_hud_dim where 
[incurable flag] in ('1.00000000000000', '2.00000000000000', '3.00000000000000', '4.00000000000000', '5.00000000000000','6.00000000000000', '7.00000000000000')
group by [Loan number] 

select [loan number], cast(max(end_dttm) as date) as 'Hold Cleared Date' into ##Holddt from rm_dmart01.dbo.dm_hud_dim where 
 [HUD Assigned Loans Tag2] like '%hold%' 
group by [Loan number] 


select loan_nbr, count(*) as 'Curative Count'  into ##curativedt from [dbo].[HUD_ASGN_EXCP_EDW] where wrk_grp_desc
in ('Curative', 'LandTran') and excp_sts_desc not in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable')
and curr_ind = 'Y'
group by loan_nbr
	
select loan_nbr, cast(max(excp_sts_dttm) as date) as 'Curative Clear Date' into ##curativecldt from [dbo].[HUD_ASGN_EXCP_EDW] where wrk_grp_desc
in ('Curative', 'LandTran') and excp_sts_desc in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable')
and curr_ind = 'Y'
group by loan_nbr


select loan_nbr, mca_percent as 'Prev MCA' into  ##prerolldt from [dbo].[RM_CHAMPION_MASTER_TBL_VW]('2020-03-30',20191126)






select final.*, case when datediff(day,[Incurable Cleared Date],getdate()) between 0 and 60 then 'From Incurable'
when datediff(day,[Hold Cleared Date],getdate()) between 0 and 60 then 'From Hold'
when datediff(day,[Active Date],getdate()) between 0 and 30 then 'From Default'
when datediff(day,[Curative Clear Date],getdate()) between 1 and 15 then 'From Curative'
when [Prev MCA] >= 97.5 then 'Existing'
else 'Roll-In'

end as 'Roll-In Category' ,
 [Last Denial],
case when [Last Denial] is null then 'Never Denied'
when datediff(day,[Last Denial],getdate()) between 1 and 3 then '1 to 3 Days'
when datediff(day,[Last Denial],getdate()) between 4 and 6 then '4 to 6 Days'
when datediff(day,[Last Denial],getdate()) between 5 and 10 then '5 to 10 Days'
when datediff(day,[Last Denial],getdate()) between 11 and 15 then '11 to 15 Days'
when datediff(day,[Last Denial],getdate()) < 31 then '16 to 30 Days'
else '31+ Days' end as 'HUD Denial Aging' into  ##loancat2
from 

(select base.*, [Active Date], [Incurable Cleared Date],  [Curative Count], [Curative Clear Date], [Hold Cleared Date]


 from 
(select * from ##curativeanalysis where mca_percent >= 97.5) base
left join
(select * from ##activedt  ) act on base.loan_key=act.loan_key
left join
(select * from  ##Incurabledt) inc on cast(base.loan_nbr as varchar)=inc.[loan number]
left join
(select * from  ##Holddt) hld on cast(base.loan_nbr as varchar)=hld.[loan number]

left join
(select * from  ##curativedt ) ccur on cast(base.loan_nbr as varchar)=ccur.loan_nbr
left join
(select * from  ##curativecldt) ccdt on cast(base.loan_nbr as varchar)=ccdt.loan_nbr

where [Curative Count] is null
 ) final
left join
(select * from ##prerolldt ) prv on final.loan_nbr=prv.loan_nbr
left join
(select lndr_loan_nbr, max(dny_dt) as 'Last Denial' from [dbo].[TP_HRMT_PRELIM_TTL_DNY]
group by lndr_loan_nbr ) ldy on cast(final.loan_nbr as varchar)=ldy.lndr_loan_nbr
order by [Curative Clear Date] desc





