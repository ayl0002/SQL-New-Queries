use reverse_dw
select loan_nbr, max(excp_sts_dttm) as 'HOA Close Date' into ##hoaclose from [dbo].[HUD_ASGN_EXCP_EDW] where doc_desc = 'HOA' and
excp_sts_desc = 'Resolved'
group by loan_nbr
order by [hoa close date] desc



select loan_nbr, max(excp_sts_dttm) as 'OCC Close Date' into ##occclose from [dbo].[HUD_ASGN_EXCP_EDW] where doc_desc = 'Current OCC Cert' and
excp_sts_desc = 'Resolved'
group by loan_nbr
order by [occ close date] desc


select loan_nbr, max(excp_sts_dttm) as 'Tax Close Date' into ##taxclose from [dbo].[HUD_ASGN_EXCP_EDW] where doc_desc = 'Tax Bill' and
excp_sts_desc = 'Resolved'
group by loan_nbr
order by [Tax close date] desc

select loan_nbr, max(excp_sts_dttm) as 'Hazard Close Date' into ##hazardclose from [dbo].[HUD_ASGN_EXCP_EDW] where (doc_desc like '%hazard%' or doc_desc like '%flood%') and
excp_sts_desc = 'Resolved'
group by loan_nbr
order by [Hazard close date] desc


select base.*, hoa.[hoa close date], tax.[Tax Close Date], occ.[OCC Close Date], haz.[Hazard Close Date] into ##lastexceptionclose from 
(select loan_nbr from ##billdashaccrual) base
left join
(select loan_nbr, cast([HOA Close Date] as date) as 'HOA Close Date' from ##hoaclose) hoa on cast(base.loan_nbr as varchar)=hoa.loan_nbr
left join
(select loan_nbr, cast([Tax Close Date] as date) as 'Tax Close Date' from ##taxclose) tax on cast(base.loan_nbr as varchar)=tax.loan_nbr
left join
(select loan_nbr, cast([OCC Close Date] as date) as 'OCC Close Date' from ##occclose) occ on cast(base.loan_nbr as varchar)=occ.loan_nbr
left join
(select loan_nbr, cast([Hazard Close Date] as date) as 'Hazard Close Date' from ##hazardclose) haz on cast(base.loan_nbr as varchar)=haz.loan_nbr






