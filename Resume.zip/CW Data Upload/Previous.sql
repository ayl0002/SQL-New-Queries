use reverse_dw
select loan_nbr, status_code, mca_percent into ##prev from [dbo].[RM_CHAMPION_MASTER_TBL_VW]('2020-02-29',20200229)
select loan_nbr, status_code, mca_percent into ##prev2 from [dbo].[RM_CHAMPION_MASTER_TBL_VW]('2020-01-31',20200131)

select loan_nbr, status_code, mca_percent into ##prev3 from [dbo].[RM_CHAMPION_MASTER_TBL_VW]('2019-12-31',20191231)

select loan_nbr, status_code, mca_percent into ##prev4 from [dbo].[RM_CHAMPION_MASTER_TBL_VW]('2019-11-30',20191130)





