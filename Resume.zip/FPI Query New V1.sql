SET NoCount ON 
SET ANSI_Warnings OFF
--Assignable--
SELECT
A.LOAN_NBR
,A.LOAN_STS_DESC
,MCA_PCT
,CASE
	WHEN MCA_PCT >=97.5 THEN '>=97.5'
	ELSE '<97.5'
	END AS 'MCA_BUCKET'
,TAG_2_VAL
,INCRBL_FLG_DESC
,STG_VAL
,C.HUD_STS_DESC
,GRP_DESC
,FNL_RVW_ASGN_TO_NM
,HUD_ASGN_TO_NM
,D.[DOC_DESC] AS 'FPI_Doc_Desc'
,E.[DOC_DESC] AS 'Flood_Doc_Desc'
,F.[DOC_DESC] AS 'Condo_Doc_Desc'
--,D.FPI_Count AS 'FPI_Excp_Count'
,CASE
WHEN FNL_RVW_ASGN_TO_NM IN ('Chelsea Daniel') OR HUD_ASGN_TO_NM IN ('Chelsea Daniel') THEN 'Pipeline Management'
WHEN FNL_RVW_ASGN_TO_NM IN ('Norse Lockhart') OR HUD_ASGN_TO_NM IN ('Norse Lockhart') THEN 'Pipeline Management'
WHEN FNL_RVW_ASGN_TO_NM IN ('Shelby Dominguez') OR HUD_ASGN_TO_NM IN ('Shelby Dominguez') THEN 'Pipeline Management'
WHEN FNL_RVW_ASGN_TO_NM IS NULL AND HUD_ASGN_TO_NM IS NULL THEN 'No RG'
WHEN FNL_RVW_ASGN_TO_NM IS NULL AND HUD_ASGN_TO_NM NOT IN ('Robert Gough') THEN 'No RG'
WHEN FNL_RVW_ASGN_TO_NM NOT IN ('Robert Gough') AND HUD_ASGN_TO_NM IS NULL THEN 'No RG'
WHEN FNL_RVW_ASGN_TO_NM IS NULL AND HUD_ASGN_TO_NM IN ('Robert Gough') THEN 'No RG'
WHEN FNL_RVW_ASGN_TO_NM IN ('Robert Gough') AND HUD_ASGN_TO_NM IS NULL THEN 'No RG'
WHEN FNL_RVW_ASGN_TO_NM IN ('Robert Gough') AND HUD_ASGN_TO_NM NOT IN ('Robert Gough') THEN 'No RG'
WHEN FNL_RVW_ASGN_TO_NM IN ('Robert Gough') AND HUD_ASGN_TO_NM IN ('Robert Gough') THEN 'Pipeline Management'
WHEN FNL_RVW_ASGN_TO_NM NOT IN ('Robert Gough') AND HUD_ASGN_TO_NM IN ('Robert Gough') THEN 'No RG'
WHEN FNL_RVW_ASGN_TO_NM NOT IN ('Robert Gough') AND HUD_ASGN_TO_NM NOT IN ('Robert Gough') THEN 'No RG'
ELSE 'Error'
END AS 'RG Flag'
,CASE WHEN MCA_PCT >= 97.5 AND A.LOAN_STS_DESC IN ('ACTIVE') AND TAG_2_VAL IS NULL AND INCRBL_FLG_DESC IN ('0') THEN 'Workable'
	WHEN MCA_PCT < 97.5 AND A.LOAN_STS_DESC IN ('ACTIVE') AND TAG_2_VAL IS NULL AND INCRBL_FLG_DESC IN ('0') THEN 'Below 97.5'
	WHEN TAG_2_VAL IS NOT NULL THEN 'Not_Workable - Tag 2'
	WHEN A.LOAN_STS_DESC NOT IN ('ACTIVE') THEN 'Not_Workable - Not Active'
	WHEN INCRBL_FLG_DESC NOT IN ('0') THEN 'Not_Workable - Incurable'
	ELSE 'Not_Workable'
	END AS 'WorkFlag'
,CASE WHEN C.HUD_STS_DESC IN ('HUD Approval','HUD Approved','Pkg Submitted to HUD','Rebuttal to HUD','Resubmitted to HUD') THEN 'Submitted to HUD'
	END AS 'Submit Flag'
INTO #ASGN
FROM REVERSE_DW.[dbo].[HUD_ASGN_LOANS] A
LEFT JOIN (SELECT * FROM REVERSE_DW.DBO.HUD_ASGN_HUD_STS WHERE CURR_IND IN ('Y')) C
ON A.LOAN_NBR=C.LOAN_NBR
LEFT JOIN (SELECT * FROM REVERSE_DW.DBO.HUD_ASGN_FNL_RVW WHERE CURR_IND IN ('Y')) B
ON A.LOAN_NBR=B.LOAN_NBR
LEFT JOIN 
(SELECT * FROM Reverse_DW.[dbo].[HUD_ASGN_EXCP_EDW] WHERE CURR_IND IN ('Y') AND [ISSU_DESC] IN ('Forced Placed Insurance') AND [Doc_Desc] NOT IN ('Flood Insurance','Condo Insurance') AND [EXCP_STS_DESC] NOT IN ('RESOLVED','CLOSED','NOT VALID','CLOSED WITH VENDOR')) D
ON A.LOAN_NBR = D.LOAN_NBR
LEFT JOIN (SELECT * FROM Reverse_DW.[dbo].[HUD_ASGN_EXCP_EDW] WHERE CURR_IND IN ('Y') AND [ISSU_DESC] IN ('Forced Placed Insurance') AND [Doc_Desc] IN ('Flood Insurance') AND [EXCP_STS_DESC] NOT IN ('RESOLVED','CLOSED','NOT VALID','CLOSED WITH VENDOR')) E
ON A.LOAN_NBR = E.LOAN_NBR
LEFT JOIN (SELECT * FROM Reverse_DW.[dbo].[HUD_ASGN_EXCP_EDW] WHERE CURR_IND IN ('Y') AND [ISSU_DESC] IN ('Forced Placed Insurance') AND [Doc_Desc] IN ('Condo Insurance') AND [EXCP_STS_DESC] NOT IN ('RESOLVED','CLOSED','NOT VALID','CLOSED WITH VENDOR')) F
ON A.LOAN_NBR = F.LOAN_NBR
WHERE A.CURR_IND IN ('Y') AND
--A.LOAN_STS_DESC IN ('ACTIVE') AND
--TAG_2_VAL IS NULL AND
--INCRBL_FLG_DESC IN ('0') AND
(GRP_DESC in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
GRP_DESC is null) AND
MCA_PCT >=89


--FPI Scrub--
SELECT
A.*--CAST(B.LOAN_NBR AS INT) AS 'LOAN_NBR'
,CVR_TYPE
,CASE WHEN [CVR_TYPE] = 'F' THEN 'Fire(Hazard)'
         WHEN [CVR_TYPE] = 'W' THEN 'Flood'
         WHEN [CVR_TYPE] = 'A' THEN 'Wind'
         WHEN [CVR_TYPE] = 'G' THEN 'Flood Gap'
         WHEN [CVR_TYPE] = 'L' THEN 'Liability'
         WHEN [CVR_TYPE] = 'E' THEN 'Equipment'
         WHEN [CVR_TYPE] = 'Q' THEN 'Quake'
         WHEN [CVR_TYPE] = '1' THEN 'Condo'
         WHEN [CVR_TYPE] = '3' THEN 'Condo Flood Gap'
         WHEN [CVR_TYPE] = '4' THEN 'Condo w/Wind Supp'
         WHEN [CVR_TYPE] IS NULL THEN 'No Insurance'
         ELSE 'UNKNOWN'
       END AS 'Policy_Type'
,CASE
	WHEN [CVR_TYPE] IS NULL THEN 'No Insurance'
	WHEN [CVR_TYPE] IN ('G','W','3') THEN 'Flood'
	WHEN [CVR_TYPE] IN ('1') THEN 'Condo'
	ELSE 'Haz'
END AS 'Excp_Flag'
,STS_DESC
,LTR_CD
,LTR_DESC
,LTR_DT_SENT
,PLCY_NBR
,PLCY_EFF_DT
,PLCY_EXPR_DT
,PLCY_TERM
,PREM_AMT
,CMPNY_NM
,BUS_PROC_DT
--,CAST(CAST(B.LOAN_NBR AS INT) AS NVARCHAR) + [CVR_TYPE] AS 'Loan_Key'
--,ROW_NUMBER () over (partition by LOAN_NBR order by bus_proc_dt desc) rn 

INTO #BASE
FROM #ASGN A
LEFT JOIN (SELECT * FROM reverse_dw.[dbo].[TP_SWBC_INS_RET] WHERE PLCY_EXPR_DT IS NOT NULL AND DATEDIFF(day,CAST(GETDATE() AS DATE),CAST(PLCY_EXPR_DT AS DATE)) > 0
AND BUS_PROC_DT = (SELECT MAX(BUS_PROC_DT) FROM reverse_dw.[dbo].[TP_SWBC_INS_RET])) B
ON A.LOAN_NBR = CAST(B.Loan_Nbr AS INT)

order by LOAN_NBR desc

--Action Scrub--
SELECT Distinct A.Loan_Nbr,A.MCA_PCT,
CASE WHEN A.MCA_PCT < 97.5 THEN '< 97.5'
WHEN A.MCA_PCT < 100 THEN '>= 97.5'
ELSE '>= 100'
END AS 'MCA Flag'
,A.WorkFlag,HUD_STS_DESC,A.[RG Flag],A.[Submit Flag],FNL_RVW_ASGN_TO_NM,HUD_ASGN_TO_NM
,CASE
	WHEN A.[Submit Flag] IS NOT NULL AND B.Policy_Type IS NOT NULL THEN 'Submitted to HUD - Close Timeline - Open Haz'
	WHEN FPI_Doc_Desc IS NULL AND B.Policy_Type IS NOT NULL THEN 'Open Haz'
	WHEN FPI_Doc_Desc IS NOT NULL AND B.Policy_Type IS NOT NULL THEN 'FPI'
	WHEN FPI_Doc_Desc IS NOT NULL AND E.Policy_Type IS NOT NULL THEN 'Close Haz'
	WHEN Flood_Doc_Desc IS NOT NULL AND J.Policy_Type IS NOT NULL THEN 'Company Missing - Check for FPI'
	--ElSE 'No Action Required'
	END AS 'Haz_Action'

,B.PLCY_EFF_DT AS 'HAZ_FPI_EFF'
,Case
	WHEN A.[Submit Flag] IS NOT NULL AND  C.Policy_Type IS NOT NULL THEN 'Submitted to HUD - Close Timeline - Open Flood'
	WHEN Flood_Doc_Desc IS NULL AND C.Policy_Type IS NOT NULL THEN 'Open Flood'
	WHEN Flood_Doc_Desc IS NOT NULL AND C.Policy_Type IS NOT NULL THEN 'FPI'
	WHEN Flood_Doc_Desc IS NOT NULL AND F.Policy_Type IS NOT NULL THEN 'Close Flood'
	WHEN Flood_Doc_Desc IS NOT NULL AND C.Policy_Type IS NULL AND F.Policy_Type IS NULL THEN ('Check Flood Gap')
	WHEN Flood_Doc_Desc IS NOT NULL AND K.Policy_Type IS NOT NULL THEN 'Company Missing - Check for FPI'
	--ElSE 'No Action Required'
	END AS 'Flood Action'
,C.PLCY_EFF_DT AS 'Flood_FPI_EFF'
,Case
	WHEN A.[Submit Flag] IS NOT NULL AND  D.Policy_Type IS NOT NULL THEN 'Submitted to HUD - Close Timeline - Open Condo'
	WHEN Condo_Doc_Desc IS NULL AND D.Policy_Type IS NOT NULL THEN 'Open Condo'
	WHEN Condo_Doc_Desc IS NOT NULL AND D.Policy_Type IS NOT NULL THEN 'FPI'
	WHEN Condo_Doc_Desc IS NOT NULL AND G.Policy_Type IS NOT NULL THEN 'Close Condo'
	WHEN Condo_Doc_Desc IS NOT NULL AND L.Policy_Type IS NOT NULL THEN 'Company Missing - Check for FPI'
	--ElSE 'No Action Required'
	END AS 'Condo Action'
,D.PLCY_EFF_DT AS 'Condo_FPI_EFF'
,H.FPI_Flag
,I.Excp_Flag
INTO #BASE2
FROM #BASE A
LEFT JOIN (Select Loan_Nbr,Policy_Type,PLCY_EFF_DT FROM #BASE WHERE ISNULL(CMPNY_NM,'No Cmpny') IN ('FP POL') AND Excp_Flag IN ('Haz')) B
	ON A.LOAN_NBR = B.Loan_Nbr
LEFT JOIN (Select Loan_Nbr,Policy_Type,PLCY_EFF_DT FROM #BASE WHERE ISNULL(CMPNY_NM,'No Cmpny') IN ('FP POL') AND Excp_Flag IN ('Flood')) C
	ON A.LOAN_NBR = C.Loan_Nbr
LEFT JOIN (Select Loan_Nbr,Policy_Type,PLCY_EFF_DT FROM #BASE WHERE ISNULL(CMPNY_NM,'No Cmpny') IN ('FP POL') AND Excp_Flag IN ('Condo')) D
	ON A.LOAN_NBR = D.Loan_Nbr
LEFT JOIN (Select Loan_Nbr,Policy_Type,PLCY_EFF_DT FROM #BASE WHERE ISNULL(CMPNY_NM,'No Cmpny') NOT IN ('FP POL','No Cmpny') AND Excp_Flag IN ('Haz')) E
	ON A.LOAN_NBR = E.Loan_Nbr
LEFT JOIN (Select Loan_Nbr,Policy_Type,PLCY_EFF_DT FROM #BASE WHERE ISNULL(CMPNY_NM,'No Cmpny') Not IN ('FP POL','No Cmpny') AND Excp_Flag IN ('Flood')) F
	ON A.LOAN_NBR = F.Loan_Nbr
LEFT JOIN (Select Loan_Nbr,Policy_Type,PLCY_EFF_DT FROM #BASE WHERE ISNULL(CMPNY_NM,'No Cmpny') Not IN ('FP POL','No Cmpny') AND Excp_Flag IN ('Condo')) G
	ON A.LOAN_NBR = G.Loan_Nbr
LEFT JOIN (SELECT Loan_Nbr,'FPI' AS 'FPI_Flag' FROM #BASE WHERE CMPNY_NM IN ('FP POL')) H
	ON A.LOAN_NBR = H.Loan_Nbr
LEFT JOIN (SELECT Loan_Nbr,'Open_FPI_Excp' AS 'Excp_Flag' FROM Reverse_DW.[dbo].[HUD_ASGN_EXCP_EDW] WHERE CURR_IND IN ('Y') AND [ISSU_DESC] IN ('Forced Placed Insurance') AND [EXCP_STS_DESC] NOT IN ('RESOLVED','CLOSED','NOT VALID','CLOSED WITH VENDOR')) I
	ON A.Loan_Nbr = I.Loan_Nbr 
LEFT JOIN (Select Loan_Nbr,Policy_Type,PLCY_EFF_DT FROM #BASE WHERE ISNULL(CMPNY_NM,'No Cmpny') IN ('No Cmpny') AND Excp_Flag IN ('Haz')) J
	ON A.LOAN_NBR = J.Loan_Nbr
LEFT JOIN (Select Loan_Nbr,Policy_Type,PLCY_EFF_DT FROM #BASE WHERE ISNULL(CMPNY_NM,'No Cmpny') IN ('No Cmpny') AND Excp_Flag IN ('Flood')) K
	ON A.LOAN_NBR = K.Loan_Nbr
LEFT JOIN (Select Loan_Nbr,Policy_Type,PLCY_EFF_DT FROM #BASE WHERE ISNULL(CMPNY_NM,'No Cmpny') IN ('No Cmpny') AND Excp_Flag IN ('Condo')) L
	ON A.LOAN_NBR = L.Loan_Nbr
--Final--
SELECT Distinct Loan_Nbr,MCA_PCT,
CASE WHEN MCA_PCT < 97.5 THEN '< 97.5'
WHEN MCA_PCT < 100 THEN '>= 97.5'
ELSE '>= 100'
END AS 'MCA Flag'
,WorkFlag,HUD_STS_DESC,[RG Flag],FNL_RVW_ASGN_TO_NM,HUD_ASGN_TO_NM
,CASE
WHEN FPI_Flag IS NOT NULL AND Excp_Flag IS NOT NULL THEN 'FPI'
WHEN Haz_Action IN ('Open Haz') THEN Haz_Action
WHEN [Flood Action] IN ('Open Flood') THEN [Flood Action]
WHEN [Condo Action] IN ('Open Condo') THEN [Condo Action]
WHEN Haz_Action IS NOT NULL THEN Haz_Action
WHEN [Flood Action] IS NOT NULL THEN [Flood Action]
WHEN [Condo Action] IS NOT NULL THEN [Condo Action]
WHEN FPI_Flag IS NULL AND Excp_Flag IS NOT NULL THEN 'Check Exception'
--WHEN FNL_RVW_ASGN_TO_NM IN ('Robert Gough') AND HUD_ASGN_TO_NM IN ('Robert Gough') THEN 'Exception Already Closed'
ELSE 'Exception Already Closed - Move from RG'
END AS 'Excp_Flag'
,GETDATE() AS 'Refreshed'

FROM #BASE2
WHERE (Haz_Action IS NOT NULL OR [Flood Action] IS NOT NULL OR [Condo Action] IS NOT NULL) --AND (Haz_Action NOT IN ('FPI') AND [Flood Action] NOT IN ('FPI') AND [Condo Action] NOT IN ('FPI'))
OR (Haz_Action IS NULL AND [Flood Action] IS NULL AND [Condo Action] IS NULL AND (FNL_RVW_ASGN_TO_NM IN ('Robert Gough') OR HUD_ASGN_TO_NM IN ('Robert Gough')))
ORDER BY WorkFlag,Excp_Flag
DROP TABLE #BASE,#ASGN,#BASE2