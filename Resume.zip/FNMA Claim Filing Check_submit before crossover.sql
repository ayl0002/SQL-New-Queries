SELECT
a.[loan number]
,a.[pool name]
,a.[loan status]
,a.[mca %]
,p.[submit date]
,m.MCA_CROSSOVER_DT
,case when a.[pool name] in ('EBOUTIQUE-FNMA-CHAMPION','WELLSFARG') AND 
m.MCA_CROSSOVER_DT < p.[Submit Date] then 'Approval required'
ELSE 'Not Required'
end as 'FNMA Required?'

FROM SHAREPOINTDATA.DBO.HUDASSIGNLOANS A
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNHUDSTATUS C
ON A.[LOAN NUMBER]=C.[LOAN NUMBER]
 left join [VRSQLRODS\RODS_PROD].reverse_dw.[dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] m
 on a.[Loan Number]=m.loan_nbr
 left join (select p.LoanNumber, max(p.DateSubmittedToHUD) as 'Submit Date' from [SharepointData].[dbo].[HUDAssignDateSubmittedResubmittedtoHUD] P group by p.[LoanNumber]) p
on p.LoanNumber = a.[Loan Number]

WHERE a.[loan number] in ('1154668')