SET NOCOUNT ON
--Roll Ins--

select base.*, case when [Curative Count] is not null then 'Y' else 'N' end as 'In Curative', [FR Agent], case when [fp count] is not null then 'Y' else 'N' end as 'Has FPI'
, case when [ld count] is not null then 'Y' else 'N' end as 'Has Loss Draft',
[Tax Close Date], [OCC Close Date], [HOA Close Date], [Hazard Close Date]
INTO #RollIn1
 from
(select * from Tact_Rev.dbo.billdashaccrual
where mca_percent < 97.5 and [next month mca] >= 97.5 and status_code = 0
and [Tag_2_Val] is null and [Incurable Flag] = '0' and ([group] is null or [Group] <> 'Grp 5 BofA GNMAs')) base
left join
(select [loan number], count(*) as [curative count] from sharepointdata.dbo.HUDAssignBackupExceptions where [Work Group] in ('Curative', 'LandTran')
and [Exception Status] not in ('Resolved', 'Incurable', 'Not Valid', 'Cancelled', 'Closed with Vendor', 'canceled')

group by [loan number]) ccur on cast(base.loan_nbr as varchar)=ccur.[loan number]
left join
(select [loan number], [Final Review Assigned To] as 'FR Agent' from sharepointdata.[dbo].[HUDAssignFinalReview]) fr on cast(base.loan_nbr as varchar)=fr.[loan number]
left join
(select [loan number], count(*) as 'FP Count' from sharepointdata.[dbo].[HUDAssignExceptions] where [issue] like '%forced placed%'
and [exception status] not in ('Resolved', 'Not Valid', 'Closed by Vendor', 'Incurable') group by [loan number]) fpi on cast(base.loan_nbr as varchar)=fpi.[loan number]
left join
(select [loan number], count(*) as 'LD Count' from sharepointdata.[dbo].[HUDAssignExceptions] where [document] like '%draft%'
and [exception status] not in ('Resolved', 'Not Valid', 'Closed by Vendor', 'Incurable') group by [loan number]) ld on cast(base.loan_nbr as varchar)=ld.[loan number]
left join
(select * from Tact_Rev.dbo.lastexceptionclose) lec on base.loan_nbr=lec.loan_nbr
order by [fp count] desc

SELECT loan_nbr,mca_percent,[Next Month MCA] AS 'Roll In MCA%'
INTO #RollIn2
FROM #RollIn1


--Active Scrub--	
SELECT CAST(A.LOAN_NBR AS NVARCHAR) AS 'Loan_Nbr',CAST(A.[MCA_PERCENT] AS FLOAT(2)) AS 'MCA%',CAST(E.[Roll In MCA%] AS FLOAT(2)) AS 'Roll In MCA%',A.[NET_LINE_OF_CREDIT]
,CASE
	WHEN A.[Prop_State] IN ('AR',	'AZ',	'CA',	'GA',	'HI',	'IA',	'ID',	'IL',	'IN',	'KS',	'KY',	'LA',	'ME',	'MI',	'MN',	'MT',	'NC',	'ND',	'NE',	'NM',	'NY',	'OH',	'OK',	'SC',	'SD',	'TX',	'UT',	'VA',	'WI',	'WY') THEN 'Junior'
	WHEN A.[Prop_State] IN ('PR') THEN 'PR'
	WHEN A.[Prop_State] IN ('AK',	'AL',	'CO',	'CT',	'DC',	'DE',	'FL',	'MA',	'MD',	'MO',	'MS',	'NH',	'NJ',	'NV',	'OR',	'PA',	'RI',	'TN',	'VT',	'WA',	'WV') THEN 'Senior'
ELSE 'Error'
END AS 'Lien_Flag'
,CASE
	WHEN A.[MCA_PERCENT] >= 105 THEN '105+'	
	WHEN A.[MCA_PERCENT] BETWEEN 100 AND 104.99 THEN '100 to 104.99'	
	WHEN A.[MCA_PERCENT] BETWEEN 98 AND 99.99 THEN '98 to 99.99'
	WHEN A.[MCA_PERCENT] BETWEEN 97.5 AND 97.99 THEN '97.5 to 97.99'
	WHEN A.[MCA_PERCENT] < 97.5 AND E.[Roll In MCA%] IS NOT NULL THEN ('Roll In - Next Month')
ELSE '< 97.5'
END AS 'MCA Flag'
,A.[LOAN_STATUS],B.[Group],A.[POOL_NAME],B.[Tag 2],B.[Incurable Flag],C.[HUD Status],D.[Final Review Status]

--CASE STATEMENT TO SORT OUT PHANTOM LOANS NOT IN I-ASSIGN--
,CASE
	WHEN C.[HUD Assigned To] IS NULL AND C.[HUD Status] IN ('New File','Not Started') AND D.[Final Review Assigned To] IN ('Robert Gough') THEN D.[Final Review Assigned To]
	ELSE C.[HUD Assigned To]
END AS 'HUD Assigned To'
--CASE STATEMENT TO SORT OUT PHANTOM LOANS NOT IN I-ASSIGN--

,D.[Final Review Assigned To]
,CASE
	WHEN C.[HUD Status] IN ('New File','Not Started') THEN D.[Final Review Assigned To]
	ELSE C.[HUD Assigned To]
	END AS 'Agent'
INTO #Active
FROM SharepointData.Dbo.HUDAssignLoans B
LEFT JOIN [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] A
	ON Cast(A.Loan_Nbr AS NVARCHAR) = B.[Loan Number]
LEFT JOIN SharepointData.Dbo.HUDAssignHUDStatus C
	ON Cast(A.Loan_Nbr AS NVARCHAR) = C.[Loan Number]
Left JOIN SharepointData.[dbo].[HUDAssignFinalReview] D
	ON Cast(A.Loan_Nbr AS NVARCHAR) = D.[Loan Number]
LEFT JOIN #RollIn2 E
	ON Cast(A.Loan_Nbr AS NVARCHAR) = E.[Loan_Nbr]
WHERE (A.[MCA_PERCENT] >=97.5 OR (A.[MCA_PERCENT] <97.5 AND [Roll In MCA%] IS NOT NULL)) AND A.[LOAN_STATUS] IN ('Active') AND B.[Incurable Flag] IN ('0') AND B.[Tag 2] IS NULL AND ISNULL(B.[Group],'NoGroup') NOT IN ('Grp 5 BofA GNMAs') AND C.[HUD Status] IN ('HUD Denied','New File','Not Started')

--Agent Scrub--
SELECT A.*,	MGR_NM,	ST_LOC,	GRP_NM
,CASE 
	WHEN A.Agent IN ('Shasta Patton') THEN 'Assignable-ARM Loan'
	WHEN A.Agent IN ('Robert Gough') THEN 'Assignable-FPI'
	WHEN A.Agent IN ('Chelsea Daniel') THEN 'Assignable-Loss Draft'
	WHEN A.Agent IN ('Shelby Dominguez') THEN 'Assignable-Repays'
	WHEN A.Agent IN ('Norse Lockhart') THEN 'Assignable-Active Lit'
	ELSE NULL
END AS 'ASGN_Pipeline'
INTO #AGENT
FROM #Active A 
LEFT JOIN [VRSQLRODS\RODS_PROD].reverse_dw.dbo.TP_HUD_RSTR B
ON A.Agent = B.[AGNT_NM]

--Closed HOA Scrub--
SELECT [Loan Number],[Exception ID],'Closed HOA' AS 'Tier 1A Scrub'--,[Document],[Exception Status],DATEDIFF(Day,CAST(GETDATE() AS DATE),CAST([Exception Status Date] AS DATE)),CAST([Exception Status Date] AS DATE) 
INTO #HOAScrub
FROM SharepointData.Dbo.HUDAssignExceptions
WHERE [Exception Status] IN ('RESOLVED') AND [DOCUMENT] IN ('HOA') AND DATEDIFF(Day,CAST([Exception Status Date] AS DATE),CAST(GETDATE() AS DATE)) <= 30

--Curative Scrub--
SELECT [Loan Number],[Exception ID],Row_Number () OVER (Partition By [Loan Number] ORDER BY [Exception ID]) AS 'Cura_Count','Open Curative' AS 'Cura_Flag'
INTO #Cura_Count
FROM SharepointData.Dbo.HUDAssignExceptions
WHERE [Work Group] IN ('Curative','LandTran') AND [Exception Status] NOT IN ('INCURABLE','CLOSED','RESOLVED','NOT VALID','CLOSED WITH VENDOR')

--HACG Scrub--
SELECT [Loan Number],[Exception ID],Row_Number () OVER (Partition By [Loan Number] ORDER BY [Exception ID]) AS 'HACG_Count'
INTO #HACG_Count
FROM SharepointData.Dbo.HUDAssignExceptions
WHERE [Work Group] IN ('HACG') AND [Exception Status] NOT IN ('INCURABLE','CLOSED','RESOLVED','NOT VALID','CLOSED WITH VENDOR')

--Exception Count--
SELECT [Loan Number],[Exception ID],Row_Number () OVER (Partition By [Loan Number] ORDER BY [Exception ID]) AS 'Excp_Count'
,CASE
	WHEN [Document] IN ('Tax Bill') AND [Issue] IN ('Delinquent') THEN '3'
	WHEN [Document] IN ('HOA') AND [Issue] IN ('Delinquent') THEN '2'
	WHEN [Document] IN ('MIC') THEN '1'
ELSE NULL
END AS 'Excp_Asgn_Flag'
INTO #Excp_Count
FROM SharepointData.Dbo.HUDAssignExceptions
WHERE [Exception Status] NOT IN ('INCURABLE','CLOSED','RESOLVED','NOT VALID','CLOSED WITH VENDOR')

--Exception Level--
SELECT DISTINCT A.[Loan_Nbr],GETDATE() AS 'Refreshed',CAST(A.[MCA%] AS FLOAT(2)) AS 'MCA%', A.[MCA Flag], A.[Roll In MCA%],		A.[LOAN_STATUS],	A.[Group],	A.[POOL_NAME],	A.[Tag 2],	A.[Incurable Flag],	A.[HUD Status],A.[Final Review Status],A.[HUD Assigned To],	A.[Final Review Assigned To],	A.[Agent],	A.[MGR_NM],	A.[ST_LOC],	A.[GRP_NM],B.[Exception ID],B.[Document],B.[Exception Status],B.[Issue],[Tier 1A Scrub],B.[Exception Description],B.[Work Group],CAST(B.[Exception Request Date] AS DATE) AS 'Excp_Request_Dt',B.[Exception Assigned To]
,Cast(B.[Exception Status Date] AS Date) AS 'Excp_Sts_Dt',Cura_Flag,ASGN_Pipeline,Excp_Asgn_Flag
,ISNULL(C.Cura_Count,0) AS 'Cura_Count',ISNULL(D.HACG_Count,0) AS 'HACG_Count',ISNULL(F.Excp_Count,0) AS 'Excp_Count'
,CAST(A.[NET_LINE_OF_CREDIT] AS FLOAT(2)) AS 'LOC',Lien_Flag
,CASE
	WHEN Cura_Flag IS NOT NULL THEN Cura_Flag
	WHEN ASGN_Pipeline IS NOT NULL THEN ASGN_Pipeline
	WHEN Excp_Asgn_Flag IS NOT NULL THEN Excp_Asgn_Flag
	WHEN [Tier 1A Scrub] IS NOT NULL AND A.Agent IS NOT NULL AND ISNULL(F.Excp_Count,0) >= 1 THEN 'Assignable - HOA Expiring'
	WHEN (ASGN_Pipeline  IS NULL AND Excp_Asgn_Flag IS NULL) AND A.Agent IS NULL THEN 'New File'
	WHEN (ASGN_Pipeline  IS NULL AND Excp_Asgn_Flag IS NULL) AND A.Agent IS NOT NULL THEN 'Assignable'
ELSE 'Error'
END AS'Asgn_Flag'
INTO #Exceptions
FROM #AGENT A 
LEFT JOIN --SharepointData.Dbo.HUDAssignExceptions B
(SELECT * FROM SharepointData.Dbo.HudAssignExceptions WHERE [Exception Status] NOT IN ('INCURABLE','CLOSED','RESOLVED','NOT VALID','CLOSED WITH VENDOR'))B
	ON A.Loan_Nbr = CAST(B.[Loan Number] AS NVARCHAR)
LEFT JOIN (SELECT [Loan Number],MAX(Cura_Count) AS 'Cura_Count' FROM #Cura_Count GROUP BY [Loan Number]) C
	ON A.Loan_Nbr = C.[Loan Number]
LEFT JOIN (SELECT [Loan Number],MAX(HACG_Count) AS 'HACG_Count' FROM #HACG_Count GROUP BY [Loan Number]) D
	ON A.Loan_Nbr = D.[Loan Number]
LEFT JOIN (SELECT [Loan Number],MAX(Excp_Count) AS 'Excp_Count' FROM #Excp_Count GROUP BY [Loan Number]) F
	ON A.Loan_Nbr =F.[Loan Number]
LEFT JOIN (SELECT A.[Loan Number],A.Excp_Asgn_Flag FROM #Excp_Count A 
	LEFT JOIN (SELECT [Loan Number],MAX(ISNULL([Excp_Asgn_Flag],'0')) AS 'Excp_Asgn_Flag' FROM #Excp_Count GROUP BY [Loan Number]) I
	ON A.[Loan Number] = I.[Loan Number]
	WHERE A.[Loan Number] = I.[Loan Number] AND A.Excp_Asgn_Flag = I.Excp_Asgn_Flag AND A.Excp_Asgn_Flag IS NOT NULL ) E
ON A.[Loan_Nbr] = E.[Loan Number]
LEFT JOIN (SELECT [Loan Number],Cura_Flag FROM #Cura_Count WHERE Cura_Flag IS NOT NULL) G
	ON A.Loan_Nbr = G.[Loan Number]
LEFT JOIN #HOAScrub H
	ON A.Loan_Nbr = H.[Loan Number]

--WHERE  OR (B.[Exception ID] IS NULL) -- F.Excp_Count in ('0') AND )

--Tier Scrub Exception Level--
SELECT A.*
,CASE 
	WHEN [MCA Flag] IN ('Roll In - Next Month') THEN 'Roll In - Next Month'
	WHEN Asgn_Flag IN ('1') THEN 'Assignable - Open MIC'
	WHEN Asgn_Flag IN ('2') THEN 'Assignable - Delinquent HOA'
	WHEN Asgn_Flag IN ('3') THEN 'Assignable - Delinquent Tax'
	ELSE Asgn_Flag
END AS 'Assignable'
,CASE
	WHEN [MCA Flag] IN ('Roll In - Next Month') AND [Tier 1A Scrub] IS NOT NULL AND Excp_Count = 0 THEN 'Roll In - Tier 1A'
	WHEN [MCA Flag] IN ('Roll In - Next Month') AND [Tier 1A Scrub] IS NULL AND Excp_Count = 0 THEN 'Roll In - Tier 1'
	WHEN [MCA Flag] IN ('Roll In - Next Month') AND Asgn_Flag IN ('2') AND Lien_Flag IN ('Senior') AND A.[LOC] <= 300 THEN 'Roll In - Tier 3 - HOA'
	WHEN [MCA Flag] IN ('Roll In - Next Month') AND Asgn_Flag IN('3') AND A.[LOC] <= 300 THEN 'Roll In - Tier 3 - Tax'
	WHEN [MCA Flag] IN ('Roll In - Next Month') AND  Excp_Count > 0 THEN 'Roll In - Tier 2'
	WHEN Asgn_Flag IN ('2') AND Lien_Flag IN ('Senior') AND A.[LOC] <= 300 THEN 'Tier 3 - HOA'
	WHEN Asgn_Flag IN('3') AND A.[LOC] <= 300 THEN 'Tier 3 - Tax'
	WHEN Excp_Count = 0 AND [Tier 1A Scrub] IS NOT NULL THEN ('Tier 1A')
	WHEN Excp_Count = 0 THEN ('Tier 1')
	WHEN Agent IN ('Billy Moore') AND Asgn_Flag IN ('1') THEN 'Tier 2 - TS Review'
	WHEN ISNULL(Excp_Count,0) >=1 AND [Tier 1A Scrub] IS NOT NULL THEN ('Tier 2 - HOA Expiring')
	WHEN ISNULL(Excp_Count,0) >=1 AND [Tier 1A Scrub] IS NULL THEN ('Tier 2')
ELSE 'Error'
END AS 'Tier'
INTO #Tier	
FROM #Exceptions A	



--Loan Level--

SELECT DISTINCT A.[Loan_Nbr],	A.[Refreshed],	CAST(A.[MCA%] AS FLOAT(2)) AS 'MCA%',	A.[MCA Flag], A.[Roll In MCA%],	A.[LOAN_STATUS],	A.[Group],	A.[POOL_NAME],	A.[Tag 2],	A.[Incurable Flag],	A.[HUD Status],A.[Final Review Status],A.[HUD Assigned To],	A.[Final Review Assigned To],	A.[Agent],	A.[MGR_NM],	A.[ST_LOC],	A.[GRP_NM],	A.[Cura_Flag],	A.[ASGN_Pipeline],	A.[Excp_Asgn_Flag],	A.[Cura_Count],	A.[HACG_Count],	A.[Excp_Count],[LOC],Lien_Flag,A.[Tier 1A Scrub],A.[Assignable],A.Tier

FROM #Tier A

ORDER BY A.Tier,A.[Assignable],Excp_Count ASC,[MCA%] DESC
DROP TABLE  #ACTIVE,#AGENT,#HACG_Count,#Cura_Count,#Excp_Count,#RollIn1,#RollIn2,#HOAScrub,#Exceptions,#Tier--,,#BASE