CREATE TABLE #DateTrack 
(Loan_Nbr INT,
Date_Flagged DATE)

INSERT INTO #DateTrack

VALUES
('1034811',	'2020-05-13'),
('1042041',	'2020-06-11'),
('2711992',	'2020-05-18'),
('755935',	'2020-06-11'),
('867282',	'2020-06-11'),
('2724806',	'2020-06-11'),
('2105512',	'2020-06-11'),
('871713',	'2019-08-14'),
('2728991',	'2020-06-11'),
('1151691',	'2019-11-25'),
('1150682',	'2020-01-03'),
('1154475',	'2020-04-07'),
('1152211',	'2020-04-07'),
('1154511',	'2020-05-13'),
('872072',	'2020-06-11'),
('1151200',	'2020-05-13'),
('1153831',	'2020-06-04'),
('758439',	'2020-06-04'),
('1154221',	'2020-06-04'),
('1150297',	'2020-06-04'),
('858856',	'2020-06-04'),
('2426758',	'2020-06-11')


SELECT A.[Loan Number]
,getdate() AS [Last Refreshed]
,isnull(Date_Flagged,CAST(GETDATE() AS DATE)) AS [Date Flagged]
,DATEDIFF(DAY,isnull(Date_Flagged,CAST(GETDATE() AS DATE)),GETDATE()) AS 'Aging'
,CAST(A.[MCA %] AS FLOAT(2)) AS 'MCA %'
,CASE
WHEN A.[MCA %] BETWEEN 90 AND 92.49 THEN '90 < 92.5'
WHEN A.[MCA %] BETWEEN 92.5 AND 94.99 THEN '92.5 < 95'
WHEN A.[MCA %] BETWEEN 95 AND 97.49 THEN '95 < 97.5'
WHEN A.[MCA %] BETWEEN 97.5 AND 99.99 THEN '97.5 < 100'
WHEN A.[MCA %] >= 100 THEN '>= 100'
ELSE '< 100'
END AS 'MCA Flag'
,A.[Loan Status],A.[Stage],A.[Tag 2]
,A.[Incurable Flag]
,CASE 
WHEN I.[OpenCurative] = 1 THEN CAST(CAST(I.[OpenCurative] AS INT) AS NVARCHAR(MAX)) + ' Curative Exception' 
ELSE CAST(CAST(I.[OpenCurative] AS INT) AS NVARCHAR(MAX)) + ' Curative Exceptions' 
END AS 'Open Curative'
,CAST(I.[OpenHACG] AS INT) AS 'Open HACG',CAST(I.[Open Exceptions] AS INT) AS 'Open Exceptions'
,[Initial Review Status],[Initial Review Start Date],A.[Initial Review End Date]
,[HUD Status Start Date],[Initial Review Collateral Start Date],[Initial Review Collateral End Date],[Initial Review Collateral Stage Update By]
,[Initial Review Compliance Start Date],[Initial Review Compliance End Date],[Initial Review Compliance Stage Update By]
,[Initial Review Servicing Start Date],[Initial Review Servicing End Date],[Initial Review Servicing Stage Update By]
FROM SharepointData.Dbo.HUDAssignLoans A
LEFT JOIN SharepointData.[dbo].[HUDAssignInitialReview] B	
ON A.[Loan Number] = B.[Loan Number]
LEFT JOIN SharepointData.Dbo.HUDAssignHUDStatus C
ON A.[Loan Number] = C.[Loan Number]
LEFT JOIN (SELECT LOAN_NBR,DT_SBMT_TO_HUD FROM [VRSQLRODS\RODS_PROD].Reverse_DW.Dbo.HUD_ASSGN_DT_SBMT_RESBMT WHERE CURR_IND IN ('Y')) D
On A.[Loan Number] = D.[Loan_Nbr]
LEFT JOIN SharepointData.[dbo].[HUDAssignInitialReviewServicing] E
ON A.[Loan Number] = E.[Loan Number]
LEFT JOIN SharepointData.[dbo].[HUDAssignInitialReviewCollateral] F
ON A.[Loan Number] = F.[Loan Number]
LEFT JOIN SharepointData.[dbo].[HUDAssignInitialReviewCompliance] G
ON A.[Loan Number] = g.[Loan Number]
LEFT JOIN SharepointData.Dbo.[HUDAssignDocPooling] H
ON A.[Loan Number] = H.[Loan Number]
Left JOIN SharepointData.Dbo.HUDAssignLoanExceptionTotals I
ON A.[Loan Number] = I.[Loan Number]
LEFT JOIN #DateTrack DT
ON A.[Loan Number] = DT.[Loan_Nbr]
WHERE A.[MCA %] >= 90.0 AND A.[Loan Status] IN ('Active') AND A.[TAG 2] IS NULL AND A.[Incurable Flag] IN ('0') AND (A.[GROUP] NOT IN ('Grp 5 BofA GNMAs') OR A.[GROUP] IS NULL) AND ISNULL(A.[Stage],'No Stage') IN ('Initial Review','No Stage','Doc Pooling')
ORDER BY [MCA %] DESC

DROP TABLE #DateTrack