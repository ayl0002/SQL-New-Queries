--Roll Ins--
select base.*, case when [Curative Count] is not null then 'Y' else 'N' end as 'In Curative', [FR Agent], case when [fp count] is not null then 'Y' else 'N' end as 'Has FPI'
, case when [ld count] is not null then 'Y' else 'N' end as 'Has Loss Draft',
[Tax Close Date], [OCC Close Date], [HOA Close Date], [Hazard Close Date]
INTO #RollIn1
 from
(select * from Tact_Rev.dbo.billdashaccrual
where mca_percent < 97.5 and [2 Month MCA] >= 97.5 and status_code = 0
and [Tag_2_Val] is null and [Incurable Flag] = '0' and ([group] is null or [Group] <> 'Grp 5 BofA GNMAs')) base
left join
(select [loan number], count(*) as [curative count] from sharepointdata.dbo.HUDAssignBackupExceptions where [Work Group] in ('Curative', 'LandTran')
and [Exception Status] not in ('Resolved', 'Incurable', 'Not Valid', 'Cancelled', 'Closed with Vendor', 'canceled')

group by [loan number]) ccur on cast(base.loan_nbr as varchar)=ccur.[loan number]
left join
(select [loan number], [Final Review Assigned To] as 'FR Agent' from sharepointdata.[dbo].[HUDAssignFinalReview]) fr on cast(base.loan_nbr as varchar)=fr.[loan number]
left join
(select [loan number], count(*) as 'FP Count' from sharepointdata.[dbo].[HUDAssignExceptions] where [issue] like '%forced placed%'
and [exception status] not in ('Resolved', 'Not Valid', 'Closed by Vendor', 'Incurable') group by [loan number]) fpi on cast(base.loan_nbr as varchar)=fpi.[loan number]
left join
(select [loan number], count(*) as 'LD Count' from sharepointdata.[dbo].[HUDAssignExceptions] where [document] like '%draft%'
and [exception status] not in ('Resolved', 'Not Valid', 'Closed by Vendor', 'Incurable') group by [loan number]) ld on cast(base.loan_nbr as varchar)=ld.[loan number]
left join
(select * from Tact_Rev.dbo.lastexceptionclose) lec on base.loan_nbr=lec.loan_nbr
order by [fp count] desc

--BASE--
SELECT D.Loan_Nbr,D.[MCA_PERCENT],D.Property_Type,[Next Month MCA],[2 Month MCA]
,CASE 
WHEN D.[MCA_PERCENT] >= 97.5 THEN CAST(GETDATE() AS DATE)
WHEN [Next Month MCA] >= 97.5 THEN CAST(DATEADD(MM,1,GETDATE()) AS DATE)
WHEN [2 Month MCA] >= 97.5 THEN CAST(DATEADD(MM,2,GETDATE()) AS DATE)
ELSE NULL
END AS 'Roll_In'

INTO #BASE
FROM SharepointData.DBO.HUDAssignLoans A
RIGHT JOIN [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] D
ON CAST(A.[Loan Number] AS VARCHAR) = CAST(D.LOAN_NBR AS VARCHAR)
LEFT JOIN SharepointData.Dbo.HUDAssignHUDStatus B
ON CAST(A.[Loan Number] AS VARCHAR) = CAST(B.[Loan Number] AS VARCHAR)
LEFT JOIN #RollIn1 E
ON CAST(A.[Loan Number] AS VARCHAR) = CAST(E.[Loan_Nbr] AS VARCHAR)

WHERE (D.[MCA_PERCENT] >= 97.5 OR [Next Month MCA] IS NOT NULL OR [2 Month MCA] IS NOT NULL) AND D.[LOAN_STATUS] IN ('Active') 
AND B.[HUD Status] NOT IN ('Pkg Submitted to HUD','Resubmitted to HUD','Rebuttal to HUD','HUD Approved','HUD Approval')
AND A.[Tag 2] IS NULL AND A.[Incurable Flag] IN ('0')
AND ISNULL(A.[GROUP],'No Group') NOT IN ('Grp 5 BofA GNMAs')

/*
SELECT Loan_Nbr,MAX(BUS_PROC_DT) AS 'BUS_PROC_DT'
INTO #MAX
FROM [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_SWBC_INS_RET]
GROUP BY Loan_Nbr

--SWBC MAX--
SELECT CAST(A.Loan_NBR AS INT) AS 'Loan_Number',A.Loan_Nbr,A.[CVR_TYPE],A.PLCY_NBR,	A.PLCY_EFF_DT,	A.PLCY_EXPR_DT,	A.PLCY_TERM,	A.AGNT_CD,	A.AGNT_NM,	A.AGNT_ADDR1,	A.AGNT_ADDR2,	A.AGNT_CITY,	A.AGNT_ST,	A.AGNT_ZIP,	A.CMPNY_NM,A.BUS_PROC_DT
INTO #MAXSWBC
FROM [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_SWBC_INS_RET] A
LEFT JOIN #MAX B 
ON B.Loan_Nbr = A.Loan_Nbr
WHERE A.BUS_PROC_DT = B.Bus_Proc_DT --AND CVR_TYPE IN ('F','W','1','G') 
*/

--MAX SWBC--
SELECT CAST(A.Loan_NBR AS INT) AS 'Loan_Number',A.Loan_Nbr,A.[CVR_TYPE],A.PLCY_NBR,	A.PLCY_EFF_DT,	A.PLCY_EXPR_DT,	A.PLCY_TERM,	A.AGNT_CD,	A.AGNT_NM,	A.AGNT_ADDR1,	A.AGNT_ADDR2,	A.AGNT_CITY,	A.AGNT_ST,	A.AGNT_ZIP,	A.CMPNY_NM,A.BUS_PROC_DT
INTO #MAXSWBC
FROM [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_SWBC_INS_RET] A
LEFT JOIN (SELECT Loan_Nbr AS 'Loan_NbrMax',MAX([Bus_Proc_DT]) AS 'Bus_Proc_DTMAX' FROM [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_SWBC_INS_RET] GROUP BY Loan_Nbr) B
ON B.Loan_NbrMAx = A.Loan_Nbr
WHERE A.BUS_PROC_DT = B.Bus_Proc_DTMAX --AND CVR_TYPE IN ('F','W','1','G') 


--MP Scrub--
SELECT [Loan Number],'HOA_Flag' AS 'HOA_Flag'
INTO #MP
FROM SharepointData.Dbo.HUDAssignExceptions
WHERE [Document] IN ('HOA') AND ISNULL([Exception Status],'NotStarted') NOT IN ('Not Valid','Incurable')

--FPI Scrub--
SELECT CAST(Loan_Nbr AS INT) AS 'Loan_Nbr','FPI' AS 'FPI',
CASE
		WHEN [CVR_TYPE] = 'F' THEN 'Fire(Hazard)'
        WHEN [CVR_TYPE] = 'W' THEN 'Flood'
        WHEN [CVR_TYPE] = 'A' THEN 'Wind'
        WHEN [CVR_TYPE] = 'G' THEN 'Flood Gap'
        WHEN [CVR_TYPE] = 'L' THEN 'Liability'
        WHEN [CVR_TYPE] = 'E' THEN 'Equipment'
        WHEN [CVR_TYPE] = 'Q' THEN 'Quake'
        WHEN [CVR_TYPE] = '1' THEN 'Condo'
        WHEN [CVR_TYPE] = '3' THEN 'Condo Flood Gap'
        WHEN [CVR_TYPE] = '4' THEN 'Condo w/Wind Supp'
        WHEN [CVR_TYPE] IS NULL THEN 'No Insurance'
ELSE 'Error'
END AS ' Policy_Type'
INTO #FPI
FROM #MAXSWBC 
WHERE CMPNY_NM IN ('FP POL')

--FINAL--
SELECT DISTINCT Loan_Number,CVR_TYPE,Property_Type,	
CASE
		WHEN CVR_TYPE IN ('F') AND HOA_Flag IS NOT NULL AND Property_Type IN ('Condo') THEN 'Master Policy'
		WHEN CVR_TYPE IN ('F') AND HOA_Flag IS NOT NULL THEN 'Open HOA - Probable MasterPolicy'
		WHEN [CVR_TYPE] = 'F' THEN 'Fire(Hazard)'
        WHEN [CVR_TYPE] = 'W' THEN 'Flood'
        WHEN [CVR_TYPE] = 'A' THEN 'Wind'
        WHEN [CVR_TYPE] = 'G' THEN 'Flood Gap'
        WHEN [CVR_TYPE] = 'L' THEN 'Liability'
        WHEN [CVR_TYPE] = 'E' THEN 'Equipment'
        WHEN [CVR_TYPE] = 'Q' THEN 'Quake'
        WHEN [CVR_TYPE] = '1' THEN 'Condo'
        WHEN [CVR_TYPE] = '3' THEN 'Condo Flood Gap'
        WHEN [CVR_TYPE] = '4' THEN 'Condo w/Wind Supp'
        WHEN [CVR_TYPE] IS NULL THEN 'No Insurance'
ELSE 'Error'
END AS ' Policy Type'
,CAST(DATEPART(mm,Roll_In) AS VARCHAR) +'/'+ CAST(DATEPART(YYYY,Roll_In)AS VARCHAR) AS 'Roll-In Month'
,CAST([MCA_PERCENT] AS FLOAT(2)) AS 'Curr_MCA',CAST([Next Month MCA] AS FLOAT(2)) AS 'Next Month MCA',CAST([2 Month MCA] AS FLOAT(2)) AS '2 Month MCA'
,PLCY_NBR,	PLCY_EFF_DT,	PLCY_EXPR_DT
,CASE 
		WHEN D.FPI IS NOT NULL THEN 'Forced Placed Insurance for ' + D.[ Policy_Type]
		WHEN CMPNY_NM IN ('FP POL') THEN 'Forced Placed Insurance'
		WHEN CAST(GETDATE() AS DATE) >= CAST(PLCY_EXPR_DT AS DATE) THEN 'Policy Expired'
		WHEN DATEDIFF(DAY,CAST(GETDATE() AS DATE),CAST(PLCY_EXPR_DT AS DATE)) <= 15 THEN 'Policy Expires <= 15 Days'
		WHEN DATEPART(mm,PLCY_EXPR_DT) = DATEPART(mm,Roll_In) AND DATEPART(YYYY,PLCY_EXPR_DT) = DATEPART(YYYY,Roll_In) THEN 'Expires in Roll-In'
		WHEN CMPNY_NM IS NOT NULL THEN 'Insured'

ELSE 'Error'
END AS 'Expire Flag'
,	PLCY_TERM,	AGNT_CD,	AGNT_NM,	AGNT_ADDR1,	AGNT_ADDR2,	AGNT_CITY,	AGNT_ST,	AGNT_ZIP,	CMPNY_NM
FROM #BASE A
LEFT JOIN #MAXSWBC B
ON A.LOAN_NBR = CAST(B.Loan_Nbr AS INT)
LEFT JOIN #MP C
ON A.LOAN_NBR = C.[Loan Number]
LEFT JOIN #FPI D
ON A.Loan_Nbr = D.Loan_Nbr
ORDER BY Loan_Number,CVR_TYPE

DROP TABLE #BASE,#MAXSWBC,#RollIn1,#MP,#FPI
