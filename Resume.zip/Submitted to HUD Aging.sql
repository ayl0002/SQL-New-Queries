SELECT A.[Loan Number],A.[Loan Status],A.[MCA %],CAST(C.[DT_TO_HUD] AS DATE) AS 'Submitted to HUD',B.[HUD Status],A.[Tag 2],A.[Incurable Flag],A.[Group],Cast(B.[HUD Preliminary Title Approval] AS DATE) AS 'HUD Preliminary Title Approval',B.[HUD Preliminary Title Denial],	Cast(B.[HUD Preliminary Title Denial Date] AS DATE) AS 'HUD Preliminary Title Denial Date'
,CASE
WHEN A.[MCA %] < 97.5 THEN '< 97.5'
WHEN A.[MCA %] < 98 THEN '97.5 < 98' 
WHEN A.[MCA %] >= 98 THEN '>= 98'
WHEN A.[MCA %] IS NULL THEN 'NULL'
ELSE 'Error'
END AS 'MCA Flag'
,CASE
WHEN DATEDIFF(DAY,CAST([DT_TO_HUD] AS DATE),CAST(GETDATE() AS DATE)) >= 60 THEN 'Over 60'
WHEN DATEDIFF(DAY,CAST([DT_TO_HUD] AS DATE),CAST(GETDATE() AS DATE)) >= 45 THEN 'Over 45'
WHEN DATEDIFF(DAY,CAST([DT_TO_HUD] AS DATE),CAST(GETDATE() AS DATE)) >= 30 THEN 'Over 30'
WHEN DATEDIFF(DAY,CAST([DT_TO_HUD] AS DATE),CAST(GETDATE() AS DATE)) >= 15 THEN 'Over 15'
WHEN DATEDIFF(DAY,CAST([DT_TO_HUD] AS DATE),CAST(GETDATE() AS DATE)) = 15 THEN '15'
ELSE 'Error'
End AS 'Submitted Aging'
FROM SharepointData.Dbo.HUDAssignLoans A
LEFT JOIN SharepointData.Dbo.HUDAssignHUDStatus B
ON A.[Loan Number] = B.[Loan Number]
--LEFT JOIN [VRSQLRODS\RODS_PROD].Reverse_DW.Dbo.HUD_ASsgn_dt_sbmt_Resbmt C
--ON C.[Loan_Nbr] = A.[Loan Number]
LEFT JOIN (Select Loan_Nbr,MAX([DT_SBMT_TO_HUD]) AS 'DT_TO_HUD' FROM [VRSQLRODS\RODS_PROD].Reverse_DW.Dbo.HUD_ASsgn_dt_sbmt_Resbmt WHERE Curr_IND IN ('Y') GROUP BY [Loan_Nbr]) C
ON C.[Loan_Nbr] = A.[Loan Number]
WHERE (DATEDIFF(Day,CAST([DT_TO_HUD] AS DATE),CAST(GETDAte() AS DAte)) > 14) AND A.[Loan Status] IN ('Active') AND B.[HUD Status] in ('Pkg Submitted to HUD','Resubmitted to HUD')
ORDER BY [DT_TO_HUD] ASC