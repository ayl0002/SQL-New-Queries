--YOUNGEST BORROWER WITH AGE TABLE--
SET NOCOUNT ON
SELECT b.MOD_LOAN_NBR[LOAN_NBR]
,c.borr_brth_dt
,c.borr_sex_cat
,c.BORR_DEATH_DT
,c.BORR_CLS_TYPE_CD
,ROW_NUMBER ()over (partition by b.MOD_LOAN_NBR order by c.borr_brth_dt desc) rn
into #base
FROM REVERSE_DW.dbo.RVRS_LOAN B 
JOIN Reverse_DW.dbo.BORR C 
on c.loan_key = b.loan_key and c.CURR_IND = 'Y'
where b.curr_ind = 'Y'
and c.BORR_DEATH_DT is null 
	
	--MAIN QUERY--
SELECT DISTINCT
t.MOD_LOAN_NBR
,p.FNMA_LOAN_NBR 
,m.LOAN_BAL_AMT 
,m.MAX_CLM_AMT 
,t.SRVC_IDNTY 
,p.MCA_CLAIM_DT  
,p.MCA_CROSSOVER_DT
,m.PPD_BAL_AMT as 'Total amt Repaid'
,p.CURRENT_TOTAL_UPB - p.MAX_CLAIM_AMOUNT as 'Total Amount over 100%'
,b.BORR_BRTH_DT as 'Youngest alive birth date'
,case
WHEN (b.borr_sex_cat) = '1' THEN 'M'
WHEN (B.BORR_SEX_CAT) = '2' THEN 'F'
END AS 'Gender'

FROM Reverse_DW.dbo.RVRS_LOAN T
LEFT JOIN Reverse_DW.dbo.RVRS_LOAN_BAL M
on M.LOAN_KEY = T.LOAN_KEY
LEFT JOIN Reverse_DW.dbo.RM_CHAMPION_MASTER_TBL_CURR_VW P
on T.LOAN_NBR = P.LOAN_NBR
LEFT JOIN #base B
ON B.LOAN_NBR = P.LOAN_NBR AND rn=1
WHERE p.STATUS_CODE IN ('0','72')AND t.curr_ind = 'Y' AND M.curr_ind = 'Y' 
DROP TABLE #BASE