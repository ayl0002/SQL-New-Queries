SELECT
E.[Loan Number]
,A.[Loan Status]
,c.[HUD Status]
,a.[MCA %]
 ,case 
	when a.[MCA %] between '97.50' and '97.99' then '97.5-97.99'
	when a.[MCA %] between '98.00' and '99.99' then '98.00-99.99'
	when a.[MCA %] >= '100.00' then '100+'
	else '<97.49'
	end as 'MCA Bucket'
,e.[Exception ID]
,E.[Document]
,E.[Issue]
,CAST(E.[Exception Request Date] AS DATE) AS 'Exception Request Date'
,case
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) <= 0  then '0 to 15'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 0 and 15 then '0 to 15'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 16 and 30 then '16 to 30'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 31 and 60 then '31 to 60'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 61 and 90 then '61 to 90'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 91 and 120 then '91 to 120'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) >= 121 then '121+'
	end as 'Exception Request Aging'
,E.[Exception Status]
,CAST(E.[Exception Status Date] AS DATE) AS 'Exception Status Date'
,A.[Property State]
,CASE
	WHEN A.[Property State] IN ('AR',	'AZ',	'CA',	'GA',	'HI',	'IA',	'ID',	'IL',	'IN',	'KS',	'KY',	'LA',	'ME',	'MI',	'MN',	'MT',	'NC',	'ND',	'NE',	'NM',	'NY',	'OH',	'OK',	'SC',	'SD',	'TX',	'UT',	'VA',	'WI','WY')
	THEN 'JUNIOR'
	WHEN A.[Property State] IN ('AK',	'AL',	'CO',	'CT',	'DC',	'DE',	'FL',	'MA',	'MD',	'MO',	'MS',	'NH',	'NJ',	'NV',	'OR',	'PA',	'RI',	'TN',	'VT',	'WA',	'WV')
	THEN 'SUPER'
	END AS 'LIEN'
--,CASE
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) <= 0  then '0 to 15'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 0 and 15 then '0 to 15'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 16 and 30 then '16 to 30'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 31 and 60 then '31 to 60'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 61 and 90 then '61 to 90'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 91 and 120 then '91 to 120'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) >= 121 then '121+'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) <= 0  then '0 to 15'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 0 and 15 then '0 to 15'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 16 and 30 then '16 to 30'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 31 and 60 then '31 to 60'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 61 and 90 then '61 to 90'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 91 and 120 then '91 to 120'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) >= 121 then '121+'
--	END AS 'Exception Status Aging'
,e.[Exception Assigned To]
,c.[hud assigned to]
,e.[Delinquent Amount]
,e.[Installment Frequency]
,CAST(e.[Due Date]AS DATE) AS 'DUE DATE'
,e.[Entity or County Name]
,e.[Contact Info]
,r.[MGR_NM]
,r.[ST_LOC]

FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignLoans A
ON E.[Loan Number]=A.[Loan Number]
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignFinalReview B
ON E.[Loan Number]=B.[Loan Number]
left join SharepointData.dbo.HUDAssignHUDStatus c
on a.[Loan Number]=c.[Loan Number]
LEFT JOIN SharepointData.DBO.HUDAssignLoanExceptionTotals T
ON A.[Loan Number]=T.[Loan Number]
left join [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_HUD_RSTR] r
on c.[hud assigned to]=r.[AGNT_NM]

WHERE E.[DOCUMENT] IN ('hoa') AND 
(e.[issue] in ('delinquent') or e.[Delinquent Amount] >= 1)and
--[ISSUE] IN ('Forced Placed Insurance')AND
E.[EXCEPTION STATUS] NOT IN ('RESOLVED','CANCELLED','NOT VALID','CLOSED','INCURABLE','closed with vendor') AND
A.[Tag 2] IS NULL AND
--T.OpenCurative IN ('0')AND
A.[Incurable Flag] IN ('0')AND
A.[Loan Status] IN ('active')AND
(a.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
a.[Group] is null)
