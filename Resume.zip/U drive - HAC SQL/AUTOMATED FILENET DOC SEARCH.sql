--SELECT 
--replace(ltrim(replace(fn.[U03D8_NSM_LOAN_NBR],'0',' ')),' ','0') as 'loan number'
--, CAST([CRE_DT] AS DATE) AS 'CRE_DT', '{' + Cast(obj_id as varchar(100)) + '}' as "GUID" 
--,fn.[U3FC8_DOC_TYPE_CD]
--,[U94D8_CNV_SRC] 

----INTO #DOC
--FROM [VRSQLRODS\RODS_PROD].REVERSE_DW.[dbo].[TP_FILENET_DOCVER] FN

----PULL MOST RECENT BUS PROC DATE FOR EACH DOCTYPE--
--Join (Select [U03D8_NSM_LOAN_NBR] AS LOAN_NBR, [U3FC8_DOC_TYPE_CD] as DOC_CODE ,MAX(BUS_PROC_DT) AS MaxBusProcDate 
--         From [VRSQLRODS\RODS_PROD].REVERSE_DW.[dbo].[TP_FILENET_DOCVER]
--		 WHERE [U94D8_CNV_SRC]  IN ('MailRoomScanning','NSM INTERNAL','DATACAP MAIL','autoingest') AND [U3FC8_DOC_TYPE_CD] in ('C.DEATH','HOADOCS','TRUST','OCCERT') --AND datediff(MONTH,CRE_DT,getdate()) <=12
--         Group by [U03D8_NSM_LOAN_NBR],[U3FC8_DOC_TYPE_CD]) TSIR 
--ON TSIR.LOAN_NBR =FN.[U03D8_NSM_LOAN_NBR]
--And TSIR.MaxBusProcDate = FN.BUS_PROC_DT
--AND TSIR.DOC_CODE = fn.[U3FC8_DOC_TYPE_CD]

--WHERE [U94D8_CNV_SRC]  IN ('MailRoomScanning','NSM INTERNAL','DATACAP MAIL','autoingest') AND fn.[U3FC8_DOC_TYPE_CD] in ('C.DEATH','HOADOCS','TRUST','OCCERT') AND datediff(MONTH,CRE_DT,getdate()) <=12

--order by CRE_DT desc



SELECT
E.[Loan Number]
,c.[HUD Status]
,a.[MCA %]
 ,case 
	when a.[MCA %] between '97.50' and '97.99' then '97.5-97.99'
	when a.[MCA %] between '98.00' and '99.99' then '98.00-99.99'
	when a.[MCA %] >= '100.00' then '100+'
	else '<97.49'
	end as 'MCA Bucket'
,e.[Exception ID]
,E.[Document]
,E.[Issue]
,CAST(E.[Exception Request Date] AS DATE) AS 'Exception Request Date'
,case
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) <= 0  then '0 to 15'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 0 and 15 then '0 to 15'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 16 and 30 then '16 to 30'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 31 and 60 then '31 to 60'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 61 and 90 then '61 to 90'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 91 and 120 then '91 to 120'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) >= 121 then '121+'
	end as 'Exception Request Aging'
,E.[Exception Status]

--NON GC--
,CAST(e.[Non GC Letter Sent 1]AS DATE) AS 'Non GC1'
,CAST(e.[Non GC Letter Sent 2]AS DATE) AS 'Non GC2'
,CAST(e.[Non GC Letter Sent 3]AS DATE) AS 'Non GC3'
,cast(e.[Non GC Letter Document Returned] as date) as 'Non GC doc returned'

--GC--
,CAST(e.[Gift Card Letter Sent]AS DATE) AS 'GC1'
,CAST(e.[Gift Card Letter Sent 2]AS DATE) AS 'GC2'
,CAST(e.[Gift Card Letter Sent 3]AS DATE) AS 'GC3'
,convert(nvarchar(10),e.[Document Returned Gift Card Eligible],101)as 'doc returned'
,CAST(e.[Sent For Gift Card Processing]AS DATE) AS 'GC FULFILLMENT'


--LEDGER--
,CAST(e.[Ledger Letter Sent 1]AS DATE) AS 'Ledger1'
,CAST(e.[Ledger Letter Sent 2]AS DATE) AS 'Ledger2'
,CAST(e.[Ledger Letter Sent 2]AS DATE) AS 'Ledger3'
,cast(e.[Ledger Letter Document Returned] as date) as 'Ledgerdoc returned'
,CAST(e.[Ledger Sent for Gift Card Processing]AS DATE) AS 'Ledger GC FULFILLMENT'
,cast(e.[Sent to Inspection Vendor] as date) as 'inspection date'
,e.[Proof of Repairs Status]

--,CASE
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) <= 0  then '0 to 15'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 0 and 15 then '0 to 15'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 16 and 30 then '16 to 30'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 31 and 60 then '31 to 60'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 61 and 90 then '61 to 90'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 91 and 120 then '91 to 120'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) >= 121 then '121+'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) <= 0  then '0 to 15'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 0 and 15 then '0 to 15'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 16 and 30 then '16 to 30'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 31 and 60 then '31 to 60'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 61 and 90 then '61 to 90'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 91 and 120 then '91 to 120'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) >= 121 then '121+'
--	END AS 'Exception Status Aging'
,e.[Exception Assigned To]
,c.[hud assigned to]
,T.[Open Exceptions]
,T.OpenCurative
,T.OpenHACG
,e.[Delinquent Amount]
,e.[Installment Frequency]
,e.[Due Date]
,e.[Entity or County Name]
,e.[Contact Info]
,e.[Fee to Obtain Info]
,e.[Fee Amount]
,r.[MGR_NM]
,r.[ST_LOC]
--,WEB.[WEB STATUS]
,case
	when e.[document] in ('current occ cert') and TSIR.[U3FC8_DOC_TYPE_CD] in ('occert') then TSIR.[GUID]
	when e.[document] in ('hoa') and TSIR.[U3FC8_DOC_TYPE_CD] in ('hoadocs') then TSIR.[GUID]
	when e.[document] in ('trust','trust - hacg') and TSIR.[U3FC8_DOC_TYPE_CD] in ('trust') then TSIR.[GUID]
	when e.[document] in ('death cert','death cert hacg') and TSIR.[U3FC8_DOC_TYPE_CD] in ('c.death') then TSIR.[GUID]
	end as 'Filenet GUID'
,case
	when e.[document] in ('current occ cert') and fn.[U3FC8_DOC_TYPE_CD] in ('occert') then fn.CRE_DT
	when e.[document] in ('hoa') and fn.[U3FC8_DOC_TYPE_CD] in ('hoadocs') then fn.CRE_DT
	when e.[document] in ('trust','trust - hacg') and fn.[U3FC8_DOC_TYPE_CD] in ('trust') then fn.CRE_DT
	when e.[document] in ('death cert','death cert hacg') and fn.[U3FC8_DOC_TYPE_CD] in ('c.death') then fn.CRE_DT
	end as 'Filenet Created Date'
,case
	when e.[document] in ('current occ cert') and fn.[U3FC8_DOC_TYPE_CD] in ('occert') then fn.[U94D8_CNV_SRC]
	when e.[document] in ('hoa') and fn.[U3FC8_DOC_TYPE_CD] in ('hoadocs') then fn.[U94D8_CNV_SRC]
	when e.[document] in ('trust','trust - hacg') and fn.[U3FC8_DOC_TYPE_CD] in ('trust') then fn.[U94D8_CNV_SRC]
	when e.[document] in ('death cert','death cert hacg') and fn.[U3FC8_DOC_TYPE_CD] in ('c.death') then fn.[U94D8_CNV_SRC]
	end as 'Filenet Source'

FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignLoans A
ON E.[Loan Number]=A.[Loan Number]
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignFinalReview B
ON E.[Loan Number]=B.[Loan Number]
left join SharepointData.dbo.HUDAssignHUDStatus c
on a.[Loan Number]=c.[Loan Number]
LEFT JOIN SharepointData.DBO.HUDAssignLoanExceptionTotals T
ON A.[Loan Number]=T.[Loan Number]
left join [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_HUD_RSTR] r
on c.[hud assigned to]=r.[AGNT_NM]
join [VRSQLRODS\RODS_PROD].REVERSE_DW.[dbo].[TP_FILENET_DOCVER] FN
--PULL MOST RECENT BUS PROC DATE FOR EACH DOCTYPE--
	Join (Select replace(ltrim(replace([U03D8_NSM_LOAN_NBR],'0',' ')),' ','0') as 'loan number'
	, CAST([CRE_DT] AS DATE) AS 'CRE_DT'
	, '{' + Cast(obj_id as varchar(100)) + '}' as "GUID" 
	,[U3FC8_DOC_TYPE_CD]
	,[U94D8_CNV_SRC] 
	,MAX(BUS_PROC_DT) AS MaxBusProcDate 
			 From [VRSQLRODS\RODS_PROD].REVERSE_DW.[dbo].[TP_FILENET_DOCVER]
			 WHERE [U94D8_CNV_SRC]  IN ('MailRoomScanning','NSM INTERNAL','DATACAP MAIL','autoingest') AND [U3FC8_DOC_TYPE_CD] in ('C.DEATH','HOADOCS','TRUST','OCCERT') --AND datediff(MONTH,CRE_DT,getdate()) <=12
			 Group by [U03D8_NSM_LOAN_NBR],[U3FC8_DOC_TYPE_CD]) TSIR 
	ON TSIR.[loan number] =FN.[U03D8_NSM_LOAN_NBR] And TSIR.MaxBusProcDate = FN.BUS_PROC_DT AND TSIR.[U3FC8_DOC_TYPE_CD] = fn.[U3FC8_DOC_TYPE_CD]
on fn.U03D8_NSM_LOAN_NBR=e.[loan number]
--web status
--LEFT JOIN TACT_REV.[dbo].[FipsAndZips3] WEB
--ON A.[Property ZIP]=WEB.[Zip Code]

WHERE E.[DOCUMENT] IN ('current occ cert','hoa','trust','death cert','death cert hacg') AND 
--[ISSUE] IN ('Forced Placed Insurance')AND
E.[EXCEPTION STATUS] NOT IN ('RESOLVED','CANCELLED','NOT VALID','CLOSED','INCURABLE','closed with vendor') AND
A.[Tag 2] IS NULL AND
A.[Incurable Flag] IN ('0')AND
A.[Loan Status] IN ('active')AND
--A.Stage IN ('FINAL REVIEW','HUD STATUS') AND 
--A.[MCA %]>=97.5 AND 
(a.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
a.[Group] is null)

