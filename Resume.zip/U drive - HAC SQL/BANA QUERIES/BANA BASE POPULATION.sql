select
a.[Loan Number]
,a.[Loan Status]
,a.[Pool Name]
,a.[Stage]
,a.[group]
,a.[Tag 2]
,A.[Incurable Flag]
,a.[MCA %]
   ,case 
	when a.[MCA %] between '97.50' and '97.99' then '97.5-97.99'
	when a.[MCA %] between '98.00' and '98.50' then '98.00-98.50'
	when a.[MCA %] between '98.51' and '99.00' then '98.51-99.00'
	when a.[MCA %] between '99.01' and '99.50' then '99.01-99.50'
	when a.[MCA %] between '99.51' and '99.99' then '99.51-99.99'
	when a.[MCA %]between '99.51' and '99.99' then '99.5-99.99'
	when a.[MCA %] >= '100.00' then '100+'
	else '<97.49'
	end as 'MCA Bucket'
,case
	when a.[Stage] IN ('DOC POOLING') THEN D.[Doc Pool Status]
	WHEN A.[Stage] IN ('INITIAL REVIEW') THEN E.[Initial Review Status]
	WHEN A.[Stage] IN ('CURATIVE') THEN F.[Cure Status]
	when a.[Stage] IN ('Final Review') then b.[Final Review Status]
	else c.[HUD status]
	end as 'Status'
,b.[Final Review Assigned To]
,t.OpenCurative
,t.OpenHACG

from SharepointData.dbo.HUDAssignLoans a
left join SharepointData.dbo.HUDAssignFinalReview b
on b.[Loan Number]=a.[Loan Number]
left join SharepointData.dbo.HUDAssignHUDStatus c
on c.[Loan Number]=a.[Loan Number]
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignDocPooling D
ON A.[Loan Number]=D.[Loan Number]
LEFT JOIN SharepointData.DBO.HUDAssignInitialReview E
ON A.[Loan Number] = E.[Loan Number]
LEFT JOIN SharepointData.DBO.HUDAssignCurative F
ON A.[Loan Number]=F.[Loan Number]
left join sharepointdata.dbo.HUDAssignLoanExceptionTotals t
on a.[Loan Number]=t.[Loan Number]

where --a.[Stage] in ('Final Review','HUD status') and
--a.[Tag 2] is null and
--a.[Loan Status] in ('active') and
--a.[Open Exceptions] =0 and
--a.[MCA %]>=97.5 and
--a.[Incurable Flag] in ('0') and
a.[group] in ('Grp 5 BofA GNMAs')
--and
--c.[HUD Status] not in ('HUD Approved','Pkg Submitted to HUD','Resubmitted to HUD','Rebuttal to HUD')
