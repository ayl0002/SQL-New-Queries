select
[loan number]
,[final review comment]

from sharepointdata.dbo.hudassignfinalreview

where [loan number] in ('809556')
