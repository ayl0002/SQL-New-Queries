select
a.[Loan Number]
,a.[Loan Status]
,a.[Pool Name]
,a.[Stage]
,a.[group]
,a.[Tag 2]
,a.[MCA %]
   ,case 
 when a.[mca %] between 97.00 and 97.49 then 'seg 2b'
 else 'not march roll in'
	end as 'MCA Bucket'
,case
	when a.[Stage] IN ('Final Review') then b.[Final Review Status]
	else c.[HUD status]
	end as 'Status'
,b.[final review assigned to]
,c.[HUD Assigned To]
,r.[MGR_NM]
,r.[ST_LOC]
,fpi.[Exception ID]
,cast(fpi.[Exception Request Date] as date) as 'Exception Request Date'
,case
	when datediff(day,cast(fpi.[Exception Request Date] as date),getdate()) <= 30 then '<= 30'
	when datediff(day,cast(fpi.[Exception Request Date] as date),getdate()) between 31 and 60 then '31 to 60'
	when datediff(day,cast(fpi.[Exception Request Date] as date),getdate()) >=61 then '61+'
	end as 'Exception Aging'
,fpi.[exception status]
,TAX1.[AGNC_NM] as 'AGCY 1'
,TAX1.PWP_1_DT AS 'AGCY 1 PWOP1'
,TAX1.PWP_2_DT AS 'AGCY 1 PWOP2'
,TAX1.PWP_3_DT AS 'AGCY 1 PWOP3'
,TAX1.PWP_4_DT AS 'AGCY 1 PWOP4'

,TAX2.[AGNC_NM] as 'AGCY 2'
,TAX2.PWP_1_DT AS 'AGCY 2 PWOP1'
,TAX2.PWP_2_DT AS 'AGCY 2 PWOP2'
,TAX2.PWP_3_DT AS 'AGCY 2 PWOP3'
,TAX2.PWP_4_DT AS 'AGCY 2 PWOP4'

,TAX3.[AGNC_NM] as 'AGCY 3'
,TAX3.PWP_1_DT AS 'AGCY 3 PWOP1'
,TAX3.PWP_2_DT AS 'AGCY 3 PWOP2'
,TAX3.PWP_3_DT AS 'AGCY 3 PWOP3'
,TAX3.PWP_4_DT AS 'AGCY 3 PWOP4'

,TAX4.[AGNC_NM] as 'AGCY 4'
,TAX4.PWP_1_DT AS 'AGCY 4 PWOP1'
,TAX4.PWP_2_DT AS 'AGCY 4 PWOP2'
,TAX4.PWP_3_DT AS 'AGCY 4 PWOP3'
,TAX4.PWP_4_DT AS 'AGCY 4 PWOP4'

from SharepointData.dbo.HUDAssignLoans a
left join SharepointData.dbo.HUDAssignFinalReview b
on b.[Loan Number]=a.[Loan Number]
left join SharepointData.dbo.HUDAssignHUDStatus c
on c.[Loan Number]=a.[Loan Number]
left join [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_HUD_RSTR] r
on c.[HUD Assigned To]=r.[AGNT_NM]
left join (select [loan number],[exception id],[document],[issue],[exception request date],[exception status] from sharepointdata.dbo.hudassignexceptions where [document] in ('tax bill') and [exception status] not in ('closed','resolved','not valid','closed with vendor'))fpi
on a.[Loan Number]=fpi.[Loan Number]
LEFT JOIN (SELECT b.LOAN_ID, B.[AGNC_NM], B.[PWP_1_DT], B.[PWP_2_DT], B.[PWP_3_DT], B.[PWP_4_DT], B.[BUS_PROC_DT], b.RN
	FROM (SELECT MAX([BUS_PROC_DT])AS 'BUS_PROC_DT' FROM [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_LERETA_INBND] )A
	LEFT JOIN (Select LOAN_ID, [AGNC_NM], [PWP_1_DT], [PWP_2_DT], [PWP_3_DT], [PWP_4_DT], [BUS_PROC_DT], ROW_NUMBER () OVER (PARTITION BY [LOAN_ID] ORDER BY [AGNC_NM] asc)RN from [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_LERETA_INBND] where BUS_PROC_DT = (SELECT MAX([BUS_PROC_DT])AS 'BUS_PROC_DT' FROM [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_LERETA_INBND] ) )B
	ON A.BUS_PROC_DT=B.BUS_PROC_DT
	)TAX1
ON A.[LOAN NUMBER]=TAX1.[LOAN_ID] AND TAX1.RN=1

LEFT JOIN (SELECT b.LOAN_ID, B.[AGNC_NM], B.[PWP_1_DT], B.[PWP_2_DT], B.[PWP_3_DT], B.[PWP_4_DT], B.[BUS_PROC_DT], b.RN
	FROM (SELECT MAX([BUS_PROC_DT])AS 'BUS_PROC_DT' FROM [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_LERETA_INBND] )A
	LEFT JOIN (Select LOAN_ID, [AGNC_NM], [PWP_1_DT], [PWP_2_DT], [PWP_3_DT], [PWP_4_DT], [BUS_PROC_DT], ROW_NUMBER () OVER (PARTITION BY [LOAN_ID] ORDER BY [AGNC_NM] asc)RN from [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_LERETA_INBND] where BUS_PROC_DT = (SELECT MAX([BUS_PROC_DT])AS 'BUS_PROC_DT' FROM [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_LERETA_INBND] ) )B
	ON A.BUS_PROC_DT=B.BUS_PROC_DT
	)TAX2
ON TAX1.[LOAN_ID]=TAX2.[LOAN_ID] AND TAX2.RN=2

LEFT JOIN (SELECT b.LOAN_ID, B.[AGNC_NM], B.[PWP_1_DT], B.[PWP_2_DT], B.[PWP_3_DT], B.[PWP_4_DT], B.[BUS_PROC_DT], b.RN
	FROM (SELECT MAX([BUS_PROC_DT])AS 'BUS_PROC_DT' FROM [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_LERETA_INBND] )A
	LEFT JOIN (Select LOAN_ID, [AGNC_NM], [PWP_1_DT], [PWP_2_DT], [PWP_3_DT], [PWP_4_DT], [BUS_PROC_DT], ROW_NUMBER () OVER (PARTITION BY [LOAN_ID] ORDER BY [AGNC_NM] asc)RN from [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_LERETA_INBND] where BUS_PROC_DT = (SELECT MAX([BUS_PROC_DT])AS 'BUS_PROC_DT' FROM [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_LERETA_INBND] ) )B
	ON A.BUS_PROC_DT=B.BUS_PROC_DT
	)TAX3
ON TAX1.[LOAN_ID]=TAX3.[LOAN_ID] AND TAX3.RN=3

LEFT JOIN (SELECT b.LOAN_ID, B.[AGNC_NM], B.[PWP_1_DT], B.[PWP_2_DT], B.[PWP_3_DT], B.[PWP_4_DT], B.[BUS_PROC_DT], b.RN
	FROM (SELECT MAX([BUS_PROC_DT])AS 'BUS_PROC_DT' FROM [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_LERETA_INBND] )A
	LEFT JOIN (Select LOAN_ID, [AGNC_NM], [PWP_1_DT], [PWP_2_DT], [PWP_3_DT], [PWP_4_DT], [BUS_PROC_DT], ROW_NUMBER () OVER (PARTITION BY [LOAN_ID] ORDER BY [AGNC_NM] asc)RN from [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_LERETA_INBND] where BUS_PROC_DT = (SELECT MAX([BUS_PROC_DT])AS 'BUS_PROC_DT' FROM [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_LERETA_INBND] ) )B
	ON A.BUS_PROC_DT=B.BUS_PROC_DT
	)TAX4
ON TAX1.[LOAN_ID]=TAX4.[LOAN_ID] AND TAX4.RN=4

where 
a.[Tag 2] is null and
a.[Loan Status] in ('active') and
a.[MCA %]>=97.00 and
a.[Incurable Flag] in ('0') and
(a.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
a.[Group] is null)and
c.[HUD Status] not in ('HUD Approved','Pkg Submitted to HUD','Resubmitted to HUD','Rebuttal to HUD') --and fpi.[Exception ID] is not null
