select distinct loan_nbr, [Aging], status_code into  ##pending
 from
(select base4.*, hdn.dny_dt, 
  mca.status_code , mca.[Assignable Bucket] from
(select base3.*, case when base3.[Date Submitted] = '2018-02-19' then 23
when base3.[Date Submitted] = '2018-03-17' then 6 else bd.[Business Days] end as [Business Days] from
(select base2.*, datediff(day,base2.[date submitted],getdate()) as 'Aging' from
(select base.*, dny.[Denial Date], apr.[Approval Date], case 
when dny.[Denial Date] is null then 0
when dny.[Denial Date] < base.[date submitted] then 0 else 1 end as 'True Denial'
,case
when apr.[Approval Date] is null then 0
when apr.[Approval Date] < base.[date submitted] then 0 else 1 end as 'True Approval'
from
(select loan_nbr, max([DT_SBMT_TO_HUD]) as 'Date Submitted'
from 
[dbo].[HUD_ASSGN_DT_SBMT_RESBMT]
where datediff(day,[DT_SBMT_TO_HUD],getdate()) < 45
group by loan_nbr) base

left join
(select distinct loan_nbr, max([HUD_PRELIM_TTL_DNY_DT]) as 'Denial Date'
from [dbo].[HUD_ASGN_HUD_STS]
 where [HUD_PRELIM_TTL_DNY_DT] < getdate()
 group by loan_nbr) dny on base.loan_nbr=dny.loan_nbr

 left join
(select distinct loan_nbr, max([HUD_PRELIM_TTL_APRVL_DT]) as 'Approval Date'
from [dbo].[HUD_ASGN_HUD_STS]
 where [HUD_PRELIM_TTL_APRVL_DT] < getdate()
 group by loan_nbr) APR on base.loan_nbr=apr.loan_nbr) base2
 where base2.[True Denial] = 0 and base2.[True Approval] = 0) base3

 left join
 (select [date], rank() over (order by [date] desc) as 'Business Days'
from [dbo].[RM_CALENDAR_BUSINESS_DAYS_TBL]
where servicingday = 1 and [date] <= getdate()) bd on base3.[Date submitted]=bd.[date]) base4
left join
(Select loan_nbr, status_code,  case when MCA_Percent < 98 then 'Less Than 98' when MCA_Percent >= 98 then 'Greater than 98' end as 'Assignable Bucket'
from [dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] ) mca on base4.loan_nbr=cast(mca.loan_nbr as varchar) 



left join
(select [LNDR_LOAN_NBR], [HUD_APRV_DT] from [dbo].[TP_HRMT_PRELIM_TTL_APRV]) hap on base4.loan_nbr=hap.[LNDR_LOAN_NBR]
left join
(select [LNDR_LOAN_NBR], [DNY_DT] from [dbo].[TP_HRMT_PRELIM_TTL_DNY]) hdn on base4.loan_nbr=hdn.[LNDR_LOAN_NBR]
left join
(select loan_nbr, [TAG_2_VAL] from [dbo].[HUD_ASGN_LOANS] where end_dttm = '9999-12-31') hal on base4.loan_nbr=hal.loan_nbr
where mca.status_code = 0 and 
hap.[HUD_APRV_DT] is null and (hdn.[dny_dt] is null or hdn.[dny_dt] <= [date submitted])
and hal.[TAG_2_VAL] is null) finito
where status_code = 0


select base.*, mca.mca_percent, mca.[MCA Bucket], mca.current_total_upb, mca.[CO Loss], sbm.[Submit Date] from
(select * from ##pending) base
left join
(select loan_nbr, mca_percent, case when MCA_Percent >= 100 then '100+' else 'LT100' end as 'MCA Bucket', current_total_upb, case  when MCA_Percent >= 100 then current_total_upb - max_claim_amount else 0 end as 'CO Loss'
from [dbo].[RM_CHAMPION_MASTER_TBL_VW]('2018-06-30',20180630)
) mca on base.loan_nbr=mca.loan_nbr
left join
(select loan_nbr, max([DT_SBMT_TO_HUD]) as 'Submit Date' from [dbo].[HUD_ASSGN_DT_SBMT_RESBMT] group by loan_nbr) sbm on base.loan_nbr=sbm.loan_nbr
where status_code = 0 order by aging


