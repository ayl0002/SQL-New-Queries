SELECT
L.[Loan Number]
,case 
	when l.[MCA %] between '97.50' and '97.99' then '97.5-97.99'
	when l.[MCA %] between '98.00' and '98.50' then '98.00-98.50'
	when l.[MCA %] between '98.51' and '99.00' then '98.51-99.00'
	when l.[MCA %] between '98.01' and '99.50' then '99.01-99.50'
	when l.[MCA %] between '99.51' and '99.99' then '99.51-99.99'
	when l.[MCA %] between '99.51' and '99.99' then '99.5-99.99'
	when l.[MCA %] > '100.00' then '100+'
	else '<97.49'
	end as 'MCA Bucket'
,l.[Loan Status]
,l.[Stage]
,A.[Work Group]
,A.[Exception ID]
,A.[Document]
,A.[Issue]
,A.[Exception Status]
,CASE
	WHEN A.[Exception Status Date] > A.[Vendor Status Date] THEN CONVERT(NVARCHAR(10),A.[Exception Status Date],101)
	WHEN A.[Exception Status Date] < A.[Vendor Status Date] THEN CONVERT(NVARCHAR(10),A.[Vendor Status Date],101)
	ELSE CONVERT(NVARCHAR(10),A.[Exception Status Date],101) END AS 'Last Updated'
--,CONVERT(NVARCHAR(10),A.[Exception Next Action Date],101) AS 'Exception Next Action Date'
--,case 
--	when datediff(day,cast(A.[Exception Next Action Date] as date),getdate()) < 0  then '0-15'
--	when datediff(day,cast(A.[Exception Next Action Date] as date),getdate()) between 0 and 15 then '0-15'
--	when datediff(day,cast(A.[Exception Next Action Date] as date),getdate()) between 16 and 30 then '16-30'
--	when datediff(day,cast(A.[Exception Next Action Date] as date),getdate()) between 31 and 45 then '31-45'
--	when datediff(day,cast(A.[Exception Next Action Date] as date),getdate()) between 46 and 60 then '46-60'
--	when datediff(day,cast(A.[Exception Next Action Date] as date),getdate()) between 61 and 90 then '61-90'
--	when datediff(day,cast(A.[Exception Next Action Date] as date),getdate()) > 91 then '91+'
--	end as 'Next Action Date Aging'
--,CONVERT(NVARCHAR(10),A.[Exception Status Date],101) AS 'Exception Status Date'
--,case 
--	when datediff(day,cast(A.[Exception Status Date] as date),getdate()) < 0  then '0-15'
--	when datediff(day,cast(A.[Exception Status Date] as date),getdate()) between 0 and 15 then '0-15'
--	when datediff(day,cast(A.[Exception Status Date] as date),getdate()) between 16 and 30 then '16-30'
--	when datediff(day,cast(A.[Exception Status Date] as date),getdate()) between 31 and 45 then '31-45'
--	when datediff(day,cast(A.[Exception Status Date] as date),getdate()) between 46 and 60 then '46-60'
--	when datediff(day,cast(A.[Exception Status Date] as date),getdate()) between 61 and 90 then '61-90'
--	when datediff(day,cast(A.[Exception Status Date] as date),getdate()) > 91 then '91+'
--	end as 'Exception Status Date Aging'
,A.[Exception Assigned To]

FROM [SharepointData].[dbo].[HUDAssignLoans] L (nolock)
join [SharepointData].[dbo].[HUDAssignFinalReview] F (nolock)
on f.[Loan Number] = L.[Loan Number]
JOIN SHAREPOINTDATA.dbo.HUDAssignExceptions A
ON A.[LOAN NUMBER] = L.[Loan Number]

WHERE 
--L.[Loan Status] in ('Active') AND
L.[Tag 2] IS NULL AND
L.[Group] NOT IN ('Grp 5 BofA GNMAs') AND
--L.[MCA %] >=97.5 AND
--L.[Stage] IN ('Final Review','HUD Status','Curative') AND
a.[Work Group] in ('Curative','Landtran')and
A.[Exception Status] NOT IN ('Resolved','Not Valid','Cancelled','Closed with Vendor','Incurable','FNMA Denied','NBS Denied') AND
L.[Incurable Flag] IN ('0')




