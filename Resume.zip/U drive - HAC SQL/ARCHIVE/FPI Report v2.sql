select
a.[Loan Number]
,a.[Loan Status]
,a.[Pool Name]
,a.[Stage]
,a.[group]
,a.[Tag 2]
,a.[MCA %]
   ,case 
	when a.[MCA %] between '97.50' and '97.99' then '97.5-97.99'
	when a.[MCA %] between '98.00' and '98.50' then '98.00-98.50'
	when a.[MCA %] between '98.51' and '99.00' then '98.51-99.00'
	when a.[MCA %] between '99.01' and '99.50' then '99.01-99.50'
	when a.[MCA %] between '99.51' and '99.99' then '99.51-99.99'
	when a.[MCA %]between '99.51' and '99.99' then '99.5-99.99'
	when a.[MCA %] >= '100.00' then '100+'
	else '<97.49'
	end as 'MCA Bucket'
,case
	when a.[Stage] IN ('Final Review') then b.[Final Review Status]
	else c.[HUD status]
	end as 'Status'
,B.[FINAL REVIEW ASSIGNED TO]
,C.[HUD ASSIGNED TO]
,t.OpenCurative
,t.OpenHACG
,t.[Open Exceptions]
,r.[MGR_NM]
,r.[ST_LOC]
,r.grp_nm
,f.[CMPNY_NM]
,CASE WHEN f.[CVR_TYPE] = 'F' THEN 'Fire(Hazard)'
         WHEN f.[CVR_TYPE] = 'W' THEN 'Flood'
         WHEN f.[CVR_TYPE] = 'A' THEN 'Wind'
         WHEN f.[CVR_TYPE] = 'G' THEN 'Flood Gap'
         WHEN f.[CVR_TYPE] = 'L' THEN 'Liability'
         WHEN f.[CVR_TYPE] = 'E' THEN 'Equipment'
         WHEN f.[CVR_TYPE] = 'Q' THEN 'Quake'
         WHEN f.[CVR_TYPE] = '1' THEN 'Condo'
         WHEN f.[CVR_TYPE] = '3' THEN 'Condo Flood Gap'
         WHEN f.[CVR_TYPE] = '4' THEN 'Condo w/Wind Supp'
         WHEN f.[CVR_TYPE] IS NULL THEN 'No Insurance'
         ELSE 'UNKNOWN'
       END AS 'Policy Type'
,f.plcy_eff_dt
,f.bus_proc_dt
,fpi.[Exception ID]


from SharepointData.dbo.HUDAssignLoans a
left join SharepointData.dbo.HUDAssignFinalReview b
on b.[Loan Number]=a.[Loan Number]
left join SharepointData.dbo.HUDAssignHUDStatus c
on c.[Loan Number]=a.[Loan Number]
left join sharepointdata.dbo.HUDAssignLoanExceptionTotals t
on a.[Loan Number]=t.[Loan Number]
left join [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_HUD_RSTR] r
on C.[HUD ASSIGNED TO]=r.[AGNT_NM]
LEFT JOIN (
	SELECT b.LOAN_NBR, B.CMPNY_NM, B.CVR_TYPE, B.plcy_eff_dt, B.[BUS_PROC_DT]
	FROM (SELECT MAX([BUS_PROC_DT])AS 'BUS_PROC_DT' FROM [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_SWBC_INS_RET] )A
	LEFT JOIN (Select cast(loan_nbr as int)as'LOAN_NBR', CMPNY_NM, CVR_TYPE, plcy_eff_dt, [BUS_PROC_DT] from [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_SWBC_INS_RET] where [CMPNY_NM] IN ('FP POL'))B
	ON A.BUS_PROC_DT=B.BUS_PROC_DT
	)F
ON A.[LOAN NUMBER]=F.LOAN_NBR
LEFT JOIN (SELECT [LOAN NUMBER],[EXCEPTION ID],[DOCUMENT],[ISSUE] FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS WHERE [ISSUE] IN ('Forced Placed Insurance')AND
[EXCEPTION STATUS] NOT IN ('RESOLVED','CANCELLED','NOT VALID','CLOSED','INCURABLE')) FPI
ON A.[LOAN NUMBER]=FPI.[Loan Number]


where a.[Stage] in ('Final Review','HUD status') and
a.[Tag 2] is null and
a.[Loan Status] in ('active') and
--a.[Open Exceptions] =0 and
--b.[final review assigned to] not in ('Kari Chadwell') and
a.[MCA %]>=97.5 and
a.[Incurable Flag] in ('0') and
(a.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
a.[Group] is null)and
c.[HUD Status] not in ('HUD Approved','Pkg Submitted to HUD','Resubmitted to HUD','Rebuttal to HUD') and f.[CMPNY_NM] is not null
