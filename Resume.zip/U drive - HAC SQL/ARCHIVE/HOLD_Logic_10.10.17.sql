/****** Script for SelectTopNRows command from SSMS  ******/
SELECT 

M.LOAN_NBR,
M.INVESTOR,
m.COUNTERPARTY
,m.POOL_NAME
,m.FHA_CASE_NBR
,case when m.INVESTOR = 'GNMA' and m.COUNTERPARTY in ('BOA','RMS','BOA/ML') then 'BOA Buyout'
when m.INVESTOR = 'FNMA' then 'FNMA'
when m.INVESTOR = 'NSM' then 'NSM'
when m.INVESTOR = 'PRIVATE' then 'PRIVATE'
END as 'Pipeline'

,CASE WHEN M.MCA_PERCENT >=92 and M.MCA_PERCENT <98 THEN '0. 92-98'
     WHEN M.MCA_PERCENT >=98 and M.MCA_PERCENT <98.5 THEN  '1. 98-98.5'
	 WHEN M.MCA_PERCENT >=98.5 and M.MCA_PERCENT <99 THEN  '2. 98.5-99'
     WHEN M.MCA_PERCENT >=99 and M.MCA_PERCENT <99.5 THEN  '3. 99-99.5'
     WHEN M.MCA_PERCENT >=99.5 and M.MCA_PERCENT <100 THEN '4. 99.5-100'
	 WHEN M.MCA_PERCENT >=100 and M.MCA_PERCENT <101 THEN '5. 100-101'
     WHEN M.MCA_PERCENT >=101 and M.MCA_PERCENT <102 THEN '6. 101-102'
     WHEN M.MCA_PERCENT >=102 and M.MCA_PERCENT <103 THEN '7. 102-103'
     WHEN M.MCA_PERCENT >=103 and M.MCA_PERCENT <104 THEN '8. 103-104'
     WHEN M.MCA_PERCENT >104 THEN '9. 104+' END as 'MCA_PERCENT',

M.MAX_CLAIM_AMOUNT,
M.CURRENT_TOTAL_UPB,
M.CURRENT_INTEREST_RATE,
M.MIP_RATE,
M.MONTHLY_PAYMENTS,
M.BORROWER_AGE,
M.COBORROWER_AGE,
CASE WHEN STATUS_CODE =0 and CURRENT_TOTAL_UPB> MAX_CLAIM_AMOUNT THEN CURRENT_TOTAL_UPB - MAX_CLAIM_AMOUNT ELSE 0 END as [Cross Over]
,case WHEN Borrower_AGE >=85 AND ISNULL(Coborrower_AGE,0)=0 AND CURRENT_INTEREST_RATE >=.0475 and MCA_PERCENT >104.8 THEN 'HOLD' 
     WHEN BORROWER_AGE >=85 AND COBORROWER_AGE >= 85 AND CURRENT_INTEREST_RATE >=.0475 and MCA_PERCENT >104.8 THEN 'HOLD'
     WHEN (CURRENT_TOTAL_UPB - MAX_CLAIM_AMOUNT)> 15000 THEN '$15k HOLD' 
   else 'Assign'
   end as 'Hold Flag'  
,h.HUD_STS_DESC
,l.TAG_2_VAL

,case
when MCA_PERCENT < '80.00' then '<80'
when MCA_PERCENT between '80.00' and '89.99' then '80-90'
when MCA_PERCENT between '90.00' and '91.99' then '90-92'
when MCA_PERCENT between '92.00' and '95.99' then '92-95'
when MCA_PERCENT between '96.00' and '97.49' then '96-97.49'
when MCA_PERCENT between '97.50' and '98.99' then '97.5-98'
when MCA_PERCENT between '99.00' and '99.50' then '99-99.5'
when MCA_PERCENT between '99.50' and '100.00' then '99.5-100'
when MCA_PERCENT  > '100.00' then '>100' 
END as 'MCA Bucket'


  FROM [Reverse_DW].[dbo].[RM_CHAMPION_MASTER_TBL_CURR] M
  join [Reverse_DW].[dbo].[HUD_ASGN_HUD_STS] H 
  on m.LOAN_NBR = h.LOAN_NBR
  join [Reverse_DW].[dbo].[HUD_ASGN_LOANS] L (nolock)
  on l.LOAN_NBR = h.LOAN_NBR
  
 where
 
 m.STATUS_CODE = '0'
 
 and h.CURR_IND = 'y'
 
and l.CURR_IND = 'y'

and (l.TAG_2_VAL not in ('HOLD','Reverse Select Not Assignable','GNMA 98% Serv. Transfer','GNMA 98% SERV.TRANS')
or l.TAG_2_VAL is NULL)
 
and m.MCA_PERCENT >= '100.00'

and m.FHA_CASE_NBR not in ('0000000000000')