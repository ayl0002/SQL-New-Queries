SET NOCOUNT ON
SELECT
[LoanNumber]
,MAX(R.DateSubmittedToHUD) AS 'Submit Date'
INTO #SUB
FROM SHAREPOINTDATA.dbo.HUDAssignDateSubmittedResubmittedtoHUD R
GROUP BY [LOANNUMBER]
select distinct
a.[LOAN NUMBER]
,CASE
WHEN b.[Final Review Status Date] >= C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),b.[Final Review Status Date],101)
WHEN b.[Final Review Status Date] < C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),C.[HUD Status Date],101)
ELSE CONVERT(NVARCHAR(10),b.[Final Review Status Date],101) END AS 'Last Updated'
INTO #UPDATE
FROM SharepointData.dbo.HUDAssignLoans a
left join SHAREPOINTDATA.DBO.HUDAssignFinalReview B
on a.[Loan Number]=b.[Loan Number]
LEFT JOIN SharepointData.DBO.HUDAssignHUDStatus C
ON a.[Loan Number]=C.[Loan Number]
WHERE B.Stage IN ('Final Review','HUD Status')
SELECT
B.[LOAN NUMBER]
,CONVERT(NVARCHAR(10),D.[Exception Status Date],101) as 'Last Exception Update'
,ROW_NUMBER () OVER (PARTITION BY D.[LOAN NUMBER] ORDER BY D.[Exception Status Date] desc)RN 
into #EXCEPTION
FROM SHAREPOINTDATA.DBO.HUDASSIGNHUDSTATUS B
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS D
ON B.[LOAN NUMBER] = D.[LOAN NUMBER]
--BASE QUERY--
SELECT
A.[LOAN NUMBER],a.Stage,a.[MCA %],a.[Loan Status],B.[FINAL REVIEW ASSIGNED TO], m.MGR_NM, m.ST_LOC ,A.[Open Exceptions]
,case
when r.[Submit Date] >=('2018-04-01') then CONVERT(NVARCHAR(10),r.[Submit Date],101) else 'NULL' end as 'Submit Date'
,case
when c.[HUD Status] in ('HUD Approved','HUD Approval') and CONVERT(nvarchar(10),r.[Submit Date],101) IS not null then 'HUD Approved'
when a.[Loan Status] not IN ('Active','Liquidated/Assigned to HUD') then 'Not Submittable'
when c.[HUD Status] in ('Pkg Submitted to HUD','Resubmitted to HUD','Rebuttal to HUD') and CONVERT(nvarchar(10),r.[Submit Date],101)IS not null then 'Submitted'
when (c.[HUD Status] not IN ('HUD Approved','Pkg Submitted to HUD','Resubmitted to HUD','Rebuttal to HUD') and CONVERT(nvarchar(10),r.[Submit Date],101)is null) Or c.[HUD Status] in ('HUD Denied') then 'Not Submitted'
when a.[Loan Status] not IN ('Active','Liquidated/Assigned to HUD') then 'Not Submittable'
end as 'Pending @ HUD'
,case
when C.[HUD Status] IN ('Pkg Submitted to HUD','Not Started') then B.[Final Review Status]
else C.[HUD Status]
end as 'Status'	
,Z.[Last Exception Update]
,case
when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) < 0  then '0-15'
when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) between 0 and 15 then '0-15'
when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) between 16 and 30 then '16-30'
when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) between 31 and 45 then '31-45'
when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) between 46 and 60 then '46-60'
when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) between 61 and 90 then '61-90'
when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) > 91 then '91+'
end as 'Exception Update Aging'
,U.[Last Updated]
,CASE
when datediff(day,cast(U.[Last Updated] as date),getdate()) < 0  then '0-3'
when datediff(day,cast(U.[Last Updated] as date),getdate()) between 0 and 3 then '0-3'
when datediff(day,cast(U.[Last Updated] as date),getdate()) between 4 and 15 then '4-15'
when datediff(day,cast(U.[Last Updated] as date),getdate()) between 16 and 30 then '16-30'
when datediff(day,cast(U.[Last Updated] as date),getdate()) between 31 and 45 then '31-45'
when datediff(day,cast(U.[Last Updated] as date),getdate()) between 46 and 60 then '46-60'
when datediff(day,cast(U.[Last Updated] as date),getdate()) between 61 and 90 then '61-90'
when datediff(day,cast(U.[Last Updated] as date),getdate()) >= 91 then '91+'
END AS 'Last Update Aging'
,CASE WHEN B.[Final Review Comment] > C.[HUD Status Comment] THEN B.[Final Review Comment] WHEN B.[Final Review Comment] < C.[HUD Status Comment] THEN C.[HUD Status Comment]ELSE B.[Final Review Comment]  END AS 'Last Comment'
,case
When a.[Loan Number] IN ('1024678',	'1044424',	'882697',	'872866',	'754933',	'742633',	'2805984',	'2780144',	'2731086',	'2721870',	'2703629',	'2276472',	'2472254',	'2460739',	'2405902',	'2369236',	'1047507',	'750173',	'2819343',	'2739869',	'874997',	'2401760',	'863326',	'883511',	'749919') then 'YES'
end as 'FPI Issue'
,case when a.[loan number] in ('1020258',	'1024030',	'1025813',	'1034070',	'1152089',	'2114875',	'2121475',	'2122853',	'2130626',	'2144165',	'2158128',	'2171864',	'2199003',	'2230284',	'2316506',	'2386420',	'2396923',	'2401760',	'2419009',	'2433303',	'2437795',	'2439571',	'2442075',	'2443270',	'2462207',	'2682236',	'2682500',	'2682840',	'2683567',	'2685284',	'2688049',	'2691328',	'2691590',	'2692773',	'2693923',	'2695446',	'2697200',	'2697277',	'2706143',	'2707985',	'2709807',	'2710092',	'2710651',	'2712492',	'2714644',	'2715736',	'2716817',	'2721723',	'2721949',	'2722427',	'2726034',	'2730267',	'2731827',	'2736445',	'2737641',	'2740350',	'2741590',	'2741727',	'2743251',	'2744946',	'2749086',	'2749495',	'2753436',	'2757806',	'2783900',	'2784810',	'2799602',	'2806337',	'2833795',	'2858853',	'2859887',	'837963',	'840726',	'841180',	'843455',	'843518',	'843560',	'843731',	'844349',	'845162',	'846289',	'846707',	'847835',	'849294',	'856311',	'859447',	'863326',	'863430',	'870088',	'878057',	'883815',	'886106',	'886237',	'886606',	'887749',	'887752',	'887892',	'889732',	'895118') then 'YES'
end as 'HUD LOC Issue'
,case when a.[loan number] in ('1066510','2623369','2632872','767434') then 'YES'
end as 'LOSS DRAFT Issue'
,CASE WHEN A.[Loan Number] IN ('2475371','2499073','2521093','2731770','2739222') THEN 'YES'
END AS 'OCC INSPC Issue'

,case
when convert(nvarchar(10),c.[HUD Preliminary Title Approval],101) <=('2018-04-01') then convert(nvarchar(10),c.[HUD Preliminary Title Approval],101) 
else 'NULL' end as 'HUD Approved Date'



FROM SHAREPOINTDATA.dbo.HUDAssignLoans A 
Left JOIN SHAREPOINTDATA.dbo.HUDAssignFinalReview B 
ON B.[LOAN NUMBER]=A.[LOAN NUMBER] 
Left JOIN SHAREPOINTDATA.DBO.HUDASSIGNHUDSTATUS C 
ON C.[LOAN NUMBER]=B.[LOAN NUMBER] 
Left Join #SUB R ON R.LoanNumber=A.[Loan Number]
LEFT JOIN #UPDATE U
ON A.[Loan Number]=U.[Loan Number]
LEFT JOIN #EXCEPTION Z
ON A.[Loan Number]=Z.[Loan Number] and z.RN=1
left JOIN [VRSQLRODS\RODS_PROD].reverse_dw.dbo.TP_HUD_RSTR m
on b.[Final Review Assigned To]=m.AGNT_NM

where a.[Loan Number] in ('1024678',	'1044424',	'882697',	'872866',	'754933',	'742633',	'2805984',	'2780144',	'2731086',	'2721870',	'2703629',	'2276472',	'2472254',	'2460739',	'2405902',	'2369236',	'1047507',	'750173',	'2819343',	'2739869',	'874997',	'1020258',	'1024030',	'1025813',	'1034070',	'1152089',	'2114875',	'2121475',	'2122853',	'2130626',	'2144165',	'2158128',	'2171864',	'2199003',	'2230284',	'2316506',	'2386420',	'2396923',	'2401760',	'2419009',	'2433303',	'2437795',	'2439571',	'2442075',	'2443270',	'2462207',	'2682236',	'2682500',	'2682840',	'2683567',	'2685284',	'2688049',	'2691328',	'2691590',	'2692773',	'2693923',	'2695446',	'2697200',	'2697277',	'2706143',	'2707985',	'2709807',	'2710092',	'2710651',	'2712492',	'2714644',	'2715736',	'2716817',	'2721723',	'2721949',	'2722427',	'2726034',	'2730267',	'2731827',	'2736445',	'2737641',	'2740350',	'2741590',	'2741727',	'2743251',	'2744946',	'2749086',	'2749495',	'2753436',	'2757806',	'2783900',	'2784810',	'2799602',	'2806337',	'2833795',	'2858853',	'2859887',	'837963',	'840726',	'841180',	'843455',	'843518',	'843560',	'843731',	'844349',	'845162',	'846289',	'846707',	'847835',	'849294',	'856311',	'859447',	'863326',	'863430',	'870088',	'878057',	'883815',	'886106',	'886237',	'886606',	'887749',	'887752',	'887892',	'889732',	'895118',	'1066510',	'2623369',	'2632872',	'767434',	'883511',	'749919',	'2475371',	'2499073',	'2521093',	'2731770',	'2739222')
DROP TABLE #SUB, #EXCEPTION, #UPDATE