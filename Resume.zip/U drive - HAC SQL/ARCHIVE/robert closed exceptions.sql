SELECT 
A.[Loan Number]
,A.[LOAN STATUS]
,M.[EXCEPTION ID]
,E.[Document]
,E.[ISSUE]
,CAST(E.[Exception Request Date]AS DATE) AS 'Exception Request Date'
,M.[Exception Status]
,M.[Exception Status Updated By]
,CAST(M.[Exception Status Date]AS DATE) AS 'Exception Status Date'
,M.[Exception Memo]

FROM SHAREPOINTDATA.DBO.HUDAssignExceptionActions M
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNLOANS A
ON M.[Loan Number]=A.[Loan Number]
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
ON M.[Exception ID]=E.[EXCEPTION ID]

WHERE M.[Exception Status] IN ('RESOLVED','INCURABLE','NOT VALID','CLOSED WITH VENDOR')
AND E.[Work Group] IN ('HACG')
AND A.[LOAN STATUS] NOT IN ('Liquidated/3rd Party Sale','INACTIVE','Liquidated/Held for Sale') 
--AND CAST(M.[Exception Status Date]AS DATE)>=('2018-12-31')

ORDER BY M.[Loan Number],M.[Exception ID], m.[Exception Status Date] DESC