SELECT
A.[Loan Number]
,A.[MCA %]
,CASE
	WHEN A.[MCA %] BETWEEN 97.5 AND 99.99 THEN ' 97.5-100'
	WHEN A.[MCA %] >= 100 THEN '100+'
	ELSE '<97.5'
	END AS 'MCA BUCKET'
,OCC.Document AS 'OCC'
,OCC.[Exception ID] 'OCC EXCP ID'
,CAST(OCC.[Exception Request Date]AS DATE) AS 'OCC EXCP RQST DT'
,CAST(OCC.[Gift Card Letter Sent]AS DATE) AS 'OCC LTR1'
,CAST(OCC.[Gift Card Letter Sent 2]AS DATE) AS 'OCC LTR2'
,CAST(OCC.[Gift Card Letter Sent 3]AS DATE) AS 'OCC LTR3'
,CASE
	WHEN OGCV.[Sent For Gift Card Processing] IS NOT NULL THEN 'GIFT CARD SENT - NOT ELIGIBLE FOR LETTER'
	WHEN (OCC.[GIFT CARD LETTER SENT] IS NULL AND OCC.[GIFT CARD LETTER SENT 2] IS NULL AND OCC.[GIFT CARD LETTER SENT 3] IS NULL) AND OCC.[Document] IS NOT NULL-- AND A.[MCA %] >= 96.5 
		THEN 'SEND GC1'
	WHEN (OCC.[GIFT CARD LETTER SENT] IS NOT NULL AND OCC.[GIFT CARD LETTER SENT 2] IS NULL) AND OCC.[Document] IS NOT NULL --AND (A.[MCA %] BETWEEN 96.5 AND 98.49) 
		AND OCC.[GC1 AGING] > 10 THEN 'SEND GC2'
	WHEN (OCC.[GIFT CARD LETTER SENT] IS NOT NULL AND OCC.[GIFT CARD LETTER SENT 2] IS NOT NULL AND OCC.[GIFT CARD LETTER SENT 3] IS NULL) AND OCC.[Document] IS NOT NULL --AND A.[MCA %] BETWEEN 96.5 AND 98.49 
		AND OCC.[GC2 AGING] > 10 THEN 'SEND GC3'
	END AS 'OCC LETTER DROP'
,CASE
	WHEN (OCC.[GIFT CARD LETTER SENT] IS NOT NULL AND OCC.[GIFT CARD LETTER SENT 2] IS NOT NULL AND OCC.[GIFT CARD LETTER SENT 3] IS NULL) AND OCC.[Document] IS NOT NULL AND OCC.[GC2 AGING] > 15 AND OCC.[Sent to Inspection Vendor] IS NULL THEN 'DOOR KNOCK/3RD LETTER'
	WHEN A.[MCA %] >=97 AND OCC.[Document] IS NOT NULL AND OCC.[Sent to Inspection Vendor] IS NULL THEN 'NCCI DOOR KNOCK'
	ELSE 'NULL'
	END AS 'OCC DOOR KNOCK'

,DC.Document AS 'DC'
,DC.[Exception ID] 'DC EXCP ID'
,CAST(DC.[Exception Request Date]AS DATE) AS 'DC EXCP RQST DT'
,CAST(DC.[Gift Card Letter Sent]AS DATE) AS 'DC LTR1'
,CAST(DC.[Gift Card Letter Sent 2]AS DATE) AS 'DC LTR2'
,CAST(DC.[Gift Card Letter Sent 3]AS DATE) AS 'DC LTR3'
,CASE
	WHEN DCGCV.[Sent For Gift Card Processing] IS NOT NULL THEN 'GIFT CARD SENT - NOT ELIGIBLE FOR LETTER'
	WHEN (DC.[GIFT CARD LETTER SENT] IS NULL AND DC.[GIFT CARD LETTER SENT 2] IS NULL AND DC.[GIFT CARD LETTER SENT 3] IS NULL) AND DC.[Document] IS NOT NULL THEN 'SEND GC1'
	WHEN (DC.[GIFT CARD LETTER SENT] IS NOT NULL AND DC.[GIFT CARD LETTER SENT 2] IS NULL) AND DC.[Document] IS NOT NULL  AND DC.[GC1 AGING] > 15 THEN 'SEND GC2'
	WHEN (DC.[GIFT CARD LETTER SENT] IS NOT NULL AND DC.[GIFT CARD LETTER SENT 2] IS NOT NULL AND DC.[GIFT CARD LETTER SENT 3] IS NULL) AND DC.[Document] IS NOT NULL  AND DC.[GC2 AGING] > 15 THEN 'SEND GC3'
	END AS 'DC LETTER DROP'

,TRST.Document AS 'TRST'
,TRST.[Exception ID] 'TRST EXCP ID'
,CAST(TRST.[Exception Request Date]AS DATE) AS 'TRST EXCP RQST DT'
,CAST(TRST.[Gift Card Letter Sent]AS DATE) AS 'TRST LTR1'
,CAST(TRST.[Gift Card Letter Sent 2]AS DATE) AS 'TRST LTR2'
,CAST(TRST.[Gift Card Letter Sent 3]AS DATE) AS 'TRST LTR3'
,CASE
	WHEN TGCV.[Sent For Gift Card Processing] IS NOT NULL THEN 'GIFT CARD SENT - NOT ELIGIBLE FOR LETTER'
	WHEN (TRST.[GIFT CARD LETTER SENT] IS NULL AND TRST.[GIFT CARD LETTER SENT 2] IS NULL AND TRST.[GIFT CARD LETTER SENT 3] IS NULL) AND TRST.[Document] IS NOT NULL  THEN 'SEND GC1'
	WHEN (TRST.[GIFT CARD LETTER SENT] IS NOT NULL AND TRST.[GIFT CARD LETTER SENT 2] IS NULL) AND TRST.[Document] IS NOT NULL  AND TRST.[GC1 AGING] > 15 THEN 'SEND GC2'
	WHEN (TRST.[GIFT CARD LETTER SENT] IS NOT NULL AND TRST.[GIFT CARD LETTER SENT 2] IS NOT NULL AND TRST.[GIFT CARD LETTER SENT 3] IS NULL) AND TRST.[Document] IS NOT NULL  AND TRST.[GC2 AGING] > 15 THEN 'SEND GC3'
	END AS 'TRST LETTER DROP'

,POR.Document AS 'POR'
,POR.[Exception ID] 'POR EXCP ID'
,CAST(POR.[Exception Request Date]AS DATE) AS 'POR EXCP RQST DT'
,CAST(POR.[Gift Card Letter Sent]AS DATE) AS 'POR LTR1'
,CAST(POR.[Gift Card Letter Sent 2]AS DATE) AS 'POR LTR2'
,CAST(POR.[Gift Card Letter Sent 3]AS DATE) AS 'POR LTR3'
,CASE
	WHEN PORGCV.[Sent For Gift Card Processing] IS NOT NULL THEN 'GIFT CARD SENT - NOT ELIGIBLE FOR LETTER'
	WHEN (POR.[GIFT CARD LETTER SENT] IS NULL AND POR.[GIFT CARD LETTER SENT 2] IS NULL AND POR.[GIFT CARD LETTER SENT 3] IS NULL) AND (POR.[Document] IS NOT NULL AND PORCURE.Document IS NULL) THEN 'SEND GC1'
	WHEN (POR.[GIFT CARD LETTER SENT] IS NOT NULL AND POR.[GIFT CARD LETTER SENT 2] IS NULL) AND (POR.[Document] IS NOT NULL AND PORCURE.Document IS NULL) AND POR.[GC1 AGING] > 15 THEN 'SEND GC2'
	WHEN (POR.[GIFT CARD LETTER SENT] IS NOT NULL AND POR.[GIFT CARD LETTER SENT 2] IS NOT NULL AND POR.[GIFT CARD LETTER SENT 3] IS NULL) AND (POR.[Document] IS NOT NULL AND PORCURE.Document IS NULL) AND POR.[GC2 AGING] > 15 THEN 'SEND GC3'
	END AS 'POR LETTER DROP'

,HOA.Document AS 'HOA'
,HOA.[Exception ID] 'HOA EXCP ID'
,CAST(HOA.[Exception Request Date]AS DATE) AS 'HOA EXCP RQST DT'
,CAST(HOA.[Gift Card Letter Sent]AS DATE) AS 'HOA LTR1'
,CAST(HOA.[Gift Card Letter Sent 2]AS DATE) AS 'HOA LTR2'
,CAST(HOA.[Gift Card Letter Sent 3]AS DATE) AS 'HOA LTR3'
,CASE
	WHEN HOAGCV.[Sent For Gift Card Processing] IS NOT NULL THEN 'GIFT CARD SENT - NOT ELIGIBLE FOR LETTER'
	WHEN (HOA.[GIFT CARD LETTER SENT] IS NULL AND HOA.[GIFT CARD LETTER SENT 2] IS NULL AND HOA.[GIFT CARD LETTER SENT 3] IS NULL) AND HOA.[Document] IS NOT NULL AND A.[MCA %] between 96 and 97.49 THEN 'SEND GC1'
	WHEN (HOA.[GIFT CARD LETTER SENT] IS NOT NULL AND HOA.[GIFT CARD LETTER SENT 2] IS NULL) AND HOA.[Document] IS NOT NULL AND HOA.[GC1 AGING] > 10 THEN 'SEND GC2'
	WHEN (HOA.[GIFT CARD LETTER SENT] IS NOT NULL AND HOA.[GIFT CARD LETTER SENT 2] IS NOT NULL AND HOA.[GIFT CARD LETTER SENT 3] IS NULL) AND HOA.[Document] IS NOT NULL AND HOA.[GC2 AGING] > 10 THEN 'SEND GC3'
	END AS 'HOA LETTER DROP'

FROM SHAREPOINTDATA.DBO.HUDASSIGNLOANS A
LEFT JOIN (SELECT E.[LOAN NUMBER],E.[EXCEPTION ID],E.[DOCUMENT],E.[ISSUE],E.[EXCEPTION REQUEST DATE]
	,e.[Gift Card Letter Sent] ,datediff(day,cast(E.[Gift Card Letter Sent] as date),getdate()) AS 'GC1 AGING'
	,e.[Gift Card Letter Sent 2] ,datediff(day,cast(E.[Gift Card Letter Sent 2] as date),getdate()) AS 'GC2 AGING'
	,e.[Gift Card Letter Sent 3] ,datediff(day,cast(E.[Gift Card Letter Sent 3] as date),getdate()) AS 'GC3 AGING'
	,E.[Document Returned Gift Card Eligible],e.[Sent For Gift Card Processing],e.[Sent to Inspection Vendor],E.[Document Received by Vendor]
	FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
	WHERE E.[EXCEPTION STATUS] NOT IN ('CLOSED','RESOLVED','NOT VALID','INCURABLE','CLOSED WITH VENDOR') AND E.[DOCUMENT] IN ('CURRENT OCC CERT')
	)OCC --OPEN OCC--
ON A.[LOAN NUMBER]=OCC.[LOAN NUMBER]
	LEFT JOIN (SELECT E.[LOAN NUMBER],E.[EXCEPTION ID],E.[DOCUMENT],E.[ISSUE],E.[EXCEPTION REQUEST DATE]
		,e.[Gift Card Letter Sent] ,datediff(day,cast(E.[Gift Card Letter Sent] as date),getdate()) AS 'GC1 AGING'
		,e.[Gift Card Letter Sent 2] ,datediff(day,cast(E.[Gift Card Letter Sent 2] as date),getdate()) AS 'GC2 AGING'
		,e.[Gift Card Letter Sent 3] ,datediff(day,cast(E.[Gift Card Letter Sent 3] as date),getdate()) AS 'GC3 AGING'
		,E.[Document Returned Gift Card Eligible],e.[Sent For Gift Card Processing],e.[Sent to Inspection Vendor],E.[Document Received by Vendor]
		FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
		WHERE E.[DOCUMENT] IN ('CURRENT OCC CERT') AND E.[Sent For Gift Card Processing] IS NOT NULL) OGCV --OCC HAS RCVD GC--
	ON A.[LOAN NUMBER]=OGCV.[LOAN NUMBER]
LEFT JOIN (SELECT E.[LOAN NUMBER],E.[EXCEPTION ID],E.[DOCUMENT],E.[ISSUE],E.[EXCEPTION REQUEST DATE] 
	,e.[Gift Card Letter Sent] ,datediff(day,cast(E.[Gift Card Letter Sent] as date),getdate()) AS 'GC1 AGING'
	,e.[Gift Card Letter Sent 2] ,datediff(day,cast(E.[Gift Card Letter Sent 2] as date),getdate()) AS 'GC2 AGING'
	,e.[Gift Card Letter Sent 3] ,datediff(day,cast(E.[Gift Card Letter Sent 3] as date),getdate()) AS 'GC3 AGING'
	,E.[Document Returned Gift Card Eligible],e.[Sent For Gift Card Processing],e.[Sent to Inspection Vendor],E.[Document Received by Vendor]
	FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
	LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNLOANS A
	ON E.[LOAN NUMBER]=A.[LOAN NUMBER]
	WHERE E.[EXCEPTION STATUS] NOT IN ('CLOSED','RESOLVED','NOT VALID','INCURABLE','CLOSED WITH VENDOR') AND E.[DOCUMENT] IN ('DEATH CERT HACG') AND A.[MCA %] >= '95'
	)DC --OPEN DC--
ON A.[Loan Number]=DC.[Loan Number]
	LEFT JOIN (SELECT E.[LOAN NUMBER],E.[EXCEPTION ID],E.[DOCUMENT],E.[ISSUE],E.[EXCEPTION REQUEST DATE]
			,e.[Gift Card Letter Sent] ,datediff(day,cast(E.[Gift Card Letter Sent] as date),getdate()) AS 'GC1 AGING'
			,e.[Gift Card Letter Sent 2] ,datediff(day,cast(E.[Gift Card Letter Sent 2] as date),getdate()) AS 'GC2 AGING'
			,e.[Gift Card Letter Sent 3] ,datediff(day,cast(E.[Gift Card Letter Sent 3] as date),getdate()) AS 'GC3 AGING'
			,E.[Document Returned Gift Card Eligible],e.[Sent For Gift Card Processing],e.[Sent to Inspection Vendor],E.[Document Received by Vendor]
			FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
			WHERE E.[DOCUMENT] IN ('DEATH CERT HACG','DEATH CERT') AND E.[Sent For Gift Card Processing] IS NOT NULL) DCGCV --DC HAS RCVD GC--
		ON A.[Loan Number]=DCGCV.[Loan Number]
LEFT JOIN (SELECT E.[LOAN NUMBER],E.[EXCEPTION ID],E.[DOCUMENT],E.[ISSUE],E.[EXCEPTION REQUEST DATE]
	,e.[Gift Card Letter Sent] ,datediff(day,cast(E.[Gift Card Letter Sent] as date),getdate()) AS 'GC1 AGING'
	,e.[Gift Card Letter Sent 2] ,datediff(day,cast(E.[Gift Card Letter Sent 2] as date),getdate()) AS 'GC2 AGING'
	,e.[Gift Card Letter Sent 3] ,datediff(day,cast(E.[Gift Card Letter Sent 3] as date),getdate()) AS 'GC3 AGING'
	,E.[Document Returned Gift Card Eligible],e.[Sent For Gift Card Processing],e.[Sent to Inspection Vendor],E.[Document Received by Vendor]
	FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
	LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNLOANS A
	ON E.[LOAN NUMBER]=A.[LOAN NUMBER]
	WHERE E.[EXCEPTION STATUS] NOT IN ('CLOSED','RESOLVED','NOT VALID','INCURABLE','CLOSED WITH VENDOR') AND E.[DOCUMENT] IN ('TRUST - HACG') AND A.[MCA %] >='92'
	)TRST --OPEN TRUST--
ON A.[Loan Number]=TRST.[Loan Number]
	LEFT JOIN (SELECT E.[LOAN NUMBER],E.[EXCEPTION ID],E.[DOCUMENT],E.[ISSUE],E.[EXCEPTION REQUEST DATE]
			,e.[Gift Card Letter Sent] ,datediff(day,cast(E.[Gift Card Letter Sent] as date),getdate()) AS 'GC1 AGING'
			,e.[Gift Card Letter Sent 2] ,datediff(day,cast(E.[Gift Card Letter Sent 2] as date),getdate()) AS 'GC2 AGING'
			,e.[Gift Card Letter Sent 3] ,datediff(day,cast(E.[Gift Card Letter Sent 3] as date),getdate()) AS 'GC3 AGING'
			,E.[Document Returned Gift Card Eligible],e.[Sent For Gift Card Processing],e.[Sent to Inspection Vendor],E.[Document Received by Vendor]
			FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
			WHERE E.[DOCUMENT] IN ('TRUST - HACG','TRUST') AND E.[Sent For Gift Card Processing] IS NOT NULL) TGCV --TRUST HAS RCVD GC--
		ON A.[Loan Number]=TGCV.[Loan Number]
LEFT JOIN (SELECT E.[LOAN NUMBER],E.[EXCEPTION ID],E.[DOCUMENT],E.[ISSUE],E.[EXCEPTION REQUEST DATE]
	,e.[Gift Card Letter Sent] ,datediff(day,cast(E.[Gift Card Letter Sent] as date),getdate()) AS 'GC1 AGING'
	,e.[Gift Card Letter Sent 2] ,datediff(day,cast(E.[Gift Card Letter Sent 2] as date),getdate()) AS 'GC2 AGING'
	,e.[Gift Card Letter Sent 3] ,datediff(day,cast(E.[Gift Card Letter Sent 3] as date),getdate()) AS 'GC3 AGING'
	,E.[Document Returned Gift Card Eligible],e.[Sent For Gift Card Processing],e.[Sent to Inspection Vendor],E.[Document Received by Vendor]
	FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
	WHERE E.[EXCEPTION STATUS] NOT IN ('CLOSED','RESOLVED','NOT VALID','INCURABLE','CLOSED WITH VENDOR') AND E.[DOCUMENT] IN ('Proof of Repair') AND (E.[Proof of Repairs Status] NOT IN ('REPORT/INSPECTION COMPLETE REPAIRS NOT COMPLETE')OR E.[Proof of Repairs Status] IS NULL)
	)POR
ON A.[Loan Number]=POR.[Loan Number] --OPEN POR EXCEPTIONS--
	LEFT JOIN (SELECT E.[LOAN NUMBER],E.[EXCEPTION ID],E.[DOCUMENT],E.[ISSUE],E.[EXCEPTION REQUEST DATE]
		FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
		WHERE E.[Work Group] IN ('CURATIVE','LANDTRAN') AND E.[EXCEPTION STATUS] NOT IN ('CLOSED','RESOLVED','NOT VALID','INCURABLE','CLOSED WITH VENDOR') 
		AND E.[DOCUMENT] NOT IN ('TITLE POLICY','Assignments','Assignments-3rd Party','Assignments-POA','DEATH CERT','TRUST'))PORCURE
		ON POR.[Loan Number]=PORCURE.[Loan Number] --CURATIVE EXCEPTIONS ON POR LOANS--
	
	LEFT JOIN (SELECT E.[LOAN NUMBER],E.[EXCEPTION ID],E.[DOCUMENT],E.[ISSUE],E.[EXCEPTION REQUEST DATE]
		,e.[Gift Card Letter Sent] ,datediff(day,cast(E.[Gift Card Letter Sent] as date),getdate()) AS 'GC1 AGING'
		,e.[Gift Card Letter Sent 2] ,datediff(day,cast(E.[Gift Card Letter Sent 2] as date),getdate()) AS 'GC2 AGING'
		,e.[Gift Card Letter Sent 3] ,datediff(day,cast(E.[Gift Card Letter Sent 3] as date),getdate()) AS 'GC3 AGING'
		,E.[Document Returned Gift Card Eligible],e.[Sent For Gift Card Processing],e.[Sent to Inspection Vendor],E.[Document Received by Vendor]
		FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
		WHERE E.[DOCUMENT] IN ('Proof of Repair') AND E.[Sent For Gift Card Processing] IS NOT NULL) PORGCV
		ON A.[Loan Number]=PORGCV.[Loan Number] --GIFT CARD SENT FOR POR EXCEPTION--
LEFT JOIN (SELECT E.[LOAN NUMBER],E.[EXCEPTION ID],E.[DOCUMENT],E.[ISSUE],E.[EXCEPTION REQUEST DATE]
	,e.[Gift Card Letter Sent] ,datediff(day,cast(E.[Gift Card Letter Sent] as date),getdate()) AS 'GC1 AGING'
	,e.[Gift Card Letter Sent 2] ,datediff(day,cast(E.[Gift Card Letter Sent 2] as date),getdate()) AS 'GC2 AGING'
	,e.[Gift Card Letter Sent 3] ,datediff(day,cast(E.[Gift Card Letter Sent 3] as date),getdate()) AS 'GC3 AGING'
	,E.[Document Returned Gift Card Eligible],e.[Sent For Gift Card Processing],e.[Sent to Inspection Vendor],E.[Document Received by Vendor]
	FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
	WHERE E.[EXCEPTION STATUS] NOT IN ('CLOSED','RESOLVED','NOT VALID','INCURABLE','CLOSED WITH VENDOR') AND E.[DOCUMENT] IN ('HOA')
	)HOA
ON A.[Loan Number]=HOA.[Loan Number]

	LEFT JOIN (SELECT E.[LOAN NUMBER],E.[EXCEPTION ID],E.[DOCUMENT],E.[ISSUE],E.[EXCEPTION REQUEST DATE]
		,e.[Gift Card Letter Sent] ,datediff(day,cast(E.[Gift Card Letter Sent] as date),getdate()) AS 'GC1 AGING'
		,e.[Gift Card Letter Sent 2] ,datediff(day,cast(E.[Gift Card Letter Sent 2] as date),getdate()) AS 'GC2 AGING'
		,e.[Gift Card Letter Sent 3] ,datediff(day,cast(E.[Gift Card Letter Sent 3] as date),getdate()) AS 'GC3 AGING'
		,E.[Document Returned Gift Card Eligible],e.[Sent For Gift Card Processing],e.[Sent to Inspection Vendor],E.[Document Received by Vendor]
		FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
		WHERE E.[DOCUMENT] IN ('HOA') AND E.[Sent For Gift Card Processing] IS NOT NULL) HOAGCV
		ON A.[Loan Number]=HOAGCV.[Loan Number]

WHERE A.[Loan Status] IN ('ACTIVE') 
AND A.[MCA %] >= 85
AND A.[Tag 2] IS NULL 
AND A.[Incurable Flag] IN ('0') 
AND(a.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
a.[Group] is null)


--VERSION 5 2/12/2019: REMOVED MCA RESTRICTION TO OCC LETTER LOGIC. ALL OCC EXCEPTIONS SHOULD BE INCLUDED IN LETTER DROP. 	WHEN (OCC.[GIFT CARD LETTER SENT] IS NOT NULL AND OCC.[GIFT CARD LETTER SENT 2] IS NOT NULL AND OCC.[GIFT CARD LETTER SENT 3] IS NULL) AND OCC.[Document] IS NOT NULL AND OCC.[GC2 AGING] > 15 AND OCC.[Sent to Inspection Vendor] IS NULL THEN 'DOOR KNOCK/3RD LETTER'
--NCCI DOOR KNOCK: 1) LOAN HAS HAD 3 GIFT CARDS AND LOAN IS 97.5+ 2)MCA 98 TO 99.50 AND EXCEPTION REQUEST AGING 30+ DAYS 3)MCA 99.51 AND EXCEPTION REQUEST DAYING 10+DAYS
--VERSION 6 2/19/2019: ADDED HOA LETTER2 AND LETTER3 DROP, 10 DAY INCREMENT. UPDATED OCC LETTER DROP TO 10 DAY INCREMENET FROM 15
--VERSION 6.1 2/20/2019: REMOVED MCA RESTRICTION FROM POR. "As long as the loan is assigned to someone on non-time sensitive it should begin getting letters.  No MCA limit."
--VERSION 6.2 2/26/2019: ADDED HOA ROLL IN GC1 LOGIC 	"WHEN (HOA.[GIFT CARD LETTER SENT] IS NULL AND HOA.[GIFT CARD LETTER SENT 2] IS NULL AND HOA.[GIFT CARD LETTER SENT 3] IS NULL) AND DC.[Document] IS NOT NULL AND A.[MCA %] between 96 and 97.49 THEN 'SEND GC1'"
--VERSION 6.3 2/28/2019: REMOVED NCCI LOGIC: WHEN (OCC.[GIFT CARD LETTER SENT] IS NOT NULL AND OCC.[GIFT CARD LETTER SENT 2] IS NOT NULL AND OCC.[GIFT CARD LETTER SENT 3] IS NOT NULL) AND OCC.[Document] IS NOT NULL AND OCC.[Sent to Inspection Vendor] IS NULL AND A.[MCA %] >=97.5 THEN 'NCCI DOOR KNOCK'
	--WHEN A.[MCA %] between 98 AND 99.50 AND OCC.[DOCUMENT] IS NOT NULL AND OCC.[Sent to Inspection Vendor] IS NULL AND datediff(day,cast(OCC.[EXCEPTION REQUEST DATE] as date),getdate()) >=30 THEN 'NCCI DOOR KNOCK'
	--WHEN A.[MCA %] >=99.51 AND OCC.[DOCUMENT] IS NOT NULL AND OCC.[Sent to Inspection Vendor] IS NULL AND datediff(day,cast(OCC.[EXCEPTION REQUEST DATE] as date),getdate()) >=10  THEN 'NCCI DOOR KNOCK'
	--ELSE 'NULL'
	--ADDED NEW LOGIC OCC: 	WHEN A.[MCA %] >=97.5 AND OCC.[Document] IS NOT NULL AND OCC.[Sent to Inspection Vendor] IS NULL THEN 'NCCI DOOR KNOCK'
	--ADDED NEW LOGIC POR - WHEN POR STATUS IN ('REPORT/INSPECTION COMPLETE REPAIRS NOT COMPLETE') DON'T SEND LETTER; 	WHERE E.[EXCEPTION STATUS] NOT IN ('CLOSED','RESOLVED','NOT VALID','INCURABLE','CLOSED WITH VENDOR') AND E.[DOCUMENT] IN ('Proof of Repair') AND E.[Proof of Repairs Status] NOT IN ('REPORT/INSPECTION COMPLETE REPAIRS NOT COMPLETE')
--VERSION 6.4 3/7/2019: EDITED MCA THRESHOLD FOR MAIN QUERY FROM 92 TO 85%
--VERSION 6.5 3/12/2019: REMOVED >=95 MCA RESTRICTION FOR DEATH CERT AND TRUST GC LETTER DROP
--VERSION 6.6 3/19/2019: EDITED NCCI DOOR KNOCK POPULATION MCA RESTRICTION FROM 97.5 TO 97; 	WHEN A.[MCA %] >=97.5 AND OCC.[Document] IS NOT NULL AND OCC.[Sent to Inspection Vendor] IS NULL THEN 'NCCI DOOR KNOCK'
