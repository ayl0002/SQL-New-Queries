DECLARE @START date = ('2017-11-01')
DECLARE @END date = ('2017-11-30')

SELECT
A.[FINAL REVIEW ASSIGNED TO]
,COUNT(A.[Date Submitted to HUD]) AS 'INITIAL'
,COUNT(B.[Resubmitted to HUD]) AS 'RESUBMITTED'

INTO #SUBS
FROM Sharepointdata.dbo.HUDAssignFinalReview A
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignHUDStatus B
ON A.[LOAN NUMBER] = B.[LOAN NUMBER]

WHERE A.[Date Submitted to HUD] BETWEEN @START AND @END OR
B.[RESUBMITTED TO HUD] BETWEEN @START AND @END

GROUP BY A.[Final Review Assigned To]

--SELECT
--A.[FINAL REVIEW ASSIGNED TO]
--,COUNT(B.[Initial Claim Filed]) AS 'CLAIMS FILED'

--INTO #CLAIMS
--FROM Sharepointdata.dbo.HUDAssignFinalReview A
--LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignHUDStatus B
--ON A.[LOAN NUMBER] = B.[LOAN NUMBER]

--WHERE A.[Date Submitted to HUD] BETWEEN @START AND @END OR
--B.[RESUBMITTED TO HUD] BETWEEN @START AND @END

--GROUP BY A.[Final Review Assigned To]

SELECT
c.[Final Review Assigned To]
,SUM(c.[Initial] + c.[Resubmitted])


FROM #SUBS C
--LEFT JOIN #CLAIMS D
--ON D.[FINAL REVIEW ASSIGNED TO] = C.[FINAL REVIEW ASSIGNED TO]
GROUP BY C.[Final Review Assigned To]
DROP TABLE #SUBS --#CLAIMS

