SET ANSI_WARNINGS OFF
SET NOCOUNT ON
SELECT
a.[Loan Number]
,a.[Loan Status]
,a.[property state]
,a.[Pool Name]
,a.[Stage]
,a.[group]
,a.[Tag 2]
,a.[MCA %]
   ,case 
	when a.[MCA %] between '97.50' and '97.99' then '97.5-97.99'
	when a.[MCA %] between '98.00' and '98.50' then '98.00-98.50'
	when a.[MCA %] between '98.51' and '99.00' then '98.51-99.00'
	when a.[MCA %] between '99.01' and '99.50' then '99.01-99.50'
	when a.[MCA %] between '99.51' and '99.99' then '99.51-99.99'
	when a.[MCA %]between '99.51' and '99.99' then '99.5-99.99'
	when a.[MCA %] >= '100.00' then '100+'
	else '<97.49'
	end as 'MCA Bucket'
,case
	when a.[Stage] IN ('Final Review') then b.[Final Review Status]
	else c.[HUD status]
	end as 'Status'
,b.[Final Review Assigned To]
,t.OpenCurative
,t.OpenHACG
,a.[Open Exceptions]
INTO #BASE

FROM SHAREPOINTDATA.DBO.HUDASSIGNLOANS A
left join SharepointData.dbo.HUDAssignFinalReview b
on b.[Loan Number]=a.[Loan Number]
left join SharepointData.dbo.HUDAssignHUDStatus c
on c.[Loan Number]=a.[Loan Number]
left join sharepointdata.dbo.HUDAssignLoanExceptionTotals t
on a.[Loan Number]=t.[Loan Number]

WHERE
a.[Stage] in ('Final Review','HUD status') and
a.[Tag 2] is null and
a.[Loan Status] in ('active') and
a.[MCA %]>=97.5 and
a.[Incurable Flag] in ('0') and
(a.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
a.[Group] is null)and
c.[HUD Status] not in ('HUD Approved','Pkg Submitted to HUD','Resubmitted to HUD','Rebuttal to HUD')

SELECT
A.[Exception ID]
,ISNULL(MAX(A.[Exception Memo]),E.[Exception Description])AS 'MEMO'
INTO #MEMO
FROM SharepointData.DBO.HUDAssignExceptionActions A
JOIN SharepointData.DBO.HUDAssignExceptions E
ON A.[Exception ID]=E.[Exception ID]
WHERE e.[Exception Assigned To] in (
'Tiffany Brown',
'Mary Cox',
'Patrice Shepherd',
'Shadea Lane',
'Brittany Baker',
'Joshua Cyres',
'Shangra Freeman',
'Brandon Terry')

GROUP BY A.[Exception ID], E.[Exception Description]

SELECT
E.[LOAN NUMBER]
,a.[property state]
,E.[Exception ID]
,a.[open exceptions]
,A.[Stage]
,A.[Status]
,A.[MCA %]
,a.[MCA Bucket]
,E.[Exception Assigned To]
,A.[Final Review Assigned To]
,E.[Document]
,E.[Issue]
,convert(nvarchar(10),e.[Exception Request Date],101) as 'Exception Request Date'
,e.[Exception Status]
,M.Memo
,CONVERT(NVARCHAR(10),e.[Exception Status Date],101) AS 'Exception Status Date'
,case 
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date) ,getdate()) <=1  then '1'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date) ,getdate()) between 2 and 5 then '2 to 5'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date) ,getdate()) between 6 and 30 then '6 to 30'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date) ,getdate()) between 31 and 60 then '31 to 60'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date) ,getdate()) between 61 and 90 then '61 to 90'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date) ,getdate()) between 91 and 120 then '91 to 120'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date) ,getdate()) >= 121 then '121+'	
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) <=1  then '1'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 2 and 5 then '2 to 5'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 6 and 30 then '6 to 30'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 31 and 60 then '31 to 60'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 61 and 90 then '61 to 90'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 91 and 120 then '91 to 120'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) >= 121 then '121+'
	end as 'Exception Status Date Aging'
,CAST(C.[HUD PRELIMINARY TITLE DENIAL DATE]AS DATE)AS 'DENIAL DATE'
,CASE
	WHEN DATEDIFF(D,CAST(C.[HUD PRELIMINARY TITLE DENIAL DATE] AS DATE),GETDATE())<=1 THEN '1'
	when datediff(day,cast(C.[HUD PRELIMINARY TITLE DENIAL DATE] as date),getdate()) between 2 and 5 then '2 to 5'
	when datediff(day,cast(C.[HUD PRELIMINARY TITLE DENIAL DATE] as date),getdate()) between 6 and 30 then '6 to 30'
	when datediff(day,cast(C.[HUD PRELIMINARY TITLE DENIAL DATE] as date),getdate()) between 31 and 60 then '31 to 60'
	when datediff(day,cast(C.[HUD PRELIMINARY TITLE DENIAL DATE] as date),getdate()) between 61 and 90 then '61 to 90'
	when datediff(day,cast(C.[HUD PRELIMINARY TITLE DENIAL DATE] as date),getdate()) between 91 and 120 then '91 to 120'
	when datediff(day,cast(C.[HUD PRELIMINARY TITLE DENIAL DATE] as date),getdate()) >= 121 then '121+'
	ELSE 'NEVER DENIED'
	END AS 'DENIAL AGING'

FROM #BASE A
LEFT JOIN SHAREPOINTDATA.dbo.HUDAssignExceptions E
ON A.[Loan Number]=E.[Loan Number]
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignHUDStatus C
ON A.[Loan Number]=C.[Loan Number]
JOIN #MEMO M ON E.[Exception ID]=M.[Exception ID]

WHERE
E.[Document] not in ('Not Doc Issue')
and e.[Exception Status] NOT IN ('Resolved','Not Valid','Cancelled','Closed with Vendor','Incurable','FNMA Denied','NBS Denied')
and e.[Exception Assigned To] in (
'Tiffany Brown',
'Mary Cox',
'Patrice Shepherd',
'Shadea Lane',
'Brittany Baker',
'Joshua Cyres',
'Shangra Freeman',
'Brandon Terry')

DROP TABLE #BASE, #MEMO