SELECT  
    l.[Loan Number]
    ,L.[Group]
    ,f.[Final Review Status]
    ,s.[HUD Status]
    ,l.[Stage] 
    ,f.[Final Review Assigned To]
    ,f.[Final Review Status Updated By]
    ,S.[HUD Assigned To]
    ,f.[MCA]
   ,case 
	when f.MCA between '97.50' and '97.99' then '97.5-97.99'
	when f.MCA between '98.00' and '98.50' then '98.00-98.50'
	when f.MCA between '98.51' and '99.00' then '98.51-99.00'
	when f.MCA between '98.01' and '99.50' then '98.01-99.50'
	when f.MCA between '99.51' and '99.99' then '99.51-99.99'
	when f.MCA between '99.51' and '99.99' then '99.5-99.99'
	when f.MCA > '100.00' then '100+'
	else '<97.49'
	end as 'MCA Bucket'
	
	,case
when [Final Review Assigned To] in ('Anindra Ghosh') then 'Alfredo Saavedra 1' 
when [Final Review Assigned To] in ('Aravindh V') then 'Alfredo Saavedra 1' 
when [Final Review Assigned To] in ('Kalpana Rajendran') then 'Alfredo Saavedra 1' 
when [Final Review Assigned To] in ('Ragavendhra Murugesan') then 'Alfredo Saavedra 1' 
when [Final Review Assigned To] in ('Rakesh Narasimhan Gnana Sekar') then 'Alfredo Saavedra 1' 
when [Final Review Assigned To] in ('Rudhra Murthy Krishnan') then 'Alfredo Saavedra 1' 
when [Final Review Assigned To] in ('Sai Pujitha J') then 'Alfredo Saavedra 1' 
when [Final Review Assigned To] in ('Sai Vignesh Premsai') then 'Alfredo Saavedra 1' 
when [Final Review Assigned To] in ('Sateesh Kumar Vaka') then 'Alfredo Saavedra 1' 
when [Final Review Assigned To] in ('Suvanesan Sundar') then 'Alfredo Saavedra 1' 
when [Final Review Assigned To] in ('Theresa Selvam') then 'Alfredo Saavedra 1' 
when [Final Review Assigned To] in ('Nikita Jaiswal J') then 'Alfredo Saavedra 2' 
when [Final Review Assigned To] in ('Pradeep S') then 'Alfredo Saavedra 2' 
when [Final Review Assigned To] in ('Priyanka E') then 'Alfredo Saavedra 2' 
when [Final Review Assigned To] in ('Rajesh Kumar P') then 'Alfredo Saavedra 2' 
when [Final Review Assigned To] in ('Sathish Kumar P') then 'Alfredo Saavedra 2' 
when [Final Review Assigned To] in ('Shankar Narayanan A') then 'Alfredo Saavedra 2' 
when [Final Review Assigned To] in ('Sivachandran M') then 'Alfredo Saavedra 2' 
when [Final Review Assigned To] in ('Syed Abuthagir S') then 'Alfredo Saavedra 2' 
when [Final Review Assigned To] in ('Venkatachalam M S') then 'Alfredo Saavedra 2' 
when [Final Review Assigned To] in ('Gokula Shankar R') then 'Alfredo Saavedra 3' 
when [Final Review Assigned To] in ('Akshita S') then 'Alfredo Saavedra 3' 
when [Final Review Assigned To] in ('Aishwarya T') then 'Alfredo Saavedra 3' 
when [Final Review Assigned To] in ('Vivek Saravanan') then 'Alfredo Saavedra 3' 
when [Final Review Assigned To] in ('Santhoshi S') then 'Alfredo Saavedra 3' 
when [Final Review Assigned To] in ('Sumithra K') then 'Alfredo Saavedra 3' 
when [Final Review Assigned To] in ('Vishal Dhanajeyan Anand') then 'Alfredo Saavedra 3' 
when [Final Review Assigned To] in ('Vanitha V') then 'Alfredo Saavedra 3' 
when [Final Review Assigned To] in ('Lakshmi Priya Dayalan') then 'Alfredo Saavedra 3' 
when [Final Review Assigned To] in ('Jyothi K') then 'Alfredo Saavedra 3' 
when [Final Review Assigned To] in ('Thenmozhi Vijayakumar') then 'Alfredo Saavedra 3' 
when [Final Review Assigned To] in ('Pradeepa B') then 'Alfredo Saavedra 3' 
when [Final Review Assigned To] in ('Celestina A') then 'Alfredo Saavedra 3' 
when [Final Review Assigned To] in ('Kalaivani K') then 'Alfredo Saavedra 3' 
when [Final Review Assigned To] in ('Kamaleshwaran B') then 'Alfredo Saavedra 3' 
when [Final Review Assigned To] in ('Ananthika Vijayan') then 'Alfredo Saavedra 3' 
when [Final Review Assigned To] in ('Kat Carson') then 'Amanda Burt' 
when [Final Review Assigned To] in ('Brianna Escoto') then 'Amanda Burt' 
when [Final Review Assigned To] in ('Patty Rodriguez') then 'Amanda Burt' 
when [Final Review Assigned To] in ('Briana Morales') then 'Amanda Burt' 
when [Final Review Assigned To] in ('Chaunie Horton') then 'Amanda Burt' 
when [Final Review Assigned To] in ('James Patrone') then 'Amanda Burt' 
when [Final Review Assigned To] in ('Bianca Stimson') then 'Amanda Burt' 
when [Final Review Assigned To] in ('Delilah Smith') then 'Amanda Burt' 
when [Final Review Assigned To] in ('Catrina Wofford') then 'Edward Martin' 
when [Final Review Assigned To] in ('Cynthia Spurlock') then 'Edward Martin' 
when [Final Review Assigned To] in ('Veronica Garcia') then 'Edward Martin' 
when [Final Review Assigned To] in ('Shawneequa Mitchell') then 'Edward Martin' 
when [Final Review Assigned To] in ('Nancy Shead') then 'Edward Martin' 
when [Final Review Assigned To] in ('Sonja Daniel') then 'Edward Martin' 
when [Final Review Assigned To] in ('Shelia White') then 'Edward Martin' 
when [Final Review Assigned To] in ('Marisela Martinez') then 'Edward Martin' 
when [Final Review Assigned To] in ('Tonia Holloman') then 'Edward Martin' 
when [Final Review Assigned To] in ('Ladarius Bryant') then 'Edward Martin' 
when [Final Review Assigned To] in ('Brenda Codoner') then 'Kellie Colegrove' 
when [Final Review Assigned To] in ('Andrika Lasker') then 'Kellie Colegrove' 
when [Final Review Assigned To] in ('Monica Mullen') then 'Kellie Colegrove' 
when [Final Review Assigned To] in ('Shawn Wright') then 'Kellie Colegrove' 
when [Final Review Assigned To] in ('Nacie Williams') then 'Kellie Colegrove' 
when [Final Review Assigned To] in ('Jesse Eyman') then 'Kellie Colegrove' 
when [Final Review Assigned To] in ('Veronica Riley') then 'Kellie Colegrove' 
when [Final Review Assigned To] in ('Lexie Beedle') then 'Kellie Colegrove' 
when [Final Review Assigned To] in ('Jeff Joyner') then 'Madeline Caldwell' 
when [Final Review Assigned To] in ('LaTonia Marshall') then 'Madeline Caldwell' 
when [Final Review Assigned To] in ('Krystal Wallace') then 'Madeline Caldwell' 
when [Final Review Assigned To] in ('Brianne Hamilton') then 'Madeline Caldwell' 
when [Final Review Assigned To] in ('Garrett Carr') then 'Madeline Caldwell' 
when [Final Review Assigned To] in ('Shawn Clayborne-Greer') then 'Madeline Caldwell' 
when [Final Review Assigned To] in ('Sengvilay Heuangpaseuth') then 'Madeline Caldwell' 
when [Final Review Assigned To] in ('Heidi Molina') then 'Madeline Caldwell' 
when [Final Review Assigned To] in ('James McNew') then 'Madeline Caldwell' 
when [Final Review Assigned To] in ('Will Bribiescas') then 'Robert Gough' 
when [Final Review Assigned To] in ('Shanika Stanley') then 'Robert Gough' 
when [Final Review Assigned To] in ('Thomas Matthews') then 'Robert Gough' 
when [Final Review Assigned To] in ('Bryan Petty') then 'Robert Gough' 
when [Final Review Assigned To] in ('Sarah Negrete') then 'Robert Gough' 
when [Final Review Assigned To] in ('Sharon Ezeodogbo') then 'Robert Gough' 
when [Final Review Assigned To] in ('Bridgett Smith') then 'Robert Gough' 
when [Final Review Assigned To] in ('Amber Ledesma') then 'Robert Gough' 
when [Final Review Assigned To] in ('Carmina Dennis') then 'Robert Gough' 
when [Final Review Assigned To] in ('Sherry Alquino') then 'Robert Gough' 
when [Final Review Assigned To] in ('Marisol Trejo') then 'Shannon Harris-Mcbrayer' 
when [Final Review Assigned To] in ('Nikki Carrington') then 'Shannon Harris-Mcbrayer' 
when [Final Review Assigned To] in ('Shameka Easterling') then 'Shannon Harris-Mcbrayer' 
when [Final Review Assigned To] in ('Alexander Ledger') then 'Shannon Harris-Mcbrayer' 
when [Final Review Assigned To] in ('Norse Lockhart') then 'Shannon Harris-Mcbrayer' 
when [Final Review Assigned To] in ('Emiliya Ivanova') then 'Shannon Harris-Mcbrayer' 
when [Final Review Assigned To] in ('Margaret Cantu') then 'Shannon Harris-Mcbrayer' 
when [Final Review Assigned To] in ('Lance Lyons') then 'Shannon Harris-Mcbrayer' 
when [Final Review Assigned To] in ('Shalonda Rodgers') then 'Shannon Harris-Mcbrayer' 
when [Final Review Assigned To] in ('Eric Wallace') then 'Shannon Harris-Mcbrayer'  
end as 'Manager - Final Review'
         
   FROM    [SharepointData].[dbo].[HUDAssignLoans] L (nolock)
    join [SharepointData].[dbo].[HUDAssignFinalReview] F (nolock)
    on f.[Loan Number] = L.[Loan Number]
    join [SharepointData].[dbo].[HUDAssignHUDStatus] S (nolock)
    on s.[Loan Number] = L.[Loan Number]  
    WHERE
    l.[Loan Status] = 'Active' AND
    L.[Tag 2] IS NULL AND
    L.[Stage] IN ('Final Review','HUD Status') AND
    S.[HUD Status] IN ('HUD Denied','Not Started') AND
	F.[Final Review Status] IN ('New File')and
	F.MCA>=97.49
