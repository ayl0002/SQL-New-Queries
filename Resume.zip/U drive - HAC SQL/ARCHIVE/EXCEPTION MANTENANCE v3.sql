SET NOCOUNT ON
Select
a.[loan number]
,case
	when a.[stage] in ('Final Review') then b.[Final Review Assigned To]
	when a.[stage] in ('hud status') then c.[HUD Assigned To]
	end as 'Agent'
INTO #AGENT
FROM SHAREPOINTDATA.DBO.HUDAssignLoans A
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNFINALREVIEW B
ON A.[LOAN NUMBER]=B.[LOAN NUMBER]
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNHUDSTATUS C
ON A.[LOAN NUMBER]=C.[LOAN NUMBER]


SELECT
a.[Loan Number]
,a.[Loan Status]
,a.[Pool Name]
,a.[Stage]
,a.[group]
,a.[Tag 2]
,a.[MCA %]
   ,case 
	when a.[MCA %] between '97.50' and '97.99' then '97.5-97.99'
	when a.[MCA %] between '98.00' and '98.50' then '98.00-98.50'
	when a.[MCA %] between '98.51' and '99.00' then '98.51-99.00'
	when a.[MCA %] between '99.01' and '99.50' then '99.01-99.50'
	when a.[MCA %] between '99.51' and '99.99' then '99.51-99.99'
	when a.[MCA %]between '99.51' and '99.99' then '99.5-99.99'
	when a.[MCA %] >= '100.00' then '100+'
	else '<97.49'
	end as 'MCA Bucket'
,case
	when a.[Stage] IN ('Final Review') then b.[Final Review Status]
	else c.[HUD status]
	end as 'Status'
,N.Agent
,R.MGR_NM
,R.ST_LOC
,r.[LST_UPDT_BY]
,t.OpenCurative
,t.OpenHACG
,a.[Open Exceptions]

INTO #BASE

FROM SHAREPOINTDATA.DBO.HUDASSIGNLOANS A
left join SharepointData.dbo.HUDAssignFinalReview b
on b.[Loan Number]=a.[Loan Number]
left join SharepointData.dbo.HUDAssignHUDStatus c
on c.[Loan Number]=a.[Loan Number]
left join sharepointdata.dbo.HUDAssignLoanExceptionTotals t
on a.[Loan Number]=t.[Loan Number]
LEFT JOIN #AGENT N
on a.[Loan Number]=n.[Loan Number]
LEFT JOIN [VRSQLRODS\RODS_PROD].reverse_dw.dbo.TP_HUD_RSTR r
ON N.Agent=R.AGNT_NM


WHERE
a.[Stage] in ('Final Review','HUD status') and
a.[Tag 2] is null and
a.[Loan Status] in ('active') and
a.[MCA %]>=97.5 and
a.[Incurable Flag] in ('0') and
(a.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
a.[Group] is null) and
c.[HUD Status] not in ('HUD Approved','Pkg Submitted to HUD','Resubmitted to HUD','Rebuttal to HUD')

SELECT
E.[LOAN NUMBER]
,a.[Open Exceptions]
,E.[Exception ID]
,A.[Stage]
,A.[Status]
,A.[MCA %]
,a.[MCA Bucket]
,E.[Exception Assigned To]
,A.Agent
,a.[MGR_NM]
,a.[ST_LOC]
,E.[Document]
,E.[Issue]
,convert(nvarchar(10),e.[Exception Request Date],101) as 'Exception Request Date'
,case
	when datediff(day,cast(e.[Exception Request Date] as date),getdate()) <= 0  then '0-3'
	when datediff(day,cast(e.[Exception Request Date] as date),getdate()) between 0 and 3 then '0-3'
	when datediff(day,cast(e.[Exception Request Date] as date),getdate()) between 4 and 15 then '4 - 15'
	when datediff(day,cast(e.[Exception Request Date] as date),getdate()) between 16 and 30 then '16-30'
	when datediff(day,cast(e.[Exception Request Date] as date),getdate()) between 31 and 45 then '31-45'
	when datediff(day,cast(e.[Exception Request Date] as date),getdate()) between 46 and 60 then '46-60'
	when datediff(day,cast(e.[Exception Request Date] as date),getdate()) between 61 and 90 then '61-90'
	when datediff(day,cast(e.[Exception Request Date] as date),getdate()) >= 91 then '91+'
	end as 'Exception Requested Aging'
,e.[Exception Status]
,CONVERT(NVARCHAR(10),e.[Exception Status Date],101) AS 'Exception Status Date'
,case 
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date) ,getdate()) <=0  then '0-3'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date) ,getdate()) between 0 and 3 then '0-3'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date) ,getdate()) between 4 and 15 then '4-15'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date) ,getdate()) between 16 and 30 then '16-30'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date) ,getdate()) between 31 and 45 then '31-45'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date) ,getdate()) between 46 and 60 then '46-60'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date) ,getdate()) between 61 and 90 then '61-90'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date) ,getdate()) >= 91 then '91+'	
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) <= 0  then '0-3'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 0 and 3 then '0-3'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 4 and 15 then '4-15'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 16 and 30 then '16-30'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 31 and 45 then '31-45'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 46 and 60 then '46-60'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 61 and 90 then '61-90'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) >= 91 then '91+'
	end as 'Exception Status Date Aging'
,case
	when e.[Exception Assigned To] IS null and a.Agent not in ('Bryan Petty') 
		AND [DOCUMENT] IN ('Current Occ Cert','death cert hacg','Flood Insurance','hazard insurance','hoa','tax bill','master policy','Trust - HACG')
		then 'Assign to Clearer'
	when e.[Exception Assigned To] IS null and a.Agent not in ('Bryan Petty') 
		AND [DOCUMENT] not IN ('Current Occ Cert','death cert hacg','Flood Insurance','hazard insurance','hoa','tax bill','master policy','Trust - HACG','Orig Appraisal','proof of repair')
		then a.Agent
	when a.Agent in ('Bryan Petty') then 'Bryan Petty'
	when r.[st_loc] in ('Pipeline Management') and a.Agent not in ('Kari Chadwell','Robert Gough','Chelsea Daniel','Shasta Patton','James Warren','Bryan Petty') 
		AND [DOCUMENT] IN ('Current Occ Cert','death cert hacg','Flood Insurance','hazard insurance','hoa','tax bill','master policy','Trust - HACG')
		then 'Assign to Clearer'
	when r.[st_loc] in ('Pipeline Management') and a.Agent not in ('Kari Chadwell','Robert Gough','Chelsea Daniel','Shasta Patton','James Warren','Bryan Petty') and 
		e.[Document] not in ('Orig Appraisal','proof of repair')
	 then a.Agent
	else 'No Change'
	end as 'Exception Maintenance'

FROM #BASE A
LEFT JOIN SHAREPOINTDATA.dbo.HUDAssignExceptions E
ON A.[Loan Number]=E.[Loan Number]
LEFT JOIN [VRSQLRODS\RODS_PROD].reverse_dw.[dbo].[TP_HUD_RSTR] r
on e.[exception assigned to]=r.[AGNT_NM] --JOINED ON EXCEPTION ASSIGNED TO, NOT FINAL REVIEW ASSIGNED TO--

WHERE
E.[Document] not in ('Not Doc Issue','proof of repair')
and e.[Exception Status] NOT IN ('Resolved','Not Valid','Cancelled','Closed with Vendor','Incurable','FNMA Denied','NBS Denied')
and e.[Work Group] in ('HACG')
--and r.[st_loc] not in ('ISGN')
DROP TABLE #BASE, #AGENT