select 
final.[Loan Count]
,r.MGR_NM
,r.ST_LOC

from
--(SELECT
--a.LOAN_NBR
--,b.FNL_RVW_ASGN_TO_NM
--,r.MGR_NM
--,r.ST_LOC

--FROM REVERSE_DW.[dbo].[HUD_ASGN_LOANS] A
--LEFT JOIN REVERSE_DW.[dbo].[HUD_ASGN_FNL_RVW] B
--ON A.LOAN_NBR=B.LOAN_NBR
--LEFT JOIN REVERSE_DW.[dbo].[HUD_ASGN_HUD_STS] C
--ON A.LOAN_NBR=B.LOAN_NBR
--LEFT JOIN REVERSE_DW.[dbo].[TP_HUD_RSTR] R
--ON B.[FNL_RVW_ASGN_TO_NM]=R.[AGNT_NM]

--where 
--A.CURR_IND='Y' AND C.CURR_IND='Y'AND b.CURR_IND='y'and
--a.[STG_VAL] in ('Final Review','HUD status') and
--a.[TAG_2_VAL] is null and
--a.[LOAN_STS_DESC] in ('active') and
----a.[Open Exceptions] =0 and
----b.[final review assigned to] not in ('Kari Chadwell') and
--a.[MCA_PCT]>=97.5 and
--a.[INCRBL_FLG_DESC] in ('0') and
--(a.[GRP_DESC] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
--a.[GRP_DESC] is null)and
--c.[HUD_STS_DESC] not in ('HUD Approved','Pkg Submitted to HUD','Resubmitted to HUD','Rebuttal to HUD'))base
--join
(SELECT 
b.FNL_RVW_ASGN_TO_NM
,Count(a.LOAN_NBR) as 'Loan Count'


	FROM REVERSE_DW.[dbo].[HUD_ASGN_LOANS] A
LEFT JOIN REVERSE_DW.[dbo].[HUD_ASGN_FNL_RVW] B
ON A.LOAN_NBR=B.LOAN_NBR
LEFT JOIN REVERSE_DW.[dbo].[HUD_ASGN_HUD_STS] C
ON A.LOAN_NBR=B.LOAN_NBR
LEFT JOIN REVERSE_DW.[dbo].[TP_HUD_RSTR] R
ON B.[FNL_RVW_ASGN_TO_NM]=R.[AGNT_NM]
where 
A.CURR_IND='Y'and
a.[STG_VAL] in ('Final Review','HUD status') and
a.[TAG_2_VAL] is null and
a.[LOAN_STS_DESC] in ('active') and
--a.[Open Exceptions] =0 and
--b.[final review assigned to] not in ('Kari Chadwell') and
a.[MCA_PCT]>=97.5 and
a.[INCRBL_FLG_DESC] in ('0') and
(a.[GRP_DESC] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
a.[GRP_DESC] is null)and
c.[HUD_STS_DESC] not in ('HUD Approved','Pkg Submitted to HUD','Resubmitted to HUD','Rebuttal to HUD')

 -- WHERE [LST_UPDT_BY] IN ('PRODUCER','SWAT')

 Group by FNL_RVW_ASGN_TO_NM
 )final
 left join Reverse_dw.[dbo].[TP_HUD_RSTR] r
on final.FNL_RVW_ASGN_TO_NM=r.AGNT_NM

 --on base.FNL_RVW_ASGN_TO_NM=final.FNL_RVW_ASGN_TO_NM
