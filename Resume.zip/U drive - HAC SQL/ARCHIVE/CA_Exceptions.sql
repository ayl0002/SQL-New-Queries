
SELECT 
v.SRC_SYS_CD
,v.LOAN_NBR
,h.HUD_STS_DESC
,cast(v.TXN_PST_DT as date) 'Post Date'
,d.DT_SBMT_TO_HUD 'Submitted Date'

,cast(v.TXN_EFF_DT as date) 'Effective Date'
,v.CELINK_TXN_CD 'Original Tran Code'
,v.[TOT_TXN_AMT] 'Transaction Amount'
,v.UPB_AMT 'Unpaid Balance'
,case when v.PRIN_LMT_BAL_AMT is NULL then '0'
else v.PRIN_LMT_BAL_AMT end as 'Prinipal Limit'
,case when v.INT_AMT IS NULL then '0'
else v.INT_AMT end as 'Integar Amt'
,case when v.MIP_AMT is NULL then '0'
else v.MIP_AMT end as 'MIP Amount'
,case when v.SRVC_FEE_AMT IS NULL then '0'
else v.SRVC_FEE_AMT end as 'Service Fee Amount'
,v.NET_LINE_CR_BAL_AMT

      
      
 FROM [Reverse_DW].[dbo].[RM_MASTER_TXN_VW] V
 join [Reverse_DW].[dbo].[HUD_ASSGN_DT_SBMT_RESBMT] D
 on v.LOAN_NBR = d.LOAN_NBR
 join [Reverse_DW].[dbo].[HUD_ASGN_HUD_STS] H
 on h.LOAN_NBR = d.LOAN_NBR

  
  where 
  
  -----Input Loan Number Below----
  
  cast(v.TXN_PST_DT as date) > d.DT_SBMT_TO_HUD
 
  and v.CELINK_TXN_CD in ('90','91','92','93','95')
  
  and d.LOAN_NBR = '752836'
  
  --and d.CURR_IND = 'Y'
  
  --and h.CURR_IND = 'y'

  -- and d.DT_SBMT_TO_HUD >= '2017-11-01'
  
  --order by TXN_EFF_DT desc