SELECT
[Loan NUMBER]
,[Exception ID]
,[Exception Requestor]
,convert(nvarchar(10),[Exception Request Date],101)as 'Exception Request Date'
,[Work Group]
,[Document]
,[Issue]
,[Exception Status]
,convert(nvarchar(10),[Exception Status Date],101) as 'Exception Status Date'


FROM SharepointData.DBO.HUDAssignExceptions

WHERE [Exception Status] NOT IN ('Resolved','Not Valid','Cancelled','Closed with Vendor','Incurable') 
AND [Document] NOT IN ('HUD LOC ADVANCE')
AND [Loan Number] IN ('2735240',
'1149796',
'1020258',
'845442',
'2717486',
'886106',
'887752',
'845795',
'2154033',
'886955',
'842861',
'2151940',
'889732',
'1152547',
'2682840',
'2844594',
'2462207',
'2744946',
'846001',
'2764598',
'886606',
'863326',
'887321',
'2684604',
'2741727',
'2691328',
'874387',
'887230',
'885800',
'2511627',
'2703969',
'2710092',
'889372',
'2439571',
'2158128',
'843560',
'1029263',
'2683636',
'2755768',
'2806337',
'2199003',
'887642',
'2316506',
'2115956',
'2775067',
'859447')
