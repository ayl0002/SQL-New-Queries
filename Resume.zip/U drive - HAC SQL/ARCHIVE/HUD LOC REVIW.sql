SELECT
a.[Loan Number]
,a.[Loan Status]
,a.[MCA %]
,a.[Tag 2]
,a.[Incurable Flag]
,a.[Stage]
,case
	when a.[Stage] IN ('Final Review') then b.[Final Review Status]
	else c.[HUD status]
	end as 'Status'
,b.[Final Review Assigned To]
,t.OpenCurative
,t.OpenHACG
,t.[Open Exceptions]
,CASE
	WHEN A.[Loan Status] IN ('ACTIVE') AND A.[Incurable Flag] IN ('0') AND T.OpenCurative >=1 THEN 'ELIGIBLE BUT CURATIVE EXCEPTIONS'
	WHEN A.[Loan Status] IN ('ACTIVE') AND A.[Incurable Flag] IN ('0') AND T.OpenCurative =0 AND T.OPENHACG >=1 THEN 'ELIGIBLE BUT EXCEPTIONS'
	WHEN A.[Loan Status] IN ('ACTIVE') AND A.[Incurable Flag] IN ('0') AND T.OpenCurative =0 AND T.OPENHACG =0 THEN 'ELIGIBLE'
	
	ELSE 'NOT ELIGIBLE'
	END AS 'ASSIGNMENT ELIGIBILITY'

FROM SharepointData.DBO.HUDAssignLoans a
left join SharepointData.dbo.HUDAssignFinalReview b
on a.[Loan Number]=b.[Loan Number]
left join sharepointdata.dbo.HUDAssignHUDStatus c
on a.[Loan Number]=c.[Loan Number]
left join SharepointData.dbo.HUDAssignLoanExceptionTotals t
on a.[Loan Number]=t.[Loan Number]

WHERE a.[Loan NUMBER] IN ('2735240',
'1149796',
'1020258',
'845442',
'2717486',
'886106',
'887752',
'845795',
'2154033',
'886955',
'842861',
'2151940',
'889732',
'1152547',
'2682840',
'2844594',
'2462207',
'2744946',
'846001',
'2764598',
'886606',
'863326',
'887321',
'2684604',
'2741727',
'2691328',
'874387',
'887230',
'885800',
'2511627',
'2703969',
'2710092',
'889372',
'2439571',
'2158128',
'843560',
'1029263',
'2683636',
'2755768',
'2806337',
'2199003',
'887642',
'2316506',
'2115956',
'2775067',
'859447')