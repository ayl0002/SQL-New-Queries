select distinct closed.*
, closed2.*
--,closed3.*
,opened.*
,opened2.*
--,opened3.* 
,case
	when closed.Document = opened.Document and closed.Issue = opened.[Issue] and closed.[1st Closed Exception ID]<>opened.[1st Opened Exception ID] then '1st Curative Closed & Same 1st New Opened'
	when closed.Document = opened2.Document and closed.Issue = opened2.[Issue] and closed.[1st Closed Exception ID]<>opened2.[2nd Opened Exception ID]  then '1st Curative Closed & Same 2nd New Opened'
	--when closed.Document = opened3.Document and closed.Issue = opened3.[Issue] and closed.[1st Closed Exception ID]<>opened3.[3rd Opened Exception ID] then '1st Curative Closed & Same 3rd New Opened'
	when closed2.Document = opened.Document and closed2.Issue = opened.[Issue] and closed2.[2nd Closed Exception ID]<>opened.[1st Opened Exception ID]  then '2nd Curative Closed & Same 1st New Opened'
	when closed2.Document = opened2.Document and closed2.Issue = opened2.[Issue] and closed2.[2nd Closed Exception ID]<>opened2.[2nd Opened Exception ID]  then '2nd Curative Closed & Same 2nd New Opened'
	--when closed2.Document = opened3.Document and closed2.Issue = opened3.[Issue] and closed2.[2nd Closed Exception ID]<>opened3.[3rd Opened Exception ID] then '2nd Curative Closed & Same 3rd New Opened'
	--when closed3.Document = opened.Document and closed3.Issue = opened.[Issue] and closed3.[3rd Closed Exception ID]<>opened.[1st Opened Exception ID]then '3rd Curative Closed & Same 1st New Opened'
	--when closed3.Document = opened2.Document and closed3.Issue = opened2.[Issue] and closed3.[3rd Closed Exception ID]<>opened2.[2nd Opened Exception ID] then ' 3rd Curative Closed & Same 2nd New Opened'
	--when closed3.Document = opened3.Document and closed3.Issue = opened3.[Issue] and closed3.[3rd Closed Exception ID]<>opened3.[3rd Opened Exception ID] then '3rd Curative Closed & Same 3rd New Opened'	
	else 'Curative Closed & New Curative Opened'
	
	end as 'Duplicate Flag'
from


--CLOSED--
(select 
a.[Loan number]
,a.[Exception Requestor]
,a.[Exception ID] as '1st Closed Exception ID'
,ROW_NUMBER () OVER (PARTITION BY a.[LOAN NUMBER] ORDER BY a.[Exception ID] asc)RN
,a.[Document]
,a.[Issue]
,a.[Exception Description]
,convert(nvarchar(10),a.[Exception Status Date],101)as '1st Exception Resolved Date'
,a.[Exception Status]
from SharepointData.dbo.HUDAssignExceptions a 
left join sharepointdata.dbo.HUDAssignLoans l
on a.[Loan Number]=l.[Loan Number]
where a.[Exception Status] IN ('Resolved','Not Valid','Cancelled','Closed with Vendor','Incurable')and
a.[work group] in ('Curative','Landtran')and a.[Exception Status Date]>=('2018-05-01') and l.[mca %] >=97.5)closed 

left join(select 
a.[Loan number]
,a.[Exception Requestor]
,a.[Exception ID] as '2nd Closed Exception ID'
,ROW_NUMBER () OVER (PARTITION BY a.[LOAN NUMBER] ORDER BY a.[Exception ID] asc)RN
,a.[Document]
,a.[Issue]
,a.[Exception Description]
,convert(nvarchar(10),a.[Exception Status Date],101)as '2nd Exception Resolved Date'
,a.[Exception Status]
from SharepointData.dbo.HUDAssignExceptions a 
left join sharepointdata.dbo.HUDAssignLoans l
on a.[Loan Number]=l.[Loan Number]
where a.[Exception Status] IN ('Resolved','Not Valid','Cancelled','Closed with Vendor','Incurable')and
a.[work group] in ('Curative','Landtran')and a.[Exception Status Date]>=('2018-05-01') and l.[mca %] >=97.5)closed2

on closed.[loan number]=closed2.[loan number] and closed2.RN=2

--left join(select 
--a.[Loan number]
--,a.[Exception Requestor]
--,a.[Exception ID] as '3rd Closed Exception ID'
--,ROW_NUMBER () OVER (PARTITION BY a.[LOAN NUMBER] ORDER BY a.[Exception ID] asc)RN
--,a.[Document]
--,a.[Issue]
--,a.[Exception Description]
--,convert(nvarchar(10),a.[Exception Status Date],101)as '3rd Exception Resolved Date'
--,a.[Exception Status]
--from SharepointData.dbo.HUDAssignExceptions a 
--left join sharepointdata.dbo.HUDAssignLoans l
--on a.[Loan Number]=l.[Loan Number]
--where a.[Exception Status] IN ('Resolved','Not Valid','Cancelled','Closed with Vendor','Incurable')and
--a.[work group] in ('Curative','Landtran')and a.[Exception Status Date]>=('2018-05-01') and l.[mca %] >=97.5)closed3

--on closed.[loan number]=closed3.[loan number] and closed3.RN=3


--NEW--
join(select 
[Loan Number]
,[Exception Requestor]
,[Exception ID] as '1st Opened Exception ID'
,ROW_NUMBER () OVER (PARTITION BY [LOAN NUMBER] ORDER BY [Exception ID] asc)RN
,[Document]
,[Issue]
,[Exception Description]
,convert(nvarchar(10),[Exception Request Date],101) as '1st Opened Exception Request Date'
,[Exception Status]
from SharepointData.DBO.HUDAssignExceptions
where [work group] in('Curative','Landtran') and
--[Exception Status] not in ('Resolved','Not Valid','Cancelled','Closed with Vendor','Incurable') and
[Exception Request Date] >=('2018-05-01'))opened

on closed.[loan number]=opened.[loan number] and closed.[1st Exception Resolved Date] <= opened.[1st Opened Exception Request Date] and (closed.[1st Closed Exception ID]<>opened.[1st Opened Exception ID] or closed2.[2nd Closed Exception ID]<>opened.[1st Opened Exception ID]) and opened.RN=1
--use below instead of above if extending to 3 exceptions--
--on closed.[loan number]=opened.[loan number] and closed.[1st Exception Resolved Date] <= opened.[1st Opened Exception Request Date] and (closed.[1st Closed Exception ID]<>opened.[1st Opened Exception ID] or closed2.[2nd Closed Exception ID]<>opened.[1st Opened Exception ID] or closed3.[3rd Closed Exception ID]<>opened.[1st Opened Exception ID]) and opened.RN=1

left join(select 
[Loan Number]
,[Exception Requestor]
,[Exception ID] as '2nd Opened Exception ID'
,ROW_NUMBER () OVER (PARTITION BY [LOAN NUMBER] ORDER BY [Exception ID] asc)RN
,[Document]
,[Issue]
,[Exception Description]
,convert(nvarchar(10),[Exception Request Date],101) as '2nd Opened Exception Request Date'
,[Exception Status]
from SharepointData.DBO.HUDAssignExceptions
where [work group] in('Curative','Landtran') and
--[Exception Status] not in ('Resolved','Not Valid','Cancelled','Closed with Vendor','Incurable') and
[Exception Request Date] >=('2018-05-01'))opened2

on opened.[Loan Number]=opened2.[Loan Number] and opened2.RN=2

--left join (select 
--[Loan Number]
--,[Exception Requestor]
--,[Exception ID] as '3rd Opened Exception ID'
--,ROW_NUMBER () OVER (PARTITION BY [LOAN NUMBER] ORDER BY [Exception ID] asc)RN
--,[Document]
--,[Issue]
--,[Exception Description]
--,convert(nvarchar(10),[Exception Request Date],101) as '3rd Opened Exception Request Date'
--,[Exception Status]
--from SharepointData.DBO.HUDAssignExceptions
--where [work group] in('Curative','Landtran') and
----[Exception Status] not in ('Resolved','Not Valid','Cancelled','Closed with Vendor','Incurable') and
--[Exception Request Date] >=('2018-05-01'))opened3

--on opened.[Loan Number]=opened3.[Loan Number] and opened3.RN=3

join TACT_REV.hudAssign.tbl_CureTeamRosters r on opened.[Exception Requestor]=r.Name

where closed.RN=1 
and r.Team not in ('Curative',
'Curative / Assign',
'Curative / Team6',
'Curative / Temp',
'LandTran',
'Offshore / Curative',
'Onshore / DP / Curative')