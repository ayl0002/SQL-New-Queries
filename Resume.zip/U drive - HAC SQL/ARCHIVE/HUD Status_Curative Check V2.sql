select
a.[Loan Number]
,a.[Loan Status]
,a.[Pool Name]
,a.[stage]
,a.[group]
--,a.[Tag 2]
,a.[MCA %]
   ,case 
	when a.[MCA %] between '97.50' and '97.99' then '97.5-97.99'
	when a.[MCA %] between '98.00' and '98.50' then '98.00-98.50'
	when a.[MCA %] between '98.51' and '99.00' then '98.51-99.00'
	when a.[MCA %] between '99.01' and '99.50' then '99.01-99.50'
	when a.[MCA %] between '99.51' and '99.99' then '99.51-99.99'
	when a.[MCA %]between '99.51' and '99.99' then '99.5-99.99'
	when a.[MCA %] >= '100.00' then '100+'
	else '<97.49'
	end as 'MCA Bucket'
,case
	when a.[Stage] IN ('Final Review') then b.[Final Review Status]
	else c.[HUD status]
	end as 'Status'
,b.[Final Review Assigned To]
,a.[Open Exceptions]
,case
	when t.[OpenCurative] =0 and b.[Final Review Assigned To] IN ('Kari Chadwell') AND V.[Certification Date] IS NOT NULL then 'Certified-Curative Cleared'
	when t.[OpenCurative] =0 and b.[Final Review Assigned To] IN ('Kari Chadwell') AND V.[Certification Date] IS NULL then 'Not Certified-Curative Cleared'
	when t.[OpenCurative] >=1 and b.[final review assigned to] not in ('Kari Chadwell') then 'Curative Sweep'
	when t.[OPENCURATIVE] =0 AND B.[FINAL REVIEW ASSIGNED TO] IS NULL AND V.[Certification Date] IS NULL THEN 'Not Certified-New File'
	end as 'HUD Status Maintenance'


from SharepointData.dbo.HUDAssignLoans a
left join SharepointData.dbo.HUDAssignFinalReview b
on b.[Loan Number]=a.[Loan Number]
left join SharepointData.dbo.HUDAssignHUDStatus c
on c.[Loan Number]=a.[Loan Number]
left join sharepointdata.dbo.HUDAssignLoanExceptionTotals t
on a.[Loan Number]=t.[Loan Number]
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNCERTIFICATIONREVIEW V
ON A.[LOAN NUMBER]=V.[LOAN NUMBER]

where --t.OpenCurative  IN ('0') AND
--B.[Final Review Assigned To]  IN ('Kari Chadwell')and 
a.[Stage] in ('FINAL REVIEW','HUD Status') and
	
	((t.[OpenCurative] =0 and b.[Final Review Assigned To] IN ('Kari Chadwell') AND V.[Certification Date] IS NOT NULL) or
	(t.[OpenCurative] =0 and b.[Final Review Assigned To] IN ('Kari Chadwell') AND V.[Certification Date] IS NULL) or
	(t.[OPENCURATIVE] =0 AND B.[FINAL REVIEW ASSIGNED TO] IS NULL AND V.[Certification Date] IS NULL) or
	(t.[OpenCurative] >=1 and b.[final review assigned to] not in ('Kari Chadwell'))) and

a.[Tag 2] is null and
a.[Loan Status] in ('active') and
a.[MCA %]>=97.5 and
c.[HUD Status] not in ('hud approved','hud approval') and
a.[Incurable Flag] in ('0') AND
(a.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
a.[Group] is null)
