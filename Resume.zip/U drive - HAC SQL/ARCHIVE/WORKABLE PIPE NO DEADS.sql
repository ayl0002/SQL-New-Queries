select
a.[Loan Number]
,a.[Loan Status]
,a.[Pool Name]
,a.[Stage]
,a.[group]
,a.[Tag 2]
,a.[MCA %]
   ,case 
	when a.[MCA %] between '97.50' and '97.99' then '97.5-97.99'
	when a.[MCA %] between '98.00' and '98.50' then '98.00-98.50'
	when a.[MCA %] between '98.51' and '99.00' then '98.51-99.00'
	when a.[MCA %] between '99.01' and '99.50' then '99.01-99.50'
	when a.[MCA %] between '99.51' and '99.99' then '99.51-99.99'
	when a.[MCA %]between '99.51' and '99.99' then '99.5-99.99'
	when a.[MCA %] >= '100.00' then '100+'
	else '<97.49'
	end as 'MCA Bucket'
,case
	when a.[Stage] IN ('Final Review') then b.[Final Review Status]
	else c.[HUD status]
	end as 'Status'
,b.[Final Review Assigned To]
,t.OpenCurative
,t.OpenHACG
,case
	when T.[Open Exceptions] = 0 then '0'
	when T.[Open Exceptions] = 1 then '1'
	when T.[Open Exceptions] = 2 then '2'
	when T.[Open Exceptions] >=3 then '3+'
	end as 'Open Exceptions'
,CASE
	WHEN b.[Final Review Status Date] > C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),b.[Final Review Status Date],101)
	WHEN b.[Final Review Status Date] < C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),C.[HUD Status Date],101)
	ELSE CONVERT(NVARCHAR(10),b.[Final Review Status Date],101) END AS 'Last Updated'
,CASE
	WHEN A.[Incurable Flag] NOT IN('0') OR A.[TAG 2] IS NOT NULL THEN 'INCURABLE/TAG2'
	WHEN A.[Loan Status] NOT IN ('ACTIVE') THEN 'INELIGIBLE LOAN STATUS'
	WHEN b.[final review assigned to] IN ('KARI CHADWELL') THEN 'WORKABLE-CURATIVE'
	WHEN B.[Final Review Assigned To] IN ('JAMES WARREN') THEN 'HUD LOC ADVANCE'
	WHEN B.[Final Review Assigned To] IN ('CHELSEA DANIEL') THEN 'ACTIVE LOSS DRAFT'
	WHEN B.[Final Review Assigned To] IN ('ROBERT GOUGH') THEN 'FPI'
	WHEN B.[Final Review Assigned To] IN ('SHASTA PATTON') THEN 'ARM INTEREST'
	WHEN R.Team IN ('ISGN') THEN 'ISGN'
	ELSE 'WORKABLE'
	END AS 'PIPELINE STATUS'

from SharepointData.dbo.HUDAssignLoans a
left join SharepointData.dbo.HUDAssignFinalReview b
on b.[Loan Number]=a.[Loan Number]
left join SharepointData.dbo.HUDAssignHUDStatus c
on c.[Loan Number]=a.[Loan Number]
left join sharepointdata.dbo.HUDAssignLoanExceptionTotals t
on a.[Loan Number]=t.[Loan Number]
left join TACT_REV.hudAssign.tbl_CureTeamRosters r
on b.[Final Review Assigned To]=r.Name

where a.[Stage] in ('Final Review','HUD status') and
a.[Tag 2] is null and
a.[Loan Status] in ('active') and
--a.[Open Exceptions] =0 and
--b.[final review assigned to] not in ('Kari Chadwell') and
a.[MCA %]>=97.5 and
a.[Incurable Flag] in ('0') and
(a.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
a.[Group] is null)and
c.[HUD Status] not in ('HUD Approved','Pkg Submitted to HUD','Resubmitted to HUD','Rebuttal to HUD')
