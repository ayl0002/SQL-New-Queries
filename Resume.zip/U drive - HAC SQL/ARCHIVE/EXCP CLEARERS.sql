SET NOCOUNT ON
SELECT
a.[Loan Number]
,A.[Property Address]
,A.[Property City]
,A.[Property County]
,A.[Property State]
,a.[Loan Status]
,a.[Pool Name]
,a.[Stage]
,a.[group]
,a.[Tag 2]
,a.[MCA %]
   ,case 
	when a.[MCA %] between '97.50' and '97.99' then '97.5-97.99'
	when a.[MCA %] between '98.00' and '98.50' then '98.00-98.50'
	when a.[MCA %] between '98.51' and '99.00' then '98.51-99.00'
	when a.[MCA %] between '99.01' and '99.50' then '99.01-99.50'
	when a.[MCA %] between '99.51' and '99.99' then '99.51-99.99'
	when a.[MCA %]between '99.51' and '99.99' then '99.5-99.99'
	when a.[MCA %] >= '100.00' then '100+'
	else '<97.49'
	end as 'MCA Bucket'
,case
	when a.[Stage] IN ('Final Review') then b.[Final Review Status]
	else c.[HUD status]
	end as 'Status'
,b.[Final Review Assigned To]
,t.OpenCurative
,t.OpenHACG
,a.[Open Exceptions]

INTO #BASE

FROM SHAREPOINTDATA.DBO.HUDASSIGNLOANS A
left join SharepointData.dbo.HUDAssignFinalReview b
on b.[Loan Number]=a.[Loan Number]
left join SharepointData.dbo.HUDAssignHUDStatus c
on c.[Loan Number]=a.[Loan Number]
left join sharepointdata.dbo.HUDAssignLoanExceptionTotals t
on a.[Loan Number]=t.[Loan Number]

WHERE
a.[Stage] in ('Final Review','HUD status') and
a.[Tag 2] is null and
--a.[Open Exceptions] = 1 and
a.[Loan Status] in ('active') and
a.[MCA %]>=97.5 and
a.[Incurable Flag] in ('0') and
(a.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
a.[Group] is null) and
c.[HUD Status] not in ('HUD Approved','Pkg Submitted to HUD','Resubmitted to HUD','Rebuttal to HUD')

SELECT
E.[LOAN NUMBER]
,a.[Property Address]
,A.[Property City]
,A.[Property County]
,A.[Property State]
,a.[Open Exceptions]
,E.[Exception ID]
,A.[Stage]
,A.[Status]
,A.[MCA %]
,a.[MCA Bucket]
,E.[Exception Assigned To]
,A.[Final Review Assigned To]
,E.[Document]
,E.[Issue]
,convert(nvarchar(10),e.[Exception Request Date],101) as 'Exception Request Date'
,case
	when datediff(day,cast(e.[Exception Request Date] as date),getdate()) <= 0  then '0-3'
	when datediff(day,cast(e.[Exception Request Date] as date),getdate()) between 0 and 3 then '0-3'
	when datediff(day,cast(e.[Exception Request Date] as date),getdate()) between 4 and 15 then '4 - 15'
	when datediff(day,cast(e.[Exception Request Date] as date),getdate()) between 16 and 30 then '16-30'
	when datediff(day,cast(e.[Exception Request Date] as date),getdate()) between 31 and 45 then '31-45'
	when datediff(day,cast(e.[Exception Request Date] as date),getdate()) between 46 and 60 then '46-60'
	when datediff(day,cast(e.[Exception Request Date] as date),getdate()) between 61 and 90 then '61-90'
	when datediff(day,cast(e.[Exception Request Date] as date),getdate()) >= 91 then '91+'
	end as 'Exception Requested Aging'
,e.[Exception Status]
,CONVERT(NVARCHAR(10),e.[Exception Status Date],101) AS 'Exception Status Date'
,case 
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date) ,getdate()) <=0  then '0-3'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date) ,getdate()) between 0 and 3 then '0-3'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date) ,getdate()) between 4 and 15 then '4-15'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date) ,getdate()) between 16 and 30 then '16-30'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date) ,getdate()) between 31 and 45 then '31-45'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date) ,getdate()) between 46 and 60 then '46-60'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date) ,getdate()) between 61 and 90 then '61-90'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date) ,getdate()) >= 91 then '91+'	
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) <= 0  then '0-3'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 0 and 3 then '0-3'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 4 and 15 then '4-15'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 16 and 30 then '16-30'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 31 and 45 then '31-45'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 46 and 60 then '46-60'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 61 and 90 then '61-90'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) >= 91 then '91+'
	end as 'Exception Status Date Aging'
,case
	when a.[final review assigned to] IN ('Kari Chadwell') and a.[Final Review Assigned To] <> e.[Exception Assigned To] then 'Curative Sweep'
	when a.[final review assigned to] IN ('Kari Chadwell') and e.[Exception Assigned To] is null then 'Curative Sweep'
	when a.[Final Review Assigned To] not in ('Kari Chadwell') and e.[Exception Assigned To] IN ('Kari Chadwell') then 'Curative Cleared'
	when e.[Exception Assigned To] IS null and a.[Final Review Assigned To] not in ('Kari Chadwell') then 'New Exception'
	else 'No Change'
	end as 'Exception Maintenance'

FROM #BASE A
LEFT JOIN SHAREPOINTDATA.dbo.HUDAssignExceptions E
ON A.[Loan Number]=E.[Loan Number]

WHERE
E.[Document] not in ('Not Doc Issue')
and e.[Document] in ('Hazard Insurance')
and e.[Exception Status] NOT IN ('Resolved','Not Valid','Cancelled','Closed with Vendor','Incurable','FNMA Denied','NBS Denied')
and e.[Work Group] in ('HACG')
--and e.[exception id] in ()
--and a.[Final Review Assigned To] not in ('Kari Chadwell') 
--and a.[Final Review Assigned To] <> e.[Exception Assigned To]
--and e.[Exception Assigned To] is null --in (
--and a.[Loan Number] in ()

DROP TABLE #BASE