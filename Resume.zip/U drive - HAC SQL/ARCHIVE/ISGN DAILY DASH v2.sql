SET NOCOUNT ON
SELECT
[LoanNumber]
,MAX(R.DateSubmittedToHUD) AS 'Submit Date'
INTO #SUB
FROM SHAREPOINTDATA.dbo.HUDAssignDateSubmittedResubmittedtoHUD R
GROUP BY [LOANNUMBER]

select distinct
a.[LOAN NUMBER]
,CASE
	WHEN b.[Final Review Status Date] >= C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),b.[Final Review Status Date],101)
	WHEN b.[Final Review Status Date] < C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),C.[HUD Status Date],101)
	ELSE CONVERT(NVARCHAR(10),b.[Final Review Status Date],101) END AS 'Last Updated'
INTO #UPDATE
FROM SharepointData.dbo.HUDAssignLoans a
left join SHAREPOINTDATA.DBO.HUDAssignFinalReview B
on a.[Loan Number]=b.[Loan Number]
LEFT JOIN SharepointData.DBO.HUDAssignHUDStatus C
ON a.[Loan Number]=C.[Loan Number]
WHERE B.Stage IN ('Final Review','HUD Status')

SELECT
B.[LOAN NUMBER]
,CONVERT(NVARCHAR(10),D.[Exception Status Date],101) as 'Last Exception Update'
,ROW_NUMBER () OVER (PARTITION BY D.[LOAN NUMBER] ORDER BY D.[Exception Status Date] desc)RN 
into #EXCEPTION
FROM SHAREPOINTDATA.DBO.HUDASSIGNHUDSTATUS B
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS D
ON B.[LOAN NUMBER] = D.[LOAN NUMBER]

--BASE QUERY--
SELECT
A.[LOAN NUMBER]
,a.[Loan Status]
,B.[FINAL REVIEW ASSIGNED TO]
,A.[Open Exceptions]
,case
	when r.[Submit Date] >=('2018-04-01') then CONVERT(NVARCHAR(10),r.[Submit Date],101)
	else 'NULL'
	end as 'Submit Date'
	
,case
	when c.[HUD Status] in ('HUD Approved','HUD Approval') and CONVERT(nvarchar(10),r.[Submit Date],101) IS not null then 'HUD Approved'
	when a.[Loan Status] not IN ('Active','Liquidated/Assigned to HUD') then 'Not Submittable'
	when c.[HUD Status] IN ('Resubmitted to HUD','Rebuttal to HUD') and b.[Final Review Assigned To] IN ('Heidi Molina','Brianne Hamilton') then 'Resubmission'
	when c.[HUD Status] in ('Pkg Submitted to HUD','Resubmitted to HUD','Rebuttal to HUD') and c.[HUD Status] not in ('HUD Denied') and CONVERT(nvarchar(10),r.[Submit Date],101)IS not null then 'Submitted'
	when (c.[HUD Status] not IN ('HUD Approved','Pkg Submitted to HUD','Resubmitted to HUD','Rebuttal to HUD') and CONVERT(nvarchar(10),r.[Submit Date],101)is null) Or c.[HUD Status] in ('HUD Denied') then 'Not Submitted'
	when a.[Loan Status] not IN ('Active','Liquidated/Assigned to HUD') then 'Not Submittable'
	end as 'Pending @ HUD'
,case
	when C.[HUD Status] IN ('Pkg Submitted to HUD','Not Started') then B.[Final Review Status]
	else C.[HUD Status]
	end as 'Status'	
,Z.[Last Exception Update]
,case
	when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) < 0  then '0-15'
	when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) between 0 and 15 then '0-15'
	when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) between 16 and 30 then '16-30'
	when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) between 31 and 45 then '31-45'
	when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) between 46 and 60 then '46-60'
	when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) between 61 and 90 then '61-90'
	when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) > 91 then '91+'
end as 'Exception Update Aging'
,U.[Last Updated]
,CASE
when datediff(day,cast(U.[Last Updated] as date),getdate()) < 0  then '0-3'
	when datediff(day,cast(U.[Last Updated] as date),getdate()) between 0 and 3 then '0-3'
	when datediff(day,cast(U.[Last Updated] as date),getdate()) between 4 and 15 then '4-15'
	when datediff(day,cast(U.[Last Updated] as date),getdate()) between 16 and 30 then '16-30'
	when datediff(day,cast(U.[Last Updated] as date),getdate()) between 31 and 45 then '31-45'
	when datediff(day,cast(U.[Last Updated] as date),getdate()) between 46 and 60 then '46-60'
	when datediff(day,cast(U.[Last Updated] as date),getdate()) between 61 and 90 then '61-90'
	when datediff(day,cast(U.[Last Updated] as date),getdate()) >= 91 then '91+'
	END AS 'Last Update Aging'
,CASE
	WHEN B.[Final Review Comment] > C.[HUD Status Comment] THEN B.[Final Review Comment]
	WHEN B.[Final Review Comment] < C.[HUD Status Comment] THEN C.[HUD Status Comment]
	ELSE B.[Final Review Comment]  END AS 'Last Comment'
,case
when a.[loan number] in ('849841') then 'Week 1' 
when a.[loan number] in ('849249') then 'Week 1' 
when a.[loan number] in ('880020') then 'Week 1' 
when a.[loan number] in ('761983') then 'Week 1' 
when a.[loan number] in ('740910') then 'Week 1' 
when a.[loan number] in ('747818') then 'Week 1' 
when a.[loan number] in ('753869') then 'Week 1' 
when a.[loan number] in ('742419') then 'Week 1' 
when a.[loan number] in ('1060197') then 'Week 1' 
when a.[loan number] in ('1045649') then 'Week 1' 
when a.[loan number] in ('741479') then 'Week 1' 
when a.[loan number] in ('889868') then 'Week 1' 
when a.[loan number] in ('2298571') then 'Week 1' 
when a.[loan number] in ('2337033') then 'Week 1' 
when a.[loan number] in ('2546786') then 'Week 1' 
when a.[loan number] in ('2658895') then 'Week 1' 
when a.[loan number] in ('2712334') then 'Week 1' 
when a.[loan number] in ('2758863') then 'Week 1' 
when a.[loan number] in ('2792503') then 'Week 1' 
when a.[loan number] in ('1154547') then 'Week 1' 
when a.[loan number] in ('761441') then 'Week 1' 
when a.[loan number] in ('756259') then 'Week 1' 
when a.[loan number] in ('2738312') then 'Week 1' 
when a.[loan number] in ('1048611') then 'Week 1' 
when a.[loan number] in ('742413') then 'Week 1' 
when a.[loan number] in ('746977') then 'Week 1' 
when a.[loan number] in ('2465870') then 'Week 1' 
when a.[loan number] in ('2733497') then 'Week 1' 
when a.[loan number] in ('844907') then 'Week 1' 
when a.[loan number] in ('1057248') then 'Week 1' 
when a.[loan number] in ('1038215') then 'Week 1' 
when a.[loan number] in ('848341') then 'Week 1' 
when a.[loan number] in ('754938') then 'Week 1' 
when a.[loan number] in ('2784558') then 'Week 1' 
when a.[loan number] in ('1026538') then 'Week 1' 
when a.[loan number] in ('1043130') then 'Week 1' 
when a.[loan number] in ('2401485') then 'Week 1' 
when a.[loan number] in ('765801') then 'Week 1' 
when a.[loan number] in ('1064581') then 'Week 1' 
when a.[loan number] in ('846353') then 'Week 1' 
when a.[loan number] in ('845453') then 'Week 1' 
when a.[loan number] in ('886951') then 'Week 1' 
when a.[loan number] in ('869256') then 'Week 1' 
when a.[loan number] in ('2600681') then 'Week 1' 
when a.[loan number] in ('2584863') then 'Week 1' 
when a.[loan number] in ('2611684') then 'Week 1' 
when a.[loan number] in ('2807372') then 'Week 1' 
when a.[loan number] in ('2670755') then 'Week 1' 
when a.[loan number] in ('768603') then 'Week 1' 
when a.[loan number] in ('2465905') then 'Week 1' 
when a.[loan number] in ('2738298') then 'Week 1' 
when a.[loan number] in ('2620721') then 'Week 1' 
when a.[loan number] in ('2747654') then 'Week 1' 
when a.[loan number] in ('1036735') then 'Week 1' 
when a.[loan number] in ('756274') then 'Week 1' 
when a.[loan number] in ('867114') then 'Week 1' 
when a.[loan number] in ('845126') then 'Week 1' 
when a.[loan number] in ('2740646') then 'Week 1' 
when a.[loan number] in ('849191') then 'Week 1' 
when a.[loan number] in ('762357') then 'Week 1' 
when a.[loan number] in ('1025600') then 'Week 1' 
when a.[loan number] in ('2421877') then 'Week 1' 
when a.[loan number] in ('767265') then 'Week 1' 
when a.[loan number] in ('2435566') then 'Week 1' 
when a.[loan number] in ('1026053') then 'Week 1' 
when a.[loan number] in ('852951') then 'Week 1' 
when a.[loan number] in ('2655460') then 'Week 1' 
when a.[loan number] in ('1062142') then 'Week 1' 
when a.[loan number] in ('768699') then 'Week 1' 
when a.[loan number] in ('2751398') then 'Week 1' 
when a.[loan number] in ('1065838') then 'Week 1' 
when a.[loan number] in ('766049') then 'Week 1' 
when a.[loan number] in ('2637560') then 'Week 1' 
when a.[loan number] in ('852716') then 'Week 1' 
when a.[loan number] in ('862594') then 'Week 1' 
when a.[loan number] in ('2639118') then 'Week 1' 
when a.[loan number] in ('2455969') then 'Week 1' 
when a.[loan number] in ('741468') then 'Week 1' 
when a.[loan number] in ('1041776') then 'Week 1' 
when a.[loan number] in ('862799') then 'Week 1' 
when a.[loan number] in ('1032218') then 'Week 1' 
when a.[loan number] in ('752259') then 'Week 1' 
when a.[loan number] in ('887478') then 'Week 1' 
when a.[loan number] in ('2712595') then 'Week 1' 
when a.[loan number] in ('855038') then 'Week 1' 
when a.[loan number] in ('756523') then 'Week 1' 
when a.[loan number] in ('2731656') then 'Week 1' 
when a.[loan number] in ('1076457') then 'Week 1' 
when a.[loan number] in ('2629092') then 'Week 1' 
when a.[loan number] in ('1068497') then 'Week 1' 
when a.[loan number] in ('1048401') then 'Week 1' 
when a.[loan number] in ('2144995') then 'Week 1' 
when a.[loan number] in ('762066') then 'Week 1' 
when a.[loan number] in ('760347') then 'Week 1' 
when a.[loan number] in ('2697222') then 'Week 1' 
when a.[loan number] in ('1048030') then 'Week 1' 
when a.[loan number] in ('1084010') then 'Week 1' 
when a.[loan number] in ('1039446') then 'Week 1' 
when a.[loan number] in ('2743477') then 'Week 1' 
when a.[loan number] in ('1046561') then 'Week 1' 
when a.[loan number] in ('2408460') then 'Week 1' 
when a.[loan number] in ('766499') then 'Week 1' 
when a.[loan number] in ('1051177') then 'Week 1' 
when a.[loan number] in ('1061873') then 'Week 1' 
when a.[loan number] in ('2302588') then 'Week 1' 
when a.[loan number] in ('855116') then 'Week 1' 
when a.[loan number] in ('761481') then 'Week 1' 
when a.[loan number] in ('1035026') then 'Week 1' 
when a.[loan number] in ('848087') then 'Week 1' 
when a.[loan number] in ('2718090') then 'Week 1' 
when a.[loan number] in ('2453923') then 'Week 1' 
when a.[loan number] in ('762352') then 'Week 1' 
when a.[loan number] in ('2694047') then 'Week 1' 
when a.[loan number] in ('2754869') then 'Week 1' 
when a.[loan number] in ('1047353') then 'Week 1' 
when a.[loan number] in ('1039004') then 'Week 1' 
when a.[loan number] in ('2752561') then 'Week 1' 
when a.[loan number] in ('1044061') then 'Week 1' 
when a.[loan number] in ('2597619') then 'Week 1' 
when a.[loan number] in ('1062932') then 'Week 1' 
when a.[loan number] in ('2697938') then 'Week 1' 
when a.[loan number] in ('741790') then 'Week 1' 
when a.[loan number] in ('2511046') then 'Week 1' 
when a.[loan number] in ('755936') then 'Week 1' 
when a.[loan number] in ('2121761') then 'Week 1' 
when a.[loan number] in ('2712312') then 'Week 1' 
when a.[loan number] in ('2463479') then 'Week 1' 
when a.[loan number] in ('2856372') then 'Week 1' 
when a.[loan number] in ('843681') then 'Week 1' 
when a.[loan number] in ('1033040') then 'Week 1' 
when a.[loan number] in ('753255') then 'Week 1' 
when a.[loan number] in ('768214') then 'Week 1' 
when a.[loan number] in ('2441290') then 'Week 1' 
when a.[loan number] in ('2706370') then 'Week 1' 
when a.[loan number] in ('745798') then 'Week 1' 
when a.[loan number] in ('1065406') then 'Week 1' 
when a.[loan number] in ('852469') then 'Week 1' 
when a.[loan number] in ('1083854') then 'Week 1' 
when a.[loan number] in ('1062091') then 'Week 1' 
when a.[loan number] in ('2665941') then 'Week 1' 
when a.[loan number] in ('2594901') then 'Week 1' 
when a.[loan number] in ('756521') then 'Week 1' 
when a.[loan number] in ('2502089') then 'Week 1' 
when a.[loan number] in ('1060498') then 'Week 1' 
when a.[loan number] in ('2693262') then 'Week 1' 
when a.[loan number] in ('2459510') then 'Week 1' 
when a.[loan number] in ('2748780') then 'Week 1' 
when a.[loan number] in ('1071387') then 'Week 1' 
when a.[loan number] in ('2137064') then 'Week 1' 
when a.[loan number] in ('1055048') then 'Week 1' 
when a.[loan number] in ('1064158') then 'Week 1' 
when a.[loan number] in ('2696868') then 'Week 1' 
when a.[loan number] in ('2461978') then 'Week 1' 
when a.[loan number] in ('2715736') then 'Week 1' 
when a.[loan number] in ('2613631') then 'Week 1' 
when a.[loan number] in ('2620402') then 'Week 1' 
when a.[loan number] in ('889227') then 'Week 1' 
when a.[loan number] in ('1028743') then 'Week 1' 
when a.[loan number] in ('1058730') then 'Week 1' 
when a.[loan number] in ('1030149') then 'Week 1' 
when a.[loan number] in ('848387') then 'Week 1' 
when a.[loan number] in ('887176') then 'Week 1' 
when a.[loan number] in ('2698267') then 'Week 1' 
when a.[loan number] in ('748231') then 'Week 1' 
when a.[loan number] in ('2512183') then 'Week 1' 
when a.[loan number] in ('1062802') then 'Week 1' 
when a.[loan number] in ('841750') then 'Week 1' 
when a.[loan number] in ('2769651') then 'Week 1' 
when a.[loan number] in ('745952') then 'Week 1' 
when a.[loan number] in ('2634910') then 'Week 1' 
when a.[loan number] in ('406405') then 'Week 1' 
when a.[loan number] in ('1040805') then 'Week 1' 
when a.[loan number] in ('761480') then 'Week 1' 
when a.[loan number] in ('891109') then 'Week 1' 
when a.[loan number] in ('891381') then 'Week 1' 
when a.[loan number] in ('1053340') then 'Week 1' 
when a.[loan number] in ('1067870') then 'Week 1' 
when a.[loan number] in ('1059549') then 'Week 1' 
when a.[loan number] in ('1059405') then 'Week 1' 
when a.[loan number] in ('748697') then 'Week 2' 
when a.[loan number] in ('747253') then 'Week 2' 
when a.[loan number] in ('766108') then 'Week 2' 
when a.[loan number] in ('1151675') then 'Week 2' 
when a.[loan number] in ('762166') then 'Week 2' 
when a.[loan number] in ('756314') then 'Week 2' 
when a.[loan number] in ('744834') then 'Week 2' 
when a.[loan number] in ('741555') then 'Week 2' 
when a.[loan number] in ('760916') then 'Week 2' 
when a.[loan number] in ('751721') then 'Week 2' 
when a.[loan number] in ('750866') then 'Week 2' 
when a.[loan number] in ('749407') then 'Week 2' 
when a.[loan number] in ('746811') then 'Week 2' 
when a.[loan number] in ('740148') then 'Week 2' 
when a.[loan number] in ('766092') then 'Week 2' 
when a.[loan number] in ('756288') then 'Week 2' 
when a.[loan number] in ('745912') then 'Week 2' 
when a.[loan number] in ('759583') then 'Week 2' 
when a.[loan number] in ('754694') then 'Week 2' 
when a.[loan number] in ('748632') then 'Week 2' 
when a.[loan number] in ('745186') then 'Week 2' 
when a.[loan number] in ('768946') then 'Week 2' 
when a.[loan number] in ('745057') then 'Week 2' 
when a.[loan number] in ('1152953') then 'Week 2' 
when a.[loan number] in ('748114') then 'Week 2' 
when a.[loan number] in ('764226') then 'Week 2' 
when a.[loan number] in ('740136') then 'Week 2' 
when a.[loan number] in ('1150480') then 'Week 2' 
when a.[loan number] in ('751708') then 'Week 2' 
when a.[loan number] in ('748636') then 'Week 2' 
when a.[loan number] in ('764009') then 'Week 2' 
when a.[loan number] in ('755662') then 'Week 2' 
when a.[loan number] in ('752661') then 'Week 2' 
when a.[loan number] in ('746263') then 'Week 2' 
when a.[loan number] in ('740464') then 'Week 2' 
when a.[loan number] in ('764961') then 'Week 2' 
when a.[loan number] in ('752614') then 'Week 2' 
when a.[loan number] in ('750134') then 'Week 2' 
when a.[loan number] in ('746966') then 'Week 2' 
when a.[loan number] in ('745962') then 'Week 2' 
when a.[loan number] in ('766099') then 'Week 2' 
when a.[loan number] in ('762908') then 'Week 2' 
when a.[loan number] in ('759310') then 'Week 2' 
when a.[loan number] in ('751723') then 'Week 2' 
when a.[loan number] in ('749073') then 'Week 2' 
when a.[loan number] in ('748840') then 'Week 2' 
when a.[loan number] in ('745261') then 'Week 2' 
when a.[loan number] in ('744333') then 'Week 2' 
when a.[loan number] in ('768192') then 'Week 2' 
when a.[loan number] in ('766022') then 'Week 2' 
when a.[loan number] in ('762216') then 'Week 2' 
when a.[loan number] in ('756298') then 'Week 2' 
when a.[loan number] in ('752038') then 'Week 2' 
when a.[loan number] in ('744807') then 'Week 2' 
when a.[loan number] in ('764296') then 'Week 2' 
when a.[loan number] in ('740900') then 'Week 2' 
when a.[loan number] in ('754494') then 'Week 2' 
when a.[loan number] in ('756763') then 'Week 2' 
when a.[loan number] in ('761143') then 'Week 2' 
when a.[loan number] in ('757889') then 'Week 2' 
when a.[loan number] in ('750982') then 'Week 2' 
when a.[loan number] in ('747521') then 'Week 2' 
when a.[loan number] in ('741848') then 'Week 2' 
when a.[loan number] in ('758068') then 'Week 2' 
when a.[loan number] in ('759232') then 'Week 2' 
when a.[loan number] in ('759229') then 'Week 2' 
when a.[loan number] in ('749279') then 'Week 2' 
when a.[loan number] in ('766670') then 'Week 2' 
when a.[loan number] in ('754495') then 'Week 2' 
when a.[loan number] in ('748241') then 'Week 2' 
when a.[loan number] in ('765423') then 'Week 2' 
when a.[loan number] in ('742646') then 'Week 2' 
when a.[loan number] in ('767235') then 'Week 2' 
when a.[loan number] in ('743377') then 'Week 2' 
when a.[loan number] in ('763407') then 'Week 2' 
when a.[loan number] in ('759792') then 'Week 2' 
when a.[loan number] in ('746822') then 'Week 2' 
when a.[loan number] in ('1153298') then 'Week 2' 
when a.[loan number] in ('1153829') then 'Week 2' 
when a.[loan number] in ('763804') then 'Week 2' 
when a.[loan number] in ('759999') then 'Week 2' 
when a.[loan number] in ('1153446') then 'Week 2' 
when a.[loan number] in ('766993') then 'Week 2' 
when a.[loan number] in ('766739') then 'Week 2' 
when a.[loan number] in ('766297') then 'Week 2' 
when a.[loan number] in ('766121') then 'Week 2' 
when a.[loan number] in ('765182') then 'Week 2' 
when a.[loan number] in ('764270') then 'Week 2' 
when a.[loan number] in ('762593') then 'Week 2' 
when a.[loan number] in ('759910') then 'Week 2' 
when a.[loan number] in ('759838') then 'Week 2' 
when a.[loan number] in ('757657') then 'Week 2' 
when a.[loan number] in ('755866') then 'Week 2' 
when a.[loan number] in ('749974') then 'Week 2' 
when a.[loan number] in ('749184') then 'Week 2' 
when a.[loan number] in ('745462') then 'Week 2' 
when a.[loan number] in ('745275') then 'Week 2' 
when a.[loan number] in ('744150') then 'Week 2' 
when a.[loan number] in ('742673') then 'Week 2' 
when a.[loan number] in ('766965') then 'Week 2' 
when a.[loan number] in ('765380') then 'Week 2' 
when a.[loan number] in ('761638') then 'Week 2' 
when a.[loan number] in ('761293') then 'Week 2' 
when a.[loan number] in ('759643') then 'Week 2' 
when a.[loan number] in ('758751') then 'Week 2' 
when a.[loan number] in ('1150658') then 'Week 2' 
when a.[loan number] in ('755516') then 'Week 2' 
when a.[loan number] in ('754544') then 'Week 2' 
when a.[loan number] in ('753417') then 'Week 2' 
when a.[loan number] in ('752845') then 'Week 2' 
when a.[loan number] in ('749730') then 'Week 2' 
when a.[loan number] in ('748224') then 'Week 2' 
when a.[loan number] in ('744391') then 'Week 2' 
when a.[loan number] in ('741374') then 'Week 2' 
when a.[loan number] in ('741138') then 'Week 2' 
when a.[loan number] in ('766534') then 'Week 2' 
when a.[loan number] in ('758107') then 'Week 2' 
when a.[loan number] in ('753033') then 'Week 2' 
when a.[loan number] in ('748261') then 'Week 2' 
when a.[loan number] in ('747939') then 'Week 2' 
when a.[loan number] in ('743385') then 'Week 2' 
when a.[loan number] in ('740386') then 'Week 2' 
when a.[loan number] in ('740094') then 'Week 2' 
when a.[loan number] in ('768645') then 'Week 2' 
when a.[loan number] in ('768453') then 'Week 2' 
when a.[loan number] in ('767501') then 'Week 2' 
when a.[loan number] in ('760262') then 'Week 2' 
when a.[loan number] in ('759014') then 'Week 2' 
when a.[loan number] in ('754953') then 'Week 2' 
when a.[loan number] in ('752486') then 'Week 2' 
when a.[loan number] in ('751263') then 'Week 2' 
when a.[loan number] in ('750870') then 'Week 2' 
when a.[loan number] in ('745983') then 'Week 2' 
when a.[loan number] in ('745827') then 'Week 2' 
when a.[loan number] in ('745174') then 'Week 2' 
when a.[loan number] in ('742089') then 'Week 2' 
when a.[loan number] in ('741820') then 'Week 2' 
when a.[loan number] in ('741258') then 'Week 2' 
when a.[loan number] in ('766599') then 'Week 2' 
when a.[loan number] in ('758552') then 'Week 2' 
when a.[loan number] in ('753733') then 'Week 2' 
when a.[loan number] in ('765256') then 'Week 2' 
when a.[loan number] in ('759955') then 'Week 2' 
when a.[loan number] in ('1151993') then 'Week 2' 
when a.[loan number] in ('749506') then 'Week 2' 
when a.[loan number] in ('749791') then 'Week 2' 
when a.[loan number] in ('745953') then 'Week 2' 
when a.[loan number] in ('744053') then 'Week 2' 
when a.[loan number] in ('745284') then 'Week 2' 
when a.[loan number] in ('753747') then 'Week 2' 
when a.[loan number] in ('1153342') then 'Week 2' 
when a.[loan number] in ('751413') then 'Week 2' 
when a.[loan number] in ('754112') then 'Week 2' 
when a.[loan number] in ('750416') then 'Week 2' 
when a.[loan number] in ('754974') then 'Week 2' 
when a.[loan number] in ('746968') then 'Week 2' 
when a.[loan number] in ('759235') then 'Week 2' 
when a.[loan number] in ('843573') then 'Week 2' 
when a.[loan number] in ('2608202') then 'Week 2' 
when a.[loan number] in ('2472539') then 'Week 2' 
when a.[loan number] in ('2455947') then 'Week 2' 
when a.[loan number] in ('2455732') then 'Week 2' 
when a.[loan number] in ('2623063') then 'Week 2' 
when a.[loan number] in ('2844344') then 'Week 2' 
when a.[loan number] in ('2809089') then 'Week 2' 
when a.[loan number] in ('2800104') then 'Week 2' 
when a.[loan number] in ('2797109') then 'Week 2' 
when a.[loan number] in ('2771223') then 'Week 2' 
when a.[loan number] in ('2750046') then 'Week 2' 
when a.[loan number] in ('2747313') then 'Week 2' 
when a.[loan number] in ('2734227') then 'Week 2' 
when a.[loan number] in ('2733180') then 'Week 2' 
when a.[loan number] in ('2731543') then 'Week 2' 
when a.[loan number] in ('2720425') then 'Week 2' 
when a.[loan number] in ('2716737') then 'Week 2' 
when a.[loan number] in ('2705471') then 'Week 2' 
when a.[loan number] in ('2695663') then 'Week 2' 
when a.[loan number] in ('2666566') then 'Week 2' 
when a.[loan number] in ('2654107') then 'Week 2' 
when a.[loan number] in ('2637753') then 'Week 2' 
when a.[loan number] in ('2613744') then 'Week 2' 
when a.[loan number] in ('2599542') then 'Week 2' 
when a.[loan number] in ('2594206') then 'Week 2' 
when a.[loan number] in ('2587764') then 'Week 2' 
when a.[loan number] in ('2554823') then 'Week 2' 
when a.[loan number] in ('2527204') then 'Week 2' 
when a.[loan number] in ('2506813') then 'Week 2' 
when a.[loan number] in ('2395432') then 'Week 2' 
when a.[loan number] in ('2155341') then 'Week 2' 
when a.[loan number] in ('863896') then 'Week 2' 
when a.[loan number] in ('842574') then 'Week 2' 
when a.[loan number] in ('1062751') then 'Week 2' 
when a.[loan number] in ('1088589') then 'Week 2' 
when a.[loan number] in ('1067834') then 'Week 2' 
when a.[loan number] in ('1063415') then 'Week 2' 
when a.[loan number] in ('1057923') then 'Week 2' 
when a.[loan number] in ('1059545') then 'Week 2' 
when a.[loan number] in ('867711') then 'Week 2' 
when a.[loan number] in ('844815') then 'Week 2' 
when a.[loan number] in ('894871') then 'Week 2' 
when a.[loan number] in ('886247') then 'Week 2' 
when a.[loan number] in ('896186') then 'Week 2' 
when a.[loan number] in ('2403056') then 'Week 2' 
when a.[loan number] in ('1072212') then 'Week 2' 
when a.[loan number] in ('846502') then 'Week 2' 
when a.[loan number] in ('2131990') then 'Week 2' 
when a.[loan number] in ('2806337') then 'Week 2' 
when a.[loan number] in ('1046687') then 'Week 2' 
when a.[loan number] in ('843036') then 'Week 2' 
when a.[loan number] in ('2708806') then 'Week 2' 
when a.[loan number] in ('2130502') then 'Week 2' 
when a.[loan number] in ('1023893') then 'Week 2' 
when a.[loan number] in ('880222') then 'Week 2' 
when a.[loan number] in ('2801980') then 'Week 2' 
when a.[loan number] in ('2776638') then 'Week 2' 
when a.[loan number] in ('2775023') then 'Week 2' 
when a.[loan number] in ('2773021') then 'Week 2' 
when a.[loan number] in ('2756963') then 'Week 2' 
when a.[loan number] in ('2716281') then 'Week 2' 
when a.[loan number] in ('2705368') then 'Week 2' 
when a.[loan number] in ('2696777') then 'Week 2' 
when a.[loan number] in ('2691589') then 'Week 2' 
when a.[loan number] in ('2676900') then 'Week 2' 
when a.[loan number] in ('845577') then 'Week 2' 
when a.[loan number] in ('854970') then 'Week 2' 
when a.[loan number] in ('875827') then 'Week 2' 
when a.[loan number] in ('887121') then 'Week 2' 
when a.[loan number] in ('868164') then 'Week 2' 
when a.[loan number] in ('866488') then 'Week 2' 
when a.[loan number] in ('849500') then 'Week 2' 
when a.[loan number] in ('845358') then 'Week 2' 
when a.[loan number] in ('888065') then 'Week 2' 
when a.[loan number] in ('843978') then 'Week 3' 
when a.[loan number] in ('1000665') then 'Week 3' 
when a.[loan number] in ('855378') then 'Week 3' 
when a.[loan number] in ('875332') then 'Week 3' 
when a.[loan number] in ('877565') then 'Week 3' 
when a.[loan number] in ('886667') then 'Week 3' 
when a.[loan number] in ('889142') then 'Week 3' 
when a.[loan number] in ('838939') then 'Week 3' 
when a.[loan number] in ('840619') then 'Week 3' 
when a.[loan number] in ('846079') then 'Week 3' 
when a.[loan number] in ('1022613') then 'Week 3' 
when a.[loan number] in ('891249') then 'Week 3' 
when a.[loan number] in ('887014') then 'Week 3' 
when a.[loan number] in ('1072051') then 'Week 3' 
when a.[loan number] in ('1070681') then 'Week 3' 
when a.[loan number] in ('757468') then 'Week 3' 
when a.[loan number] in ('748112') then 'Week 3' 
when a.[loan number] in ('1063046') then 'Week 3' 
when a.[loan number] in ('1044134') then 'Week 3' 
when a.[loan number] in ('871592') then 'Week 3' 
when a.[loan number] in ('1031173') then 'Week 3' 
when a.[loan number] in ('1067987') then 'Week 3' 
when a.[loan number] in ('849086') then 'Week 3' 
when a.[loan number] in ('871151') then 'Week 3' 
when a.[loan number] in ('762631') then 'Week 3' 
when a.[loan number] in ('762603') then 'Week 3' 
when a.[loan number] in ('749369') then 'Week 3' 
when a.[loan number] in ('1031282') then 'Week 3' 
when a.[loan number] in ('1059558') then 'Week 3' 
when a.[loan number] in ('763361') then 'Week 3' 
when a.[loan number] in ('844086') then 'Week 3' 
when a.[loan number] in ('1044080') then 'Week 3' 
when a.[loan number] in ('1061152') then 'Week 3' 
when a.[loan number] in ('745778') then 'Week 3' 
when a.[loan number] in ('1020990') then 'Week 3' 
when a.[loan number] in ('1027049') then 'Week 3' 
when a.[loan number] in ('750550') then 'Week 3' 
when a.[loan number] in ('763113') then 'Week 3' 
when a.[loan number] in ('768469') then 'Week 3' 
when a.[loan number] in ('883883') then 'Week 3' 
when a.[loan number] in ('871093') then 'Week 3' 
when a.[loan number] in ('764952') then 'Week 3' 
when a.[loan number] in ('1153999') then 'Week 3' 
when a.[loan number] in ('745008') then 'Week 3' 
when a.[loan number] in ('1052615') then 'Week 3' 
when a.[loan number] in ('766521') then 'Week 3' 
when a.[loan number] in ('1058448') then 'Week 3' 
when a.[loan number] in ('1075026') then 'Week 3' 
when a.[loan number] in ('1038816') then 'Week 3' 
when a.[loan number] in ('1063024') then 'Week 3' 
when a.[loan number] in ('1067912') then 'Week 3' 
when a.[loan number] in ('1037695') then 'Week 3' 
when a.[loan number] in ('1049434') then 'Week 3' 
when a.[loan number] in ('1062940') then 'Week 3' 
when a.[loan number] in ('1068748') then 'Week 3' 
when a.[loan number] in ('1085140') then 'Week 3' 
when a.[loan number] in ('1088034') then 'Week 3' 
when a.[loan number] in ('757626') then 'Week 3' 
when a.[loan number] in ('759191') then 'Week 3' 
when a.[loan number] in ('767840') then 'Week 3' 
when a.[loan number] in ('865170') then 'Week 3' 
when a.[loan number] in ('1042559') then 'Week 3' 
when a.[loan number] in ('1060920') then 'Week 3' 
when a.[loan number] in ('1062228') then 'Week 3' 
when a.[loan number] in ('1065206') then 'Week 3' 
when a.[loan number] in ('1069607') then 'Week 3' 
when a.[loan number] in ('1070867') then 'Week 3' 
when a.[loan number] in ('1059692') then 'Week 3' 
when a.[loan number] in ('843441') then 'Week 3' 
when a.[loan number] in ('2113475') then 'Week 3' 
when a.[loan number] in ('2132866') then 'Week 3' 
when a.[loan number] in ('2163205') then 'Week 3' 
when a.[loan number] in ('2234211') then 'Week 3' 
when a.[loan number] in ('2295841') then 'Week 3' 
when a.[loan number] in ('2331914') then 'Week 3' 
when a.[loan number] in ('2382654') then 'Week 3' 
when a.[loan number] in ('2402408') then 'Week 3' 
when a.[loan number] in ('2412718') then 'Week 3' 
when a.[loan number] in ('2422903') then 'Week 3' 
when a.[loan number] in ('2464891') then 'Week 3' 
when a.[loan number] in ('2507028') then 'Week 3' 
when a.[loan number] in ('2509188') then 'Week 3' 
when a.[loan number] in ('2536795') then 'Week 3' 
when a.[loan number] in ('2544089') then 'Week 3' 
when a.[loan number] in ('2567737') then 'Week 3' 
when a.[loan number] in ('2570311') then 'Week 3' 
when a.[loan number] in ('2576066') then 'Week 3' 
when a.[loan number] in ('2578547') then 'Week 3' 
when a.[loan number] in ('2595150') then 'Week 3' 
when a.[loan number] in ('2596947') then 'Week 3' 
when a.[loan number] in ('2603651') then 'Week 3' 
when a.[loan number] in ('2609599') then 'Week 3' 
when a.[loan number] in ('2612572') then 'Week 3' 
when a.[loan number] in ('2613788') then 'Week 3' 
when a.[loan number] in ('2620992') then 'Week 3' 
when a.[loan number] in ('2625566') then 'Week 3' 
when a.[loan number] in ('2626523') then 'Week 3' 
when a.[loan number] in ('2627648') then 'Week 3' 
when a.[loan number] in ('2628342') then 'Week 3' 
when a.[loan number] in ('2636159') then 'Week 3' 
when a.[loan number] in ('2641430') then 'Week 3' 
when a.[loan number] in ('2643136') then 'Week 3' 
when a.[loan number] in ('2643819') then 'Week 3' 
when a.[loan number] in ('2664438') then 'Week 3' 
when a.[loan number] in ('2679594') then 'Week 3' 
when a.[loan number] in ('2693649') then 'Week 3' 
when a.[loan number] in ('2711505') then 'Week 3' 
when a.[loan number] in ('2717829') then 'Week 3' 
when a.[loan number] in ('2721437') then 'Week 3' 
when a.[loan number] in ('2729457') then 'Week 3' 
when a.[loan number] in ('2731985') then 'Week 3' 
when a.[loan number] in ('2735148') then 'Week 3' 
when a.[loan number] in ('2744230') then 'Week 3' 
when a.[loan number] in ('2755859') then 'Week 3' 
when a.[loan number] in ('2759966') then 'Week 3' 
when a.[loan number] in ('2765305') then 'Week 3' 
when a.[loan number] in ('2812916') then 'Week 3' 
when a.[loan number] in ('2850662') then 'Week 3' 
when a.[loan number] in ('2596231') then 'Week 3' 
when a.[loan number] in ('2607303') then 'Week 3' 
when a.[loan number] in ('2700045') then 'Week 3' 
when a.[loan number] in ('841419') then 'Week 3' 
when a.[loan number] in ('740908') then 'Week 3' 
when a.[loan number] in ('768820') then 'Week 3' 
when a.[loan number] in ('763141') then 'Week 3' 
when a.[loan number] in ('740547') then 'Week 3' 
when a.[loan number] in ('1061403') then 'Week 3' 
when a.[loan number] in ('1065632') then 'Week 3' 
when a.[loan number] in ('1009061') then 'Week 3' 
when a.[loan number] in ('2150186') then 'Week 3' 
when a.[loan number] in ('2275051') then 'Week 3' 
when a.[loan number] in ('2388741') then 'Week 3' 
when a.[loan number] in ('2487694') then 'Week 3' 
when a.[loan number] in ('2516132') then 'Week 3' 
when a.[loan number] in ('2533484') then 'Week 3' 
when a.[loan number] in ('2601900') then 'Week 3' 
when a.[loan number] in ('2612128') then 'Week 3' 
when a.[loan number] in ('2543099') then 'Week 3' 
when a.[loan number] in ('887946') then 'Week 3' 
when a.[loan number] in ('872875') then 'Week 3' 
when a.[loan number] in ('2114637') then 'Week 3' 
when a.[loan number] in ('2420865') then 'Week 3' 
when a.[loan number] in ('2592486') then 'Week 3' 
when a.[loan number] in ('752821') then 'Week 3' 
when a.[loan number] in ('756775') then 'Week 3' 
when a.[loan number] in ('886916') then 'Week 3' 
when a.[loan number] in ('2654608') then 'Week 3' 
when a.[loan number] in ('750984') then 'Week 3' 
when a.[loan number] in ('760693') then 'Week 3' 
when a.[loan number] in ('1070813') then 'Week 3' 
when a.[loan number] in ('1059503') then 'Week 3' 
when a.[loan number] in ('1067541') then 'Week 3' 
when a.[loan number] in ('1054529') then 'Week 3' 
when a.[loan number] in ('2762200') then 'Week 3' 
when a.[loan number] in ('1072606') then 'Week 3' 
when a.[loan number] in ('1088585') then 'Week 3' 
when a.[loan number] in ('2367029') then 'Week 3' 
when a.[loan number] in ('1072008') then 'Week 3' 
when a.[loan number] in ('1042210') then 'Week 3' 
when a.[loan number] in ('749941') then 'Week 3' 
when a.[loan number] in ('842571') then 'Week 3' 
when a.[loan number] in ('2732441') then 'Week 3' 
when a.[loan number] in ('2740635') then 'Week 3' 
when a.[loan number] in ('1055735') then 'Week 3' 
when a.[loan number] in ('1016336') then 'Week 3' 
when a.[loan number] in ('1048763') then 'Week 3' 
when a.[loan number] in ('767273') then 'Week 3' 
when a.[loan number] in ('1021545') then 'Week 3' 
when a.[loan number] in ('758292') then 'Week 3' 
when a.[loan number] in ('763351') then 'Week 3' 
when a.[loan number] in ('2533086') then 'Week 3' 
when a.[loan number] in ('744323') then 'Week 3' 
when a.[loan number] in ('1064916') then 'Week 3' 
when a.[loan number] in ('1075764') then 'Week 3' 
when a.[loan number] in ('2482699') then 'Week 3' 
when a.[loan number] in ('886976') then 'Week 3' 
when a.[loan number] in ('1060215') then 'Week 3' 
when a.[loan number] in ('843560') then 'Week 3' 
when a.[loan number] in ('755365') then 'Week 3' 
when a.[loan number] in ('2798031') then 'Week 3' 
when a.[loan number] in ('862701') then 'Week 3' 
when a.[loan number] in ('885855') then 'Week 4' 
when a.[loan number] in ('1053897') then 'Week 4' 
when a.[loan number] in ('870782') then 'Week 4' 
when a.[loan number] in ('869791') then 'Week 4' 
when a.[loan number] in ('1060799') then 'Week 4' 
when a.[loan number] in ('763391') then 'Week 4' 
when a.[loan number] in ('756607') then 'Week 4' 
when a.[loan number] in ('1068957') then 'Week 4' 
when a.[loan number] in ('2784672') then 'Week 4' 
when a.[loan number] in ('2404386') then 'Week 4' 
when a.[loan number] in ('2696846') then 'Week 4' 
when a.[loan number] in ('2479956') then 'Week 4' 
when a.[loan number] in ('2665291') then 'Week 4' 
when a.[loan number] in ('2664893') then 'Week 4' 
when a.[loan number] in ('2625327') then 'Week 4' 
when a.[loan number] in ('2752709') then 'Week 4' 
when a.[loan number] in ('740537') then 'Week 4' 
when a.[loan number] in ('1058054') then 'Week 4' 
when a.[loan number] in ('2588538') then 'Week 4' 
when a.[loan number] in ('1064258') then 'Week 4' 
when a.[loan number] in ('2575065') then 'Week 4' 
when a.[loan number] in ('746085') then 'Week 4' 
when a.[loan number] in ('2457983') then 'Week 4' 
when a.[loan number] in ('2439387') then 'Week 4' 
when a.[loan number] in ('2410442') then 'Week 4' 
when a.[loan number] in ('752519') then 'Week 4' 
when a.[loan number] in ('2629980') then 'Week 4' 
when a.[loan number] in ('1058269') then 'Week 4' 
when a.[loan number] in ('1068445') then 'Week 4' 
when a.[loan number] in ('1052743') then 'Week 4' 
when a.[loan number] in ('2644068') then 'Week 4' 
when a.[loan number] in ('1051228') then 'Week 4' 
when a.[loan number] in ('1051711') then 'Week 4' 
when a.[loan number] in ('1062471') then 'Week 4' 
when a.[loan number] in ('1060186') then 'Week 4' 
when a.[loan number] in ('1056774') then 'Week 4' 
when a.[loan number] in ('1068856') then 'Week 4' 
when a.[loan number] in ('1056996') then 'Week 4' 
when a.[loan number] in ('2403067') then 'Week 4' 
when a.[loan number] in ('2419986') then 'Week 4' 
when a.[loan number] in ('2501293') then 'Week 4' 
when a.[loan number] in ('2695732') then 'Week 4' 
when a.[loan number] in ('743202') then 'Week 4' 
when a.[loan number] in ('746708') then 'Week 4' 
when a.[loan number] in ('846820') then 'Week 4' 
when a.[loan number] in ('749484') then 'Week 4' 
when a.[loan number] in ('1073168') then 'Week 4' 
when a.[loan number] in ('2607267') then 'Week 4' 
when a.[loan number] in ('2763724') then 'Week 4' 
when a.[loan number] in ('2473789') then 'Week 4' 
when a.[loan number] in ('1058381') then 'Week 4' 
when a.[loan number] in ('880630') then 'Week 4' 
when a.[loan number] in ('757385') then 'Week 4' 
when a.[loan number] in ('764944') then 'Week 4' 
when a.[loan number] in ('888702') then 'Week 4' 
when a.[loan number] in ('1043967') then 'Week 4' 
when a.[loan number] in ('2707360') then 'Week 4' 
when a.[loan number] in ('1060434') then 'Week 4' 
when a.[loan number] in ('1062698') then 'Week 4' 
when a.[loan number] in ('1075996') then 'Week 4' 
when a.[loan number] in ('1032520') then 'Week 4' 
when a.[loan number] in ('2442623') then 'Week 4' 
when a.[loan number] in ('2514367') then 'Week 4' 
when a.[loan number] in ('2594228') then 'Week 4' 
when a.[loan number] in ('2648255') then 'Week 4' 
when a.[loan number] in ('2648426') then 'Week 4' 
when a.[loan number] in ('759420') then 'Week 4' 
when a.[loan number] in ('1049908') then 'Week 4' 
when a.[loan number] in ('757909') then 'Week 4' 
when a.[loan number] in ('1070726') then 'Week 4' 
when a.[loan number] in ('1070573') then 'Week 4' 
when a.[loan number] in ('2132800') then 'Week 4' 
when a.[loan number] in ('1039131') then 'Week 4' 
when a.[loan number] in ('2618464') then 'Week 4' 
when a.[loan number] in ('1062320') then 'Week 4' 
when a.[loan number] in ('2629218') then 'Week 4' 
when a.[loan number] in ('2692158') then 'Week 4' 
when a.[loan number] in ('1024743') then 'Week 4' 
when a.[loan number] in ('1066042') then 'Week 4' 
when a.[loan number] in ('1065467') then 'Week 4' 
when a.[loan number] in ('1063015') then 'Week 4' 
when a.[loan number] in ('1068504') then 'Week 4' 
when a.[loan number] in ('2738608') then 'Week 4' 
when a.[loan number] in ('1073806') then 'Week 4' 
when a.[loan number] in ('2748370') then 'Week 4' 
when a.[loan number] in ('754580') then 'Week 4' 
when a.[loan number] in ('886106') then 'Week 4' 
when a.[loan number] in ('879525') then 'Week 4' 
when a.[loan number] in ('1056040') then 'Week 4' 
when a.[loan number] in ('1064562') then 'Week 4' 
when a.[loan number] in ('756043') then 'Week 4' 
when a.[loan number] in ('1072802') then 'Week 4' 
when a.[loan number] in ('1074734') then 'Week 4' 
when a.[loan number] in ('2127563') then 'Week 4' 
when a.[loan number] in ('1035517') then 'Week 4' 
when a.[loan number] in ('2544001') then 'Week 4' 
when a.[loan number] in ('2809114') then 'Week 4' 
when a.[loan number] in ('2787027') then 'Week 4' 
when a.[loan number] in ('2629274') then 'Week 4' 
when a.[loan number] in ('2648222') then 'Week 4' 
when a.[loan number] in ('2781588') then 'Week 4' 
when a.[loan number] in ('2800752') then 'Week 4' 
when a.[loan number] in ('2668114') then 'Week 4' 
when a.[loan number] in ('751454') then 'Week 4' 
when a.[loan number] in ('767610') then 'Week 4' 
when a.[loan number] in ('2519658') then 'Week 4' 
when a.[loan number] in ('838474') then 'Week 4' 
when a.[loan number] in ('841727') then 'Week 4' 
when a.[loan number] in ('850890') then 'Week 4' 
when a.[loan number] in ('869020') then 'Week 4' 
when a.[loan number] in ('887364') then 'Week 4' 
when a.[loan number] in ('887799') then 'Week 4' 
when a.[loan number] in ('1062920') then 'Week 4' 
when a.[loan number] in ('2108708') then 'Week 4' 
when a.[loan number] in ('1055299') then 'Week 4' 
when a.[loan number] in ('2635089') then 'Week 4' 
when a.[loan number] in ('763616') then 'Week 4' 
when a.[loan number] in ('1040523') then 'Week 4' 
when a.[loan number] in ('1073119') then 'Week 4' 
when a.[loan number] in ('2474860') then 'Week 4' 
when a.[loan number] in ('2498152') then 'Week 4' 
when a.[loan number] in ('2588867') then 'Week 4' 
when a.[loan number] in ('745586') then 'Week 4' 
when a.[loan number] in ('2515881') then 'Week 4' 
when a.[loan number] in ('760201') then 'Week 4' 
when a.[loan number] in ('1072259') then 'Week 4' 
when a.[loan number] in ('2165515') then 'Week 4' 
when a.[loan number] in ('2738163') then 'Week 4' 
when a.[loan number] in ('766124') then 'Week 4' 
when a.[loan number] in ('761633') then 'Week 4' 
when a.[loan number] in ('2599267') then 'Week 4' 
when a.[loan number] in ('1067828') then 'Week 4' 
when a.[loan number] in ('2685854') then 'Week 4' 
when a.[loan number] in ('2308948') then 'Week 4' 
when a.[loan number] in ('767983') then 'Week 4' 
when a.[loan number] in ('887703') then 'Week 4' 
when a.[loan number] in ('1058037') then 'Week 4' 
when a.[loan number] in ('1079436') then 'Week 4' 
when a.[loan number] in ('2519998') then 'Week 4' 
when a.[loan number] in ('2684819') then 'Week 4' 
when a.[loan number] in ('1023400') then 'Week 4' 
when a.[loan number] in ('755176') then 'Week 4' 
when a.[loan number] in ('2820803') then 'Week 4' 
when a.[loan number] in ('2650604') then 'Week 4' 
when a.[loan number] in ('2615940') then 'Week 4' 
when a.[loan number] in ('1052264') then 'Week 4' 
when a.[loan number] in ('1071589') then 'Week 4' 
when a.[loan number] in ('1071715') then 'Week 4' 
when a.[loan number] in ('1073152') then 'Week 4' 
when a.[loan number] in ('2430333') then 'Week 4' 
when a.[loan number] in ('1090066') then 'Week 4' 
when a.[loan number] in ('750429') then 'Week 4' 
when a.[loan number] in ('1063760') then 'Week 4' 
when a.[loan number] in ('2444099') then 'Week 4' 
when a.[loan number] in ('891037') then 'Week 4' 
when a.[loan number] in ('2452410') then 'Week 4' 
when a.[loan number] in ('746733') then 'Week 4' 
when a.[loan number] in ('1085852') then 'Week 4' 
when a.[loan number] in ('1060641') then 'Week 4' 
when a.[loan number] in ('1055257') then 'Week 4' 
when a.[loan number] in ('2591010') then 'Week 4' 
when a.[loan number] in ('2121408') then 'Week 4' 
when a.[loan number] in ('1064225') then 'Week 4' 
when a.[loan number] in ('2595866') then 'Week 4' 
when a.[loan number] in ('2608941') then 'Week 4' 
when a.[loan number] in ('2637069') then 'Week 4' 
when a.[loan number] in ('2620344') then 'Week 4' 
when a.[loan number] in ('2649724') then 'Week 4' 
when a.[loan number] in ('2737275') then 'Week 4' 
when a.[loan number] in ('2417325') then 'Week 4' 
when a.[loan number] in ('2446558') then 'Week 4' 
when a.[loan number] in ('2716668') then 'Week 4' 
when a.[loan number] in ('2517111') then 'Week 4' 
when a.[loan number] in ('2519055') then 'Week 4' 
when a.[loan number] in ('2519373') then 'Week 4' 
when a.[loan number] in ('2543932') then 'Week 4' 
when a.[loan number] in ('2614017') then 'Week 4' 
when a.[loan number] in ('2573109') then 'Week 4' 
when a.[loan number] in ('2603935') then 'Week 4' 
when a.[loan number] in ('2625407') then 'Week 4' 
when a.[loan number] in ('2375358') then 'Week 4' 
when a.[loan number] in ('2331424') then 'Week 4' 
when a.[loan number] in ('2274631') then 'Week 4' 
when a.[loan number] in ('765560') then 'Week 4' 
when a.[loan number] in ('860908') then 'Week 4' 
when a.[loan number] in ('883881') then 'Week 4' 
when a.[loan number] in ('887526') then 'Week 4' 
when a.[loan number] in ('754527') then 'Week 4' 
when a.[loan number] in ('2665020') then 'Week 4' 
when a.[loan number] in ('2633624') then 'Week 4' 
when a.[loan number] in ('759698') then 'Week 4' 
when a.[loan number] in ('749350') then 'Week 4' 
when a.[loan number] in ('741753') then 'Week 4' 
when a.[loan number] in ('1043040') then 'Week 4' 
when a.[loan number] in ('2573508') then 'Week 4' 
when a.[loan number] in ('2556789') then 'Week 4' 
when a.[loan number] in ('754150') then 'Week 4' 
when a.[loan number] in ('2631757') then 'Week 4' 
when a.[loan number] in ('2390062') then 'Week 4' 
when a.[loan number] in ('760910') then 'Week 4' 
when a.[loan number] in ('746879') then 'Week 4' 
when a.[loan number] in ('2640576') then 'Week 4' 
when a.[loan number] in ('2286327') then 'Week 4' 
when a.[loan number] in ('2581052') then 'Week 4' 
when a.[loan number] in ('2513652') then 'Week 4' 
when a.[loan number] in ('2482564') then 'Week 4' 
when a.[loan number] in ('1070647') then 'Week 4' 
when a.[loan number] in ('763652') then 'Week 4' 
when a.[loan number] in ('762285') then 'Week 4' 
when a.[loan number] in ('754122') then 'Week 4' 
when a.[loan number] in ('751957') then 'Week 4' 
when a.[loan number] in ('743561') then 'Week 4' 
when a.[loan number] in ('2634011') then 'Week 4' 
when a.[loan number] in ('2623826') then 'Week 4' 
when a.[loan number] in ('2621152') then 'Week 4' 
when a.[loan number] in ('2597265') then 'Week 4' 
when a.[loan number] in ('2531302') then 'Week 4' 
when a.[loan number] in ('2529821') then 'Week 4' 
when a.[loan number] in ('2507175') then 'Week 4' 
when a.[loan number] in ('2414538') then 'Week 4' 
when a.[loan number] in ('755205') then 'Week 1' 
when a.[loan number] in ('1053245') then 'Week 1' 
when a.[loan number] in ('743888') then 'Week 2' 
when a.[loan number] in ('887242') then 'Week 3' 
when a.[loan number] in ('865912') then 'Week 3' 
when a.[loan number] in ('2719683') then 'Week 3' 
when a.[loan number] in ('2789256') then 'Week 3' 
when a.[loan number] in ('1056885') then 'Week 3' 
when a.[loan number] in ('2602730') then 'Week 3' 

end as 'Week'

,case
when a.[loan number] in ('887242') then 'Curative Cleared' 
when a.[loan number] in ('1053245') then 'Denied & Submitted 2+' 
when a.[loan number] in ('849841') then 'Denied Before 02.14.18' 
when a.[loan number] in ('849249') then 'Denied & Submitted 2+' 
when a.[loan number] in ('880020') then 'Denied & Submitted 2+' 
when a.[loan number] in ('761983') then 'Denied & Submitted 2+' 
when a.[loan number] in ('740910') then 'Denied & Submitted 2+' 
when a.[loan number] in ('747818') then 'Denied & Submitted 2+' 
when a.[loan number] in ('753869') then 'Denied & Submitted 2+' 
when a.[loan number] in ('742419') then 'Denied & Submitted 2+' 
when a.[loan number] in ('1060197') then 'Denied & Submitted 2+' 
when a.[loan number] in ('1045649') then 'Denied & Submitted 2+' 
when a.[loan number] in ('741479') then 'Denied & Submitted 2+' 
when a.[loan number] in ('889868') then 'Denied & Submitted 2+' 
when a.[loan number] in ('2298571') then 'Denied & Submitted 2+' 
when a.[loan number] in ('2337033') then 'Denied & Submitted 2+' 
when a.[loan number] in ('2546786') then 'Denied & Submitted 2+' 
when a.[loan number] in ('2658895') then 'Denied & Submitted 2+' 
when a.[loan number] in ('2712334') then 'Denied & Submitted 2+' 
when a.[loan number] in ('2758863') then 'Denied & Submitted 2+' 
when a.[loan number] in ('2792503') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1154547') then 'Denied Before 02.14.18' 
when a.[loan number] in ('761441') then 'Denied Before 02.14.18' 
when a.[loan number] in ('756259') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2738312') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1048611') then 'Denied Before 02.14.18' 
when a.[loan number] in ('742413') then 'Denied Before 02.14.18' 
when a.[loan number] in ('746977') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2465870') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2733497') then 'Denied Before 02.14.18' 
when a.[loan number] in ('844907') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1057248') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1038215') then 'Denied Before 02.14.18' 
when a.[loan number] in ('848341') then 'Denied Before 02.14.18' 
when a.[loan number] in ('754938') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2784558') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1026538') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1043130') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2401485') then 'Denied Before 02.14.18' 
when a.[loan number] in ('765801') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1064581') then 'Denied Before 02.14.18' 
when a.[loan number] in ('846353') then 'Denied Before 02.14.18' 
when a.[loan number] in ('845453') then 'Denied Before 02.14.18' 
when a.[loan number] in ('886951') then 'Denied Before 02.14.18' 
when a.[loan number] in ('869256') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2600681') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2584863') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2611684') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2807372') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2670755') then 'Denied Before 02.14.18' 
when a.[loan number] in ('768603') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2465905') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2738298') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2620721') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2747654') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1036735') then 'Denied Before 02.14.18' 
when a.[loan number] in ('756274') then 'Denied Before 02.14.18' 
when a.[loan number] in ('867114') then 'Denied Before 02.14.18' 
when a.[loan number] in ('845126') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2740646') then 'Denied Before 02.14.18' 
when a.[loan number] in ('849191') then 'Denied Before 02.14.18' 
when a.[loan number] in ('762357') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1025600') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2421877') then 'Denied Before 02.14.18' 
when a.[loan number] in ('767265') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2435566') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1026053') then 'Denied Before 02.14.18' 
when a.[loan number] in ('852951') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2655460') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1062142') then 'Denied Before 02.14.18' 
when a.[loan number] in ('768699') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2751398') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1065838') then 'Denied Before 02.14.18' 
when a.[loan number] in ('766049') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2637560') then 'Denied Before 02.14.18' 
when a.[loan number] in ('852716') then 'Denied Before 02.14.18' 
when a.[loan number] in ('862594') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2639118') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2455969') then 'Denied Before 02.14.18' 
when a.[loan number] in ('741468') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1041776') then 'Denied Before 02.14.18' 
when a.[loan number] in ('862799') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1032218') then 'Denied Before 02.14.18' 
when a.[loan number] in ('752259') then 'Denied Before 02.14.18' 
when a.[loan number] in ('887478') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2712595') then 'Denied Before 02.14.18' 
when a.[loan number] in ('855038') then 'Denied Before 02.14.18' 
when a.[loan number] in ('756523') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2731656') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1076457') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2629092') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1068497') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1048401') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2144995') then 'Denied Before 02.14.18' 
when a.[loan number] in ('762066') then 'Denied Before 02.14.18' 
when a.[loan number] in ('760347') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2697222') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1048030') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1084010') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1039446') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2743477') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1046561') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2408460') then 'Denied Before 02.14.18' 
when a.[loan number] in ('766499') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1051177') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1061873') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2302588') then 'Denied Before 02.14.18' 
when a.[loan number] in ('855116') then 'Denied Before 02.14.18' 
when a.[loan number] in ('761481') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1035026') then 'Denied Before 02.14.18' 
when a.[loan number] in ('848087') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2718090') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2453923') then 'Denied Before 02.14.18' 
when a.[loan number] in ('762352') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2694047') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2754869') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1047353') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1039004') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2752561') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1044061') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2597619') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1062932') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2697938') then 'Denied Before 02.14.18' 
when a.[loan number] in ('741790') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2511046') then 'Denied Before 02.14.18' 
when a.[loan number] in ('755936') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2121761') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2712312') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2463479') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2856372') then 'Denied Before 02.14.18' 
when a.[loan number] in ('843681') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1033040') then 'Denied Before 02.14.18' 
when a.[loan number] in ('753255') then 'Denied Before 02.14.18' 
when a.[loan number] in ('768214') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2441290') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2706370') then 'Denied Before 02.14.18' 
when a.[loan number] in ('745798') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1065406') then 'Denied Before 02.14.18' 
when a.[loan number] in ('852469') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1083854') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1062091') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2665941') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2594901') then 'Denied Before 02.14.18' 
when a.[loan number] in ('756521') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2502089') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1060498') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2693262') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2459510') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2748780') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1071387') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2137064') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1055048') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1064158') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2696868') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2461978') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2715736') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2613631') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2620402') then 'Denied Before 02.14.18' 
when a.[loan number] in ('889227') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1028743') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1058730') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1030149') then 'Denied Before 02.14.18' 
when a.[loan number] in ('848387') then 'Denied Before 02.14.18' 
when a.[loan number] in ('887176') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2698267') then 'Denied Before 02.14.18' 
when a.[loan number] in ('748231') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2512183') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1062802') then 'Denied Before 02.14.18' 
when a.[loan number] in ('841750') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2769651') then 'Denied Before 02.14.18' 
when a.[loan number] in ('745952') then 'Denied Before 02.14.18' 
when a.[loan number] in ('2634910') then 'Denied Before 02.14.18' 
when a.[loan number] in ('406405') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1040805') then 'Denied Before 02.14.18' 
when a.[loan number] in ('761480') then 'Denied Before 02.14.18' 
when a.[loan number] in ('891109') then 'Denied Before 02.14.18' 
when a.[loan number] in ('891381') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1053340') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1067870') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1059549') then 'Denied Before 02.14.18' 
when a.[loan number] in ('1059405') then 'Denied Before 02.14.18' 
when a.[loan number] in ('748697') then 'Generation' 
when a.[loan number] in ('747253') then 'Generation' 
when a.[loan number] in ('766108') then 'Generation' 
when a.[loan number] in ('1151675') then 'Generation' 
when a.[loan number] in ('762166') then 'Generation' 
when a.[loan number] in ('756314') then 'Generation' 
when a.[loan number] in ('744834') then 'Generation' 
when a.[loan number] in ('741555') then 'Generation' 
when a.[loan number] in ('760916') then 'Generation' 
when a.[loan number] in ('751721') then 'Generation' 
when a.[loan number] in ('750866') then 'Generation' 
when a.[loan number] in ('749407') then 'Generation' 
when a.[loan number] in ('746811') then 'Generation' 
when a.[loan number] in ('740148') then 'Generation' 
when a.[loan number] in ('766092') then 'Generation' 
when a.[loan number] in ('756288') then 'Generation' 
when a.[loan number] in ('745912') then 'Generation' 
when a.[loan number] in ('759583') then 'Generation' 
when a.[loan number] in ('754694') then 'Generation' 
when a.[loan number] in ('748632') then 'Generation' 
when a.[loan number] in ('745186') then 'Generation' 
when a.[loan number] in ('768946') then 'Generation' 
when a.[loan number] in ('745057') then 'Generation' 
when a.[loan number] in ('1152953') then 'Generation' 
when a.[loan number] in ('748114') then 'Generation' 
when a.[loan number] in ('764226') then 'Generation' 
when a.[loan number] in ('740136') then 'Generation' 
when a.[loan number] in ('1150480') then 'Generation' 
when a.[loan number] in ('751708') then 'Generation' 
when a.[loan number] in ('748636') then 'Generation' 
when a.[loan number] in ('764009') then 'Generation' 
when a.[loan number] in ('755662') then 'Generation' 
when a.[loan number] in ('752661') then 'Generation' 
when a.[loan number] in ('746263') then 'Generation' 
when a.[loan number] in ('740464') then 'Generation' 
when a.[loan number] in ('764961') then 'Generation' 
when a.[loan number] in ('752614') then 'Generation' 
when a.[loan number] in ('750134') then 'Generation' 
when a.[loan number] in ('746966') then 'Generation' 
when a.[loan number] in ('745962') then 'Generation' 
when a.[loan number] in ('766099') then 'Generation' 
when a.[loan number] in ('762908') then 'Generation' 
when a.[loan number] in ('759310') then 'Generation' 
when a.[loan number] in ('751723') then 'Generation' 
when a.[loan number] in ('749073') then 'Generation' 
when a.[loan number] in ('748840') then 'Generation' 
when a.[loan number] in ('745261') then 'Generation' 
when a.[loan number] in ('744333') then 'Generation' 
when a.[loan number] in ('768192') then 'Generation' 
when a.[loan number] in ('766022') then 'Generation' 
when a.[loan number] in ('762216') then 'Generation' 
when a.[loan number] in ('756298') then 'Generation' 
when a.[loan number] in ('752038') then 'Generation' 
when a.[loan number] in ('744807') then 'Generation' 
when a.[loan number] in ('764296') then 'Generation' 
when a.[loan number] in ('740900') then 'Generation' 
when a.[loan number] in ('754494') then 'Generation' 
when a.[loan number] in ('756763') then 'Generation' 
when a.[loan number] in ('761143') then 'Generation' 
when a.[loan number] in ('757889') then 'Generation' 
when a.[loan number] in ('750982') then 'Generation' 
when a.[loan number] in ('747521') then 'Generation' 
when a.[loan number] in ('741848') then 'Generation' 
when a.[loan number] in ('758068') then 'Generation' 
when a.[loan number] in ('759232') then 'Generation' 
when a.[loan number] in ('759229') then 'Generation' 
when a.[loan number] in ('749279') then 'Generation' 
when a.[loan number] in ('766670') then 'Generation' 
when a.[loan number] in ('754495') then 'Generation' 
when a.[loan number] in ('748241') then 'Generation' 
when a.[loan number] in ('765423') then 'Generation' 
when a.[loan number] in ('742646') then 'Generation' 
when a.[loan number] in ('767235') then 'Generation' 
when a.[loan number] in ('743377') then 'Generation' 
when a.[loan number] in ('763407') then 'Generation' 
when a.[loan number] in ('759792') then 'Generation' 
when a.[loan number] in ('746822') then 'Generation' 
when a.[loan number] in ('1153298') then 'Generation' 
when a.[loan number] in ('1153829') then 'Generation' 
when a.[loan number] in ('763804') then 'Generation' 
when a.[loan number] in ('759999') then 'Generation' 
when a.[loan number] in ('1153446') then 'Generation' 
when a.[loan number] in ('766993') then 'Generation' 
when a.[loan number] in ('766739') then 'Generation' 
when a.[loan number] in ('766297') then 'Generation' 
when a.[loan number] in ('766121') then 'Generation' 
when a.[loan number] in ('765182') then 'Generation' 
when a.[loan number] in ('764270') then 'Generation' 
when a.[loan number] in ('762593') then 'Generation' 
when a.[loan number] in ('759910') then 'Generation' 
when a.[loan number] in ('759838') then 'Generation' 
when a.[loan number] in ('757657') then 'Generation' 
when a.[loan number] in ('755866') then 'Generation' 
when a.[loan number] in ('749974') then 'Generation' 
when a.[loan number] in ('749184') then 'Generation' 
when a.[loan number] in ('745462') then 'Generation' 
when a.[loan number] in ('745275') then 'Generation' 
when a.[loan number] in ('744150') then 'Generation' 
when a.[loan number] in ('742673') then 'Generation' 
when a.[loan number] in ('766965') then 'Generation' 
when a.[loan number] in ('765380') then 'Generation' 
when a.[loan number] in ('761638') then 'Generation' 
when a.[loan number] in ('761293') then 'Generation' 
when a.[loan number] in ('759643') then 'Generation' 
when a.[loan number] in ('758751') then 'Generation' 
when a.[loan number] in ('1150658') then 'Generation' 
when a.[loan number] in ('755516') then 'Generation' 
when a.[loan number] in ('754544') then 'Generation' 
when a.[loan number] in ('753417') then 'Generation' 
when a.[loan number] in ('752845') then 'Generation' 
when a.[loan number] in ('749730') then 'Generation' 
when a.[loan number] in ('748224') then 'Generation' 
when a.[loan number] in ('744391') then 'Generation' 
when a.[loan number] in ('741374') then 'Generation' 
when a.[loan number] in ('741138') then 'Generation' 
when a.[loan number] in ('766534') then 'Generation' 
when a.[loan number] in ('758107') then 'Generation' 
when a.[loan number] in ('753033') then 'Generation' 
when a.[loan number] in ('748261') then 'Generation' 
when a.[loan number] in ('747939') then 'Generation' 
when a.[loan number] in ('743385') then 'Generation' 
when a.[loan number] in ('740386') then 'Generation' 
when a.[loan number] in ('740094') then 'Generation' 
when a.[loan number] in ('768645') then 'Generation' 
when a.[loan number] in ('768453') then 'Generation' 
when a.[loan number] in ('767501') then 'Generation' 
when a.[loan number] in ('760262') then 'Generation' 
when a.[loan number] in ('759014') then 'Generation' 
when a.[loan number] in ('754953') then 'Generation' 
when a.[loan number] in ('752486') then 'Generation' 
when a.[loan number] in ('751263') then 'Generation' 
when a.[loan number] in ('750870') then 'Generation' 
when a.[loan number] in ('745983') then 'Generation' 
when a.[loan number] in ('745827') then 'Generation' 
when a.[loan number] in ('745174') then 'Generation' 
when a.[loan number] in ('742089') then 'Generation' 
when a.[loan number] in ('741820') then 'Generation' 
when a.[loan number] in ('741258') then 'Generation' 
when a.[loan number] in ('766599') then 'Generation' 
when a.[loan number] in ('758552') then 'Generation' 
when a.[loan number] in ('753733') then 'Generation' 
when a.[loan number] in ('765256') then 'Generation' 
when a.[loan number] in ('759955') then 'Generation' 
when a.[loan number] in ('1151993') then 'Generation' 
when a.[loan number] in ('749506') then 'Generation' 
when a.[loan number] in ('749791') then 'Generation' 
when a.[loan number] in ('745953') then 'Generation' 
when a.[loan number] in ('744053') then 'Generation' 
when a.[loan number] in ('745284') then 'Generation' 
when a.[loan number] in ('753747') then 'Generation' 
when a.[loan number] in ('1153342') then 'Generation' 
when a.[loan number] in ('751413') then 'Generation' 
when a.[loan number] in ('754112') then 'Generation' 
when a.[loan number] in ('750416') then 'Generation' 
when a.[loan number] in ('754974') then 'Generation' 
when a.[loan number] in ('746968') then 'Generation' 
when a.[loan number] in ('759235') then 'Generation' 
when a.[loan number] in ('843573') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2608202') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2472539') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2455947') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2455732') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2623063') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2844344') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2809089') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2800104') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2797109') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2771223') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2750046') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2747313') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2734227') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2733180') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2731543') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2720425') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2716737') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2705471') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2695663') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2666566') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2654107') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2637753') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2613744') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2599542') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2594206') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2587764') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2554823') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2527204') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2506813') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2395432') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2155341') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('863896') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('842574') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('1062751') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('1088589') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('1067834') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('1063415') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('1057923') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('1059545') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('867711') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('844815') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('894871') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('886247') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('896186') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2403056') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('1072212') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('846502') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2131990') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2806337') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('1046687') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('843036') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2708806') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2130502') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('1023893') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('880222') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2801980') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2776638') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2775023') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2773021') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2756963') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2716281') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2705368') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2696777') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2691589') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('2676900') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('845577') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('854970') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('875827') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('887121') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('868164') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('866488') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('849500') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('845358') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('888065') then 'Not Submitted & 3+ Excp' 
when a.[loan number] in ('843978') then 'HUD Denied & Resubmitted' 
when a.[loan number] in ('1000665') then '3+ Exceptions' 
when a.[loan number] in ('855378') then '3+ Exceptions' 
when a.[loan number] in ('875332') then '3+ Exceptions' 
when a.[loan number] in ('877565') then '3+ Exceptions' 
when a.[loan number] in ('886667') then 'Curative Cleared' 
when a.[loan number] in ('889142') then '3+ Exceptions' 
when a.[loan number] in ('838939') then '3+ Exceptions' 
when a.[loan number] in ('840619') then '3+ Exceptions' 
when a.[loan number] in ('846079') then '3+ Exceptions' 
when a.[loan number] in ('1022613') then '3+ Exceptions' 
when a.[loan number] in ('891249') then '3+ Exceptions' 
when a.[loan number] in ('887014') then 'Curative Cleared' 
when a.[loan number] in ('1072051') then '3+ Exceptions' 
when a.[loan number] in ('1070681') then '3+ Exceptions' 
when a.[loan number] in ('757468') then 'Generation +3' 
when a.[loan number] in ('748112') then 'Generation +3' 
when a.[loan number] in ('1063046') then 'Curative Cleared' 
when a.[loan number] in ('1044134') then '3+ Exceptions' 
when a.[loan number] in ('871592') then '3+ Exceptions' 
when a.[loan number] in ('1031173') then 'HUD Denied & Resubmitted' 
when a.[loan number] in ('1067987') then '3+ Exceptions' 
when a.[loan number] in ('849086') then '3+ Exceptions' 
when a.[loan number] in ('871151') then 'Curative Cleared' 
when a.[loan number] in ('762631') then '3+ Exceptions' 
when a.[loan number] in ('762603') then 'Curative Cleared' 
when a.[loan number] in ('749369') then 'HUD Denied & Resubmitted' 
when a.[loan number] in ('1031282') then 'Curative Cleared' 
when a.[loan number] in ('1059558') then '3+ Exceptions' 
when a.[loan number] in ('763361') then '3+ Exceptions' 
when a.[loan number] in ('844086') then 'Curative Cleared' 
when a.[loan number] in ('1044080') then 'Curative Cleared' 
when a.[loan number] in ('1061152') then 'HUD Denied & Resubmitted' 
when a.[loan number] in ('745778') then 'Generation +3' 
when a.[loan number] in ('1020990') then 'Curative Cleared' 
when a.[loan number] in ('1027049') then 'HUD Denied & Resubmitted' 
when a.[loan number] in ('750550') then 'Generation +3' 
when a.[loan number] in ('763113') then 'HUD Denied & Resubmitted' 
when a.[loan number] in ('768469') then 'Generation +3' 
when a.[loan number] in ('883883') then '3+ Exceptions' 
when a.[loan number] in ('871093') then 'Curative Cleared' 
when a.[loan number] in ('764952') then 'Generation +3' 
when a.[loan number] in ('1153999') then '3+ Exceptions' 
when a.[loan number] in ('745008') then '3+ Exceptions' 
when a.[loan number] in ('1052615') then 'Curative Cleared' 
when a.[loan number] in ('766521') then 'HUD Denied & Resubmitted' 
when a.[loan number] in ('1058448') then 'Generation +3' 
when a.[loan number] in ('1075026') then 'Curative Cleared' 
when a.[loan number] in ('1038816') then '3+ Exceptions' 
when a.[loan number] in ('1063024') then '3+ Exceptions' 
when a.[loan number] in ('1067912') then 'HUD Denied & Resubmitted' 
when a.[loan number] in ('1037695') then 'Curative Cleared' 
when a.[loan number] in ('1049434') then '3+ Exceptions' 
when a.[loan number] in ('1062940') then '3+ Exceptions' 
when a.[loan number] in ('1068748') then '3+ Exceptions' 
when a.[loan number] in ('1085140') then '3+ Exceptions' 
when a.[loan number] in ('1088034') then '3+ Exceptions' 
when a.[loan number] in ('757626') then 'Generation +3' 
when a.[loan number] in ('759191') then 'Generation +3' 
when a.[loan number] in ('767840') then 'Curative Cleared' 
when a.[loan number] in ('865170') then '3+ Exceptions' 
when a.[loan number] in ('1042559') then '3+ Exceptions' 
when a.[loan number] in ('1060920') then '3+ Exceptions' 
when a.[loan number] in ('1062228') then '3+ Exceptions' 
when a.[loan number] in ('1065206') then 'Curative Cleared' 
when a.[loan number] in ('1069607') then 'Curative Cleared' 
when a.[loan number] in ('1070867') then '3+ Exceptions' 
when a.[loan number] in ('1059692') then '3+ Exceptions' 
when a.[loan number] in ('843441') then '3+ Exceptions' 
when a.[loan number] in ('2113475') then '3+ Exceptions' 
when a.[loan number] in ('2132866') then '3+ Exceptions' 
when a.[loan number] in ('2163205') then '3+ Exceptions' 
when a.[loan number] in ('2234211') then '3+ Exceptions' 
when a.[loan number] in ('2295841') then '3+ Exceptions' 
when a.[loan number] in ('2331914') then 'Curative Cleared' 
when a.[loan number] in ('2382654') then '3+ Exceptions' 
when a.[loan number] in ('2402408') then 'Generation +3' 
when a.[loan number] in ('2412718') then '3+ Exceptions' 
when a.[loan number] in ('2422903') then '3+ Exceptions' 
when a.[loan number] in ('2464891') then '3+ Exceptions' 
when a.[loan number] in ('2507028') then '3+ Exceptions' 
when a.[loan number] in ('2509188') then '3+ Exceptions' 
when a.[loan number] in ('2536795') then '3+ Exceptions' 
when a.[loan number] in ('2544089') then '3+ Exceptions' 
when a.[loan number] in ('2567737') then '3+ Exceptions' 
when a.[loan number] in ('2570311') then '3+ Exceptions' 
when a.[loan number] in ('2576066') then '3+ Exceptions' 
when a.[loan number] in ('2578547') then '3+ Exceptions' 
when a.[loan number] in ('2595150') then '3+ Exceptions' 
when a.[loan number] in ('2596947') then '3+ Exceptions' 
when a.[loan number] in ('2603651') then '3+ Exceptions' 
when a.[loan number] in ('2609599') then '3+ Exceptions' 
when a.[loan number] in ('2612572') then 'Generation +3' 
when a.[loan number] in ('2613788') then '3+ Exceptions' 
when a.[loan number] in ('2620992') then 'Generation +3' 
when a.[loan number] in ('2625566') then '3+ Exceptions' 
when a.[loan number] in ('2626523') then 'Curative Cleared' 
when a.[loan number] in ('2627648') then '3+ Exceptions' 
when a.[loan number] in ('2628342') then 'HUD Denied & Resubmitted' 
when a.[loan number] in ('2636159') then '3+ Exceptions' 
when a.[loan number] in ('2641430') then '3+ Exceptions' 
when a.[loan number] in ('2643136') then '3+ Exceptions' 
when a.[loan number] in ('2643819') then '3+ Exceptions' 
when a.[loan number] in ('2664438') then '3+ Exceptions' 
when a.[loan number] in ('2679594') then '3+ Exceptions' 
when a.[loan number] in ('2693649') then 'Curative Cleared' 
when a.[loan number] in ('2711505') then 'HUD Denied & Resubmitted' 
when a.[loan number] in ('2717829') then '3+ Exceptions' 
when a.[loan number] in ('2721437') then 'HUD Denied & Resubmitted' 
when a.[loan number] in ('2729457') then '3+ Exceptions' 
when a.[loan number] in ('2731985') then '3+ Exceptions' 
when a.[loan number] in ('2735148') then '3+ Exceptions' 
when a.[loan number] in ('2744230') then '3+ Exceptions' 
when a.[loan number] in ('2755859') then 'HUD Denied & Resubmitted' 
when a.[loan number] in ('2759966') then 'HUD Denied & Resubmitted' 
when a.[loan number] in ('2765305') then 'Curative Cleared' 
when a.[loan number] in ('2812916') then '3+ Exceptions' 
when a.[loan number] in ('2850662') then 'Curative Cleared' 
when a.[loan number] in ('2596231') then '3+ Exceptions' 
when a.[loan number] in ('2607303') then '3+ Exceptions' 
when a.[loan number] in ('2700045') then '3+ Exceptions' 
when a.[loan number] in ('841419') then 'Curative Cleared' 
when a.[loan number] in ('740908') then 'Curative Cleared' 
when a.[loan number] in ('768820') then 'Curative Cleared' 
when a.[loan number] in ('763141') then 'Curative Cleared' 
when a.[loan number] in ('740547') then 'Curative Cleared' 
when a.[loan number] in ('1061403') then 'Curative Cleared' 
when a.[loan number] in ('1065632') then 'Curative Cleared' 
when a.[loan number] in ('1009061') then 'Curative Cleared' 
when a.[loan number] in ('2150186') then 'Curative Cleared' 
when a.[loan number] in ('2275051') then 'Curative Cleared' 
when a.[loan number] in ('2388741') then 'Curative Cleared' 
when a.[loan number] in ('2487694') then 'Curative Cleared' 
when a.[loan number] in ('2516132') then 'Curative Cleared' 
when a.[loan number] in ('2533484') then 'Curative Cleared' 
when a.[loan number] in ('2601900') then 'Curative Cleared' 
when a.[loan number] in ('2612128') then 'Curative Cleared' 
when a.[loan number] in ('2543099') then 'Curative Cleared' 
when a.[loan number] in ('887946') then 'Curative Cleared' 
when a.[loan number] in ('872875') then 'Curative Cleared' 
when a.[loan number] in ('2114637') then 'Curative Cleared' 
when a.[loan number] in ('2420865') then 'Curative Cleared' 
when a.[loan number] in ('2592486') then 'Curative Cleared' 
when a.[loan number] in ('752821') then 'Curative Cleared' 
when a.[loan number] in ('756775') then 'Curative Cleared' 
when a.[loan number] in ('886916') then 'Curative Cleared' 
when a.[loan number] in ('2654608') then 'Curative Cleared' 
when a.[loan number] in ('750984') then 'Curative Cleared' 
when a.[loan number] in ('760693') then 'Curative Cleared' 
when a.[loan number] in ('1070813') then 'Curative Cleared' 
when a.[loan number] in ('1059503') then 'Curative Cleared' 
when a.[loan number] in ('1067541') then 'Curative Cleared' 
when a.[loan number] in ('1054529') then 'Curative Cleared' 
when a.[loan number] in ('2762200') then 'Curative Cleared' 
when a.[loan number] in ('1072606') then 'Curative Cleared' 
when a.[loan number] in ('1088585') then 'Curative Cleared' 
when a.[loan number] in ('2367029') then 'Curative Cleared' 
when a.[loan number] in ('1072008') then 'Curative Cleared' 
when a.[loan number] in ('1042210') then 'Curative Cleared' 
when a.[loan number] in ('749941') then 'Curative Cleared' 
when a.[loan number] in ('842571') then 'Curative Cleared' 
when a.[loan number] in ('2732441') then 'Curative Cleared' 
when a.[loan number] in ('2740635') then 'Curative Cleared' 
when a.[loan number] in ('1055735') then 'Curative Cleared' 
when a.[loan number] in ('1016336') then 'Curative Cleared' 
when a.[loan number] in ('1048763') then 'Curative Cleared' 
when a.[loan number] in ('767273') then 'Curative Cleared' 
when a.[loan number] in ('1021545') then 'Curative Cleared' 
when a.[loan number] in ('758292') then 'Curative Cleared' 
when a.[loan number] in ('763351') then 'Curative Cleared' 
when a.[loan number] in ('2533086') then 'Curative Cleared' 
when a.[loan number] in ('744323') then 'Curative Cleared' 
when a.[loan number] in ('1064916') then 'Curative Cleared' 
when a.[loan number] in ('1075764') then 'Curative Cleared' 
when a.[loan number] in ('2482699') then 'Curative Cleared' 
when a.[loan number] in ('886976') then 'Curative Cleared' 
when a.[loan number] in ('1060215') then 'Curative Cleared' 
when a.[loan number] in ('843560') then 'Curative Cleared' 
when a.[loan number] in ('755365') then 'Curative Cleared' 
when a.[loan number] in ('2798031') then 'Curative Cleared' 
when a.[loan number] in ('862701') then 'Curative Cleared' 
when a.[loan number] in ('885855') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1053897') then 'SWAT Old Pipeline' 
when a.[loan number] in ('870782') then 'SWAT Old Pipeline' 
when a.[loan number] in ('869791') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1060799') then 'SWAT Old Pipeline' 
when a.[loan number] in ('763391') then 'SWAT Old Pipeline' 
when a.[loan number] in ('756607') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1068957') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2784672') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2404386') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2696846') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2479956') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2665291') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2664893') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2625327') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2752709') then 'SWAT Old Pipeline' 
when a.[loan number] in ('740537') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1058054') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2588538') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1064258') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2575065') then 'SWAT Old Pipeline' 
when a.[loan number] in ('746085') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2457983') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2439387') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2410442') then 'SWAT Old Pipeline' 
when a.[loan number] in ('752519') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2629980') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1058269') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1068445') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1052743') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2644068') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1051228') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1051711') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1062471') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1060186') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1056774') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1068856') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1056996') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2403067') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2419986') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2501293') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2695732') then 'SWAT Old Pipeline' 
when a.[loan number] in ('743202') then 'SWAT Old Pipeline' 
when a.[loan number] in ('746708') then 'SWAT Old Pipeline' 
when a.[loan number] in ('846820') then 'SWAT Old Pipeline' 
when a.[loan number] in ('749484') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1073168') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2607267') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2763724') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2473789') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1058381') then 'SWAT Old Pipeline' 
when a.[loan number] in ('880630') then 'SWAT Old Pipeline' 
when a.[loan number] in ('757385') then 'SWAT Old Pipeline' 
when a.[loan number] in ('764944') then 'SWAT Old Pipeline' 
when a.[loan number] in ('888702') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1043967') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2707360') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1060434') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1062698') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1075996') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1032520') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2442623') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2514367') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2594228') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2648255') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2648426') then 'SWAT Old Pipeline' 
when a.[loan number] in ('759420') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1049908') then 'SWAT Old Pipeline' 
when a.[loan number] in ('757909') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1070726') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1070573') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2132800') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1039131') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2618464') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1062320') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2629218') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2692158') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1024743') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1066042') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1065467') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1063015') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1068504') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2738608') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1073806') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2748370') then 'SWAT Old Pipeline' 
when a.[loan number] in ('754580') then 'SWAT Old Pipeline' 
when a.[loan number] in ('886106') then 'SWAT Old Pipeline' 
when a.[loan number] in ('879525') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1056040') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1064562') then 'SWAT Old Pipeline' 
when a.[loan number] in ('756043') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1072802') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1074734') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2127563') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1035517') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2544001') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2809114') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2787027') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2629274') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2648222') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2781588') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2800752') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2668114') then 'SWAT Old Pipeline' 
when a.[loan number] in ('751454') then 'SWAT Old Pipeline' 
when a.[loan number] in ('767610') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2519658') then 'SWAT Old Pipeline' 
when a.[loan number] in ('838474') then 'SWAT Old Pipeline' 
when a.[loan number] in ('841727') then 'SWAT Old Pipeline' 
when a.[loan number] in ('850890') then 'SWAT Old Pipeline' 
when a.[loan number] in ('869020') then 'SWAT Old Pipeline' 
when a.[loan number] in ('887364') then 'SWAT Old Pipeline' 
when a.[loan number] in ('887799') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1062920') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2108708') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1055299') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2635089') then 'SWAT Old Pipeline' 
when a.[loan number] in ('763616') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1040523') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1073119') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2474860') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2498152') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2588867') then 'SWAT Old Pipeline' 
when a.[loan number] in ('745586') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2515881') then 'SWAT Old Pipeline' 
when a.[loan number] in ('760201') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1072259') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2165515') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2738163') then 'SWAT Old Pipeline' 
when a.[loan number] in ('766124') then 'SWAT Old Pipeline' 
when a.[loan number] in ('761633') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2599267') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1067828') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2685854') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2308948') then 'SWAT Old Pipeline' 
when a.[loan number] in ('767983') then 'SWAT Old Pipeline' 
when a.[loan number] in ('887703') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1058037') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1079436') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2519998') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2684819') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1023400') then 'SWAT Old Pipeline' 
when a.[loan number] in ('755176') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2820803') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2650604') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2615940') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1052264') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1071589') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1071715') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1073152') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2430333') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1090066') then 'SWAT Old Pipeline' 
when a.[loan number] in ('750429') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1063760') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2444099') then 'SWAT Old Pipeline' 
when a.[loan number] in ('891037') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2452410') then 'SWAT Old Pipeline' 
when a.[loan number] in ('746733') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1085852') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1060641') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1055257') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2591010') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2121408') then 'SWAT Old Pipeline' 
when a.[loan number] in ('1064225') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2595866') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2608941') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2637069') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2620344') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2649724') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2737275') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2417325') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2446558') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2716668') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2517111') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2519055') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2519373') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2543932') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2614017') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2573109') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2603935') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2625407') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2375358') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2331424') then 'SWAT Old Pipeline' 
when a.[loan number] in ('2274631') then 'SWAT Old Pipeline' 
when a.[loan number] in ('765560') then 'SWAT Old Pipeline' 
when a.[loan number] in ('860908') then 'SWAT Old Pipeline' 
when a.[loan number] in ('883881') then 'SWAT Old Pipeline' 
when a.[loan number] in ('887526') then 'SWAT Old Pipeline' 
when a.[loan number] in ('754527') then 'New File' 
when a.[loan number] in ('2665020') then 'New File' 
when a.[loan number] in ('2633624') then 'New File' 
when a.[loan number] in ('759698') then 'New File' 
when a.[loan number] in ('749350') then 'New File' 
when a.[loan number] in ('741753') then 'New File' 
when a.[loan number] in ('1043040') then 'New File' 
when a.[loan number] in ('2573508') then 'New File' 
when a.[loan number] in ('2556789') then 'New File' 
when a.[loan number] in ('754150') then 'New File' 
when a.[loan number] in ('2631757') then 'New File' 
when a.[loan number] in ('2390062') then 'New File' 
when a.[loan number] in ('760910') then 'New File' 
when a.[loan number] in ('746879') then 'New File' 
when a.[loan number] in ('2640576') then 'New File' 
when a.[loan number] in ('2286327') then 'New File' 
when a.[loan number] in ('2581052') then 'New File' 
when a.[loan number] in ('2513652') then 'New File' 
when a.[loan number] in ('2482564') then 'New File' 
when a.[loan number] in ('1070647') then 'New File' 
when a.[loan number] in ('763652') then 'New File' 
when a.[loan number] in ('762285') then 'New File' 
when a.[loan number] in ('754122') then 'New File' 
when a.[loan number] in ('751957') then 'New File' 
when a.[loan number] in ('743561') then 'New File' 
when a.[loan number] in ('2634011') then 'New File' 
when a.[loan number] in ('2623826') then 'New File' 
when a.[loan number] in ('2621152') then 'New File' 
when a.[loan number] in ('2597265') then 'New File' 
when a.[loan number] in ('2531302') then 'New File' 
when a.[loan number] in ('2529821') then 'New File' 
when a.[loan number] in ('2507175') then 'New File' 
when a.[loan number] in ('2414538') then 'New File' 
when a.[loan number] in ('755205') then 'Denied Before 02.14.18' 
when a.[loan number] in ('743888') then 'Generation' 
when a.[loan number] in ('865912') then 'HUD Denied & Resubmitted' 
when a.[loan number] in ('2719683') then 'HUD Denied & Resubmitted' 
when a.[loan number] in ('2789256') then 'Curative Cleared' 
when a.[loan number] in ('1056885') then 'Curative Cleared' 
when a.[loan number] in ('2602730') then 'Curative Cleared' 


end as 'Bucket'

,case
	when convert(nvarchar(10),c.[HUD Preliminary Title Approval],101) <=('2018-04-01') then convert(nvarchar(10),c.[HUD Preliminary Title Approval],101) 
	else 'NULL'
	end as 'HUD Approved Date'

FROM SHAREPOINTDATA.dbo.HUDAssignLoans A
Left JOIN SHAREPOINTDATA.dbo.HUDAssignFinalReview B
ON B.[LOAN NUMBER]=A.[LOAN NUMBER]
Left JOIN SHAREPOINTDATA.DBO.HUDASSIGNHUDSTATUS C
ON C.[LOAN NUMBER]=B.[LOAN NUMBER]
Left Join #SUB R
ON R.LoanNumber=A.[Loan Number]
LEFT JOIN #UPDATE U
ON A.[Loan Number]=U.[Loan Number]
LEFT JOIN #EXCEPTION Z
ON A.[Loan Number]=Z.[Loan Number] and z.RN=1

WHERE A.[Loan Number] IN ('2602730',
'865912',
'2719683',
'2789256',
'1056885',
'887242',
'755205',
'849841',
'849249',
'880020',
'761983',
'740910',
'747818',
'753869',
'742419',
'1060197',
'1045649',
'741479',
'889868',
'2298571',
'2337033',
'2546786',
'2658895',
'2712334',
'2758863',
'2792503',
'1154547',
'761441',
'756259',
'2738312',
'1048611',
'742413',
'746977',
'2465870',
'2733497',
'844907',
'1057248',
'1038215',
'848341',
'754938',
'2784558',
'1026538',
'1043130',
'2401485',
'765801',
'1064581',
'846353',
'845453',
'886951',
'869256',
'2600681',
'2584863',
'2611684',
'2807372',
'2670755',
'768603',
'2465905',
'2738298',
'2620721',
'2747654',
'1036735',
'756274',
'867114',
'845126',
'2740646',
'849191',
'762357',
'1025600',
'2421877',
'767265',
'2435566',
'1026053',
'852951',
'2655460',
'1062142',
'768699',
'2751398',
'1053245',
'743888',
'1065838',
'766049',
'2637560',
'852716',
'862594',
'2639118',
'2455969',
'741468',
'1041776',
'862799',
'1032218',
'752259',
'887478',
'2712595',
'855038',
'756523',
'2731656',
'1076457',
'2629092',
'1068497',
'1048401',
'2144995',
'762066',
'760347',
'2697222',
'1048030',
'1084010',
'1039446',
'2743477',
'1046561',
'2408460',
'766499',
'1051177',
'1061873',
'2302588',
'855116',
'761481',
'1035026',
'848087',
'2718090',
'2453923',
'762352',
'2694047',
'2754869',
'1047353',
'1039004',
'2752561',
'1044061',
'2597619',
'1062932',
'2697938',
'741790',
'2511046',
'755936',
'2121761',
'2712312',
'2463479',
'2856372',
'843681',
'1033040',
'753255',
'768214',
'2441290',
'2706370',
'745798',
'1065406',
'852469',
'1083854',
'1062091',
'2665941',
'2594901',
'756521',
'2502089',
'1060498',
'2693262',
'2459510',
'2748780',
'1071387',
'2137064',
'1055048',
'1064158',
'2696868',
'2461978',
'2715736',
'2613631',
'2620402',
'889227',
'1028743',
'1058730',
'1030149',
'848387',
'887176',
'2698267',
'748231',
'2512183',
'1062802',
'841750',
'2769651',
'745952',
'2634910',
'406405',
'1040805',
'761480',
'891109',
'891381',
'1053340',
'1067870',
'1059549',
'1059405',
'748697',
'747253',
'766108',
'1151675',
'762166',
'756314',
'744834',
'741555',
'760916',
'751721',
'750866',
'749407',
'746811',
'740148',
'766092',
'756288',
'745912',
'759583',
'754694',
'748632',
'745186',
'768946',
'745057',
'1152953',
'748114',
'764226',
'740136',
'1150480',
'751708',
'748636',
'764009',
'755662',
'752661',
'746263',
'740464',
'764961',
'752614',
'750134',
'746966',
'745962',
'766099',
'762908',
'759310',
'751723',
'749073',
'748840',
'745261',
'744333',
'768192',
'766022',
'762216',
'756298',
'752038',
'744807',
'764296',
'740900',
'754494',
'756763',
'761143',
'757889',
'750982',
'747521',
'741848',
'758068',
'759232',
'759229',
'749279',
'766670',
'754495',
'748241',
'765423',
'742646',
'767235',
'743377',
'763407',
'759792',
'746822',
'1153298',
'1153829',
'763804',
'759999',
'1153446',
'766993',
'766739',
'766297',
'766121',
'765182',
'764270',
'762593',
'759910',
'759838',
'757657',
'755866',
'749974',
'749184',
'745462',
'745275',
'744150',
'742673',
'766965',
'765380',
'761638',
'761293',
'759643',
'758751',
'1150658',
'755516',
'754544',
'753417',
'752845',
'749730',
'748224',
'744391',
'741374',
'741138',
'766534',
'758107',
'753033',
'748261',
'747939',
'743385',
'740386',
'740094',
'768645',
'768453',
'767501',
'760262',
'759014',
'754953',
'752486',
'751263',
'750870',
'745983',
'745827',
'745174',
'742089',
'741820',
'741258',
'766599',
'758552',
'753733',
'765256',
'759955',
'1151993',
'749506',
'749791',
'745953',
'744053',
'745284',
'753747',
'1153342',
'751413',
'754112',
'750416',
'754974',
'746968',
'759235',
'843573',
'2608202',
'2472539',
'2455947',
'2455732',
'2623063',
'2844344',
'2809089',
'2800104',
'2797109',
'2771223',
'2750046',
'2747313',
'2734227',
'2733180',
'2731543',
'2720425',
'2716737',
'2705471',
'2695663',
'2666566',
'2654107',
'2637753',
'2613744',
'2599542',
'2594206',
'2587764',
'2554823',
'2527204',
'2506813',
'2395432',
'2155341',
'863896',
'842574',
'1062751',
'1088589',
'1067834',
'1063415',
'1057923',
'1059545',
'867711',
'844815',
'894871',
'886247',
'896186',
'2403056',
'1072212',
'846502',
'2131990',
'2806337',
'1046687',
'843036',
'2708806',
'2130502',
'1023893',
'880222',
'2801980',
'2776638',
'2775023',
'2773021',
'2756963',
'2716281',
'2705368',
'2696777',
'2691589',
'2676900',
'845577',
'854970',
'875827',
'887121',
'868164',
'866488',
'849500',
'845358',
'888065',
'843978',
'1000665',
'855378',
'875332',
'877565',
'886667',
'889142',
'838939',
'840619',
'846079',
'1022613',
'891249',
'887014',
'1072051',
'1070681',
'757468',
'748112',
'1063046',
'1044134',
'871592',
'1031173',
'1067987',
'849086',
'871151',
'762631',
'762603',
'749369',
'1031282',
'1059558',
'763361',
'844086',
'1044080',
'1061152',
'745778',
'1020990',
'1027049',
'750550',
'763113',
'768469',
'883883',
'871093',
'764952',
'1153999',
'745008',
'1052615',
'766521',
'1058448',
'1075026',
'1038816',
'1063024',
'1067912',
'1037695',
'1049434',
'1062940',
'1068748',
'1085140',
'1088034',
'757626',
'759191',
'767840',
'865170',
'1042559',
'1060920',
'1062228',
'1065206',
'1069607',
'1070867',
'1059692',
'843441',
'2113475',
'2132866',
'2163205',
'2234211',
'2295841',
'2331914',
'2382654',
'2402408',
'2412718',
'2422903',
'2464891',
'2507028',
'2509188',
'2536795',
'2544089',
'2567737',
'2570311',
'2576066',
'2578547',
'2595150',
'2596947',
'2603651',
'2609599',
'2612572',
'2613788',
'2620992',
'2625566',
'2626523',
'2627648',
'2628342',
'2636159',
'2641430',
'2643136',
'2643819',
'2664438',
'2679594',
'2693649',
'2711505',
'2717829',
'2721437',
'2729457',
'2731985',
'2735148',
'2744230',
'2755859',
'2759966',
'2765305',
'2812916',
'2850662',
'2596231',
'2607303',
'2700045',
'841419',
'740908',
'768820',
'763141',
'740547',
'1061403',
'1065632',
'1009061',
'2150186',
'2275051',
'2388741',
'2487694',
'2516132',
'2533484',
'2601900',
'2612128',
'2543099',
'887946',
'872875',
'2114637',
'2420865',
'2592486',
'752821',
'756775',
'886916',
'2654608',
'750984',
'760693',
'1070813',
'1059503',
'1067541',
'1054529',
'2762200',
'1072606',
'1088585',
'2367029',
'1072008',
'1042210',
'749941',
'842571',
'2732441',
'2740635',
'1055735',
'1016336',
'1048763',
'767273',
'1021545',
'758292',
'763351',
'2533086',
'744323',
'1064916',
'1075764',
'2482699',
'886976',
'1060215',
'843560',
'755365',
'2798031',
'862701',
'885855',
'1053897',
'870782',
'869791',
'1060799',
'763391',
'756607',
'1068957',
'2784672',
'2404386',
'2696846',
'2479956',
'2665291',
'2664893',
'2625327',
'2752709',
'740537',
'1058054',
'2588538',
'1064258',
'2575065',
'746085',
'2457983',
'2439387',
'2410442',
'752519',
'2629980',
'1058269',
'1068445',
'1052743',
'2644068',
'1051228',
'1051711',
'1062471',
'1060186',
'1056774',
'1068856',
'1056996',
'2403067',
'2419986',
'2501293',
'2695732',
'743202',
'746708',
'846820',
'749484',
'1073168',
'2607267',
'2763724',
'2473789',
'1058381',
'880630',
'757385',
'764944',
'888702',
'1043967',
'2707360',
'1060434',
'1062698',
'1075996',
'1032520',
'2442623',
'2514367',
'2594228',
'2648255',
'2648426',
'759420',
'1049908',
'757909',
'1070726',
'1070573',
'2132800',
'1039131',
'2618464',
'1062320',
'2629218',
'2692158',
'1024743',
'1066042',
'1065467',
'1063015',
'1068504',
'2738608',
'1073806',
'2748370',
'754580',
'886106',
'879525',
'1056040',
'1064562',
'756043',
'1072802',
'1074734',
'2127563',
'1035517',
'2544001',
'2809114',
'2787027',
'2629274',
'2648222',
'2781588',
'2800752',
'2668114',
'751454',
'767610',
'2519658',
'838474',
'841727',
'850890',
'869020',
'887364',
'887799',
'1062920',
'2108708',
'1055299',
'2635089',
'763616',
'1040523',
'1073119',
'2474860',
'2498152',
'2588867',
'745586',
'2515881',
'760201',
'1072259',
'2165515',
'2738163',
'766124',
'761633',
'2599267',
'1067828',
'2685854',
'2308948',
'767983',
'887703',
'1058037',
'1079436',
'2519998',
'2684819',
'1023400',
'755176',
'2820803',
'2650604',
'2615940',
'1052264',
'1071589',
'1071715',
'1073152',
'2430333',
'1090066',
'750429',
'1063760',
'2444099',
'891037',
'2452410',
'746733',
'1085852',
'1060641',
'1055257',
'2591010',
'2121408',
'1064225',
'2595866',
'2608941',
'2637069',
'2620344',
'2649724',
'2737275',
'2417325',
'2446558',
'2716668',
'2517111',
'2519055',
'2519373',
'2543932',
'2614017',
'2573109',
'2603935',
'2625407',
'2375358',
'2331424',
'2274631',
'765560',
'860908',
'883881',
'887526',
'754527',
'2665020',
'2633624',
'759698',
'749350',
'741753',
'1043040',
'2573508',
'2556789',
'754150',
'2631757',
'2390062',
'760910',
'746879',
'2640576',
'2286327',
'2581052',
'2513652',
'2482564',
'1070647',
'763652',
'762285',
'754122',
'751957',
'743561',
'2634011',
'2623826',
'2621152',
'2597265',
'2531302',
'2529821',
'2507175',
'2414538')

DROP TABLE #SUB, #EXCEPTION, #UPDATE