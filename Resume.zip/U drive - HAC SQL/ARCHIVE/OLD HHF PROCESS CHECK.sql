select flag.*, TI.*

from
(select x.[MOD_LOAN_NBR], a.[SRC_OF_FND], a.[PREPYMT_AMT],cast(a.[TXN_DT]as date)as 'TXN DT'
	from [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[RVRS_LOAN_PPD] a
	left join [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[LOAN_NBR_CROSS_REF] x
	on a.loan_key=x.loan_key
	where a.curr_ind = 'Y' --and a.[SRC_OF_FND] = '3'
	 and a.prepay_type_cd = '83' 
	--group by x.[MOD_LOAN_NBR], a.[SRC_OF_FND]
	)flag
left join ( select B.MOD_LOAN_NBR ,a.TAX_AND_INS_SET_ASIDE_AMT 
	from [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[RVRS_LOAN_BAL] A
	LEFT JOIN [VRSQLRODS\RODS_PROD].reverse_dw.[dbo].[LOAN_NBR_CROSS_REF] B
	on a.loan_key=b.loan_key
	where a.TAX_AND_INS_SET_ASIDE_AMT is not null and a.curr_ind in ('y')) TI
on flag.mod_loan_nbr=ti.mod_loan_nbr

where ti.TAX_AND_INS_SET_ASIDE_AMT > 0