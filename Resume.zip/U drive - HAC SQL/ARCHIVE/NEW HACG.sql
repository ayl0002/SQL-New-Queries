SELECT
A.[Loan Number]
,A.[Exception ID]
,A.[Exception Requestor]
,R.Team
,A.[Document]
,A.[Issue]
,CASE
	WHEN A.[Exception Status] IN('Resolved','Not Valid','Cancelled','Closed with Vendor','Incurable') THEN 'CLOSED'
	ELSE 'OPEN'
	END AS 'OPEN/CLOSED'
,A.[Exception Status]
,CONVERT(NVARCHAR(10),A.[Exception Request Date],101) AS 'Exception Request Date'
,CONVERT(NVARCHAR(10),A.[Exception Status Date],101) as 'Exception Status Date'


FROM SharepointData.DBO.HUDAssignExceptions A
JOIN SharepointData.DBO.HUDAssignLoans B
ON A.[Loan Number]=B.[Loan Number]
JOIN TACT_REV.hudAssign.tbl_CureTeamRosters R
ON A.[Exception Requestor]=R.Name


WHERE A.[Exception Request Date] >=('2018-06-01') AND 
A.[Work Group] IN ('hacg') AND
B.[Loan Status] IN ('ACTIVE') AND
B.[Stage] IN ('FINAL REVIEW','HUD STATUS') AND
B.[MCA %] >= 97.5 

ORDER BY A.[Exception Request Date] ASC