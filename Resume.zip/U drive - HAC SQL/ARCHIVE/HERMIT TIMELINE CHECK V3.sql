SET NOCOUNT ON

sELECT
A.[LOAN NUMBER]
,M.STATUS_DESCRIPTION
,h.FHA_CASE_NBR_N
,A.[MCA %]
,c.[HUD Status]
,h.CASE_STATUS
,h.CASE_SUB_STATUS
,h.SERVICING_TYPE
,h.SERVICING_STATUS
,CAST(h.HERMIT_CREATED_DATE AS DATE) AS 'HERMIT CREATE DATE'
,CAST(h.HERMIT_ASOFDATE AS DATE) AS 'HERMIT ASOF DATE'
,dny.[HERMIT Dny Date]
,aprv.[HERMIT Aprv Date]
,b.[Final Review Assigned To]
,C.[HUD Assigned To]
,SUB.[SUBMIT DATE]

,cast(c.[HUD Preliminary Title Approval]as date) as 'PTA DATE'
,case
	WHEN H.CASE_SUB_STATUS NOT IN ('CT 22 - Pending Assignment','CT 22 - Preliminary Title Approval','Bankruptcy/Chapter 7') THEN 'DEFAULT TIMELINE OPENED - CLOSE DEFAULT TIMELINE'
	 when h.SERVICING_STATUS IS NULL 
		AND C.[HUD Status] IN ('PKG SUBMITTED TO HUD','RESUBMITTED TO HUD') THEN 'MISSING TIMELINE'
	 when h.SERVICING_STATUS IS NOT NULL 
		AND C.[HUD Status] NOT IN ('PKG SUBMITTED TO HUD','RESUBMITTED TO HUD','hud approved','hud approval') THEN 'MISSING SUBMIT DATE'
	 when h.SERVICING_STATUS IS NOT NULL 
		AND h.SERVICING_STATUS NOT IN ('Assignment Package Received','Follow-up on Incomplete Package','Original Mortgage/Deed of Trust & Note sent to HUD','HUD Issued Preliminary Title Approval')
		AND C.[HUD Status] IN ('PKG SUBMITTED TO HUD','RESUBMITTED TO HUD') THEN 'INCOMPLETE TIMELINE'
	 WHEN C.[HUD Preliminary Title Approval] IS NOT NULL 
		AND h.SERVICING_STATUS IS NULL AND m.status_description NOT IN ('Liquidated/Assigned to HU')
		AND C.[HUD Status] IN ('HUD APPROVED','HUD APPROVAL') THEN 'APPROVED BUT MISSING TIMELINE'
	 ELSE 'NULL'
	 END AS 'HERMIT REVIEW'
,CASE
	WHEN H.CASE_SUB_STATUS NOT IN ('CT 22 - Preliminary Title Approval') 
		AND H.SERVICING_STATUS IN ('Assignment to HUD sent for recording/Servicer Files Claim Ty','HUD Issued Preliminary Title Approval','Original Mortgage/Deed of Trust & Note received by HUD','Original Mortgage/Deed of Trust & Note sent to HUD') 
		AND A.[MCA %] >= 97.5
		AND C.[HUD Preliminary Title Approval] IS NULL THEN 'PTA GRANTED - IA MISSING PTA DATE'
	WHEN C.[HUD Preliminary Title Approval] IS NOT NULL 
		AND H.CASE_SUB_STATUS NOT IN ('CT 22 - Preliminary Title Approval') 
		AND H.SERVICING_STATUS NOT IN ('Assignment to HUD sent for recording/Servicer Files Claim Ty','HUD Issued Preliminary Title Approval','Original Mortgage/Deed of Trust & Note received by HUD','Original Mortgage/Deed of Trust & Note sent to HUD') 
		AND C.[HUD Status] NOT IN ('RESUBMITTED TO HUD')
		THEN 'IA PTA DATE ENTERED INCORRECTLY'
	ELSE NULL
	END AS 'PTA RECON'

FROM SHAREPOINTDATA.DBO.HUDASSIGNLOANS A
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNFINALREVIEW B
ON A.[LOAN NUMBER]=B.[LOAN NUMBER]
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNHUDSTATUS C
ON A.[LOAN NUMBER]=C.[LOAN NUMBER]
JOIN TACT_REV.docs.tbl_ChainOfTitle_Master H
ON A.[loan number]=h.LOAN_NBR
LEFT JOIN [VRSQLRODS\RODS_PROD].REVERSE_DW.[dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] M
ON A.[Loan Number]=M.LOAN_NBR
LEFT JOIN (SELECT [LoanNumber],MAX(DateSubmittedToHUD)as 'SUBMIT DATE'
		FROM SHAREPOINTDATA.dbo.HUDAssignDateSubmittedResubmittedtoHUD
		GROUP BY [LoanNumber])SUB
on a.[loan number]=sub.[LoanNumber]
LEFT JOIN (SELECT [LNDR_LOAN_NBR],MAX(cast([DNY_DT]as date))as 'HERMIT Dny Date'
			FROM [VRSQLRODS\RODS_PROD].REVERSE_DW.[dbo].[TP_HRMT_PRELIM_TTL_DNY]
			GROUP BY [LNDR_LOAN_NBR])DNY
on a.[loan number]=dny.[LNDR_LOAN_NBR]
LEFT JOIN (SELECT [LNDR_LOAN_NBR],MAX(cast([HUD_APRV_DT]as date))as 'HERMIT Aprv Date'
			FROM [VRSQLRODS\RODS_PROD].REVERSE_DW.[dbo].[TP_HRMT_PRELIM_TTL_APRV]
			GROUP BY [LNDR_LOAN_NBR])APRV
on a.[loan number]=APRV.[LNDR_LOAN_NBR]


where --a.[stage] in ('final review','hud status') and 
--c.[hud status] in ('pkg submitted to hud','resubmitted to hud','rebuttal to hud','hud approved','hud approval','hud denied')and
a.[Loan Status] not in ('inactive','Refer for FCL: Death','Called Due: Death')--and
--(a.[Loan Status] not in ('liquidated/assigned to hud') and c.[HUD Status] not in ('hud approved','hud approval'))
