SELECT
[LOAN NUMBER]
,COUNT(*) AS 'Past Curative Count'
INTO #CURE
FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS
WHERE [WORK GROUP] IN ('Curative','Landtran') and 
[EXCEPTION STATUS] not IN ('Not Valid','Cancelled') 
--AND[EXCEPTION REQUEST DATE] < @DATE
GROUP BY [LOAN NUMBER]

SELECT
[LOAN NUMBER]
,COUNT(*) AS 'Current Exception Count'
INTO #CURREXCP
FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS
WHERE [EXCEPTION STATUS] not IN ('Resolved','Not Valid','Cancelled','Closed with Vendor','Incurable','FNMA Denied','NBS Denied') 
--AND [EXCEPTION REQUEST DATE] <@DATE
GROUP BY [LOAN NUMBER]

SELECT
A.[LOAN NUMBER]
,case
	when c.[Resubmit to HUD Count]>=1 then 'Denied & 2+ Submission'
	when a.[portfolio] in ('GENERATION 2015','Generation','GENERATION 2015 WL')and a.[open exceptions] >=3 then 'Generation 3+'
	when a.[portfolio] not in ('GENERATION 2015','Generation','GENERATION 2015 WL')and a.[open exceptions] >=3 then 'Workable 3+'
	--when c.[HUD Status] in ('HUD Denied') and c.[Resubmit to HUD Count]=0 then '1 Submission'
	--else 'Not Submitted'
	ELSE 'General Population'
	end as 'Bucket'
INTO #BUCKET
from SharepointData.dbo.HUDAssignLoans a
left join SharepointData.dbo.HUDAssignHUDStatus c
on c.[Loan Number]=a.[Loan Number]



select distinct
a.[Loan Number]
,a.[Loan Status]
,a.[Pool Name]
,a.[Stage]
,a.[group]
,a.[Tag 2]
,a.[MCA %]
   ,case 
	when a.[MCA %] between '97.50' and '99.99' then '97.5-99.99'
	when a.[MCA %]between '100.00' and '104.99' then '100-104.99'
	when a.[MCA %] >= '105.00' then '105+'
	else '<97.49'
	end as 'MCA Bucket'
,case
	when a.[Stage] IN ('Final Review') then b.[Final Review Status]
	else c.[HUD status]
	end as 'Status'
,b.[Final Review Assigned To]
,t.OpenCurative AS 'Current Curative'
,t.OpenHACG as 'Current HACG'
,t.[Total Exceptions]
,case
	when t.[Open Exceptions]=0 then '0'
	when t.[Open Exceptions]=1 then '1'
	when t.[Open Exceptions]=2 then '2'
	else '3+'
	end as 'Open Exceptions'
,case
	when t.[OpenCurative] >=1 then 'Curative'
	else 'HACG'
	end as 'Current Pipeline'
,case
	when c.[HUD Status] in ('HUD Approved','Pkg Submitted to HUD','Resubmitted to HUD','Rebuttal to HUD') then 'Yes'
	else 'No'
	end as 'Pending @ HUD'
,case
	when b.[Final Review Assigned To] IN ('Camille Barnes',
'Adlai richards3',
'Catherine Hoffman2',
'Joan Kamara2',
'Anthony Lanza',
'Elizabeth Leon1',
'Jeannetta Mathis',
'Omar Namari',
'Donna Oliver',
'Lisa Pedicini',
'Maggie Quinn1',
'Amber Samuels',
'Emily Spencer1',
'Alda Bermudez',
'Gabrielle Ciotto',
'Lydianne Bermudez',
'Meagan Avery',
'Megan Rose2',
'Melissa Morgan4',
'Monique Koba',
'Raufzhon Abduzhalilov',
'Susan Joseph3',
'Sapphire Williams19') then 'Yes'
	else 'No'
	end as 'Assigned to ISGN'
,H.[BUCKET]
,case 
	when W.[Past Curative Count] is null and G.[Current Exception Count] is null then 'No Past Curatives or Exceptions'										
	when W.[Past Curative Count] is null and G.[Current Exception Count] is not null then 'Exceptions'										
	when W.[Past Curative Count] is not null and G.[Current Exception Count] is  null then 'Past Curative and No Exceptions'										
	when W.[Past Curative Count] is not null and G.[Current Exception Count] is not null then 'Past Curative and Exceptions' 
	End as 'Exception Bucket'

from SharepointData.dbo.HUDAssignLoans a
left join SharepointData.dbo.HUDAssignFinalReview b
on b.[Loan Number]=a.[Loan Number]
left join SharepointData.dbo.HUDAssignHUDStatus c
on c.[Loan Number]=a.[Loan Number]
left join sharepointdata.dbo.HUDAssignLoanExceptionTotals t
on a.[Loan Number]=t.[Loan Number]
LEFT JOIN #CURE W
ON A.[Loan Number]=W.[Loan Number]
LEFT JOIN #CURREXCP G
ON A.[Loan Number]=G.[Loan Number]
left join #BUCKET H
ON H.[LOAN NUMBER]=A.[LOAN NUMBER]


where a.[Stage] in ('Final Review','HUD status') and
a.[Tag 2] is null and
a.[Loan Status] in ('active') and
--a.[Open Exceptions] =0 and
--b.[final review assigned to] not in ('Kari Chadwell') and
a.[MCA %]>=97.5 and
a.[Incurable Flag] in ('0') and
(a.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
a.[Group] is null)--and
--c.[HUD Status] not in ('HUD Approved','Pkg Submitted to HUD','Resubmitted to HUD','Rebuttal to HUD')

DROP TABLE #CURE,#CURREXCP, #BUCKET
