SELECT
A.[Loan Number]
,A.[MCA %]
,CASE
	WHEN A.[MCA %] BETWEEN 97.5 AND 99.99 THEN ' 97.5-100'
	WHEN A.[MCA %] >= 100 THEN '100+'
	ELSE '<97.5'
	END AS 'MCA BUCKET'
,OCC.Document AS 'OCC'
,OCC.[Exception ID] 'OCC EXCP ID'
,CAST(OCC.[Exception Request Date]AS DATE) AS 'OCC EXCP RQST DT'
,CAST(OCC.[Gift Card Letter Sent]AS DATE) AS 'OCC LTR1'
,CAST(OCC.[Gift Card Letter Sent 2]AS DATE) AS 'OCC LTR2'
,CAST(OCC.[Gift Card Letter Sent 3]AS DATE) AS 'OCC LTR3'
,CASE
	WHEN OGCV.[Sent For Gift Card Processing] IS NOT NULL THEN 'GIFT CARD SENT - NOT ELIGIBLE FOR LETTER'
	WHEN (OCC.[GIFT CARD LETTER SENT] IS NULL AND OCC.[GIFT CARD LETTER SENT 2] IS NULL AND OCC.[GIFT CARD LETTER SENT 3] IS NULL) AND OCC.[Document] IS NOT NULL AND (A.[MCA %] BETWEEN 96.5 AND 98.49)  THEN 'SEND GC1'
	WHEN (OCC.[GIFT CARD LETTER SENT] IS NOT NULL AND OCC.[GIFT CARD LETTER SENT 2] IS NULL) AND OCC.[Document] IS NOT NULL --AND (A.[MCA %] BETWEEN 96.5 AND 98.49) 
		AND OCC.[GC1 AGING] > 15 THEN 'SEND GC2'
	WHEN (OCC.[GIFT CARD LETTER SENT] IS NOT NULL AND OCC.[GIFT CARD LETTER SENT 2] IS NOT NULL AND OCC.[GIFT CARD LETTER SENT 3] IS NULL) AND OCC.[Document] IS NOT NULL --AND A.[MCA %] BETWEEN 96.5 AND 98.49 
		AND OCC.[GC2 AGING] > 15 THEN 'SEND GC3'
	END AS 'OCC LETTER DROP'
,CASE
	WHEN (OCC.[GIFT CARD LETTER SENT] IS NOT NULL AND OCC.[GIFT CARD LETTER SENT 2] IS NOT NULL AND OCC.[GIFT CARD LETTER SENT 3] IS NULL) AND OCC.[Document] IS NOT NULL AND OCC.[GC2 AGING] > 15 AND OCC.[Sent to Inspection Vendor] IS NULL THEN 'DOOR KNOCK/3RD LETTER'
	WHEN (OCC.[GIFT CARD LETTER SENT] IS NOT NULL AND OCC.[GIFT CARD LETTER SENT 2] IS NOT NULL AND OCC.[GIFT CARD LETTER SENT 3] IS NOT NULL) AND OCC.[Document] IS NOT NULL AND OCC.[Sent to Inspection Vendor] IS NULL THEN 'DOOR KNOCK/3RD LETTER'
	WHEN A.[MCA %] >= 98.5 AND OCC.[DOCUMENT] IS NOT NULL AND OCC.[Sent to Inspection Vendor] IS NULL THEN 'NCCI DOOR KNOCK'
	ELSE 'NULL'
	END AS 'OCC DOOR KNOCK'

,DC.Document AS 'DC'
,DC.[Exception ID] 'DC EXCP ID'
,CAST(DC.[Exception Request Date]AS DATE) AS 'DC EXCP RQST DT'
,CAST(DC.[Gift Card Letter Sent]AS DATE) AS 'DC LTR1'
,CAST(DC.[Gift Card Letter Sent 2]AS DATE) AS 'DC LTR2'
,CAST(DC.[Gift Card Letter Sent 3]AS DATE) AS 'DC LTR3'
,CASE
	WHEN DCGCV.[Sent For Gift Card Processing] IS NOT NULL THEN 'GIFT CARD SENT - NOT ELIGIBLE FOR LETTER'
	WHEN (DC.[GIFT CARD LETTER SENT] IS NULL AND DC.[GIFT CARD LETTER SENT 2] IS NULL AND DC.[GIFT CARD LETTER SENT 3] IS NULL) AND DC.[Document] IS NOT NULL AND A.[MCA %] >=95 THEN 'SEND GC1'
	WHEN (DC.[GIFT CARD LETTER SENT] IS NOT NULL AND DC.[GIFT CARD LETTER SENT 2] IS NULL) AND DC.[Document] IS NOT NULL AND A.[MCA %] >=95 AND DC.[GC1 AGING] > 15 THEN 'SEND GC2'
	WHEN (DC.[GIFT CARD LETTER SENT] IS NOT NULL AND DC.[GIFT CARD LETTER SENT 2] IS NOT NULL AND DC.[GIFT CARD LETTER SENT 3] IS NULL) AND DC.[Document] IS NOT NULL AND A.[MCA %] >=95 AND DC.[GC2 AGING] > 15 THEN 'SEND GC3'
	END AS 'DC LETTER DROP'

,TRST.Document AS 'TRST'
,TRST.[Exception ID] 'TRST EXCP ID'
,CAST(TRST.[Exception Request Date]AS DATE) AS 'TRST EXCP RQST DT'
,CAST(TRST.[Gift Card Letter Sent]AS DATE) AS 'TRST LTR1'
,CAST(TRST.[Gift Card Letter Sent 2]AS DATE) AS 'TRST LTR2'
,CAST(TRST.[Gift Card Letter Sent 3]AS DATE) AS 'TRST LTR3'
,CASE
	WHEN TGCV.[Sent For Gift Card Processing] IS NOT NULL THEN 'GIFT CARD SENT - NOT ELIGIBLE FOR LETTER'
	WHEN (TRST.[GIFT CARD LETTER SENT] IS NULL AND TRST.[GIFT CARD LETTER SENT 2] IS NULL AND TRST.[GIFT CARD LETTER SENT 3] IS NULL) AND TRST.[Document] IS NOT NULL AND A.[MCA %] >=95 THEN 'SEND GC1'
	WHEN (TRST.[GIFT CARD LETTER SENT] IS NOT NULL AND TRST.[GIFT CARD LETTER SENT 2] IS NULL) AND TRST.[Document] IS NOT NULL AND A.[MCA %] >=95 AND TRST.[GC1 AGING] > 15 THEN 'SEND GC2'
	WHEN (TRST.[GIFT CARD LETTER SENT] IS NOT NULL AND TRST.[GIFT CARD LETTER SENT 2] IS NOT NULL AND TRST.[GIFT CARD LETTER SENT 3] IS NULL) AND TRST.[Document] IS NOT NULL AND A.[MCA %] >=95 AND TRST.[GC2 AGING] > 15 THEN 'SEND GC3'
	END AS 'TRST LETTER DROP'

,POR.Document AS 'POR'
,POR.[Exception ID] 'POR EXCP ID'
,CAST(POR.[Exception Request Date]AS DATE) AS 'POR EXCP RQST DT'
,CAST(POR.[Gift Card Letter Sent]AS DATE) AS 'POR LTR1'
,CAST(POR.[Gift Card Letter Sent 2]AS DATE) AS 'POR LTR2'
,CAST(POR.[Gift Card Letter Sent 3]AS DATE) AS 'POR LTR3'
,CASE
	WHEN PORGCV.[Sent For Gift Card Processing] IS NOT NULL THEN 'GIFT CARD SENT - NOT ELIGIBLE FOR LETTER'
	WHEN (POR.[GIFT CARD LETTER SENT] IS NULL AND POR.[GIFT CARD LETTER SENT 2] IS NULL AND POR.[GIFT CARD LETTER SENT 3] IS NULL) AND (POR.[Document] IS NOT NULL AND PORCURE.Document IS NULL) AND A.[MCA %] >=92 THEN 'SEND GC1'
	WHEN (POR.[GIFT CARD LETTER SENT] IS NOT NULL AND POR.[GIFT CARD LETTER SENT 2] IS NULL) AND (POR.[Document] IS NOT NULL AND PORCURE.Document IS NULL) AND A.[MCA %] >=92 AND POR.[GC1 AGING] > 15 THEN 'SEND GC2'
	WHEN (POR.[GIFT CARD LETTER SENT] IS NOT NULL AND POR.[GIFT CARD LETTER SENT 2] IS NOT NULL AND POR.[GIFT CARD LETTER SENT 3] IS NULL) AND (POR.[Document] IS NOT NULL AND PORCURE.Document IS NULL) AND A.[MCA %] >=92 AND POR.[GC2 AGING] > 15 THEN 'SEND GC3'
	END AS 'POR LETTER DROP'

FROM SHAREPOINTDATA.DBO.HUDASSIGNLOANS A
LEFT JOIN (SELECT E.[LOAN NUMBER],E.[EXCEPTION ID],E.[DOCUMENT],E.[ISSUE],E.[EXCEPTION REQUEST DATE]
	,e.[Gift Card Letter Sent] ,datediff(day,cast(E.[Gift Card Letter Sent] as date),getdate()) AS 'GC1 AGING'
	,e.[Gift Card Letter Sent 2] ,datediff(day,cast(E.[Gift Card Letter Sent 2] as date),getdate()) AS 'GC2 AGING'
	,e.[Gift Card Letter Sent 3] ,datediff(day,cast(E.[Gift Card Letter Sent 3] as date),getdate()) AS 'GC3 AGING'
	,E.[Document Returned Gift Card Eligible],e.[Sent For Gift Card Processing],e.[Sent to Inspection Vendor],E.[Document Received by Vendor]
	FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
	WHERE E.[EXCEPTION STATUS] NOT IN ('CLOSED','RESOLVED','NOT VALID','INCURABLE','CLOSED WITH VENDOR') AND E.[DOCUMENT] IN ('CURRENT OCC CERT')
	)OCC
ON A.[LOAN NUMBER]=OCC.[LOAN NUMBER]
	LEFT JOIN (SELECT E.[LOAN NUMBER],E.[EXCEPTION ID],E.[DOCUMENT],E.[ISSUE],E.[EXCEPTION REQUEST DATE]
		,e.[Gift Card Letter Sent] ,datediff(day,cast(E.[Gift Card Letter Sent] as date),getdate()) AS 'GC1 AGING'
		,e.[Gift Card Letter Sent 2] ,datediff(day,cast(E.[Gift Card Letter Sent 2] as date),getdate()) AS 'GC2 AGING'
		,e.[Gift Card Letter Sent 3] ,datediff(day,cast(E.[Gift Card Letter Sent 3] as date),getdate()) AS 'GC3 AGING'
		,E.[Document Returned Gift Card Eligible],e.[Sent For Gift Card Processing],e.[Sent to Inspection Vendor],E.[Document Received by Vendor]
		FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
		WHERE E.[DOCUMENT] IN ('CURRENT OCC CERT') AND E.[Sent For Gift Card Processing] IS NOT NULL) OGCV
	ON A.[LOAN NUMBER]=OGCV.[LOAN NUMBER]
LEFT JOIN (SELECT E.[LOAN NUMBER],E.[EXCEPTION ID],E.[DOCUMENT],E.[ISSUE],E.[EXCEPTION REQUEST DATE] 
	,e.[Gift Card Letter Sent] ,datediff(day,cast(E.[Gift Card Letter Sent] as date),getdate()) AS 'GC1 AGING'
	,e.[Gift Card Letter Sent 2] ,datediff(day,cast(E.[Gift Card Letter Sent 2] as date),getdate()) AS 'GC2 AGING'
	,e.[Gift Card Letter Sent 3] ,datediff(day,cast(E.[Gift Card Letter Sent 3] as date),getdate()) AS 'GC3 AGING'
	,E.[Document Returned Gift Card Eligible],e.[Sent For Gift Card Processing],e.[Sent to Inspection Vendor],E.[Document Received by Vendor]
	FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
	LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNLOANS A
	ON E.[LOAN NUMBER]=A.[LOAN NUMBER]
	WHERE E.[EXCEPTION STATUS] NOT IN ('CLOSED','RESOLVED','NOT VALID','INCURABLE','CLOSED WITH VENDOR') AND E.[DOCUMENT] IN ('DEATH CERT HACG') AND A.[MCA %] >= '95'
	)DC
ON A.[Loan Number]=DC.[Loan Number]
	LEFT JOIN (SELECT E.[LOAN NUMBER],E.[EXCEPTION ID],E.[DOCUMENT],E.[ISSUE],E.[EXCEPTION REQUEST DATE]
			,e.[Gift Card Letter Sent] ,datediff(day,cast(E.[Gift Card Letter Sent] as date),getdate()) AS 'GC1 AGING'
			,e.[Gift Card Letter Sent 2] ,datediff(day,cast(E.[Gift Card Letter Sent 2] as date),getdate()) AS 'GC2 AGING'
			,e.[Gift Card Letter Sent 3] ,datediff(day,cast(E.[Gift Card Letter Sent 3] as date),getdate()) AS 'GC3 AGING'
			,E.[Document Returned Gift Card Eligible],e.[Sent For Gift Card Processing],e.[Sent to Inspection Vendor],E.[Document Received by Vendor]
			FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
			WHERE E.[DOCUMENT] IN ('DEATH CERT HACG','DEATH CERT') AND E.[Sent For Gift Card Processing] IS NOT NULL) DCGCV
		ON A.[Loan Number]=DCGCV.[Loan Number]
LEFT JOIN (SELECT E.[LOAN NUMBER],E.[EXCEPTION ID],E.[DOCUMENT],E.[ISSUE],E.[EXCEPTION REQUEST DATE]
	,e.[Gift Card Letter Sent] ,datediff(day,cast(E.[Gift Card Letter Sent] as date),getdate()) AS 'GC1 AGING'
	,e.[Gift Card Letter Sent 2] ,datediff(day,cast(E.[Gift Card Letter Sent 2] as date),getdate()) AS 'GC2 AGING'
	,e.[Gift Card Letter Sent 3] ,datediff(day,cast(E.[Gift Card Letter Sent 3] as date),getdate()) AS 'GC3 AGING'
	,E.[Document Returned Gift Card Eligible],e.[Sent For Gift Card Processing],e.[Sent to Inspection Vendor],E.[Document Received by Vendor]
	FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
	LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNLOANS A
	ON E.[LOAN NUMBER]=A.[LOAN NUMBER]
	WHERE E.[EXCEPTION STATUS] NOT IN ('CLOSED','RESOLVED','NOT VALID','INCURABLE','CLOSED WITH VENDOR') AND E.[DOCUMENT] IN ('TRUST - HACG') AND A.[MCA %] >='92'
	)TRST
ON A.[Loan Number]=TRST.[Loan Number]
	LEFT JOIN (SELECT E.[LOAN NUMBER],E.[EXCEPTION ID],E.[DOCUMENT],E.[ISSUE],E.[EXCEPTION REQUEST DATE]
			,e.[Gift Card Letter Sent] ,datediff(day,cast(E.[Gift Card Letter Sent] as date),getdate()) AS 'GC1 AGING'
			,e.[Gift Card Letter Sent 2] ,datediff(day,cast(E.[Gift Card Letter Sent 2] as date),getdate()) AS 'GC2 AGING'
			,e.[Gift Card Letter Sent 3] ,datediff(day,cast(E.[Gift Card Letter Sent 3] as date),getdate()) AS 'GC3 AGING'
			,E.[Document Returned Gift Card Eligible],e.[Sent For Gift Card Processing],e.[Sent to Inspection Vendor],E.[Document Received by Vendor]
			FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
			WHERE E.[DOCUMENT] IN ('TRUST - HACG','TRUST') AND E.[Sent For Gift Card Processing] IS NOT NULL) TGCV
		ON A.[Loan Number]=TGCV.[Loan Number]
LEFT JOIN (SELECT E.[LOAN NUMBER],E.[EXCEPTION ID],E.[DOCUMENT],E.[ISSUE],E.[EXCEPTION REQUEST DATE]
	,e.[Gift Card Letter Sent] ,datediff(day,cast(E.[Gift Card Letter Sent] as date),getdate()) AS 'GC1 AGING'
	,e.[Gift Card Letter Sent 2] ,datediff(day,cast(E.[Gift Card Letter Sent 2] as date),getdate()) AS 'GC2 AGING'
	,e.[Gift Card Letter Sent 3] ,datediff(day,cast(E.[Gift Card Letter Sent 3] as date),getdate()) AS 'GC3 AGING'
	,E.[Document Returned Gift Card Eligible],e.[Sent For Gift Card Processing],e.[Sent to Inspection Vendor],E.[Document Received by Vendor]
	FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
	WHERE E.[EXCEPTION STATUS] NOT IN ('CLOSED','RESOLVED','NOT VALID','INCURABLE','CLOSED WITH VENDOR') AND E.[DOCUMENT] IN ('Proof of Repair')
	)POR
ON A.[Loan Number]=POR.[Loan Number]
	LEFT JOIN (SELECT E.[LOAN NUMBER],E.[EXCEPTION ID],E.[DOCUMENT],E.[ISSUE],E.[EXCEPTION REQUEST DATE]
		FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
		WHERE E.[Work Group] IN ('CURATIVE','LANDTRAN') AND E.[EXCEPTION STATUS] NOT IN ('CLOSED','RESOLVED','NOT VALID','INCURABLE','CLOSED WITH VENDOR') 
		AND E.[DOCUMENT] NOT IN ('TITLE POLICY','Assignments','Assignments-3rd Party','Assignments-POA','DEATH CERT','TRUST'))PORCURE
		ON POR.[Loan Number]=PORCURE.[Loan Number]
	
	LEFT JOIN (SELECT E.[LOAN NUMBER],E.[EXCEPTION ID],E.[DOCUMENT],E.[ISSUE],E.[EXCEPTION REQUEST DATE]
		,e.[Gift Card Letter Sent] ,datediff(day,cast(E.[Gift Card Letter Sent] as date),getdate()) AS 'GC1 AGING'
		,e.[Gift Card Letter Sent 2] ,datediff(day,cast(E.[Gift Card Letter Sent 2] as date),getdate()) AS 'GC2 AGING'
		,e.[Gift Card Letter Sent 3] ,datediff(day,cast(E.[Gift Card Letter Sent 3] as date),getdate()) AS 'GC3 AGING'
		,E.[Document Returned Gift Card Eligible],e.[Sent For Gift Card Processing],e.[Sent to Inspection Vendor],E.[Document Received by Vendor]
		FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
		WHERE E.[DOCUMENT] IN ('Proof of Repair') AND E.[Sent For Gift Card Processing] IS NOT NULL) PORGCV
		ON A.[Loan Number]=PORGCV.[Loan Number]

WHERE A.[Loan Status] IN ('ACTIVE') 
AND A.[MCA %] >= 92
AND A.[Tag 2] IS NULL 
AND A.[Incurable Flag] IN ('0') 
AND(a.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
a.[Group] is null)
