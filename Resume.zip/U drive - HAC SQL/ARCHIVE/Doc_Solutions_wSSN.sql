/****** Script for SelectTopNRows command from SSMS  ******/
SELECT distinct

d.LOAN_NBR
,right(b.TAXPYR_IDNTY_VAL,4) 'SSN'
,d.CLIENT_LOAN_NBR
,d.INVESTOR_LOAN_NBR
,b.FULL_NM
,d.PROP_ADDRESS
,d.PROP_STATE
,d.PROP_CITY
,d.PROP_ZIP_CODE
,d.ORIGINAL_TOTAL_UPB
,d.MAX_CLAIM_AMOUNT
,d.STATUS_DESCRIPTION
,d.MCA_PERCENT
,d.MAX_CLAIM_AMOUNT
,d.CLOSING_DATE



  FROM [Reverse_DW].[dbo].[RM_CHAMPION_MASTER_TBL_CURR] D
  join [Reverse_DW].[dbo].[BORR] B 
  on d.LOAN_KEY = b.LOAN_KEY
  
  
 where
 
d.INVESTOR = 'GNMA' 

and d.COUNTERPARTY in ('BOA','RMS','BOA/ML')

and d.STATUS_CODE = '0'

and d.MCA_PERCENT between '95.00' and '97.50'

and b.CURR_IND = 'y'


 

 
 