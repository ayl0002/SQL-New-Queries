
select xx.*, 
case when xx.[Days Since Last Worked] < 31 then '0-30 Days'
when xx.[Days Since Last Worked] < 61 then '31-60 Days'
when xx.[Days Since Last Worked] < 91 then '61-90 Days'
when xx.[Days Since Last Worked] >=91 then '91+ Days'
end as 'Days Since Worked Bucket'
from
(select z.*, ld.[Assigned to date], case when z.[Incurable Date] is null then 'N' else 'Y' end as 'Incurable Flag'
,case when z.[last eligible date] > ld.[assigned to date] then datediff(day,z.[last eligible date],getdate())
when z.[assigned to]=ld.[fnl_rvw_asgn_to_nm] then datediff(day,ld.[assigned to date],getdate()) end as 'Days Active and Eligible to Agent'
,datediff(day,z.[last eligible date],getdate()) as 'Days Eligible'
,datediff(day,z.[last update date],getdate()) as 'Days Since Last Worked'
, CASE WHEN Z.[ASSIGNED TO] IN
 ( 'Sharon Ezeodogbo' 
 ,'Carmina Dennis'
 ,'Sarah Negrete'
 ,'Will Bribiescas'
 ,'Chaunette Horton'
 ,'Amber Ledesma'
 ,'Bridgett Smith'
 ,'Shanika Stanley'
 ,'Bryan Petty'
 ,'Sherry Alquino'
 ,'Thomas Matthews') THEN 'ROBERT GOUGH'
 WHEN Z.[ASSIGNED TO] IN
  ('Chuntel Clayborne-Greer'
  ,'Shawn Clayborne-Greer'
  ,'Sengvilay Heuangpaseuth'
 -- ,'Arthur Lyles'
  ,'Jeff Joyner'
  ,'Latonia Marshall'
  ,'Garrett Carr'
  ,'Alesha Whitby'
  ,'Heidi Molina'
  ,'Krystal Wallace'
  ,'Brianne Hamilton' 
  ,'James McNew') then 'MADELINE CALDWELL'
 WHEN Z.[ASSIGNED TO] IN

 ('Shannon Harris-Mcbrayer'
 ,'Nikki Carrington'
 ,'Norse Lockhart'
 ,'Marisol Trejo'
 ,'Emiliya Ivanova'
 ,'Daniel Pepe'

 ,'Veronica Garcia1'
 ,'Alexander Ledger'
 ,'Shameka Easterling'
 ,'Margaret Cantu'
 ,'Shalonda Rodgers'
 ,'Lance Lyons'
 ,'Eric Wallace') then 'SHANNON HARRIS-MCBRAYER'

 WHEN Z.[ASSIGNED TO] IN
 
( 'Shelia White', 
 
'Sonja Daniel', 
  
  'Cynthia Spurlock',
  'Catrina Wofford',
  'Veronica Garcia',
 'Marisela Martinez', 
 'Jalisa Nelvis') then 'EDWARD MARTIN'
 WHEN Z.[ASSIGNED TO] IN
 ('Brenda Codoner' 
 -- ,'Jeff Marquez' 
  ,'Andrika Lasker'
  ,'Nacie Williams' 
 -- ,'Jo Siel' 
  ,'Rachel Osterman'
 -- ,'Jen Smith' 
  ,'Veronica Riley'
  --,'Anita Shepherd' 
  ,'Shawn Wright' 
  ,'Jesse Eyman' 
  ,'Monica Mullen' 
 ,'Sherry Alquino') then 'KELLIE COLEGROVE'

 WHEN Z.[ASSIGNED TO] IN
 ( 'Briana Morales'
 ,'Marlene Okolita'
  ,'Kat Carson'
 ,'James Patrone'
 ,'Cord Newman'
 ,'Robert Gough'
 ,'Briana Morales'
 ,'Chaunie Horton'
 ,'Patty Rodriguez'
 ,'Brianna Escoto'
 ,'Frederick Garcia') then 'AMANDA BURT'
 WHEN Z.[ASSIGNED TO] IN
('RUDHRA MURTHY KRISHNAN'
,'Georgia Rowe'
 ,'Nikita Hilson'
 ,'Jen Smith'
 ,'Anita Shepherd'
,'SHANKAR NARAYANAN A'
,'MOHAMED SHAFI N'
,'SAI PAJITHA J'
,'RAGAVENDHRA MURUGESAN'
,'SAI VIGNESH PREMSAI'
,'SUVANESAN SUNDAR'
,'ARAVINDH V'
,'SATEESH KUMAR VAKA'
,'SYED ABUTHAGIR S'
,'RAKESH NARASIMHAN GNANA SEKAR'
,'ANINDRA GHOSH') THEN 'ALFREDO SAAVEDRA'
  END AS [MANAGER]


from 
(select a.*, b.[Last Current Active Date],
case when b.[last current active date] > a.[97.5 date] then b.[last current active date] else a.[97.5 date] end as 'Last Eligible Date'
,case when a.MCA_Percent < 97.5 then 'Less Than 97.5'
when a.MCA_Percent < 98 then '97.5 to 97.99'
when a.MCA_Percent < 100 then '98-99.99'
when a.MCA_Percent >= 100 then '100 Plus' end as 'MCA Bucket'
,c.[assigned to]
,c.[FNL_RVW_STS_DESC] as 'Final Review Status'
,cast(c.[FNL_RVW_STS_DT] as date) as 'Last Update Date'
,ex.[Incurable Date]

 from
(select distinct a.loan_nbr, a.mca_percent, a.loan_key, cast(a.MCA_SUBMIT_DT as date) as '97.5 Date'
 
from [dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] a
left join
[dbo].[HUD_ASGN_LOANS] b on a.loan_nbr=b.loan_nbr


where a.status_code = 0
and b.curr_ind = 'Y'
and a.MCA_Percent >= 97.5
and b.[TAG_2_VAL] is null) a

left join (select loan_key, cast(max(txn_dt)as date) as 'Last Current Active Date'
from [dbo].[LOAN_STS_EVT_TXN] where [OLD_LOAN_STS_CD] <> '0' and [NEW_LOAN_STS_CD] = '0'
group by loan_key) b
on a.loan_key=b.loan_key

left join (select loan_nbr, cast(max([EXCP_STS_DTTM]) as date) as 'Incurable Date' from [dbo].[HUD_ASGN_EXCP_EDW] where curr_ind = 'Y' and [EXCP_STS_DESC] = 'Incurable'
group by loan_nbr) ex on a.loan_nbr=ex.loan_nbr

left join
(select loan_nbr, [FNL_RVW_ASGN_TO_NM] as 'Assigned To', [FNL_RVW_STS_DESC],[FNL_RVW_STS_DT]  from [dbo].[HUD_ASGN_FNL_RVW] where Curr_ind = 'Y') c 
on cast(a.loan_nbr as varchar)=c.loan_nbr) z
left join
(select loan_nbr,[FNL_RVW_ASGN_TO_NM], cast(min([FNL_RVW_STS_DT])as date) as 'Assigned To Date' from [dbo].[HUD_ASGN_FNL_RVW] 

group by loan_nbr, [FNL_RVW_ASGN_TO_NM]) ld on cast(z.loan_nbr as varchar)=ld.loan_nbr and z.[assigned to]=ld.[FNL_RVW_ASGN_TO_NM]

group by z.loan_nbr, z.mca_percent, z.loan_key, z.[97.5 date], z.[incurable date], z.[last current active date], z.[last eligible date], z.[assigned to], z.[mca bucket]
,z.[final review status], z.[last update date],ld.[Assigned to date], ld.[FNL_RVW_ASGN_TO_NM]) xx