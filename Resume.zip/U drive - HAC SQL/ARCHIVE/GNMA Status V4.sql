SELECT  
a.loan_nbr
,case
	when B.Loan_Nbr is null then 'not in iassign'
	else 'iAssign Pipe'
	end as 'iassign flag'
,A.CLIENT_LOAN_NBR
,A.Pool_Name
,A.Investor
--,D.FNL_RVW_ASGN_TO_NM
,C.HUD_ASGN_TO_NM
,B.BORR_NM
,A.Borrower_Last_Name
,B.LOAN_STS_DESC
,B.STG_VAL
,B.HUD_STS_DESC
,CAST(b.[BUS_PROC_DT]AS DATE) AS 'BUS_PROC_DT'
,c.[BUS_PROC_DT]
--,d.[BUS_PROC_DT]
,CASE
	WHEN B.ALL_EXCP_CNT > 0 THEN (CAST(B.ALL_EXCP_CNT - B.ALL_CLOSD_EXCP_CNT AS INT)) 
	ELSE B.ALL_EXCP_CNT
	END AS 'Open Exceptions'
,CAST(B.ALL_EXCP_CNT AS INT)AS 'Total Exceptions'
,CAST(B.ALL_CLOSD_EXCP_CNT AS INT)AS 'Closed Exceptions'
,B.MCA_PCT
--,(SELECT MAX (BUS_PROC_DT) FROM [Reverse_DW].[dbo].[HUD_ASGN_LOANS]) AS 'Last Updated Date'
,CASE
	WHEN B.LOAN_STS_DESC in ('Liquidated/Assigned to HU') AND B.HUD_STS_DESC in ('HUD Approved') THEN 'Claim Paid'
	When B.HUD_STS_DESC in ('HUD Denied') and B.LOAN_STS_DESC in ('Active') THEN 'HUD Denied'
	When B.LOAN_STS_DESC not in ('Active') THEN B.LOAN_STS_DESC
	WHEN B.HUD_STS_DESC in ('Pkg Submitted to HUD') and B.LOAN_STS_DESC in ('Active') or B.HUD_STS_DESC in ('Resubmitted to HUD') AND B.LOAN_STS_DESC in ('Active') THEN 'Submitted to HUD'
	WHEN B.MCA_PCT > '97.5' AND B.LOAN_STS_DESC in ('Active') AND B.HUD_STS_DESC in ('Not Started') THEN 'Currently Under Review for Assignment'
	ELSE 'Under 97.5'
	END AS 'Claim Status'
,Case
	WHEN B.MCA_PCT < '97.5' then 'Less Than 97.5'
	WHEN B.MCA_PCT BETWEEN '97.5' and '100' THEN 'Between 97.5 and 100'
	ELSE 'Above 100'
	END AS 'MCA Bucket'
FROM (SELECT A.* FROM [Reverse_DW].[dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] A WHERE A.Investor in ('GNMA'))A
LEFT JOIN (select A.*
		from
		(select max([BUS_PROC_DT]) as 'BUS_PROC_DT' from  [Reverse_DW].[dbo].[HUD_ASGN_LOANS])B
		LEFT JOIN (SELECT * FROM [Reverse_DW].[dbo].[HUD_ASGN_LOANS])A
		ON B.[BUS_PROC_DT]=A.[BUS_PROC_DT]
		) b
 --[Reverse_DW].[dbo].[HUD_ASGN_LOANS] B
ON B.Loan_Key = A.Loan_Key
LEFT JOIN [Reverse_DW].[dbo].[HUD_ASGN_HUD_STS] C
ON C.Loan_Key = b.Loan_Key and 
b.[BUS_PROC_DT]= c.[BUS_PROC_DT]
--LEFT JOIN [Reverse_DW].[dbo].[HUD_ASGN_FNL_RVW] D
--ON D.Loan_Key = b.Loan_Key and d.[BUS_PROC_DT] = b.[BUS_PROC_DT]

--WHERE --B.INVSTR_DESC in ('GNMA') AND 
--A.Investor in ('GNMA')-- and 
--B.STG_VAL not in ('Non HAC')
--and B.Curr_Ind in ('Y') and c.CURR_IND in ('y') and c.CURR_IND in ('y')
--B.LOAN_NBR IS NOT NULL

--ORDER BY ('Claim Status'),('MCA Bucket')
