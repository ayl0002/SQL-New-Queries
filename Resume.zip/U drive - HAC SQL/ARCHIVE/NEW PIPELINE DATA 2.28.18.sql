SET NOCOUNT ON
select distinct
a.[LOAN NUMBER]
,CASE
	WHEN b.[Final Review Status Date] > C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),b.[Final Review Status Date],101)
	WHEN b.[Final Review Status Date] < C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),C.[HUD Status Date],101)
	ELSE CONVERT(NVARCHAR(10),b.[Final Review Status Date],101) END AS 'Last Updated'
	
INTO #UPDATE
FROM SharepointData.dbo.HUDAssignLoans a
left join SHAREPOINTDATA.DBO.HUDAssignFinalReview B
on a.[Loan Number]=b.[Loan Number]
LEFT JOIN SharepointData.DBO.HUDAssignHUDStatus C
ON a.[Loan Number]=C.[Loan Number]
WHERE B.Stage IN ('Final Review','HUD Status')and
b.[Loan Status] in ('Active') and
b.[Tag 2] is null and
a.[MCA %] >=97.5

SET NOCOUNT ON
SELECT
B.[LOAN NUMBER]
,CONVERT(NVARCHAR(10),D.[Exception Status Date],101) as 'Last Exception Update'
,ROW_NUMBER () OVER (PARTITION BY D.[LOAN NUMBER] ORDER BY D.[Exception Status Date] desc)RN 
into #EXCEPTION
FROM SHAREPOINTDATA.DBO.HUDASSIGNHUDSTATUS B
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS D
ON B.[LOAN NUMBER] = D.[LOAN NUMBER]

select distinct
a.[Loan Number]
,LEFT(RIGHT(A.[FHA Case Number],13),10)AS 'FHA'
,a.[Loan Status]
,a.[Pool Name]
,a.[Stage]
,t.[OpenCurative]
,t.[OpenHACG]
,T.[Open Exceptions]
,a.[MCA %]
   ,case 
	when a.[MCA %] between '97.50' and '97.99' then '97.5-97.99'
	when a.[MCA %] between '98.00' and '98.50' then '98.00-98.50'
	when a.[MCA %] between '98.51' and '99.00' then '98.51-99.00'
	when a.[MCA %] between '99.01' and '99.50' then '99.01-99.50'
	when a.[MCA %] between '99.51' and '99.99' then '99.51-99.99'
	when a.[MCA %]between '99.51' and '99.99' then '99.5-99.99'
	when a.[MCA %] >= '100.00' then '100+'
	else '<97.49'
	end as 'MCA Bucket'
,case
	when C.[HUD Status] IN ('Pkg Submitted to HUD','Not Started') then B.[Final Review Status]
	else C.[HUD Status]
	end as 'Status'
,Z.[Last Exception Update]
,case
	when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) < 0  then '0-15'
	when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) between 0 and 15 then '0-15'
	when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) between 16 and 30 then '16-30'
	when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) between 31 and 45 then '31-45'
	when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) between 46 and 60 then '46-60'
	when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) between 61 and 90 then '61-90'
	when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) > 91 then '91+'
end as 'Exception Update Aging'
,U.[Last Updated]
,CASE
when datediff(day,cast(U.[Last Updated] as date),getdate()) < 0  then '0-3'
	when datediff(day,cast(U.[Last Updated] as date),getdate()) between 0 and 3 then '0-3'
	when datediff(day,cast(U.[Last Updated] as date),getdate()) between 4 and 15 then '4-15'
	when datediff(day,cast(U.[Last Updated] as date),getdate()) between 16 and 30 then '16-30'
	when datediff(day,cast(U.[Last Updated] as date),getdate()) between 31 and 45 then '31-45'
	when datediff(day,cast(U.[Last Updated] as date),getdate()) between 46 and 60 then '46-60'
	when datediff(day,cast(U.[Last Updated] as date),getdate()) between 61 and 90 then '61-90'
	when datediff(day,cast(U.[Last Updated] as date),getdate()) >= 91 then '91+'
	END AS 'Last Update Aging'
,CASE
	WHEN B.[Final Review Comment] > C.[HUD Status Comment] THEN B.[Final Review Comment]
	WHEN B.[Final Review Comment] < C.[HUD Status Comment] THEN C.[HUD Status Comment]
	ELSE B.[Final Review Comment]  END AS 'Last Comment'
,b.[Final Review Assigned To]
,case
when b.[Final Review Assigned To] in ('Anindra Ghosh') then 'Offshore 1' 
when b.[Final Review Assigned To] in ('Aravindh V') then 'Offshore 1' 
when b.[Final Review Assigned To] in ('Kalpana Rajendran') then 'Offshore 1' 
when b.[Final Review Assigned To] in ('Ragavendhra Murugesan') then 'Offshore 1' 
when b.[Final Review Assigned To] in ('Rakesh Narasimhan Gnana Sekar') then 'Offshore 1' 
when b.[Final Review Assigned To] in ('Sai Pujitha J') then 'Offshore 1' 
when b.[Final Review Assigned To] in ('Sai Vignesh Premsai') then 'Offshore 1' 
when b.[Final Review Assigned To] in ('Suvanesan Sundar') then 'Offshore 1' 
when b.[Final Review Assigned To] in ('Theresa Selvam') then 'Offshore 1' 
when b.[Final Review Assigned To] in ('Nikita Jaiswal J') then 'Offshore 2' 
when b.[Final Review Assigned To] in ('Pradeep S') then 'Offshore 2' 
when b.[Final Review Assigned To] in ('Priyanka E') then 'Offshore 2' 
when b.[Final Review Assigned To] in ('Rajesh Kumar P') then 'Offshore 2' 
when b.[Final Review Assigned To] in ('Sathish Kumar P') then 'Offshore 2' 
when b.[Final Review Assigned To] in ('Sivachandran M') then 'Offshore 2' 
when b.[Final Review Assigned To] in ('Syed Abuthagir S') then 'Offshore 2' 
when b.[Final Review Assigned To] in ('Venkatachalam M S') then 'Offshore 2' 
when b.[Final Review Assigned To] in ('Gokula Shankar R') then 'Offshore 3' 
when b.[Final Review Assigned To] in ('Akshita S') then 'Offshore 3' 
when b.[Final Review Assigned To] in ('Aishwarya T') then 'Offshore 3' 
when b.[Final Review Assigned To] in ('Santhoshi S') then 'Offshore 3' 
when b.[Final Review Assigned To] in ('Sumithra K') then 'Offshore 3' 
when b.[Final Review Assigned To] in ('Vishal Dhanajeyan Anand') then 'Offshore 3' 
when b.[Final Review Assigned To] in ('Vanitha V') then 'Offshore 3' 
when b.[Final Review Assigned To] in ('Lakshmi Priya Dayalan') then 'Offshore 3' 
when b.[Final Review Assigned To] in ('Jyothi K') then 'Offshore 3' 
when b.[Final Review Assigned To] in ('Thenmozhi Vijayakumar') then 'Offshore 3' 
when b.[Final Review Assigned To] in ('Pradeepa B') then 'Offshore 3' 
when b.[Final Review Assigned To] in ('Celestina A') then 'Offshore 3' 
when b.[Final Review Assigned To] in ('Kalaivani K') then 'Offshore 3' 
when b.[Final Review Assigned To] in ('Kamaleshwaran B') then 'Offshore 3' 
when b.[Final Review Assigned To] in ('Ananthika Vijayan') then 'Offshore 3' 
when b.[Final Review Assigned To] in ('Kat Carson') then 'Amanda Burt' 
when b.[Final Review Assigned To] in ('Brianna Escoto') then 'Amanda Burt' 
when b.[Final Review Assigned To] in ('Patty Rodriguez') then 'Amanda Burt' 
when b.[Final Review Assigned To] in ('Briana Morales') then 'Amanda Burt' 
when b.[Final Review Assigned To] in ('Chaunie Horton') then 'Amanda Burt' 
when b.[Final Review Assigned To] in ('James Patrone') then 'Amanda Burt' 
when b.[Final Review Assigned To] in ('Bianca Stimson') then 'Amanda Burt' 
when b.[Final Review Assigned To] in ('Delilah Smith') then 'Amanda Burt' 
when b.[Final Review Assigned To] in ('Tyllisa Tripp') then 'Amanda Burt' 
when b.[Final Review Assigned To] in ('Lori Wendt') then 'Amanda Burt' 
when b.[Final Review Assigned To] in ('Catrina Wofford') then 'Edward Martin' 
when b.[Final Review Assigned To] in ('Cynthia Spurlock') then 'Edward Martin' 
when b.[Final Review Assigned To] in ('Veronica Garcia') then 'Edward Martin' 
when b.[Final Review Assigned To] in ('Shawneequa Mitchell') then 'Edward Martin' 
when b.[Final Review Assigned To] in ('Sonja Daniel') then 'Edward Martin' 
when b.[Final Review Assigned To] in ('Shelia White') then 'Edward Martin' 
when b.[Final Review Assigned To] in ('Marisela Martinez') then 'Edward Martin' 
when b.[Final Review Assigned To] in ('Tonia Holloman') then 'Edward Martin' 
when b.[Final Review Assigned To] in ('Ladarius Bryant') then 'Edward Martin' 
when b.[Final Review Assigned To] in ('Nancy Shead') then 'Edward Martin' 
when b.[Final Review Assigned To] in ('Brenda Codoner') then 'Kellie Colegrove' 
when b.[Final Review Assigned To] in ('Andrika Lasker') then 'Kellie Colegrove' 
when b.[Final Review Assigned To] in ('Monica Mullen') then 'Kellie Colegrove' 
when b.[Final Review Assigned To] in ('Nacie Williams') then 'Kellie Colegrove' 
when b.[Final Review Assigned To] in ('Jesse Eyman') then 'Kellie Colegrove' 
when b.[Final Review Assigned To] in ('Veronica Riley') then 'Kellie Colegrove' 
when b.[Final Review Assigned To] in ('Shawn Wright') then 'Kellie Colegrove' 
when b.[Final Review Assigned To] in ('Lexie Beedle') then 'Kellie Colegrove' 
when b.[Final Review Assigned To] in ('Michelle McRae') then 'Kellie Colegrove' 
when b.[Final Review Assigned To] in ('Ray Castillo') then 'Kellie Colegrove' 
when b.[Final Review Assigned To] in ('Jeff Joyner') then 'Madeline Caldwell' 
when b.[Final Review Assigned To] in ('LaTonia Marshall') then 'Madeline Caldwell' 
when b.[Final Review Assigned To] in ('Krystal Wallace') then 'Madeline Caldwell' 
when b.[Final Review Assigned To] in ('Brianne Hamilton') then 'Madeline Caldwell' 
when b.[Final Review Assigned To] in ('Shawn Clayborne-Greer') then 'Madeline Caldwell' 
when b.[Final Review Assigned To] in ('Sengvilay Heuangpaseuth') then 'Madeline Caldwell' 
when b.[Final Review Assigned To] in ('Heidi Molina') then 'Madeline Caldwell' 
when b.[Final Review Assigned To] in ('James McNew') then 'Madeline Caldwell' 
when b.[Final Review Assigned To] in ('Will Bribiescas') then 'Robert Gough' 
when b.[Final Review Assigned To] in ('Shanika Stanley') then 'Robert Gough' 
when b.[Final Review Assigned To] in ('Thomas Matthews') then 'Robert Gough' 
when b.[Final Review Assigned To] in ('Bryan Petty') then 'Robert Gough' 
when b.[Final Review Assigned To] in ('Sarah Negrete') then 'Robert Gough' 
when b.[Final Review Assigned To] in ('Sharon Ezeodogbo') then 'Robert Gough' 
when b.[Final Review Assigned To] in ('Bridgett Smith') then 'Robert Gough' 
when b.[Final Review Assigned To] in ('Amber Ledesma') then 'Robert Gough' 
when b.[Final Review Assigned To] in ('Carmina Dennis') then 'Robert Gough' 
when b.[Final Review Assigned To] in ('Sherry Alquino') then 'Robert Gough' 
when b.[Final Review Assigned To] in ('Marisol Trejo') then 'Shannon Harris-Mcbrayer' 
when b.[Final Review Assigned To] in ('Nikki Carrington') then 'Shannon Harris-Mcbrayer' 
when b.[Final Review Assigned To] in ('Shameka Easterling') then 'Shannon Harris-Mcbrayer' 
when b.[Final Review Assigned To] in ('Alexander Ledger') then 'Shannon Harris-Mcbrayer' 
when b.[Final Review Assigned To] in ('Norse Lockhart') then 'Shannon Harris-Mcbrayer' 
when b.[Final Review Assigned To] in ('Emiliya Ivanova') then 'Shannon Harris-Mcbrayer' 
when b.[Final Review Assigned To] in ('Margaret Cantu') then 'Shannon Harris-Mcbrayer' 
when b.[Final Review Assigned To] in ('Lance Lyons') then 'Shannon Harris-Mcbrayer' 
when b.[Final Review Assigned To] in ('Shalonda Rodgers') then 'Shannon Harris-Mcbrayer' 
when b.[Final Review Assigned To] in ('Eric Wallace') then 'Shannon Harris-Mcbrayer' 
when b.[Final Review Assigned To] in ('Garrett Carr') then 'Resubmission Team' 
when b.[Final Review Assigned To] in ('Kari Chadwell') then 'Pipeline Management' 
end as 'Manager'

,case
when b.[Final Review Assigned To] in ('Anindra Ghosh') then 'Offshore' 
when b.[Final Review Assigned To] in ('Aravindh V') then 'Offshore' 
when b.[Final Review Assigned To] in ('Kalpana Rajendran') then 'Offshore' 
when b.[Final Review Assigned To] in ('Ragavendhra Murugesan') then 'Offshore' 
when b.[Final Review Assigned To] in ('Rakesh Narasimhan Gnana Sekar') then 'Offshore' 
when b.[Final Review Assigned To] in ('Sai Pujitha J') then 'Offshore' 
when b.[Final Review Assigned To] in ('Sai Vignesh Premsai') then 'Offshore' 
when b.[Final Review Assigned To] in ('Suvanesan Sundar') then 'Offshore' 
when b.[Final Review Assigned To] in ('Theresa Selvam') then 'Offshore' 
when b.[Final Review Assigned To] in ('Nikita Jaiswal J') then 'Offshore' 
when b.[Final Review Assigned To] in ('Pradeep S') then 'Offshore' 
when b.[Final Review Assigned To] in ('Priyanka E') then 'Offshore' 
when b.[Final Review Assigned To] in ('Rajesh Kumar P') then 'Offshore' 
when b.[Final Review Assigned To] in ('Sathish Kumar P') then 'Offshore' 
when b.[Final Review Assigned To] in ('Sivachandran M') then 'Offshore' 
when b.[Final Review Assigned To] in ('Syed Abuthagir S') then 'Offshore' 
when b.[Final Review Assigned To] in ('Venkatachalam M S') then 'Offshore' 
when b.[Final Review Assigned To] in ('Gokula Shankar R') then 'Offshore' 
when b.[Final Review Assigned To] in ('Akshita S') then 'Offshore' 
when b.[Final Review Assigned To] in ('Aishwarya T') then 'Offshore' 
when b.[Final Review Assigned To] in ('Santhoshi S') then 'Offshore' 
when b.[Final Review Assigned To] in ('Sumithra K') then 'Offshore' 
when b.[Final Review Assigned To] in ('Vishal Dhanajeyan Anand') then 'Offshore' 
when b.[Final Review Assigned To] in ('Vanitha V') then 'Offshore' 
when b.[Final Review Assigned To] in ('Lakshmi Priya Dayalan') then 'Offshore' 
when b.[Final Review Assigned To] in ('Jyothi K') then 'Offshore' 
when b.[Final Review Assigned To] in ('Thenmozhi Vijayakumar') then 'Offshore' 
when b.[Final Review Assigned To] in ('Pradeepa B') then 'Offshore' 
when b.[Final Review Assigned To] in ('Celestina A') then 'Offshore' 
when b.[Final Review Assigned To] in ('Kalaivani K') then 'Offshore' 
when b.[Final Review Assigned To] in ('Kamaleshwaran B') then 'Offshore' 
when b.[Final Review Assigned To] in ('Ananthika Vijayan') then 'Offshore' 
when b.[Final Review Assigned To] in ('Kat Carson') then 'Arizona' 
when b.[Final Review Assigned To] in ('Brianna Escoto') then 'Arizona' 
when b.[Final Review Assigned To] in ('Patty Rodriguez') then 'Arizona' 
when b.[Final Review Assigned To] in ('Briana Morales') then 'Arizona' 
when b.[Final Review Assigned To] in ('Chaunie Horton') then 'Arizona' 
when b.[Final Review Assigned To] in ('James Patrone') then 'Arizona' 
when b.[Final Review Assigned To] in ('Bianca Stimson') then 'Arizona' 
when b.[Final Review Assigned To] in ('Delilah Smith') then 'Arizona' 
when b.[Final Review Assigned To] in ('Tyllisa Tripp') then 'Arizona' 
when b.[Final Review Assigned To] in ('Lori Wendt') then 'Arizona' 
when b.[Final Review Assigned To] in ('Catrina Wofford') then 'Texas' 
when b.[Final Review Assigned To] in ('Cynthia Spurlock') then 'Texas' 
when b.[Final Review Assigned To] in ('Veronica Garcia') then 'Texas' 
when b.[Final Review Assigned To] in ('Shawneequa Mitchell') then 'Texas' 
when b.[Final Review Assigned To] in ('Sonja Daniel') then 'Texas' 
when b.[Final Review Assigned To] in ('Shelia White') then 'Texas' 
when b.[Final Review Assigned To] in ('Marisela Martinez') then 'Texas' 
when b.[Final Review Assigned To] in ('Tonia Holloman') then 'Texas' 
when b.[Final Review Assigned To] in ('Ladarius Bryant') then 'Texas' 
when b.[Final Review Assigned To] in ('Nancy Shead') then 'Texas' 
when b.[Final Review Assigned To] in ('Brenda Codoner') then 'Arizona' 
when b.[Final Review Assigned To] in ('Andrika Lasker') then 'Arizona' 
when b.[Final Review Assigned To] in ('Monica Mullen') then 'Arizona' 
when b.[Final Review Assigned To] in ('Nacie Williams') then 'Arizona' 
when b.[Final Review Assigned To] in ('Jesse Eyman') then 'Arizona' 
when b.[Final Review Assigned To] in ('Veronica Riley') then 'Arizona' 
when b.[Final Review Assigned To] in ('Shawn Wright') then 'Arizona' 
when b.[Final Review Assigned To] in ('Lexie Beedle') then 'Arizona' 
when b.[Final Review Assigned To] in ('Michelle McRae') then 'Arizona' 
when b.[Final Review Assigned To] in ('Ray Castillo') then 'Arizona' 
when b.[Final Review Assigned To] in ('Jeff Joyner') then 'Texas' 
when b.[Final Review Assigned To] in ('LaTonia Marshall') then 'Texas' 
when b.[Final Review Assigned To] in ('Krystal Wallace') then 'Texas' 
when b.[Final Review Assigned To] in ('Brianne Hamilton') then 'Texas' 
when b.[Final Review Assigned To] in ('Shawn Clayborne-Greer') then 'Texas' 
when b.[Final Review Assigned To] in ('Sengvilay Heuangpaseuth') then 'Texas' 
when b.[Final Review Assigned To] in ('Heidi Molina') then 'Texas' 
when b.[Final Review Assigned To] in ('James McNew') then 'Texas' 
when b.[Final Review Assigned To] in ('Will Bribiescas') then 'Arizona' 
when b.[Final Review Assigned To] in ('Shanika Stanley') then 'Arizona' 
when b.[Final Review Assigned To] in ('Thomas Matthews') then 'Arizona' 
when b.[Final Review Assigned To] in ('Bryan Petty') then 'Arizona' 
when b.[Final Review Assigned To] in ('Sarah Negrete') then 'Arizona' 
when b.[Final Review Assigned To] in ('Sharon Ezeodogbo') then 'Arizona' 
when b.[Final Review Assigned To] in ('Bridgett Smith') then 'Arizona' 
when b.[Final Review Assigned To] in ('Amber Ledesma') then 'Arizona' 
when b.[Final Review Assigned To] in ('Carmina Dennis') then 'Arizona' 
when b.[Final Review Assigned To] in ('Sherry Alquino') then 'Arizona' 
when b.[Final Review Assigned To] in ('Marisol Trejo') then 'Texas' 
when b.[Final Review Assigned To] in ('Nikki Carrington') then 'Texas' 
when b.[Final Review Assigned To] in ('Shameka Easterling') then 'Texas' 
when b.[Final Review Assigned To] in ('Alexander Ledger') then 'Texas' 
when b.[Final Review Assigned To] in ('Norse Lockhart') then 'Texas' 
when b.[Final Review Assigned To] in ('Emiliya Ivanova') then 'Texas' 
when b.[Final Review Assigned To] in ('Margaret Cantu') then 'Texas' 
when b.[Final Review Assigned To] in ('Lance Lyons') then 'Texas' 
when b.[Final Review Assigned To] in ('Shalonda Rodgers') then 'Texas' 
when b.[Final Review Assigned To] in ('Eric Wallace') then 'Texas' 
when b.[Final Review Assigned To] in ('Garrett Carr') then 'Resubmission Team' 
when b.[Final Review Assigned To] in ('Kari Chadwell') then 'Pipeline Management' 
end as 'Site'


from SharepointData.dbo.HUDAssignLoans a
left join SharepointData.dbo.HUDAssignFinalReview b
on b.[Loan Number]=a.[Loan Number]
left join SharepointData.dbo.HUDAssignHUDStatus c
on c.[Loan Number]=a.[Loan Number]
left join sharepointdata.dbo.HUDAssignLoanExceptionTotals t
on a.[Loan Number]=t.[Loan Number]
LEFT JOIN #UPDATE U
ON A.[Loan Number]=U.[Loan Number]
LEFT JOIN #EXCEPTION Z
ON A.[Loan Number]=Z.[Loan Number] and z.RN=1


where 
a.[Stage] in ('Final Review','HUD Status') and
a.[Tag 2] is null and
a.[Loan Status] in ('Active') and
(a.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
a.[Group] is null) and
a.[MCA %]>=97.5 and
a.[Incurable Flag] in ('0')

DROP TABLE #UPDATE, #EXCEPTION