SET ANSI_WARNINGS OFF
SET NOCOUNT ON
select finito2.*, 
case when [Days in Pipeline] < 4 then '1-3 Days'
when [Days in Pipeline] < 16 then '4-15 Days'
when [Days in Pipeline] < 31 then '16-30 Days'
when [Days in Pipeline] < 61 then '31-60 Days'
when [Days in Pipeline] < 91 then '61-90 Days'
when [Days in Pipeline] < 121 then '91-120 Days'
else '121+' end as 'Karis Special Aging Bucket'  into ##basehactable from
(select finito.*, 


case when pnd.loan_nbr is not null then 'Y' else 'N' end as 'Pending at HUD',
case when datediff(day,[Cure Close Date],getdate()) < 4 then '1-3 Days'
when datediff(day,[Cure Close Date],getdate()) < 16 then '4-15 Days'
when datediff(day,[Cure Close Date],getdate()) < 31 then '16-30 Days'
when datediff(day,[Cure Close Date],getdate()) < 61 then '31-60 Days'
when datediff(day,[Cure Close Date],getdate()) < 91 then '61-90 Days'
when datediff(day,[Cure Close Date],getdate()) < 121 then '91-120 Days'
else '121+ Days' end as 'Pipeline Aging',

case when [Days in Active] is null and [Days out of Curative] <= [Days Since 97.5] then [Days out of Curative]


when [Days out of Curative] is null and [Days In Active] <= [Days Since 97.5] then datediff(day,[Active Date],getdate())
when [Days out of Curative] is null and [Days In Active] > [Days Since 97.5] then datediff(day,[MCA 97.5 Date],getdate())
when [Days out of Curative] <= [Days in Active] and [Days out of Curative] <= [Days Since 97.5] then datediff(day,[Cure Close Date],getdate())
when [Days in Active] <= [Days out of Curative] and [Days in Active] <= [Days since 97.5] then datediff(day,[Active Date],getdate()) 
else datediff(day,[MCA 97.5 Date],getdate()) end as 'Days in Pipeline' from

(select final.* , datediff(day,[Cure Close Date],getdate()) as 'Days out of Curative',
case when [Approval Date] is null and [Curative Count] is null and (grp_desc is null or grp_desc <> 'Grp 5 BofA GNMAs') and [incrbl_flg_desc] = '0' 
and ([tag_2_val] is null or [tag_2_val] in ('HOLD LOC', 'HUD LOC'))
   then 'Y' else 'N' end as 'Pipeline'
from 
(select base.*, apr.[Approval Date], ast.[Active Date], [INCRBL_FLG_DESC],[TAG_2_VAL], hld.[grp_desc], hld.[MCA 97.5 Date], fnl.[HAC Agent], fnl.[Manager],fnl.[Site], cc.[Curative Count], datediff(day,hld.[MCA 97.5 Date],getdate()) as 'Days Since 97.5', exc.[Cure Close Date],  hac.[Exception Count], datediff(day,sbm.[Last Submission],getdate()) as 'Days Since Submitted', datediff(day,ast.[Active Date],getdate()) as 'Days In Active'
,
case when exc.[Cure Close Date] is null then 'Never in Curative'
when  datediff(day,exc.[Cure Close Date],getdate()) < 31 then '1-30 Days'
when datediff(day,exc.[Cure Close Date],getdate()) < 61 then '31-60 Days'
when datediff(day,exc.[Cure Close Date],getdate()) < 91 then '61-90 Days'
when datediff(day,exc.[Cure Close Date],getdate()) < 120 then '91-120 Days'
when datediff(day,exc.[Cure Close Date],getdate()) >= 120 then '120+ Days' end as 'Days No Curatives',
case when sbm.[Last Submission] is null then 'Never Submitted'
when  datediff(day,sbm.[Last Submission],getdate()) < 31 then '1-30 Days'
when datediff(day,sbm.[Last Submission],getdate()) < 61 then '31-60 Days'
when datediff(day,sbm.[Last Submission],getdate()) < 91 then '61-90 Days'
when datediff(day,sbm.[Last Submission],getdate()) < 120 then '91-120 Days'
when datediff(day,sbm.[Last Submission],getdate()) >= 120 then '120+ Days' end as 'Days Since Submission',
case when ast.[Active Date] is null then 'Never out of Active'
when  datediff(day,ast.[Active Date],getdate()) < 31 then '1-30 Days'
when datediff(day,ast.[Active Date],getdate()) < 61 then '31-60 Days'
when datediff(day,ast.[Active Date],getdate()) < 91 then '61-90 Days'
when datediff(day,ast.[Active Date],getdate()) < 120 then '91-120 Days'
when datediff(day,ast.[Active Date],getdate()) >= 120 then '120+ Days' end as 'Days Active',
h1.[HAC 1 Doc], h1.[HAC 1 Issue], h1.[HAC 1 Start], h1.[HAC 1 Aging],
h2.[HAC 2 Doc], h2.[HAC 2 Issue], h2.[HAC 2 Start], h2.[HAC 2 Aging],
h3.[HAC 3 Doc], h3.[HAC 3 Issue], h3.[HAC 3 Start], h3.[HAC 3 Aging],
case when h1.[HAC 1 Doc] is null then '0 Exceptions' when h2.[HAC 2 Doc] is null then '1 Exception' when h3.[HAC 3 Doc] is null then '2 Exceptions' else '3+ Exceptions' end as 'HAC Exception Count'
,case when [HAC 1 Doc] like '%HOA%' or [HAC 2 Doc] like '%HOA%' or [HAC 3 Doc] like '%HOA%' then 'Y' else 'N' end as 'HOA Issue' 
,case when [HAC 1 Doc] like '%tax%' or [HAC 2 Doc] like '%tax%' or [HAC 3 Doc] like '%tax%' then 'Y' else 'N' end as 'Tax Issue'
,case when [HAC 1 Doc] like '%repair%' or [HAC 2 Doc] like '%repair%' or [HAC 3 Doc] like '%repair%' then 'Y' else 'N' end as 'Proof of Repair Issue'
,case when [HAC 1 Doc] like '%OCC%' or [HAC 2 Doc] like '%OCC%' or [HAC 3 Doc] like '%OCC%' then 'Y' else 'N' end as 'OCC Issue'
,case when [HAC 1 Doc] like '%Hazard Insurance%' or [HAC 2 Doc] like '%Hazard Insurance%' or [HAC 3 Doc] like '%Hazard Insurance%' then 'Y' else 'N' end as 'Haz Ins Issue'
from
(select loan_nbr, loan_key from [dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] where status_code = 0 and mca_percent >= 97.5 and pool_name not in  ('BOAHOLDOVER','BOAWarehouse','NSBOA Warehouse','NSBOAWarehouse')  ) base
left join
(select loan_nbr, max([excp_sts_dttm]) as 'Cure Close Date' from [dbo].[HUD_ASGN_EXCP_EDW] where curr_ind = 'Y' and [WRK_GRP_DESC] in ('Curative', 'LandTran') and [EXCP_STS_DESC]  in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable')
group by loan_nbr) exc on cast(base.loan_nbr as varchar)=exc.loan_nbr
left join
(select loan_nbr, count(*) as 'Curative Count' from [dbo].[HUD_ASGN_EXCP_EDW] where [WRK_GRP_DESC] in ('Curative', 'LandTran') and [EXCP_STS_DESC] not in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable') --and doc_desc not like '%death%' 
and curr_ind = 'Y' group by loan_nbr) cc on cast(base.loan_nbr as varchar)=cc.loan_nbr
left join
(select loan_nbr, max([DT_SBMT_TO_HUD]) as 'Last Submission' from [dbo].[HUD_ASSGN_DT_SBMT_RESBMT] group by loan_nbr) sbm on cast(base.loan_nbr as varchar)=sbm.loan_nbr
left join
(select loan_key, max([TXN_DT])  as 'Active Date' from [dbo].[LOAN_STS_EVT_TXN] where [NEW_LOAN_STS_CD] = '0' and [OLD_LOAN_STS_CD] <> '0' and curr_ind = 'Y' group by loan_key) ast on base.loan_key=ast.loan_key
left join
(select loan_nbr, count(*) as 'Exception Count' from [dbo].[HUD_ASGN_EXCP_EDW] where curr_ind = 'Y' and [WRK_GRP_DESC] = ('HACG') and [EXCP_STS_DESC] not in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable') group by loan_nbr) hac on cast(base.loan_nbr as varchar)=hac.loan_nbr
left join
(select loan_nbr, DOC_DESC as 'HAC 1 Doc', [ISSU_DESC] as 'HAC 1 Issue', [excp_rqst_dttm] as 'HAC 1 Start', datediff(day,[excp_rqst_dttm],getdate()) as 'HAC 1 Aging' from ##EXCEPTIONBASEKARI where xrank =1) h1 on cast(base.loan_nbr as varchar)=h1.loan_nbr
left join
(select loan_nbr, DOC_DESC as 'HAC 2 Doc', [ISSU_DESC] as 'HAC 2 Issue', [excp_rqst_dttm] as 'HAC 2 Start', datediff(day,[excp_rqst_dttm],getdate()) as 'HAC 2 Aging' from ##EXCEPTIONBASEKARI where xrank =2) h2 on cast(base.loan_nbr as varchar)=h2.loan_nbr
left join
(select loan_nbr, DOC_DESC as 'HAC 3 Doc', [ISSU_DESC] as 'HAC 3 Issue', [excp_rqst_dttm] as 'HAC 3 Start', datediff(day,[excp_rqst_dttm],getdate()) as 'HAC 3 Aging' from ##EXCEPTIONBASEKARI where xrank =3) h3 on cast(base.loan_nbr as varchar)=h3.loan_nbr
left join
(select a.loan_nbr, a.fnl_rvw_asgn_to_nm as 'HAC Agent',b.MGR_NM as 'Manager', b.ST_LOC as 'Site' from [dbo].[HUD_ASGN_FNL_RVW] a left join dbo.TP_HUD_RSTR b on a.fnl_rvw_asgn_to_nm = b.AGNT_NM where curr_ind = 'Y') fnl on cast(base.loan_nbr as varchar)=fnl.loan_nbr
left join 
(select distinct [Loan Number] as loan_nbr,[HUD Assigned Loans Tag2] as [TAG_2_VAL], [MCA 97.5 Date]
                           ,[Group] as [GRP_DESC]
                           ,[Incurable Flag] as [INCRBL_FLG_DESC]
                     from RM_DMART01..dm_hud_dim(nolock) 
                     where curr_ind='y'
              ) hld on cast(base.loan_nbr as varchar)=hld.loan_nbr 
left join
(select lndr_loan_nbr, max([HUD_APRV_DT]) as 'Approval Date' from [dbo].[TP_HRMT_PRELIM_TTL_APRV] group by lndr_loan_nbr) apr on cast(base.loan_nbr as varchar)=apr.lndr_loan_nbr

) final) finito
left join
(select loan_nbr from ##pending) pnd on cast(finito.loan_nbr as varchar)=pnd.loan_nbr
where ([grp_desc] is null or [grp_desc] <> 'Grp 5 BofA GNMAs') ) finito2



select base.*, sec.[BOM Exception Count], lc.[Last HAC Cure] from
(select * from ##basehactable) base
left join
(select loan_nbr, count(*) as 'BOM Exception Count' from 
(select base.*, sta.[excp_sts_desc]  from 
(select distinct loan_nbr, excp_id, max([EFF_DTTM]) as [Exc Eff Date] from [dbo].[HUD_ASGN_EXCP_EDW] where [WRK_GRP_DESC] in ('HACG') and [EFF_DTTM] <= '2018-08-01' and doc_desc not like '%Death%'
group by loan_nbr, excp_id) base
left join
(select loan_nbr, excp_id, eff_dttm, [EXCP_STS_DESC] from [dbo].[HUD_ASGN_EXCP_EDW] ) sta on base.loan_nbr=sta.loan_nbr and base.excp_id=sta.excp_id and base.[Exc Eff Date]=sta.[EFF_DTTM]) dac  
where  [EXCP_STS_DESC] not in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable')  group by loan_nbr) sec on cast(base.loan_nbr as varchar)=sec.loan_nbr

left join
(select loan_nbr, max(excp_sts_dttm) as [Last HAC Cure] from [dbo].[HUD_ASGN_EXCP_EDW] where [EXCP_STS_DESC]  in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable') and curr_ind = 'Y' and wrk_grp_desc = 'HACG' and
excp_sts_dttm >= '2018-08-01' group by loan_nbr) lc on cast(base.loan_nbr as varchar)=lc.loan_nbr


order by [Pending at HUD]

--Drop table ##basehactable