select loan_nbr,[EXCP_RQST_DTTM], [DOC_DESC],[ISSU_DESC] , [EXCP_ASGN_TO_DESC] , rank() over (partition by loan_nbr order by  [EXCP_RQST_DTTM] asc) as XRank into ##ExceptionbaseKARI
from
(select loan_nbr, [EXCP_RQST_DTTM],[DOC_DESC], issu_desc, [EXCP_ASGN_TO_DESC] from [dbo].[HUD_ASGN_EXCP_EDW] where curr_ind = 'Y' and [WRK_GRP_DESC] in ('HACG') and [EXCP_STS_DESC] not in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable')) a

SELECT * FROM ##ExceptionbaseKARI