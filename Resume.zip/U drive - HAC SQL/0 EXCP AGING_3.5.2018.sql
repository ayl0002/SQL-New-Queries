SET NOCOUNT ON
SELECT
B.[LOAN NUMBER]
,CONVERT(NVARCHAR(10),D.[Exception Status Date],101) as 'Last Exception Update'
,ROW_NUMBER () OVER (PARTITION BY D.[LOAN NUMBER] ORDER BY D.[Exception Status Date] desc)RN 
into #EXCEPTION
FROM SHAREPOINTDATA.DBO.HUDASSIGNHUDSTATUS B
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS D
ON B.[LOAN NUMBER] = D.[LOAN NUMBER]

select distinct
a.[LOAN NUMBER]
,CASE
	WHEN b.[Final Review Status Date] > C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),b.[Final Review Status Date],101)
	WHEN b.[Final Review Status Date] < C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),C.[HUD Status Date],101)
	ELSE CONVERT(NVARCHAR(10),b.[Final Review Status Date],101) END AS 'Last Updated'
	
INTO #UPDATE
FROM SharepointData.dbo.HUDAssignLoans a
left join SHAREPOINTDATA.DBO.HUDAssignFinalReview B
on a.[Loan Number]=b.[Loan Number]
LEFT JOIN SharepointData.DBO.HUDAssignHUDStatus C
ON a.[Loan Number]=C.[Loan Number]

SELECT
l.[Loan Number]
,LEFT(RIGHT(l.[FHA Case Number],13),10)AS 'FHA'
,s.[Stage]
,case
	when s.[HUD Status] IN ('Pkg Submitted to HUD','Not Started') then f.[Final Review Status]
	else s.[HUD Status]
	end as 'Status'
,f.[Final Review Assigned To]
,f.[Final Review Status Updated By]
,f.[MCA]
,case 
	when f.MCA between '97.50' and '97.99' then '97.5-97.99'
	when f.MCA between '98.00' and '98.50' then '98.00-98.50'
	when f.MCA between '98.51' and '99.00' then '98.51-99.00'
	when f.MCA between '99.01' and '99.50' then '99.01-99.50'
	when f.MCA between '99.51' and '99.99' then '99.51-99.99'
	when f.MCA between '99.51' and '99.99' then '99.5-99.99'
	when f.MCA >= '100.00' then '100+'
	else '<97.49'
	end as 'MCA Bucket'
,l.[Open Exceptions]
,Z.[Last Exception Update]
,case
	when datediff(day,cast(Z.[Last Exception Update] as date),getdate()) < 0  then '0-3'
	when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) between 0 and 3 then '0-3'
	when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) between 4 and 15 then '4-15'
	when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) between 16 and 30 then '16-30'
	when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) between 31 and 45 then '31-45'
	when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) between 46 and 60 then '46-60'
	when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) between 61 and 90 then '61-90'
	when datediff(day,cast(Z.[Last Exception Update]as date),getdate()) > 91 then '91+'
end as 'Exception Update Aging'
,case
	when datediff(day,cast(U.[Last Updated] as date),getdate()) < 0  then '0-3'
	when datediff(day,cast(U.[Last Updated] as date),getdate()) between 0 and 3 then '0-3'
	when datediff(day,cast(U.[Last Updated] as date),getdate()) between 4 and 15 then '4-15'
	when datediff(day,cast(U.[Last Updated] as date),getdate()) between 16 and 30 then '16-30'
	when datediff(day,cast(U.[Last Updated] as date),getdate()) between 31 and 45 then '31-45'
	when datediff(day,cast(U.[Last Updated] as date),getdate()) between 46 and 60 then '46-60'
	when datediff(day,cast(U.[Last Updated] as date),getdate()) between 61 and 90 then '61-90'
	when datediff(day,cast(U.[Last Updated] as date),getdate()) >= 91 then '91+'
	END AS 'Last Update Aging'
	
,case
when [Final Review Assigned To] in ('Anindra Ghosh') then 'Offshore 1' 
when [Final Review Assigned To] in ('Aravindh V') then 'Offshore 1' 
when [Final Review Assigned To] in ('Kalpana Rajendran') then 'Offshore 1' 
when [Final Review Assigned To] in ('Ragavendhra Murugesan') then 'Offshore 1' 
when [Final Review Assigned To] in ('Rakesh Narasimhan Gnana Sekar') then 'Offshore 1' 
when [Final Review Assigned To] in ('Sai Pujitha J') then 'Offshore 1' 
when [Final Review Assigned To] in ('Sai Vignesh Premsai') then 'Offshore 1' 
when [Final Review Assigned To] in ('Suvanesan Sundar') then 'Offshore 1' 
when [Final Review Assigned To] in ('Theresa Selvam') then 'Offshore 1' 
when [Final Review Assigned To] in ('Nikita Jaiswal J') then 'Offshore 2' 
when [Final Review Assigned To] in ('Pradeep S') then 'Offshore 2' 
when [Final Review Assigned To] in ('Priyanka E') then 'Offshore 2' 
when [Final Review Assigned To] in ('Rajesh Kumar P') then 'Offshore 2' 
when [Final Review Assigned To] in ('Sathish Kumar P') then 'Offshore 2' 
when [Final Review Assigned To] in ('Sivachandran M') then 'Offshore 2' 
when [Final Review Assigned To] in ('Syed Abuthagir S') then 'Offshore 2' 
when [Final Review Assigned To] in ('Venkatachalam M S') then 'Offshore 2' 
when [Final Review Assigned To] in ('Gokula Shankar R') then 'Offshore 3' 
when [Final Review Assigned To] in ('Akshita S') then 'Offshore 3' 
when [Final Review Assigned To] in ('Aishwarya T') then 'Offshore 3' 
when [Final Review Assigned To] in ('Santhoshi S') then 'Offshore 3' 
when [Final Review Assigned To] in ('Sumithra K') then 'Offshore 3' 
when [Final Review Assigned To] in ('Vishal Dhanajeyan Anand') then 'Offshore 3' 
when [Final Review Assigned To] in ('Vanitha V') then 'Offshore 3' 
when [Final Review Assigned To] in ('Lakshmi Priya Dayalan') then 'Offshore 3' 
when [Final Review Assigned To] in ('Jyothi K') then 'Offshore 3' 
when [Final Review Assigned To] in ('Thenmozhi Vijayakumar') then 'Offshore 3' 
when [Final Review Assigned To] in ('Pradeepa B') then 'Offshore 3' 
when [Final Review Assigned To] in ('Celestina A') then 'Offshore 3' 
when [Final Review Assigned To] in ('Kalaivani K') then 'Offshore 3' 
when [Final Review Assigned To] in ('Kamaleshwaran B') then 'Offshore 3' 
when [Final Review Assigned To] in ('Ananthika Vijayan') then 'Offshore 3' 
when [Final Review Assigned To] in ('Kat Carson') then 'Amanda Burt' 
when [Final Review Assigned To] in ('Brianna Escoto') then 'Amanda Burt' 
when [Final Review Assigned To] in ('Patty Rodriguez') then 'Amanda Burt' 
when [Final Review Assigned To] in ('Briana Morales') then 'Amanda Burt' 
when [Final Review Assigned To] in ('Chaunie Horton') then 'Amanda Burt' 
when [Final Review Assigned To] in ('James Patrone') then 'Amanda Burt' 
when [Final Review Assigned To] in ('Bianca Stimson') then 'Amanda Burt' 
when [Final Review Assigned To] in ('Delilah Smith') then 'Amanda Burt' 
when [Final Review Assigned To] in ('Tyllisa Tripp') then 'Amanda Burt' 
when [Final Review Assigned To] in ('Lori Wendt') then 'Amanda Burt' 
when [Final Review Assigned To] in ('Catrina Wofford') then 'Edward Martin' 
when [Final Review Assigned To] in ('Cynthia Spurlock') then 'Edward Martin' 
when [Final Review Assigned To] in ('Veronica Garcia') then 'Edward Martin' 
when [Final Review Assigned To] in ('Shawneequa Mitchell') then 'Edward Martin' 
when [Final Review Assigned To] in ('Sonja Daniel') then 'Edward Martin' 
when [Final Review Assigned To] in ('Shelia White') then 'Edward Martin' 
when [Final Review Assigned To] in ('Marisela Martinez') then 'Edward Martin' 
when [Final Review Assigned To] in ('Tonia Holloman') then 'Edward Martin' 
when [Final Review Assigned To] in ('Ladarius Bryant') then 'Edward Martin' 
when [Final Review Assigned To] in ('Nancy Shead') then 'Edward Martin' 
when [Final Review Assigned To] in ('Brenda Codoner') then 'Kellie Colegrove' 
when [Final Review Assigned To] in ('Andrika Lasker') then 'Kellie Colegrove' 
when [Final Review Assigned To] in ('Monica Mullen') then 'Kellie Colegrove' 
when [Final Review Assigned To] in ('Nacie Williams') then 'Kellie Colegrove' 
when [Final Review Assigned To] in ('Jesse Eyman') then 'Kellie Colegrove' 
when [Final Review Assigned To] in ('Veronica Riley') then 'Kellie Colegrove' 
when [Final Review Assigned To] in ('Shawn Wright') then 'Kellie Colegrove' 
when [Final Review Assigned To] in ('Lexie Beedle') then 'Kellie Colegrove' 
when [Final Review Assigned To] in ('Michelle McRae') then 'Kellie Colegrove' 
when [Final Review Assigned To] in ('Ray Castillo') then 'Kellie Colegrove' 
when [Final Review Assigned To] in ('Jeff Joyner') then 'Madeline Caldwell' 
when [Final Review Assigned To] in ('LaTonia Marshall') then 'Madeline Caldwell' 
when [Final Review Assigned To] in ('Krystal Wallace') then 'Madeline Caldwell' 
when [Final Review Assigned To] in ('Brianne Hamilton') then 'Madeline Caldwell' 
when [Final Review Assigned To] in ('Shawn Clayborne-Greer') then 'Madeline Caldwell' 
when [Final Review Assigned To] in ('Sengvilay Heuangpaseuth') then 'Madeline Caldwell' 
when [Final Review Assigned To] in ('Heidi Molina') then 'Madeline Caldwell' 
when [Final Review Assigned To] in ('James McNew') then 'Madeline Caldwell' 
when [Final Review Assigned To] in ('Will Bribiescas') then 'Robert Gough' 
when [Final Review Assigned To] in ('Shanika Stanley') then 'Robert Gough' 
when [Final Review Assigned To] in ('Thomas Matthews') then 'Robert Gough' 
when [Final Review Assigned To] in ('Bryan Petty') then 'Robert Gough' 
when [Final Review Assigned To] in ('Sarah Negrete') then 'Robert Gough' 
when [Final Review Assigned To] in ('Sharon Ezeodogbo') then 'Robert Gough' 
when [Final Review Assigned To] in ('Bridgett Smith') then 'Robert Gough' 
when [Final Review Assigned To] in ('Amber Ledesma') then 'Robert Gough' 
when [Final Review Assigned To] in ('Carmina Dennis') then 'Robert Gough' 
when [Final Review Assigned To] in ('Sherry Alquino') then 'Robert Gough' 
when [Final Review Assigned To] in ('Marisol Trejo') then 'Shannon Harris-Mcbrayer' 
when [Final Review Assigned To] in ('Nikki Carrington') then 'Shannon Harris-Mcbrayer' 
when [Final Review Assigned To] in ('Shameka Easterling') then 'Shannon Harris-Mcbrayer' 
when [Final Review Assigned To] in ('Alexander Ledger') then 'Shannon Harris-Mcbrayer' 
when [Final Review Assigned To] in ('Norse Lockhart') then 'Shannon Harris-Mcbrayer' 
when [Final Review Assigned To] in ('Emiliya Ivanova') then 'Shannon Harris-Mcbrayer' 
when [Final Review Assigned To] in ('Margaret Cantu') then 'Shannon Harris-Mcbrayer' 
when [Final Review Assigned To] in ('Lance Lyons') then 'Shannon Harris-Mcbrayer' 
when [Final Review Assigned To] in ('Shalonda Rodgers') then 'Shannon Harris-Mcbrayer' 
when [Final Review Assigned To] in ('Eric Wallace') then 'Shannon Harris-Mcbrayer' 
when [Final Review Assigned To] in ('Garrett Carr') then 'Resubmission Team' 
when [Final Review Assigned To] in ('Kari Chadwell') then 'Pipeline Management' 
end as 'Manager'

,case
when [Final Review Assigned To] in ('Anindra Ghosh') then 'Offshore' 
when [Final Review Assigned To] in ('Aravindh V') then 'Offshore' 
when [Final Review Assigned To] in ('Kalpana Rajendran') then 'Offshore' 
when [Final Review Assigned To] in ('Ragavendhra Murugesan') then 'Offshore' 
when [Final Review Assigned To] in ('Rakesh Narasimhan Gnana Sekar') then 'Offshore' 
when [Final Review Assigned To] in ('Sai Pujitha J') then 'Offshore' 
when [Final Review Assigned To] in ('Sai Vignesh Premsai') then 'Offshore' 
when [Final Review Assigned To] in ('Suvanesan Sundar') then 'Offshore' 
when [Final Review Assigned To] in ('Theresa Selvam') then 'Offshore' 
when [Final Review Assigned To] in ('Nikita Jaiswal J') then 'Offshore' 
when [Final Review Assigned To] in ('Pradeep S') then 'Offshore' 
when [Final Review Assigned To] in ('Priyanka E') then 'Offshore' 
when [Final Review Assigned To] in ('Rajesh Kumar P') then 'Offshore' 
when [Final Review Assigned To] in ('Sathish Kumar P') then 'Offshore' 
when [Final Review Assigned To] in ('Sivachandran M') then 'Offshore' 
when [Final Review Assigned To] in ('Syed Abuthagir S') then 'Offshore' 
when [Final Review Assigned To] in ('Venkatachalam M S') then 'Offshore' 
when [Final Review Assigned To] in ('Gokula Shankar R') then 'Offshore' 
when [Final Review Assigned To] in ('Akshita S') then 'Offshore' 
when [Final Review Assigned To] in ('Aishwarya T') then 'Offshore' 
when [Final Review Assigned To] in ('Santhoshi S') then 'Offshore' 
when [Final Review Assigned To] in ('Sumithra K') then 'Offshore' 
when [Final Review Assigned To] in ('Vishal Dhanajeyan Anand') then 'Offshore' 
when [Final Review Assigned To] in ('Vanitha V') then 'Offshore' 
when [Final Review Assigned To] in ('Lakshmi Priya Dayalan') then 'Offshore' 
when [Final Review Assigned To] in ('Jyothi K') then 'Offshore' 
when [Final Review Assigned To] in ('Thenmozhi Vijayakumar') then 'Offshore' 
when [Final Review Assigned To] in ('Pradeepa B') then 'Offshore' 
when [Final Review Assigned To] in ('Celestina A') then 'Offshore' 
when [Final Review Assigned To] in ('Kalaivani K') then 'Offshore' 
when [Final Review Assigned To] in ('Kamaleshwaran B') then 'Offshore' 
when [Final Review Assigned To] in ('Ananthika Vijayan') then 'Offshore' 
when [Final Review Assigned To] in ('Kat Carson') then 'Arizona' 
when [Final Review Assigned To] in ('Brianna Escoto') then 'Arizona' 
when [Final Review Assigned To] in ('Patty Rodriguez') then 'Arizona' 
when [Final Review Assigned To] in ('Briana Morales') then 'Arizona' 
when [Final Review Assigned To] in ('Chaunie Horton') then 'Arizona' 
when [Final Review Assigned To] in ('James Patrone') then 'Arizona' 
when [Final Review Assigned To] in ('Bianca Stimson') then 'Arizona' 
when [Final Review Assigned To] in ('Delilah Smith') then 'Arizona' 
when [Final Review Assigned To] in ('Tyllisa Tripp') then 'Arizona' 
when [Final Review Assigned To] in ('Lori Wendt') then 'Arizona' 
when [Final Review Assigned To] in ('Catrina Wofford') then 'Texas' 
when [Final Review Assigned To] in ('Cynthia Spurlock') then 'Texas' 
when [Final Review Assigned To] in ('Veronica Garcia') then 'Texas' 
when [Final Review Assigned To] in ('Shawneequa Mitchell') then 'Texas' 
when [Final Review Assigned To] in ('Sonja Daniel') then 'Texas' 
when [Final Review Assigned To] in ('Shelia White') then 'Texas' 
when [Final Review Assigned To] in ('Marisela Martinez') then 'Texas' 
when [Final Review Assigned To] in ('Tonia Holloman') then 'Texas' 
when [Final Review Assigned To] in ('Ladarius Bryant') then 'Texas' 
when [Final Review Assigned To] in ('Nancy Shead') then 'Texas' 
when [Final Review Assigned To] in ('Brenda Codoner') then 'Arizona' 
when [Final Review Assigned To] in ('Andrika Lasker') then 'Arizona' 
when [Final Review Assigned To] in ('Monica Mullen') then 'Arizona' 
when [Final Review Assigned To] in ('Nacie Williams') then 'Arizona' 
when [Final Review Assigned To] in ('Jesse Eyman') then 'Arizona' 
when [Final Review Assigned To] in ('Veronica Riley') then 'Arizona' 
when [Final Review Assigned To] in ('Shawn Wright') then 'Arizona' 
when [Final Review Assigned To] in ('Lexie Beedle') then 'Arizona' 
when [Final Review Assigned To] in ('Michelle McRae') then 'Arizona' 
when [Final Review Assigned To] in ('Ray Castillo') then 'Arizona' 
when [Final Review Assigned To] in ('Jeff Joyner') then 'Texas' 
when [Final Review Assigned To] in ('LaTonia Marshall') then 'Texas' 
when [Final Review Assigned To] in ('Krystal Wallace') then 'Texas' 
when [Final Review Assigned To] in ('Brianne Hamilton') then 'Texas' 
when [Final Review Assigned To] in ('Shawn Clayborne-Greer') then 'Texas' 
when [Final Review Assigned To] in ('Sengvilay Heuangpaseuth') then 'Texas' 
when [Final Review Assigned To] in ('Heidi Molina') then 'Texas' 
when [Final Review Assigned To] in ('James McNew') then 'Texas' 
when [Final Review Assigned To] in ('Will Bribiescas') then 'Arizona' 
when [Final Review Assigned To] in ('Shanika Stanley') then 'Arizona' 
when [Final Review Assigned To] in ('Thomas Matthews') then 'Arizona' 
when [Final Review Assigned To] in ('Bryan Petty') then 'Arizona' 
when [Final Review Assigned To] in ('Sarah Negrete') then 'Arizona' 
when [Final Review Assigned To] in ('Sharon Ezeodogbo') then 'Arizona' 
when [Final Review Assigned To] in ('Bridgett Smith') then 'Arizona' 
when [Final Review Assigned To] in ('Amber Ledesma') then 'Arizona' 
when [Final Review Assigned To] in ('Carmina Dennis') then 'Arizona' 
when [Final Review Assigned To] in ('Sherry Alquino') then 'Arizona' 
when [Final Review Assigned To] in ('Marisol Trejo') then 'Texas' 
when [Final Review Assigned To] in ('Nikki Carrington') then 'Texas' 
when [Final Review Assigned To] in ('Shameka Easterling') then 'Texas' 
when [Final Review Assigned To] in ('Alexander Ledger') then 'Texas' 
when [Final Review Assigned To] in ('Norse Lockhart') then 'Texas' 
when [Final Review Assigned To] in ('Emiliya Ivanova') then 'Texas' 
when [Final Review Assigned To] in ('Margaret Cantu') then 'Texas' 
when [Final Review Assigned To] in ('Lance Lyons') then 'Texas' 
when [Final Review Assigned To] in ('Shalonda Rodgers') then 'Texas' 
when [Final Review Assigned To] in ('Eric Wallace') then 'Texas' 
when [Final Review Assigned To] in ('Garrett Carr') then 'Resubmission Team' 
when [Final Review Assigned To] in ('Kari Chadwell') then 'Pipeline Management' 
end as 'Site'
	
FROM 
 [SharepointData].[dbo].[HUDAssignLoans] L (nolock)
left join [SharepointData].[dbo].[HUDAssignFinalReview] F (nolock)
on f.[Loan Number] = L.[Loan Number]
left join [SharepointData].[dbo].[HUDAssignHUDStatus] S (nolock)
on s.[Loan Number] = f.[Loan Number]
left join [SharepointData].[dbo].[HUDAssignCurative] C (nolock)
on c.[Loan Number] = L.[Loan Number]
LEFT JOIN #EXCEPTION Z
ON L.[LOAN NUMBER] =  Z.[LOAN NUMBER]
LEFT JOIN #UPDATE U
ON L.[Loan Number]= U.[Loan Number]
 
WHERE
Z.RN=1 and
l.[Open Exceptions]=0 and
L.[Stage] in ('Final Review','HUD Status') and
l.[Loan Status] = 'Active' and
l.[Tag 2] IS NULL AND
l.[MCA %]>=97.5 and
l.[Incurable Flag] in ('0')and
--datediff(d,F.[Final Review Status Date],GETDATE()) >=3 AND
--datediff(d,S.[HUD Status Date],GETDATE()) >=3 AND
F.[Final Review Status] NOT IN ('Incurable','New File','Pending QC','Not Started') AND
S.[HUD Status] IN ('HUD Denied','Not Started') AND
(l.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
l.[Group] is null)


DROP TABLE #EXCEPTION, #UPDATE