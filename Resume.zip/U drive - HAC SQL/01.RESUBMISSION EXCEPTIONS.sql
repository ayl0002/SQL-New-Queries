SET NOCOUNT ON
SELECT
a.[loan number]
,CASE
	WHEN A.[Incurable Flag] NOT IN('0') OR A.[TAG 2] IS NOT NULL THEN 'INCURABLE/TAG2'
	WHEN A.[Loan Status] NOT IN ('ACTIVE') THEN 'INELIGIBLE LOAN STATUS'
	WHEN B.[Final Review Assigned To] IN ('KARI CHADWELL') THEN 'WORKABLE-CURATIVE'
	WHEN B.[Final Review Assigned To] IN ('JAMES WARREN') THEN 'HUD LOC ADVANCE'
	WHEN B.[Final Review Assigned To] IN ('CHELSEA DANIEL') THEN 'ACTIVE LOSS DRAFT'
	WHEN B.[Final Review Assigned To] IN ('SHASTA PATTON') THEN 'ARM INTEREST'
	WHEN B.[Final Review Assigned To] IN ('ROBERT GOUGH') THEN 'FPI'
	ELSE 'WORKABLE'
	END AS 'PIPELINE STATUS'
INTO #BASE
FROM SHAREPOINTDATA.DBO.HUDASSIGNLOANS A
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNFINALREVIEW B
ON A.[LOAN NUMBER]=B.[LOAN NUMBER]
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNHUDSTATUS C
ON A.[LOAN NUMBER]=C.[LOAN NUMBER]
WHERE C.[HUD Preliminary Title Denial Date] >= ('2018-01-01') AND B.[Loan Status] NOT IN ('Refer for FCL: Death')

SELECT
e.[Loan Number]
,E.[Work Group]
,e.[Exception ID]
,CONVERT(NVARCHAR(10),e.[Exception Request Date],101) AS 'Exception Request Date'
,e.[Exception Requestor]
,e.Document
,e.Issue
,e.[Exception Status]
,b.[Final Review Assigned To]
,R.Team
,a.[PIPELINE STATUS]

FROM #BASE a
left join SharepointData.dbo.HUDAssignExceptions e
on a.[Loan Number]=e.[Loan Number]
left join SharepointData.dbo.HUDAssignFinalReview b
on a.[Loan Number]=b.[Loan Number]
LEFT JOIN TACT_REV.hudAssign.tbl_CureTeamRosters R
ON B.[Final Review Assigned To]=R.Name

where  e.[Exception Status] not IN('Resolved','Not Valid','Cancelled','Closed with Vendor','Incurable')

DROP TABLE #BASE