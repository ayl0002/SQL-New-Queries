SET NOCOUNT ON
SELECT
A.[LOAN NUMBER]
,case
	when C.[HUD Status] IN ('Pkg Submitted to HUD','Not Started') then B.[Final Review Status]
	else C.[HUD Status]
	end as 'Status'
	
INTO #STATUS
FROM SHAREPOINTDATA.DBO.HUDASSIGNFINALREVIEW B
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNLOANS A
ON A.[LOAN NUMBER]=B.[LOAN NUMBER]
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNHUDSTATUS C
ON A.[LOAN NUMBER]=C.[LOAN NUMBER]

SELECT
[LoanNumber]
,MAX([DateSubmittedToHUD]) as 'Max Submission Date'
INTO #SUB
FROM SHAREPOINTDATA.dbo.HUDAssignDateSubmittedResubmittedtoHUD
GROUP BY [LoanNumber]

SELECT
A.[LOAN NUMBER]
,S.STATUS
,CONVERT(NVARCHAR(10),C.[HUD Preliminary Title Denial Date],101) AS 'DENIAL DATE'
,CASE
	when datediff(day,cast(C.[HUD Preliminary Title Denial Date] as date),getdate()) <= 0  then '0 to 15'
	when datediff(day,cast(C.[HUD Preliminary Title Denial Date] as date),getdate()) between 0 and 15 then '0 to 15'
	when datediff(day,cast(C.[HUD Preliminary Title Denial Date] as date),getdate()) between 16 and 30 then '16 to 30'
	when datediff(day,cast(C.[HUD Preliminary Title Denial Date] as date),getdate()) between 31 and 60 then '31 to 60'
	when datediff(day,cast(C.[HUD Preliminary Title Denial Date] as date),getdate()) between 61 and 90 then '61 to 90'
	when datediff(day,cast(C.[HUD Preliminary Title Denial Date] as date),getdate()) between 91 and 120 then '91 to 120'
	when datediff(day,cast(C.[HUD Preliminary Title Denial Date] as date),getdate()) >= 121 then '121+'
	END AS 'DENIAL AGING'
,C.[RESUBMIT TO HUD COUNT]
,case
	when convert(nvarchar(10),sub.[Max Submission Date],101)>= cast(C.[HUD Preliminary Title Denial Date] as date) then convert(nvarchar(10),sub.[Max Submission Date],101)
	else 'NULL'
	end as 'Resubmit Date'
,case

	when DATEDIFF(day,cast(C.[HUD Preliminary Title Denial Date] as date),convert(nvarchar(10),sub.[Max Submission Date],101)) between 0 and 3 then '0 to 3'
	when DATEDIFF(day,cast(C.[HUD Preliminary Title Denial Date] as date),convert(nvarchar(10),sub.[Max Submission Date],101)) between 4 and 15 then '4 to 15'
	when DATEDIFF(day,cast(C.[HUD Preliminary Title Denial Date] as date),convert(nvarchar(10),sub.[Max Submission Date],101)) between 16 and 30 then '16 to 30'
	when DATEDIFF(day,cast(C.[HUD Preliminary Title Denial Date] as date),convert(nvarchar(10),sub.[Max Submission Date],101)) between 31 and 60 then '31 to 60'
	when DATEDIFF(day,cast(C.[HUD Preliminary Title Denial Date] as date),convert(nvarchar(10),sub.[Max Submission Date],101)) between 61 and 90 then '61 to 90'
	when DATEDIFF(day,cast(C.[HUD Preliminary Title Denial Date] as date),convert(nvarchar(10),sub.[Max Submission Date],101)) between 91 and 120 then '91 to 120'
	when DATEDIFF(day,cast(C.[HUD Preliminary Title Denial Date] as date),convert(nvarchar(10),sub.[Max Submission Date],101)) >=121 then '121+'
	else 'NULL'
	end as 'Days to Conversion'
,B.[FINAL REVIEW ASSIGNED TO]
,T.[OPENCURATIVE]
,T.[OpenHACG]
,case
	when T.[Open Exceptions] = 0 then '0'
	when T.[Open Exceptions] = 1 then '1'
	when T.[Open Exceptions] = 2 then '2'
	when T.[Open Exceptions] >=3 then '3+'
	end as 'Open Exceptions'
	
,CASE
	WHEN b.[Final Review Status Date] > C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),b.[Final Review Status Date],101)
	WHEN b.[Final Review Status Date] < C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),C.[HUD Status Date],101)
	ELSE CONVERT(NVARCHAR(10),b.[Final Review Status Date],101) END AS 'Last Updated'
,CASE
	WHEN S.[Status] IN ('HUD APPROVED','HUD APPROVAL') THEN 'Approved'
	WHEN S.[Status] IN ('RESUBMITTED TO HUD','REBUTTAL TO HUD','PKG SUBMITTED TO HUD') THEN 'Pending @ HUD'
	WHEN S.[Status] IN ('HUD DENIED') THEN 'Pipeline'
	ELSE 'NULL'
	END AS 'RESUBMIT STATUS'
,CASE
	WHEN A.[Incurable Flag] NOT IN('0') OR A.[TAG 2] IS NOT NULL THEN 'INCURABLE/TAG2'
	WHEN A.[Loan Status] NOT IN ('ACTIVE') THEN 'INELIGIBLE LOAN STATUS'
	WHEN B.[Final Review Assigned To] IN ('KARI CHADWELL') THEN 'WORKABLE-CURATIVE'
	WHEN B.[Final Review Assigned To] IN ('JAMES WARREN') THEN 'HUD LOC ADVANCE'
	WHEN B.[Final Review Assigned To] IN ('CHELSEA DANIEL') THEN 'ACTIVE LOSS DRAFT'
	WHEN B.[Final Review Assigned To] IN ('SHASTA PATTON') THEN 'ARM INTEREST'
	WHEN B.[Final Review Assigned To] IN ('ROBERT GOUGH') THEN 'FPI'
	ELSE 'WORKABLE'
	END AS 'PIPELINE STATUS'
,R.Team


FROM SHAREPOINTDATA.DBO.HUDASSIGNLOANS A
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNFINALREVIEW B
ON A.[LOAN NUMBER]=B.[LOAN NUMBER]
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNHUDSTATUS C
ON A.[LOAN NUMBER]=C.[LOAN NUMBER]
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNLOANEXCEPTIONTOTALS T
ON A.[LOAN NUMBER]=T.[LOAN NUMBER]
LEFT JOIN #STATUS S
ON A.[LOAN NUMBER]=S.[LOAN NUMBER]
left join TACT_REV.hudAssign.tbl_CureTeamRosters R
ON B.[Final Review Assigned To]=R.Name
left join #SUB sub
on a.[Loan Number]=sub.LoanNumber

WHERE C.[HUD Preliminary Title Denial Date] >= ('2018-01-01') AND B.[Loan Status] NOT IN ('Refer for FCL: Death')

DROP TABLE #STATUS, #SUB