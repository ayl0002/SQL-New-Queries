SELECT
E.[Loan Number]
,a.[Loan Status]
,a.[Tag 2]
,a.[Incurable Flag]
,a.[Group]
,a.[MCA %]
 ,case 
	when a.[MCA %] between '97.50' and '99.99' then '97.5-99.99'
	when a.[MCA %] >= '100.00' then '100+'
	else '<97.49'
	end as 'MCA Bucket'
,T.[Open Exceptions]
,T.OpenCurative
,T.OpenHACG
,e.[Exception ID]
,E.[Document]
,E.[Issue]
,e.[Exception Assigned To]
,E.[EXCEPTION DESCRIPTION]
,CAST(E.[Exception Request Date] AS DATE) AS 'Exception Request Date'
,case
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) <= 0  then '0 to 15'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 0 and 15 then '0 to 15'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 16 and 30 then '16 to 30'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 31 and 60 then '31 to 60'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 61 and 90 then '61 to 90'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 91 and 120 then '91 to 120'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) >= 121 then '121+'
	end as 'Exception Request Aging'
,E.[Exception Status]
,CAST(E.[Exception Status Date] AS DATE) AS 'Exception Status Date'

,CASE
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) <= 0  then '0 to 15'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 0 and 15 then '0 to 15'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 16 and 30 then '16 to 30'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 31 and 60 then '31 to 60'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 61 and 90 then '61 to 90'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 91 and 120 then '91 to 120'
	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) >= 121 then '121+'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) <= 0  then '0 to 15'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 0 and 15 then '0 to 15'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 16 and 30 then '16 to 30'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 31 and 60 then '31 to 60'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 61 and 90 then '61 to 90'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 91 and 120 then '91 to 120'
	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) >= 121 then '121+'
	END AS 'Exception Status Aging'
,LU.[Exception Memo] AS 'Last Comment'


FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignLoans A
ON E.[Loan Number]=A.[Loan Number]
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignFinalReview B
ON E.[Loan Number]=B.[Loan Number]
left join SharepointData.dbo.HUDAssignHUDStatus c
on a.[Loan Number]=c.[Loan Number]
LEFT JOIN SharepointData.DBO.HUDAssignLoanExceptionTotals T
ON A.[Loan Number]=T.[Loan Number]
left join [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_HUD_RSTR] r
on c.[hud assigned to]=r.[AGNT_NM]
LEFT JOIN (SELECT M.[Exception ID], M.[Exception Memo]
			FROM SHAREPOINTDATA.[dbo].[HUDAssignExceptionActions] M
			LEFT JOIN (SELECT [EXCEPTION ID],MAX([Exception Status Date]) as 'Exception Status Date'
						FROM SharepointData.[dbo].[HUDAssignExceptionActions]
						GROUP BY [EXCEPTION ID])LU
			ON M.[Exception ID] =LU.[Exception ID] AND M.[Exception Status Date]=LU.[Exception Status Date])LU
on e.[Exception ID]=lu.[Exception ID]
WHERE E.[work group] IN ('LANDTRAN') AND 
E.[EXCEPTION STATUS] NOT IN ('RESOLVED','CANCELLED','NOT VALID','CLOSED','INCURABLE','closed with vendor') AND
A.[Tag 2] IS NULL AND
A.[Incurable Flag] IN ('0')AND
A.[Loan Status] IN ('active')--AND
--A.[MCA %]>=97.5 AND (a.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
--a.[Group] is null)
