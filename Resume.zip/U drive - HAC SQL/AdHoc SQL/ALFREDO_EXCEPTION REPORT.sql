--Temp Table--
SELECT
L.[Loan Number]
,A.[Exception ID]
,A.[Document]
,A.[Issue]
,A.[Exception Status]
,F.[Portfolio]
,A.[Exception Assigned To]
,f.[Final Review Status]
INTO #EXCEPTION
FROM [SharepointData].[dbo].[HUDAssignLoans] L (nolock)
join [SharepointData].[dbo].[HUDAssignFinalReview] F (nolock)
on f.[Loan Number] = L.[Loan Number]
JOIN SHAREPOINTDATA.dbo.HUDAssignExceptions A
ON A.[LOAN NUMBER] = L.[Loan Number]

--Adjust logic here--
Select * 
FROM #EXCEPTION 
WHERE --[Portfolio] IN ('WF') AND
[Exception Status] NOT IN ('Resolved','Not Valid') AND
[Exception Assigned To] IN ('Georgia Rowe')

DROP TABLE #EXCEPTION


