--Temp Table--
SELECT
L.[Loan Number]
,A.[Work Group]
,A.[Exception ID]
,A.[Document]
,A.[Issue]
,A.[Exception Request Date]
,A.[Exception Status]
,CONVERT(NVARCHAR(10),A.[Exception Status Date],101) AS 'Exception Status Date'
,a.[Exception Description]
,F.[Portfolio]
,A.[Exception Assigned To]
,F.[Final Review Assigned To]
INTO #EXCEPTION
FROM [SharepointData].[dbo].[HUDAssignLoans] L (nolock)
join [SharepointData].[dbo].[HUDAssignFinalReview] F (nolock)
on f.[Loan Number] = L.[Loan Number]
JOIN SHAREPOINTDATA.dbo.HUDAssignExceptions A
ON A.[LOAN NUMBER] = L.[Loan Number]
WHERE 
--[Work Group] in ('HACG') AND
[Document] in ('Current Occ Cert','Death Cert','Death Cert HACG','Flood Cert','Name Affidavit','Proof of Repair')AND
[Exception Status] NOT IN ('Resolved','Not Valid','Cancelled','Closed with Vendor','Incurable','FNMA Denied','NBS Denied') and
[Document] not in ('NSB Denied','FNMA Denied','HOLD','NSB Denied')

--Adjust logic here--
Select
A.[Loan Number]
,A.[Work Group]
,A.[Exception ID]
,A.[Document]
,A.[Issue]
,a.[Exception Description]
,CONVERT(NVARCHAR(10),A.[Exception Request Date],101) AS 'Exception Request Date'
,A.[Exception Status]
,CONVERT(NVARCHAR(10),A.[Exception Status Date],101) AS 'Exception Status Date'
,A.[Portfolio]
,A.[Exception Assigned To]
,A.[Final Review Assigned To]
,B.[Stage]
,b.[MCA %]
   ,case 
      when b.[MCA %] between '97.50' and '97.99' then '97.5-97.99'
      when b.[MCA %] between '98.00' and '98.50' then '98.00-98.50'
      when b.[MCA %] between '98.51' and '99.00' then '98.51-99.00'
      when b.[MCA %] between '99.01' and '99.50' then '99.01-99.50'
      when b.[MCA %] between '99.51' and '99.99' then '99.51-99.99'
      when b.[MCA %]between '99.51' and '99.99' then '99.5-99.99'
      when b.[MCA %] > '100.00' then '100+'
      else '<97.49'
      end as 'MCA Bucket'


FROM #EXCEPTION A
JOIN SharepointData.DBO.HUDAssignLoans B
ON A.[Loan Number]=B.[Loan Number]
JOIN SHAREPOINTDATA.DBO.HUDAssignFinalReview C
ON C.[Loan Number]=B.[Loan Number]

WHERE 
B.[Open Exceptions]>=1 AND
B.[Loan Status] IN ('Active')AND
b.[Tag 2] is null and
B.[MCA %] >=97.5 and
b.[Incurable Flag] not in ('y') AND
--A.[FINAL REVIEW ASSIGNED TO] IN ('Krystal Wallace','LaTonia Marshall','Marisol Trejo','Cynthia Spurlock','Shameka Easterling','Nikki Carrington')and
b.[Group] not in ('Grp 5 BofA GNMAs')

ORDER BY b.[MCA %] DESC

DROP TABLE #EXCEPTION
