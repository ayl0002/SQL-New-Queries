--Temp Table--
SELECT
L.[Loan Number]
,A.[Exception ID]
,A.[DocumentCode]
,A.[IssueCode]
,A.[Exception Status]
,F.[Portfolio]
INTO #EXCEPTION
FROM [SharepointData].[dbo].[HUDAssignLoans] L (nolock)
join [SharepointData].[dbo].[HUDAssignFinalReview] F (nolock)
on f.[Loan Number] = L.[Loan Number]
JOIN SHAREPOINTDATA.dbo.HUDAssignExceptions A
ON A.[LOAN NUMBER] = L.[Loan Number]

--Adjust logic here--
Select * 
FROM #EXCEPTION 
WHERE [Portfolio] IN ('WF') AND
[Exception Status] NOT IN ('Resolved','Not Valid') AND
[DocumentCode] IN ('14') AND
[IssueCode] IN ('02')

DROP TABLE #EXCEPTION


