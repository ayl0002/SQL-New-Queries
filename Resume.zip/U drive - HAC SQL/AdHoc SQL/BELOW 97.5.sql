SELECT A.[Loan Number]
,B.[Final Review Assigned To]
,A.[MCA %]
,A.[Loan Status]

FROM SHAREPOINTDATA.DBO.HUDAssignLoans A
LEFT JOIN SharepointData.DBO.HUDAssignFinalReview B
ON A.[Loan Number]=B.[Loan Number]

WHERE A.[MCA %] <= ('97.49') and 
(a.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
a.[Group] is null)AND
B.[Final Review Status] not in ('pkg submitted to hud')AND
A.[Loan Status] IN ('ACTIVE') AND
(B.[Final Review Assigned To] NOT IN ('JAMES WARREN','CHELSEA DANIEL','ROBERT GOUGH','KARI CHADWELL','SHASTA PATTON') OR B.[Final Review Assigned To] IS NOT NULL)