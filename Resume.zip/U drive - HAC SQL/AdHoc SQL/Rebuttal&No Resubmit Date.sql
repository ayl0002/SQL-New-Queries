SELECT
B.[Loan Number]
,b.[Loan Status]
,B.[Final Review Assigned To]
,a.[HUD Assigned To]
,A.[HUD Status]
,A.[Resubmitted to HUD]
,CONVERT(NVARCHAR(10),A.[Rebuttal Date],101) AS "Rebuttal Date"

FROM SharepointData.DBO.HUDAssignHUDStatus A
LEFT JOIN SharepointData.DBO.HUDAssignFinalReview B
ON A.[Loan Number] = B.[Loan Number]
left join SHAREPOINTDATA.dbo.HUDAssignLoans C
on c.[LOAN NUMBER]=B.[LOAN NUMBER]

WHERE
B.[Loan Status] in ('Active') AND
C.[Tag 2] IS NULL AND
A.[HUD Status] IN ('HUD DENIED') AND A.[Rebuttal Date] IS NOT NULL
AND A.[Resubmitted to HUD] IS NULL
AND C.[Open Exceptions]=0

