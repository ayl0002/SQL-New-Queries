SELECT
L.[Loan Number]
,A.[Work Group]
,A.[Exception ID]
,A.[Document]
,A.[Issue]
,A.[Exception Request Date]
,A.[Exception Status]
,CONVERT(NVARCHAR(10),A.[Exception Status Date],101) AS 'Exception Status Date'
,F.[Portfolio]
,A.[Exception Assigned To]
INTO #EXCEPTION
FROM [SharepointData].[dbo].[HUDAssignLoans] L (nolock)
join [SharepointData].[dbo].[HUDAssignFinalReview] F (nolock)
on f.[Loan Number] = L.[Loan Number]
JOIN SHAREPOINTDATA.dbo.HUDAssignExceptions A
ON A.[LOAN NUMBER] = L.[Loan Number]
WHERE 
--[Work Group] in ('HACG') AND
[Document] in ('Current Occ Cert') AND
[Exception Status] NOT IN ('Resolved','Not Valid','Cancelled','Closed with Vendor','Incurable','FNMA Denied','NBS Denied') 

Select
A.[Loan Number]
,A.[Work Group]
,A.[Exception ID]
,A.[Document]
,A.[Issue]
,CONVERT(NVARCHAR(10),A.[Exception Request Date],101) AS 'Exception Request Date'
,A.[Exception Status]
,CONVERT(NVARCHAR(10),A.[Exception Status Date],101) AS 'Exception Status Date'
,A.[Portfolio]
,A.[Exception Assigned To]
,B.[Stage]

FROM #EXCEPTION A
JOIN SharepointData.DBO.HUDAssignLoans B
ON A.[Loan Number]=B.[Loan Number]
WHERE 
B.[Open Exceptions]=1 AND
B.[Loan Status] IN ('Active')AND
B.[TAG 2] IS NULL AND
B.[MCA %] >97.49

DROP TABLE #EXCEPTION
