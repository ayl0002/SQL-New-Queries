select
a.[Loan Number]
,a.[Loan Status]
,a.[Pool Name]
,I.INTEREST_TYPE
,a.[Stage]
,a.[group]
,a.[Tag 2]
,a.[MCA %]
   ,case 
	when a.[MCA %] between '97.50' and '97.99' then '97.5-97.99'
	when a.[MCA %] between '98.00' and '98.50' then '98.00-98.50'
	when a.[MCA %] between '98.51' and '99.00' then '98.51-99.00'
	when a.[MCA %] between '99.01' and '99.50' then '99.01-99.50'
	when a.[MCA %] between '99.51' and '99.99' then '99.51-99.99'
	when a.[MCA %]between '99.51' and '99.99' then '99.5-99.99'
	when a.[MCA %] >= '100.00' then '100+'
	else '<97.49'
	end as 'MCA Bucket'
,case
	when a.[Stage] IN ('Final Review') then b.[Final Review Status]
	else c.[HUD status]
	end as 'Status'
,b.[final review assigned to]
,c.[HUD Assigned To]
,t.OpenCurative
,t.OpenHACG
,t.[Open Exceptions]
,r.[MGR_NM]
,r.[ST_LOC]
,fpi.[Exception ID]
,cast(fpi.[Exception Request Date] as date) as 'Exception Request Date'
,case
	when datediff(day,cast(fpi.[Exception Request Date] as date),getdate()) <= 30 then '<= 30'
	when datediff(day,cast(fpi.[Exception Request Date] as date),getdate()) between 31 and 60 then '31 to 60'
	when datediff(day,cast(fpi.[Exception Request Date] as date),getdate()) >=61 then '61+'
	end as 'Exception Aging'
,fpi.[exception status]

from SharepointData.dbo.HUDAssignLoans a
left join SharepointData.dbo.HUDAssignFinalReview b
on b.[Loan Number]=a.[Loan Number]
left join SharepointData.dbo.HUDAssignHUDStatus c
on c.[Loan Number]=a.[Loan Number]
left join sharepointdata.dbo.HUDAssignLoanExceptionTotals t
on a.[Loan Number]=t.[Loan Number]
left join [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_HUD_RSTR] r
on c.[HUD Assigned To]=r.[AGNT_NM]
LEFT JOIN [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] I
ON A.[LOAN NUMBER]=I.[LOAN_NBR]
left join (select [loan number],[exception id],[document],[issue],[exception request date],[exception status] from sharepointdata.dbo.hudassignexceptions where [document] in ('mic') and [exception status] not in ('closed','resolved','not valid','closed with vendor'))fpi
on a.[Loan Number]=fpi.[Loan Number]

where --a.[Stage] in ('Final Review','HUD status') and
a.[Tag 2] is null and
a.[Loan Status] in ('active') and
--a.[Open Exceptions] =0 and
--b.[final review assigned to] not in ('Kari Chadwell') and
a.[MCA %]>=97.5 and
a.[Incurable Flag] in ('0') and
(a.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
a.[Group] is null)and
c.[HUD Status] not in ('HUD Approved','Pkg Submitted to HUD','Resubmitted to HUD','Rebuttal to HUD') --and fpi.[Exception ID] is not null
