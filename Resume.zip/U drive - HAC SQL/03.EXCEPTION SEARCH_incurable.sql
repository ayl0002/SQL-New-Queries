SELECT
E.[Loan Number]
,a.[Loan Status]
,a.[Tag 2]
,a.[MCA %]
 ,case 
	when a.[MCA %] between '97.50' and '97.99' then '97.5-97.99'
	when a.[MCA %] between '98.00' and '99.99' then '98.00-99.99'
	when a.[MCA %] >= '100.00' then '100+'
	else '<97.49'
	end as 'MCA Bucket'
,e.[Work Group]
,e.[Exception ID]
,E.[Document]
,E.[Issue]
,CAST(E.[Exception Request Date] AS DATE) AS 'Exception Request Date'
,case
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) <= 0  then '0 to 15'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 0 and 15 then '0 to 15'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 16 and 30 then '16 to 30'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 31 and 60 then '31 to 60'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 61 and 90 then '61 to 90'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 91 and 120 then '91 to 120'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) >= 121 then '121+'
	end as 'Exception Request Aging'
,E.[Exception Status]
,CAST(E.[Exception Status Date] AS DATE) AS 'Exception Status Date'

--,CASE
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) <= 0  then '0 to 15'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 0 and 15 then '0 to 15'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 16 and 30 then '16 to 30'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 31 and 60 then '31 to 60'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 61 and 90 then '61 to 90'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 91 and 120 then '91 to 120'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) >= 121 then '121+'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) <= 0  then '0 to 15'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 0 and 15 then '0 to 15'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 16 and 30 then '16 to 30'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 31 and 60 then '31 to 60'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 61 and 90 then '61 to 90'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 91 and 120 then '91 to 120'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) >= 121 then '121+'
--	END AS 'Exception Status Aging'
,B.[Final Review Assigned To]
,T.[Open Exceptions]
,T.OpenCurative
,T.OpenHACG
,e.[Delinquent Amount]
,e.[Installment Frequency]
,e.[Due Date]
,e.[Entity or County Name]
,e.[Contact Info]
,e.[Fee to Obtain Info]
,e.[Fee Amount]
,r.[MGR_NM]
,r.[ST_LOC]

FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignLoans A
ON E.[Loan Number]=A.[Loan Number]
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignFinalReview B
ON E.[Loan Number]=B.[Loan Number]
LEFT JOIN SharepointData.DBO.HUDAssignLoanExceptionTotals T
ON A.[Loan Number]=T.[Loan Number]
left join [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_HUD_RSTR] r
on b.[final review assigned to]=r.[AGNT_NM]

WHERE --E.[DOCUMENT] IN ('tax bill') AND 
--[ISSUE] IN ('unpaid')AND
E.[EXCEPTION STATUS] IN ('incurable') --AND
--A.[Tag 2] IS NULL AND
--T.OpenCurative IN ('0')AND
--A.[Incurable Flag] IN ('0')AND
--A.[Loan Status] IN ('active')AND
--A.Stage IN ('FINAL REVIEW','HUD STATUS') AND A.[MCA %]>=97.5 AND (a.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
--a.[Group] is null)
and a.[Loan Status] not in ('Liquidated/Assigned to HU','Liquidated/Held for Sale','inactive','Paid Off','Refer for FCL: Death','Called Due: Death','Liquidated/3rd Party Sale')
