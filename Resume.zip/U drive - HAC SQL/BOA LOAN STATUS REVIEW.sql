SELECT
E.[Loan Number]
,a.[MCA %]
,a.[Tag 2]
,a.[Incurable Flag]
,a.[Loan Status]
,a.Stage
 ,case 
	when a.[MCA %] between '97.50' and '97.99' then '97.5-97.99'
	when a.[MCA %] between '98.00' and '99.99' then '98.00-99.99'
	when a.[MCA %] >= '100.00' then '100+'
	else '<97.49'
	end as 'MCA Bucket'
,E.[Document]
,E.[Issue]
,CAST(E.[Exception Request Date] AS DATE) AS 'Exception Request Date'
,case
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) <= 0  then '0 to 15'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 0 and 15 then '0 to 15'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 16 and 30 then '16 to 30'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 31 and 60 then '31 to 60'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 61 and 90 then '61 to 90'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) between 91 and 120 then '91 to 120'
	when datediff(day,cast(E.[Exception Request Date] as date),getdate()) >= 121 then '121+'
	end as 'Exception Request Aging'
,E.[Exception Status]
,CAST(E.[Exception Status Date] AS DATE) AS 'Exception Status Date'

--,CASE
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) <= 0  then '0 to 15'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 0 and 15 then '0 to 15'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 16 and 30 then '16 to 30'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 31 and 60 then '31 to 60'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 61 and 90 then '61 to 90'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) between 91 and 120 then '91 to 120'
--	when datediff(day,cast(ISNULL(E.[Exception Status Date],E.[Exception Request Date]) as date),getdate()) >= 121 then '121+'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) <= 0  then '0 to 15'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 0 and 15 then '0 to 15'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 16 and 30 then '16 to 30'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 31 and 60 then '31 to 60'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 61 and 90 then '61 to 90'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) between 91 and 120 then '91 to 120'
--	when datediff(day,cast(E.[Exception Status Date] as date),getdate()) >= 121 then '121+'
--	END AS 'Exception Status Aging'
,B.[Final Review Assigned To]
,T.[Open Exceptions]
,T.OpenCurative
,T.OpenHACG
,e.[Delinquent Amount]
,e.[Installment Frequency]
,e.[Due Date]
,e.[Entity or County Name]
,e.[Contact Info]
,e.[Fee to Obtain Info]
,e.[Fee Amount]

FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS E
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignLoans A
ON E.[Loan Number]=A.[Loan Number]
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignFinalReview B
ON E.[Loan Number]=B.[Loan Number]
LEFT JOIN SharepointData.DBO.HUDAssignLoanExceptionTotals T
ON A.[Loan Number]=T.[Loan Number]

--WHERE E.[DOCUMENT] IN ('HOA','TAX Bill') AND 
----[ISSUE] IN ('MISSING','MISSING CONTACT INFO')AND
--E.[EXCEPTION STATUS] NOT IN ('RESOLVED','CANCELLED','NOT VALID','CLOSED') AND
--A.[Tag 2] IS NULL AND
----T.OpenCurative IN ('0')AND
--A.[Incurable Flag] IN ('0')AND
--A.[Loan Status] IN ('ACTIVE')AND
--A.Stage IN ('FINAL REVIEW','HUD STATUS') AND A.[MCA %]>=97.5 AND (a.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
--a.[Group] is null)

where a.[Loan Number] in ('2435566',
'2435997',
'2436589',
'2436976',
'2436987',
'2437795',
'2438707',
'2438730',
'2439014',
'2439138',
'2439321',
'2439387',
'2439456',
'2441074',
'2441085',
'2441290',
'2441303',
'2442075',
'2443087',
'2443178',
'2446558',
'2446730',
'2446934',
'2450270',
'2451987',
'2452034',
'2452535',
'2456481',
'2458234',
'2459097',
'2462207',
'2482837',
'2483484',
'2438945',
'2440459',
'2437966',
'2480061')