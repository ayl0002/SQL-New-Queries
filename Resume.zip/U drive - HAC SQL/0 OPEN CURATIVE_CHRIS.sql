select base.*, [curative count]--, hex.[Exception Count]
into ##curebase2
from 
(select loan_nbr from [dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] where status_code = 0 and mca_percent >= 97.5
and pool_name not in ('BOAHOLDOVER','BOAWarehouse','NSBOA Warehouse','NSBOAWarehouse')) base
left join
(select distinct [Loan Number] as loan_nbr,[HUD Assigned Loans Tag2] as [TAG_2_VAL]
                           ,[Group] as [GRP_DESC]
                           ,[Incurable Flag] as [INCRBL_FLG_DESC]
                     from RM_DMART01..dm_hud_dim(nolock) 
                     where curr_ind='y'
              ) hld on cast(base.loan_nbr as varchar)=hld.loan_nbr 
              left join


(select smb.loan_nbr, count(*) as 'Curative Count' from 
(select base2.*, ste.[EXCP_STS_DESC] from
(select distinct loan_nbr, excp_id, max([EFF_DTTM]) as [Exc Eff Date] from [dbo].[HUD_ASGN_EXCP_EDW] where [WRK_GRP_DESC] in ('Curative', 'LandTran') and [EFF_DTTM] <= '2018-06-01'
group by loan_nbr, excp_id) base2
left join
(select loan_nbr, excp_id, eff_dttm, [EXCP_STS_DESC] from [dbo].[HUD_ASGN_EXCP_EDW]) ste on base2.loan_nbr=ste.loan_nbr and base2.excp_id=ste.excp_id and base2.[Exc Eff Date]=ste.[EFF_DTTM]  
where [EXCP_STS_DESC] not in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable')) smb
group by smb.loan_nbr) cur on cast(base.loan_nbr as varchar)=cur.loan_nbr


where ([INCRBL_FLG_DESC] is null or [INCRBL_FLG_DESC] = '0') and [TAG_2_VAL] is null and (grp_desc <> 'Group 5 BofA GNMAs' or grp_desc is null) and cur.[Curative Count] is not null


select  base.*, cur.[Cured Date], 
 agt.[Agent], cex.[Curative Count], sbm.[Last Submission]
from
(select * from ##curebase2) base
left join
--(select loan_nbr, cast(min([EFF_DTTM]) as date) as 'Curative Date' from [dbo].[HUD_ASGN_EXCP_EDW] where  
--[EFF_DTTM] > '2018-04-30' and [WRK_GRP_DESC] in ('LandTran', 'Curative') and [EXCP_STS_DESC] not in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable')
--group by loan_nbr) ro on base.loan_nbr=ro.loan_nbr
--left join
(select loan_nbr, fnl_rvw_asgn_to_nm as 'Agent' from [dbo].[HUD_ASGN_FNL_RVW] where curr_ind = 'Y') agt on cast(base.loan_nbr as varchar)=agt.loan_nbr
left join
(select loan_nbr, count(*) as 'Curative Count' from [dbo].[HUD_ASGN_EXCP_EDW] where [WRK_GRP_DESC] in ('LandTran', 'Curative') and [EXCP_STS_DESC] not in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable') and Curr_ind = 'Y'
group by loan_nbr) cex on cast(base.loan_nbr as varchar)=cex.loan_nbr
left join
(select loan_nbr, cast(max([EFF_DTTM]) as date) as 'Cured Date' from [dbo].[HUD_ASGN_EXCP_EDW] where [WRK_GRP_DESC] in ('LandTran', 'Curative') and [EXCP_STS_DESC] in ('Closed with Vendor', 'Resolved', 'Not Valid', 'Cancelled', 'Incurable') and Curr_ind = 'Y' and  cast(eff_dttm as date) > '2018-04-17'
group by loan_nbr) cur on cast(base.loan_nbr as varchar)=cur.loan_nbr
left join
(select loan_nbr, max([DT_SBMT_TO_HUD]) as 'Last Submission' from [dbo].[HUD_ASSGN_DT_SBMT_RESBMT] where [DT_SBMT_TO_HUD] > '2018-04-17' group by loan_nbr) sbm on cast(base.loan_nbr as varchar)=sbm.loan_nbr
