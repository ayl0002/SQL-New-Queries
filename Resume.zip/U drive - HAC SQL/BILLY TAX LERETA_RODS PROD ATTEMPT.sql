Select LOAN_ID, [AGNC_NM], [PWP_1_DT], [PWP_2_DT], [PWP_3_DT], [PWP_4_DT], [BUS_PROC_DT]
, ROW_NUMBER () OVER (PARTITION BY Loan_id ORDER BY [AGNC_NM] asc)RN 
into #tax1
from [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_LERETA_INBND] 


--ON A.[LOAN NUMBER]=TAX1.[LOAN_ID] AND TAX1.RN=1


Select LOAN_ID, [AGNC_NM], [PWP_1_DT], [PWP_2_DT], [PWP_3_DT], [PWP_4_DT], [BUS_PROC_DT]
, ROW_NUMBER () OVER (PARTITION BY Loan_id ORDER BY [AGNC_NM] asc)RN 
into #tax2
from [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_LERETA_INBND] 
--ON TAX1.[LOAN_ID]=TAX2.[LOAN_ID] AND TAX2.[AGNC_NM]<>tax1.[AGNC_NM] 


Select LOAN_ID, [AGNC_NM], [PWP_1_DT], [PWP_2_DT], [PWP_3_DT], [PWP_4_DT], [BUS_PROC_DT]
, ROW_NUMBER () OVER (PARTITION BY Loan_id ORDER BY [AGNC_NM] asc)RN 
into #tax3
from [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_LERETA_INBND] 
--ON TAX1.[LOAN_ID]=TAX3.[LOAN_ID] AND TAX2.[AGNC_NM]<>tax3.[AGNC_NM]

Select LOAN_ID, [AGNC_NM], [PWP_1_DT], [PWP_2_DT], [PWP_3_DT], [PWP_4_DT], [BUS_PROC_DT]
, ROW_NUMBER () OVER (PARTITION BY Loan_id ORDER BY [AGNC_NM] asc)RN 
into #tax4
from [VRSQLRODS\RODS_PROD].Reverse_DW.[dbo].[TP_LERETA_INBND] 


select
tax1.*
,tax2.*
,tax3.*
,tax4.*

from #tax1
left join #tax2
on #tax1.loan_id=#tax2.loan_id
left join #tax3
on #tax1.loan_id=#tax3.loan_id
left join #tax4
on #tax1.loan_id=#tax4.loan_id

where TAX2.[AGNC_NM]<>tax1.[AGNC_NM] and TAX2.[AGNC_NM]<>tax3.[AGNC_NM] and tax3.[AGNC_NM]<>tax4.[AGNC_NM]


drop table #tax1, #tax2, #tax3, #tax4
