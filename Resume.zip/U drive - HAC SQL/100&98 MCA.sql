Select
a.loan_nbr
,a.Max_claim_amount
,a.MAX_CLAIM_AMOUNT * 0.98 as '98%'
,LEFT(a.FHA_CASE_NBR,10) as 'fha'
,a.prop_state


from reverse_dw.dbo.RM_CHAMPION_MASTER_TBL_CURR_VW a

where loan_nbr in (2128984)