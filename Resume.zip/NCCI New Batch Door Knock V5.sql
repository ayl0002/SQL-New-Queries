
--EXCEPTION DATA--
SELECT
[LOAN NUMBER]
,[Exception ID]
,[Document]
,[ISSUE]
,[exception status]
,cast([Exception Request Date]as date) as 'Exception request date'

	--NON GC--
,CAST([Non GC Letter Sent 1]AS DATE) AS 'Non GC1'
,CAST([Non GC Letter Sent 2]AS DATE) AS 'Non GC2'
,CAST([Non GC Letter Sent 3]AS DATE) AS 'Non GC3'
,cast([Non GC Letter Document Returned] as date) as 'Non GC doc returned'

	--GC--
,CAST([Gift Card Letter Sent]AS DATE) AS 'GC1'
,CAST([Gift Card Letter Sent 2]AS DATE) AS 'GC2'
,CAST([Gift Card Letter Sent 3]AS DATE) AS 'GC3'
,cast([Document Returned] as date) as 'doc returned'
,CAST([Sent For Gift Card Processing]AS DATE) AS 'GC FULFILLMENT'

	--LEDGER--
,CAST([Ledger Letter Sent 1]AS DATE) AS 'Ledger1'
,CAST([Ledger Letter Sent 2]AS DATE) AS 'Ledger2'
,CAST([Ledger Letter Sent 3]AS DATE) AS 'Ledger3'
,cast([Ledger Letter Document Returned] as date) as 'Ledgerdoc returned'
,CAST([Ledger Sent for Gift Card Processing]AS DATE) AS 'Ledger GC FULFILLMENT'

,cast([sent to inspection vendor] as date) as 'Inspection Vendor'
,[Proof of Repairs Status]
INTO #GC
FROM SHAREPOINTDATA.[dbo].[HUDAssignExceptions]

WHERE 
[DOCUMENT] IN ('PROOF OF REPAIR','CURRENT OCC CERT','HOA') AND [Exception Status] NOT IN ('RESOLVED','NOT VALID','CANCELLED','INCURABLE','CLOSED WITH VENDOR')

ORDER BY [LOAN NUMBER], [DOCUMENT] DESC

--MAX DATE OCC--
SELECT #GC.*,(SELECT MAX(V) FROM (VALUES ([Ledger1]),([Ledger2]),([Ledger3]),([Inspection Vendor])) AS VALUE(V)) AS [MAX DK],(SELECT COUNT(V) FROM (VALUES ([Ledger1]),([Ledger2]),([Ledger3]),([Inspection Vendor])) AS VALUE (V)) AS [DK COUNT]
INTO #MAXGC
FROM #GC
WHERE [DOCUMENT] IN ('CURRENT OCC CERT')

--MAX DATE HOA--
INSERT INTO #MAXGC
SELECT #GC.*,(SELECT MAX(V) FROM (VALUES ([Ledgerdoc returned]),([Inspection Vendor])) AS VALUE(V)) AS [MAX DK],(SELECT COUNT(V) FROM (VALUES ([Ledgerdoc returned]),	([Inspection Vendor])) AS VALUE (V)) AS [DK COUNT]
FROM #GC
WHERE [DOCUMENT] IN ('HOA')

--MAX POR--
INSERT INTO #MAXGC
SELECT #GC.*,[Ledger1] AS 'MAX DK',(SELECT COUNT(V) FROM (VALUES ([Ledger1])) AS VALUE (V)) AS [DK COUNT]
FROM #GC
WHERE [DOCUMENT] IN ('Proof of Repair')



--ASSIGNABLE PORTFOLIO--
SELECT
A.[Loan Number]
,A.[MCA %]
,A.[LOAN STATUS]
,C.[HUD STATUS]

INTO #ASGN
FROM SharepointData.DBO.HUDASSIGNLOANS A
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNHUDSTATUS C
ON A.[LOAN NUMBER]=C.[LOAN NUMBER]
WHERE a.[Tag 2] is null and
a.[Loan Status] in ('active') and
a.[Incurable Flag] in ('0') and
(a.[Group] in ('Grp 1 NSM Balance Sheet','Grp 2 FNMA','Grp 3 GNMA excl BofA','Grp 4 Trust / Private exlc BofA','Grp 4 Trust / Private exlc BofA') or
a.[Group] is null)and
c.[HUD Status] not in ('HUD Approved','Pkg Submitted to HUD','Resubmitted to HUD','Rebuttal to HUD') 



--BUILD--
SELECT
GC.*
,A.[MCA %]
,A.[HUD Status]
,DATEDIFF(D,CAST([MAX DK] AS DATE),CAST(GETDATE() AS DATE)) AS 'TEST'
,CASE
	WHEN DATEDIFF(D,CAST([MAX DK] AS DATE),CAST(GETDATE() AS DATE)) <= 60 THEN NULL
	WHEN [DOCUMENT] IN ('CURRENT OCC CERT') AND A.[MCA %] >= 97 AND [Inspection Vendor] IS NULL THEN 'OCC DOOR KNOCK 1'
	WHEN [DOCUMENT] IN ('CURRENT OCC CERT')AND A.[MCA %] >= 97 AND [Inspection Vendor] IS NULL THEN 'OCC DOOR KNOCK 1'
	WHEN [DOCUMENT] IN ('CURRENT OCC CERT')AND A.[MCA %] >= 97 AND [Inspection Vendor] IS NOT NULL AND [Ledger1] IS NULL THEN 'OCC DOOR KNOCK 2'
	WHEN [DOCUMENT] IN ('CURRENT OCC CERT')AND A.[MCA %] >= 97 AND [Ledger1] IS NULL AND [Inspection Vendor] IS NULL AND [Ledger2] IS NULL  THEN 'OCC DOOR KNOCK 1'
	WHEN [DOCUMENT] IN ('CURRENT OCC CERT')AND A.[MCA %] >= 97 AND [Ledger1] IS NULL AND [Inspection Vendor] IS NOT NULL AND [Ledger2] IS NULL  THEN 'OCC DOOR KNOCK 2'
	WHEN [DOCUMENT] IN ('CURRENT OCC CERT')AND A.[MCA %] >= 97 AND [Ledger1] IS NOT NULL AND [Inspection Vendor] IS NOT NULL AND [Ledger2] IS NULL  THEN 'OCC DOOR KNOCK 3'
	WHEN A.[MCA %] >= 95 AND [DOCUMENT] IN ('PROOF OF REPAIR') AND ISNULL([Proof of Repairs Status],'No Status') NOT IN ('Report/Inspection complete repairs are not complete','Request Pending - Inspection Ordered') AND [Ledger1] IS NULL THEN 'POR DOOR KNOCK 1'
	WHEN A.[MCA %] >= 97.5 AND [DOCUMENT] IN ('PROOF OF REPAIR') AND ISNULL([Proof of Repairs Status],'No Status') NOT IN ('Report/Inspection complete repairs are not complete','Request Pending - Inspection Ordered') AND [Ledger1] IS NOT NULL AND [Ledger2] IS NULL THEN 'POR DOOR KNOCK 2'
	/*WHEN [DOCUMENT] IN ('HOA') AND [MCA %] >= 99.5 AND [Inspection Vendor] IS NULL THEN 'HOA DOOR KNOCK 1'
	WHEN [DOCUMENT] IN ('HOA') AND [MCA %] >= 99.5 AND [Inspection Vendor] IS NOT NULL AND [Ledgerdoc returned] IS NULL THEN 'HOA DOOR KNOCK 2'
	WHEN [Document] IN ('HOA') AND [ISSUE] IN ('MISSING CONTACT INFO','Missing') AND [MCA %] >= 97.5  AND [Inspection Vendor] IS NULL THEN 'HOA DOOR KNOCK 1'
	WHEN [DOCUMENT] IN ('HOA') AND [ISSUE] IN ('MISSING CONTACT INFO','Missing') AND [MCA %] >= 97.5 AND [Ledgerdoc returned] IS NULL THEN 'HOA DOOR KNOCK 2'*/
		END AS 'DOOR KNOCK FLAG'
INTO #BUILD
FROM #ASGN A
JOIN #MAXGC GC
ON GC.[LOAN NUMBER]=A.[LOAN NUMBER]

--SELECT * FROM #BUILD

--MANIFEST--
SELECT
LOAN_NBR
,[BORROWER_LAST_NAME]
,BORROWER_FIRST_NAME
,ISNULL(COBORROWER_LAST_NAME,' ') AS 'COBORROWER_LAST_NAME'
,ISNULL(COBORROWER_FIRST_NAME,' ') AS 'COBORROWER_FIRST_NAME'
,[PROP_ADDRESS]
,[PROP_CITY]
,[PROP_STATE]
,[PROP_ZIP_CODE]
,[DOOR KNOCK FLAG]
,[Exception ID],CAST(GETDATE() AS DATE) AS 'DATE',[MAX DK],[DK COUNT]
FROM [VRSQLRODS\RODS_PROD].REVERSE_DW.[dbo].[RM_CHAMPION_MASTER_TBL_CURR_VW] B
LEFT join #BUILD A
on B.loan_nbr=A.[loan number]

WHERE loan_nbr in (SELECT [LOAN NUMBER] FROM #BUILD WHERE [DOOR KNOCK FLAG] IS NOT NULL) AND [DOOR KNOCK FLAG] IS NOT NULL
order by [DOOR KNOCK FLAG] asc


DROP TABLE #GC, #ASGN, #BUILD, #MAXGC

