SELECT 
      replace(ltrim(replace([u03d8_nsm_loan_number],'0',' ')),' ','0') as 'loan number'
	  ,GETDATE() AS 'Refreshed'
	  ,CASE
	  WHEN [u3fc8_document_type_code] NOT IN ('REPAIRINS') THEN CAST(replace(ltrim(replace([u03d8_nsm_loan_number],'0',' ')),' ','0') AS NVARCHAR) + [u3fc8_document_type_code]
	  WHEN [u3fc8_document_type_code] IN ('REPAIRINS') THEN CAST(replace(ltrim(replace([u03d8_nsm_loan_number],'0',' ')),' ','0') AS NVARCHAR) + 'REPAIRS'
	  END AS 'Concat'
	  ,'{' + Cast(object_id as varchar(100)) + '}' as "GUID"
      ,CAST([create_date] as DATE) AS "Date Created"
      ,[u3fc8_document_type_code] as "Document Type Code"
	  --,B.GGUID
 	        
  FROM (SELECT * FROM [RMCEOS_NSM].[dbo].[DocVersion] nolock) AS A
  --LEFT JOIN #Invalid B 
  --ON CAST(A.object_id AS VARCHAR(100)) = CAST(B.GGuid AS Varchar(100))
  
  where 
  --u94d8_conversion_source = 'Lereta' and ua878_original_doc_name like '%POP%'  
 u94d8_conversion_source IN('MailRoomScanning','NSM INTERNAL','DATACAP MAIL','autoingest') and u3fc8_document_type_code in ('OCCERT',	'TRUST',	'HOADOCS','C.DEATH','REPAIRINS','REPAIRS') AND DateDIFF(Month,Cast([create_date] AS Date),CAST(Getdate() AS Date)) <= 10
 --AND B.GGUID IS NULL
 --AND Cast(object_id as varchar(100)) NOT IN ()
 ORDER BY [Document Type Code],[create_date] DESC