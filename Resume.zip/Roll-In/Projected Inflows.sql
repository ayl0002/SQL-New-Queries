select base.*, case when [Curative Count] is not null then 'Y' else 'N' end as 'In Curative', [FR Agent], case when [fp count] is not null then 'Y' else 'N' end as 'Has FPI'
, case when [ld count] is not null then 'Y' else 'N' end as 'Has Loss Draft',
case when [Tax count] is not null then 'Y' else 'N' end as 'Has Open Tax',
case when [OCC count] is not null then 'Y' else 'N' end as 'Has Open OCC',
case when [HOA count] is not null then 'Y' else 'N' end as 'Has Open HOA',
[Tax Close Date], [OCC Close Date], [HOA Close Date], [Hazard Close Date]
 from
(select * from dbo.billdashaccrual
where mca_percent < 97.5 and [next month mca] >= 97.5 and status_code = 0
and [Tag_2_Val] is null and [Incurable Flag] = '0' and ([group] is null or [Group] <> 'Grp 5 BofA GNMAs')) base
left join
(select [loan number], count(*) as [curative count] from sharepointdata.[dbo].[HUDAssignExceptions] where [Work Group] in ('Curative', 'LandTran')
and [Exception Status] not in ('Resolved', 'Incurable', 'Not Valid', 'Cancelled', 'Closed with Vendor', 'canceled','Resolved by ML')

group by [loan number]) ccur on cast(base.loan_nbr as varchar)=ccur.[loan number]
left join
(select [loan number], [Final Review Assigned To] as 'FR Agent' from sharepointdata.[dbo].[HUDAssignFinalReview]) fr on cast(base.loan_nbr as varchar)=fr.[loan number]
left join
(select [loan number], count(*) as 'FP Count' from sharepointdata.[dbo].[HUDAssignExceptions] where [issue] like '%forced placed%'
and [exception status] not in ('Resolved', 'Not Valid', 'Closed by Vendor', 'Incurable','Resolved by ML') group by [loan number]) fpi on cast(base.loan_nbr as varchar)=fpi.[loan number]
left join
(select [loan number], count(*) as 'LD Count' from sharepointdata.[dbo].[HUDAssignExceptions] where [document] like '%draft%'
and [exception status] not in ('Resolved', 'Not Valid', 'Closed by Vendor', 'Incurable','Resolved by ML') group by [loan number]) ld on cast(base.loan_nbr as varchar)=ld.[loan number]
left join
(select * from dbo.lastexceptionclose) lec on base.loan_nbr=lec.loan_nbr
left join
(select [loan number], count(*) as 'HOA Count' from sharepointdata.[dbo].[HUDAssignExceptions] where [document] = 'HOA'
and [exception status] not in ('Resolved', 'Not Valid', 'Closed with Vendor', 'Incurable','Resolved by ML') group by [loan number]) ohoa on cast(base.loan_nbr as varchar)=ohoa.[loan number]
left join
(select [loan number], count(*) as 'OCC Count' from sharepointdata.[dbo].[HUDAssignExceptions] where [document] = 'Current OCC Cert'
and [exception status] not in ('Resolved', 'Not Valid', 'Closed with Vendor', 'Incurable','Resolved by ML') group by [loan number]) cocc on cast(base.loan_nbr as varchar)=cocc.[loan number]
left join
(select [loan number], count(*) as 'Tax Count' from sharepointdata.[dbo].[HUDAssignExceptions] where [document] = 'Tax Bill'
and [exception status] not in ('Resolved', 'Not Valid', 'Closed with Vendor', 'Incurable','Resolved by ML') group by [loan number]) oet on cast(base.loan_nbr as varchar)=oet.[loan number]
order by [fp count] desc