SELECT distinct
A.[LOAN NUMBER]
,Cast(E.[Exception Request Date] AS Date) AS 'Exception Request Date'
,DATEDIFF(day,E.[Exception Request Date],Getdate()) AS 'Aged'
,a.[tag 2]
,a.[incurable flag]
,a.[loan status]
,a.Stage
,a.[mca %]
,CASE
	WHEN Cura_Check.[Document] is NULL THEN 'Send Letter'
	WHEN Cura_Check.[Document] is not NULL THEN 'Do Not Send Letter'
	ELSE 'Error'
	END AS 'Curative Check'
,CASE
	WHEN a.[MCA %] < 97.5 THEN '< 97.5'
	WHEN a.[MCA %] >= 97.5 THEN '>= 97.5'
	ELSE 'Error'
	END AS 'MCA Flag'
,e.[Exception ID]
,case
	when c.[hud status] in ('not started') then b.[final review assigned to]
	else c.[hud assigned to]
	end as 'Agent'
,r.mgr_nm
,r.st_loc
,t.[Open Exceptions]
,T.OpenCurative
,T.OpenHACG
,case
	when C.[HUD Status] IN ('Pkg Submitted to HUD','resubmitted to hud','rebuttal to hud') then 'Submitted'
	when c.[hud status] in ('hud approved') then 'HUD Approved'
	else 'Not Submitted'
	end as 'Status'

--,CASE
	--WHEN b.[Final Review Status Date] > C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),b.[Final Review Status Date],101)
	--WHEN b.[Final Review Status Date] < C.[HUD Status Date] THEN CONVERT(NVARCHAR(10),C.[HUD Status Date],101)
	--ELSE CONVERT(NVARCHAR(10),b.[Final Review Status Date],101) END AS 'Last Updated'

--,CASE
	--WHEN B.[Final Review Comment] > C.[HUD Status Comment] THEN B.[Final Review Comment]
	--WHEN B.[Final Review Comment] < C.[HUD Status Comment] THEN C.[HUD Status Comment]
	--ELSE B.[Final Review Comment]  END AS 'Last Comment'
,case
	when E.Document is null then 'No Issue'
	when e.[Document] is not null then e.[Document]
	end as 'Document'
,E.Issue
,E.[Exception Status]
,E.[Exception Status Updated By]
,Cast(E.[Exception Status Date] AS Date) AS 'Exception Status Date'

FROM SHAREPOINTDATA.dbo.HUDAssignLoans A
LEFT JOIN SHAREPOINTDATA.dbo.HUDAssignFinalReview B
ON a.[LOAN NUMBER]=b.[LOAN NUMBER]
LEFT JOIN (SELECT [LOAN NUMBER],[EXCEPTION ID],[DOCUMENT],[ISSUE], [EXCEPTION ASSIGNED TO],[EXCEPTION REQUEST DATE],[EXCEPTION STATUS],[EXCEPTION STATUS DATE],[Exception Status Updated By] FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS WHERE [Document] in ('Orig Appraisal') AND [EXCEPTION STATUS] NOT IN ('RESOLVED','CLOSED','NOT VALID','CLOSED WITH VENDOR')) E
ON A.[LOAN NUMBER]=E.[Loan Number]
LEFT JOIN SHAREPOINTDATA.DBO.HUDASSIGNHUDSTATUS C
ON a.[LOAN NUMBER]=c.[LOAN NUMBER]
LEFT JOIN SHAREPOINTDATA.DBO.HUDAssignLoanExceptionTotals T
on a.[Loan Number]=T.[Loan Number]
left join [VRSQLRODS\RODS_PROD].reverse_dw.[dbo].[TP_HUD_RSTR] r
on c.[HUD Assigned To]=r.agnt_nm
LEFT JOIN
(SELECT [LOAN NUMBER],[EXCEPTION ID],[DOCUMENT],[ISSUE],[EXCEPTION REQUEST DATE]
FROM SHAREPOINTDATA.DBO.HUDASSIGNEXCEPTIONS
 WHERE [Work Group] IN ('CURATIVE','LANDTRAN') AND [EXCEPTION STATUS] NOT IN ('CLOSED','RESOLVED','NOT VALID','INCURABLE','CLOSED WITH VENDOR') 
              AND [DOCUMENT] NOT IN ('TITLE POLICY','Assignments','Assignments-3rd Party','Assignments-POA','DEATH CERT','TRUST','orig appraisal')) Cura_Check
ON Cura_Check.[Loan Number] = A.[Loan Number]

WHERE A.[Loan Number] IN ('896109',
'1000749',
'891818',
'890320',
'890299',
'890156',
'889753',
'889591',
'889583',
'889553',
'889534',
'889460',
'889441',
'889379',
'889333',
'888733',
'888641',
'888614',
'888562',
'888493',
'888183',
'888111',
'888066',
'887944',
'887736',
'887331',
'1008094',
'887328',
'887289',
'887108',
'886840',
'886612',
'886536',
'886531',
'886451',
'879980',
'861753',
'859202',
'853124',
'851891',
'851826',
'851187',
'849974',
'1011154',
'849445',
'849097',
'848655',
'847832',
'846988',
'750118',
'743062',
'2831806',
'2828366',
'2808863',
'2798246',
'2788665',
'2731894',
'2728183',
'2724247',
'2719707',
'2717841',
'2716759',
'2709567',
'2705698',
'2686310',
'2685514',
'2278908',
'2274540',
'2131433',
'1046119',
'1046049',
'1026917',
'1023061',
'888156',
'887983',
'851779',
'756522',
'2657417',
'1060653',
'1041910',
'1041165',
'1036870')
ORDER BY 'MCA Flag' DESC,'Document','Open Exceptions'