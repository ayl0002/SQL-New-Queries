SELECT 
e.[Loan Number]
,E.[EXCEPTION ID]
,E.[Document]
,E.[Issue]
,e.[Exception Description]
,convert(nvarchar(10),E.[Exception Request Date],101) as 'Exception Request Date'
,M.[Exception Status]
,M.[Exception Status Updated By]
,convert(nvarchar(10),M.[Exception Status Date],101) as 'Exception Status Date'
,M.[Exception Memo]

FROM SHAREPOINTDATA.DBO.HUDAssignExceptionActions M
LEFT JOIN SharepointData.DBO.HUDAssignExceptions E
ON M.[EXCEPTION ID]=E.[EXCEPTION ID]

WHERE E.[Exception Status] NOT IN ('NOT VALID','INCURABLE') AND
e.[Loan Number] in ('2683306')

Order by m.[Exception Status Date]
